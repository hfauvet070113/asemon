set ASEMON_LOGGER_HOME=PUT_PATH_HERE
set JCONNECT_HOME=%ASEMON_LOGGER_HOME%\JCONNECT-16_0
set classpath=%ASEMON_LOGGER_HOME%\lib\jdom.jar;%ASEMON_LOGGER_HOME%\lib\xerces.jar;%ASEMON_LOGGER_HOME%\lib\java-getopt-1.0.9.jar;%JCONNECT_HOME%\classes\jconn4.jar;%JCONNECT_HOME%\classes\jTDS3.jar;


echo %classpath%

mkdir build
mkdir build\classes

cd src
rem javac -Xlint -d ../build/classes asemon_logger/*.java
javac -g -d ../build/classes asemon_logger/*.java

cd ..\build\classes
jar -cvf ../../dist/Asemon_logger_V3.jar asemon_logger/*
cd ..\..


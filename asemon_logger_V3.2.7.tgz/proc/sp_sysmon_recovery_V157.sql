/* This stored procedure produces a report containing a summary of
** checkpoint and housekeeper activity.
*/
create procedure sp_sysmon_recovery_V157
	@NumElapsedMs int,	/* for "per Elapsed second" calculations */
	@NumXacts int		/* for per transactions calculations */
as


/* --------- declare local variables --------- */
declare @tmp_int int		/* temp var for integer storage */
declare @tmp_int2 int		/* temp var for integer storage */
declare @tmp_total int		/* temp var for summing 'total #s' data */
declare @sum1line char(80)	/* string to delimit total lines without 
				** percent calc on printout */	
declare @sum2line char(80)	/* string to delimit total lines without 
				** percent calc on printout */	
declare @blankline char(1)	/* to print blank line */ 
declare @psign char(3)		/* hold a percent sign (%) for print out */
declare @na_str char(3)		/* holds 'n/a' for 'not applicable' strings */
declare @rptline char(80)	/* formatted stats line for print statement */
declare @section char(80)       /* string to delimit sections on printout */


/* --------- Setup Environment --------- */
set nocount on			/* disable row counts being sent to client */


select @sum1line   = "  -------------------------  ------------  ------------  ----------  ----------"
select @sum2line   = "  -------------------------  ------------  ------------  ----------"
select @blankline  = " "
select @psign      = " %%"		/* extra % symbol because '%' is escape char in print statement */
select @na_str     = "n/a"
select @section = "==============================================================================="


print @section
print @blankline


print "Recovery Management"
print "-------------------"
print @blankline


print "  Checkpoints                     per sec      per xact       count  %% of total"
print @sum1line


select @tmp_int = value
  from #tempmonitors
  where group_name = "access" and
		field_name = "normal_database_checkpoints"


select @tmp_int2 = value
  from #tempmonitors
  where group_name = "housekeeper" and
		field_name = "free_database_checkpoints"


select @tmp_total = @tmp_int + @tmp_int2


if @tmp_total = 0 
 begin
	select @rptline = "  Total Checkpoints                   0.0           0.0           0       n/a"
  	print @rptline
 end
else
  begin
	select @rptline = "    # of Normal Checkpoints" + space(2) +
			str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
			space(2) +
			str(@tmp_int / convert(real, @NumXacts),12,1) +
			space(2) +
			str(@tmp_int, 10) + space(5) +
			str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
	print @rptline


	select @rptline = "    # of Free Checkpoints" + space(4) +
			str(@tmp_int2 / (@NumElapsedMs / 1000.0),12,1) + 
			space(2) +
			str(@tmp_int2 / convert(real, @NumXacts),12,1) + 
			space(2) +
			str(@tmp_int2, 10) + space(5) +
			str(100.0 * @tmp_int2 / @tmp_total,5,1) + @psign
	print @rptline


	print @sum2line
	select @rptline = "  Total Checkpoints" + space(10) +
			str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) + 
			space(2) +
			str(@tmp_total / convert(real, @NumXacts),12,1) + 
			space(2) +
			str(@tmp_total, 10) 
	print @rptline
	print @blankline
	
	select @tmp_total = value
	  from #tempmonitors
	  where group_name = "access" and
			field_name = "time_todo_normal_checkpoints"




	if @tmp_int != 0	/* any normal checkpoints ? */
	  begin
		select @rptline = "  Avg Time per Normal Chkpt" + space(2) +
				str(convert(real,@tmp_total) / @tmp_int,12,5) +
				" seconds"
		print @rptline
	  end


	select @tmp_total = value
	  from #tempmonitors
	  where group_name = "housekeeper" and
			field_name = "time_todo_free_checkpoints"




	if @tmp_int2 != 0	/* any housekeeper checkpoints ? */
	  begin
		select @rptline = "  Avg Time per Free Chkpt" + space(4) +
			str(convert(real,@tmp_total) / @tmp_int2,12,5) + 
			" seconds"
		print @rptline
	  end
  end


print @blankline
return 0

create table #muxthreadsinfo (  
        InstanceID int,         
        enginename  varchar(15),                                                                        
        engineid int,           
        threadid int,           
        tpname varchar(80))                                                          
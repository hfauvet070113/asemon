/* This stored procedure produces a report containing a summary of
** of locking characteristics including lock requests and waits.
*/

create procedure sp_sysmon_locks_V161

        @NumElapsedMs int,      /* for "per Elapsed second" calculations */
        @NumXacts int,          /* for per transactions calculations */
        @Reco char(1),
        @NumEngines smallint     = 1 /* number of engines online */
as

/* --------- declare local variables --------- */

declare @TotalLocks bigint      /* Count Total Number of Locks */
declare @tmp_int bigint         /* temp var for integer storage */
declare @tmp_int2 bigint        /* temp var for integer storage */
declare @tmp_access bigint      /* temp var for integer storage */
declare @tmp_xls bigint         /* temp var for integer storage */
declare @tmp_total bigint       /* temp var for summing 'total #s' data */
declare @sum1line char(80)      /* string to delimit total lines without
                                ** percent calc on printout */
declare @sum2line char(67)      /* string to delimit total lines with
                                ** percent calc on printout */
declare @blankline char(1)      /* to print blank line */
declare @psign char(3)          /* hold a percent sign (%) for print out */
declare @na_str char(3)         /* holds 'n/a' for 'not applicable' strings */
declare @rptline char(80)       /* formatted stats line for print statement */
declare @section char(80)       /* string to delimit sections on printout */

/* ------------- Variables for Suggested Recomendations ------------*/
declare @recotxt char(80)
declare @recoline char(80)
declare @maxengfreelocks int    /* Value for max engine freelocks */
declare @max_online_engine int  /* Max online engine count */
declare @freelock_tr_blksize char(5) /* Freelock transfer block size */
declare @deadlocks int           /* Deadlock count */
declare @deadlock_search int    /* Deadlock Search count */
declare @tempmaxengfreelocks char(5) /* Temp maxengfreelocks for convert */
declare @curfreelocks int
declare @tot_movefreelock_toengine int
declare @tot_movefreelock_toserver int
declare @newval char(5)
declare @tmp_num_lock_op int
declare @reco_hdr_prn bit
declare @reco_lastpg_wait_percent real
declare @reco_avg_chain_length_pagerow real
declare @spinlock_contention float
declare @reco_tabspin_contention float
declare @reco_addrspin_contention float
declare @reco_fgspin_contention float
declare @totalrequested bigint
declare @totalretained bigint
declare @totaldiskreads bigint
declare @totaldeadlocks bigint
declare @totalwaits bigint
declare @totaltransfers bigint
declare @totallockmgrcalls bigint
declare @NumElapsedSec real
declare @totalreqs bigint
declare @totallocalmaster bigint
declare @totalgrants bigint
declare @totalbastreqs bigint


/* --------- Setup Environment --------- */
set nocount on                  /* disable row counts being sent to client */

select @sum1line   = "  -------------------------  ------------  ------------  ----------  ----------"
select @sum2line   = "  -------------------------  ------------  ------------  ----------"
select @blankline  = " "
select @psign      = " %%"              /* extra % symbol because '%' is escape char in print statement */
select @na_str     = "n/a"
select @recotxt =   "  Tuning Recommendations for Lock Management"
select @recoline="  ------------------------------------------"
select @section = "==============================================================================="

print @section
print @blankline

print "Lock Management"
print "---------------"
print @blankline
print "  Lock Summary                    per sec      per xact       count  %% of total"
print @sum1line

select @NumElapsedSec = @NumElapsedMs / 1000.0

select @TotalLocks = SUM(convert(bigint, value))
  from #tempmonitors
  where group_name = "lock" and
                (field_name like "granted%" or field_name like "waited%")

select @totalretained = SUM(convert(bigint, value))
  from #tempmonitors
  where group_name = "lock" and
                field_name like "clm_logical_retained"


select @rptline = "  Total Lock Requests" + space(8) +
                        str(@TotalLocks / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@TotalLocks / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@TotalLocks,11) + space(7) +
                        @na_str
print @rptline

if @TotalLocks != 0     /* Avoid Divide by Zero Errors after printout */
  begin
        select @tmp_int = SUM(convert(bigint, value))
          from #tempmonitors
          where group_name = "lock" and
                        field_name like "%waited%"

        select @rptline = "  Avg Lock Contention" + space(8) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @TotalLocks,5,1) +
                                @psign
        print @rptline
        select @rptline = "  Cluster Locks Retained" + space(5) +
                                str(@totalretained / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@totalretained / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@totalretained, 11) + space(5) +
                                str(100.0 * @totalretained / @TotalLocks,5,1) +
                                @psign
        print @rptline

        select @tmp_int = SUM(convert(bigint, value))
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "deadlocks"

        select @rptline = "  Deadlock Percentage" + space(8) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @TotalLocks,5,1) +
                                @psign
        print @rptline

        print @blankline

        /*
        ** Get spinlock related counters for hashtable spinlock contentions
        */
        select  P.field_name as name,
                P.value as grabs,
                W.value as waits,
                S.value as spins
        into #foo
        from #tempmonitors P, #tempmonitors W, #tempmonitors S
        where
                        P.group_name = "spinlock_p"
                and W.group_name = "spinlock_w"
                and S.group_name = "spinlock_s"
                and P.field_id = W.field_id
                and P.field_id = S.field_id
                and P.field_name in ( 'fglockspins', 'tablockspins', 'addrlockspins')

        print "  Lock Detail                     per sec      per xact       count  %% of total"
        print @sum1line
        print @blankline

        print "  Table & Partition Lock Hashtable"
        -- asemon_report : added "top 1" (for IQ)
        select top 1 @tmp_int = value
          from #tempmonitors
          where group_name = "lock" and
                        (field_name = "hashtab_lookups_table_lock" or
                                field_name = "hashtab_lookups_partition_lock")

        select @rptline = "    Lookups" + space(18) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(7) +
                                @na_str
        print @rptline

        /* Avoid divide by 0 error */
        if ( @tmp_int > 0 )
        begin
            select @tmp_int2 = value
              from #tempmonitors
              where group_name = "lock" and
                            (field_name = "hashtab_overflow_table_lock" or
                                field_name = "hashtab_overflow_partition_lock")

            select @rptline = "    Avg Chain Length" + space(18) +
                                    @na_str + space(11) +
                                    @na_str + space(2) +
                                    str(convert(real, @tmp_int2) / @tmp_int, 10, 5) +
                                    space(7) + @na_str
            print @rptline
        end

        select @spinlock_contention = isnull(100.0*(sum(convert(float,waits))/sum(convert(float,grabs))), 0)
          from #foo
         where name = 'tablockspins'
           and grabs > 0

        select @rptline = "    Spinlock Contention" + space(15) +
                                                @na_str + space(11) +
                                                @na_str + space(9) +
                                                @na_str + space(5) +
                                                str( @spinlock_contention,5,1)
                                                        + @psign
                        , @reco_tabspin_contention = @spinlock_contention
        print @rptline
        print @blankline

        print "  Exclusive Table"

        select @tmp_total = SUM(convert(bigint, value))
          from #tempmonitors
          where group_name = "lock" and
                        (field_name like "granted%_EX_TAB" or
                                field_name like "waited%_EX_TAB")

        if @tmp_total = 0               /* Avoid Divide by Zero Errors */
        begin
                select @rptline = "    Total EX-Table Requests           0.0           0.0           0       n/a"
                print @rptline
        end
        else
          begin
                select @tmp_int = SUM(convert(bigint, value))
                  from #tempmonitors
                  where group_name = "lock" and
                                field_name like "granted%_EX_TAB"

                select @rptline = "    Granted" + space(18) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
                print @rptline

                select @tmp_int = SUM(convert(bigint, value))
                  from #tempmonitors
                  where group_name = "lock" and
                                field_name like "waited%_EX_TAB"

                select @rptline = "    Waited" + space(19) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
                print @rptline
                print @sum1line
                select @rptline = "  Total EX-Table Requests" + space(4) +
                        str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_total / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_total,11) + space(5) +
                        str(100.0 * @tmp_total / @TotalLocks,5,1) +
                        @psign
                print @rptline
        end
        print @blankline

        print "  Shared Table"

        select @tmp_total = SUM(convert(bigint, value))
          from #tempmonitors
          where group_name = "lock" and
          (field_name like "granted%_SH_TAB" or field_name like "waited%_SH_TAB")

        if @tmp_total = 0               /* Avoid Divide by Zero Errors */
        begin
                select @rptline = "    Total SH-Table Requests           0.0           0.0           0       n/a"
                print @rptline
        end
        else
          begin
                select @tmp_int = SUM(convert(bigint, value))
                  from #tempmonitors
                  where group_name = "lock" and
                                field_name like "granted%_SH_TAB"

                select @rptline = "    Granted" + space(18) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
                print @rptline

                select @tmp_int = SUM(convert(bigint, value))
                  from #tempmonitors
                  where group_name = "lock" and
                                field_name like "waited%_SH_TAB"

                select @rptline = "    Waited" + space(19) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
                print @rptline

                print @sum1line
                select @rptline = "  Total SH-Table Requests" + space(4) +
                        str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_total / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_total,11) + space(5) +
                        str(100.0 * @tmp_total / @TotalLocks,5,1) +
                        @psign
                print @rptline
          end
        print @blankline

        print "  Exclusive Intent"

        select @tmp_total = SUM(convert(bigint, value))
          from #tempmonitors
          where group_name = "lock" and
                        (field_name like "granted%_EX_INT" or
                                field_name like "waited%_EX_INT")

        if @tmp_total = 0               /* Avoid Divide by Zero Errors */
        begin
                select @rptline = "    Total EX-Intent Requests          0.0           0.0           0       n/a"
                print @rptline
        end
        else
          begin
                select @tmp_int = SUM(convert(bigint, value))
                  from #tempmonitors
                  where group_name = "lock" and
                                field_name like "granted%_EX_INT"

                select @rptline = "    Granted" + space(18) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
                print @rptline

                select @tmp_int = SUM(convert(bigint, value))
                  from #tempmonitors
                  where group_name = "lock" and
                                field_name like "waited%_EX_INT"

                select @rptline = "    Waited" + space(19) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
                print @rptline

                print @sum1line
                select @rptline = "  Total EX-Intent Requests" + space(3) +
                        str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_total / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_total,11) + space(5) +
                        str(100.0 * @tmp_total / @TotalLocks,5,1) +
                        @psign
                print @rptline
          end
        print @blankline

        print "  Shared Intent"

        select @tmp_total = SUM(convert(bigint, value))
          from #tempmonitors
          where group_name = "lock" and
                        (field_name like "granted%_SH_INT" or
                                field_name like "waited%_SH_INT")

        if @tmp_total = 0               /* Avoid Divide by Zero Errors */
        begin
                select @rptline = "    Total SH-Intent Requests          0.0           0.0           0       n/a"
                print @rptline
        end
        else
          begin
                select @tmp_int = SUM(convert(bigint, value))
                  from #tempmonitors
                  where group_name = "lock" and
                                field_name like "granted%_SH_INT"

                select @rptline = "    Granted" + space(18) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
                print @rptline

                select @tmp_int = SUM(convert(bigint, value))
                  from #tempmonitors
                  where group_name = "lock" and
                                field_name like "waited%_SH_INT"

                select @rptline = "    Waited" + space(19) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
                print @rptline
                print @sum1line

                select @rptline = "  Total SH-Intent Requests" + space(3) +
                        str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_total / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_total,11) + space(5) +
                        str(100.0 * @tmp_total / @TotalLocks,5,1) +
                        @psign
                print @rptline
        end
        print @blankline

        print "  Exclusive Partition"

        select @tmp_total = SUM(convert(bigint, value))
          from #tempmonitors
          where group_name = "lock" and
                        (field_name like "granted%_EX_PTN" or
                                field_name like "waited%_EX_PTN")

        if @tmp_total = 0               /* Avoid Divide by Zero Errors */
        begin
                select @rptline = "    Total EX-Partition Reqs           0.0           0.0           0       n/a"
                print @rptline
        end
        else
          begin
                select @tmp_int = SUM(convert(bigint, value))
                  from #tempmonitors
                  where group_name = "lock" and
                                field_name like "granted%_EX_PTN"

                select @rptline = "    Granted" + space(18) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
                print @rptline

                select @tmp_int = SUM(convert(bigint, value))
                  from #tempmonitors
                  where group_name = "lock" and
                                field_name like "waited%_EX_PTN"

                select @rptline = "    Waited" + space(19) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
                print @rptline
                print @sum1line
                select @rptline = "  Total EX-Partition Reqs" + space(4) +
                        str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_total / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_total,11) + space(5) +
                        str(100.0 * @tmp_total / @TotalLocks,5,1) +
                        @psign
                print @rptline
        end
        print @blankline

        print "  Shared Partition"

        select @tmp_total = SUM(convert(bigint, value))
          from #tempmonitors
          where group_name = "lock" and
          (field_name like "granted%_SH_PTN" or field_name like "waited%_SH_PTN")

        if @tmp_total = 0               /* Avoid Divide by Zero Errors */
        begin
                select @rptline = "    Total SH-Partition Reqs           0.0           0.0           0       n/a"
                print @rptline
        end
        else
          begin
                select @tmp_int = SUM(convert(bigint, value))
                  from #tempmonitors
                  where group_name = "lock" and
                                field_name like "granted%_SH_PTN"

                select @rptline = "    Granted" + space(18) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
                print @rptline

                select @tmp_int = SUM(convert(bigint, value))
                  from #tempmonitors
                  where group_name = "lock" and
                                field_name like "waited%_SH_PTN"

                select @rptline = "    Waited" + space(19) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
                print @rptline

                print @sum1line
                select @rptline = "  Total SH-Partition Reqs" + space(4) +
                        str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_total / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_total,11) + space(5) +
                        str(100.0 * @tmp_total / @TotalLocks,5,1) +
                        @psign
                print @rptline
          end
        print @blankline

        print "  Exclusive Partition Intent"

        select @tmp_total = SUM(convert(bigint, value))
          from #tempmonitors
          where group_name = "lock" and
                        (field_name like "granted%_EX_INT_PTN" or
                                field_name like "waited%_EX_INT_PTN")

        if @tmp_total = 0               /* Avoid Divide by Zero Errors */
        begin
                select @rptline = "    Total EX-Ptn_Intent Reqs          0.0           0.0           0       n/a"
                print @rptline
        end
        else
          begin
                select @tmp_int = SUM(convert(bigint, value))
                  from #tempmonitors
                  where group_name = "lock" and
                                field_name like "granted%_EX_INT_PTN"

                select @rptline = "    Granted" + space(18) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
                print @rptline

                select @tmp_int = SUM(convert(bigint, value))
                  from #tempmonitors
                  where group_name = "lock" and
                                field_name like "waited%_EX_INT_PTN"

                select @rptline = "    Waited" + space(19) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
                print @rptline

                print @sum1line
                select @rptline = "  Total EX-Ptn_Intent Reqs" + space(3) +
                        str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_total / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_total,11) + space(5) +
                        str(100.0 * @tmp_total / @TotalLocks,5,1) +
                        @psign
                print @rptline
          end
        print @blankline

        print "  Shared Partition Intent"

        select @tmp_total = SUM(convert(bigint, value))
          from #tempmonitors
          where group_name = "lock" and
                        (field_name like "granted%_SH_INT_PTN" or
                                field_name like "waited%_SH_INT_PTN")

        if @tmp_total = 0               /* Avoid Divide by Zero Errors */
        begin
                select @rptline = "    Total SH-Ptn_Intent Reqs          0.0           0.0           0       n/a"
                print @rptline
        end
        else
          begin
                select @tmp_int = SUM(convert(bigint, value))
                  from #tempmonitors
                  where group_name = "lock" and
                                field_name like "granted%_SH_INT_PTN"

                select @rptline = "    Granted" + space(18) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
                print @rptline

                select @tmp_int = SUM(convert(bigint, value))
                  from #tempmonitors
                  where group_name = "lock" and
                                field_name like "waited%_SH_INT_PTN"

                select @rptline = "    Waited" + space(19) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
                print @rptline
                print @sum1line

                select @rptline = "  Total SH-Ptn_Intent Reqs" + space(3) +
                        str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_total / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_total,11) + space(5) +
                        str(100.0 * @tmp_total / @TotalLocks,5,1) +
                        @psign
                print @rptline
        end
        print @blankline

        print "  Exclusive Covering Partition Intent"

        select @tmp_total = SUM(convert(bigint, value))
          from #tempmonitors
          where group_name = "lock" and
                        (field_name like "granted%_EX_CPTN" or
                                field_name like "waited%_EX_CPTN")

        if @tmp_total = 0               /* Avoid Divide by Zero Errors */
        begin
                select @rptline = "    Total EX-CPtn_Intent Reqs         0.0           0.0           0       n/a"
                print @rptline
        end
        else
          begin
                select @tmp_int = SUM(convert(bigint, value))
                  from #tempmonitors
                  where group_name = "lock" and
                                field_name like "granted%_EX_CPTN"

                select @rptline = "    Granted" + space(18) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
                print @rptline

                select @tmp_int = SUM(convert(bigint, value))
                  from #tempmonitors
                  where group_name = "lock" and
                                field_name like "waited%_EX_CPTN"

                select @rptline = "    Waited" + space(19) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
                print @rptline

                print @sum1line
                select @rptline = "  Total EX-CPtn_Intent Reqs" + space(2) +
                        str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_total / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_total,11) + space(5) +
                        str(100.0 * @tmp_total / @TotalLocks,5,1) +
                        @psign
                print @rptline
          end
        print @blankline

        print "  Shared Covering Partition Intent"

        select @tmp_total = SUM(convert(bigint, value))
          from #tempmonitors
          where group_name = "lock" and
                        (field_name like "granted%_SH_CPTN" or
                                field_name like "waited%_SH_CPTN")

        if @tmp_total = 0               /* Avoid Divide by Zero Errors */
        begin
                select @rptline = "    Total SH-CPtn_Intent Reqs         0.0           0.0           0       n/a"
                print @rptline
        end
        else
          begin
                select @tmp_int = SUM(convert(bigint, value))
                  from #tempmonitors
                  where group_name = "lock" and
                                field_name like "granted%_SH_CPTN"

                select @rptline = "    Granted" + space(18) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
                print @rptline

                select @tmp_int = SUM(convert(bigint, value))
                  from #tempmonitors
                  where group_name = "lock" and
                                field_name like "waited%_SH_CPTN"

                select @rptline = "    Waited" + space(19) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
                print @rptline
                print @sum1line

                select @rptline = "  Total SH-CPtn_Intent Reqs" + space(2) +
                        str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_total / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_total,11) + space(5) +
                        str(100.0 * @tmp_total / @TotalLocks,5,1) +
                        @psign
                print @rptline
        end
        print @blankline

        print "  Page & Row Lock HashTable"
        select @tmp_int = value
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "hashtab_lookups_pagerow_lock"

        select @rptline = "    Lookups" + space(18) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(7) + @na_str
        print @rptline

        /* Avoid divide by 0 error */
        if ( @tmp_int > 0 )
        begin
            select @tmp_int2 = value
              from #tempmonitors
              where group_name = "lock" and
                            field_name = "hashtab_overflow_pagerow_lock"

            select @rptline = "    Avg Chain Length" +space(18)+
                                    @na_str + space(11) +
                                    @na_str + space(2) +
                                    str(convert(real, @tmp_int2) / @tmp_int, 10, 5) +
                                    space(7) + @na_str
                        , @reco_avg_chain_length_pagerow = convert(real, @tmp_int2)/@tmp_int
            print @rptline
        end
        else
        begin
            select @reco_avg_chain_length_pagerow = 0
        end

        select @spinlock_contention = isnull(100.0*(sum(convert(float,waits))/sum(convert(float,grabs))), 0)
          from #foo
         where name = 'fglockspins'
           and grabs > 0

        select @rptline = "    Spinlock Contention" + space(15) +
                                        @na_str + space(11) +
                                        @na_str + space(9) +
                                        @na_str + space(5) +
                                        str( @spinlock_contention,5,1)
                                                + @psign
                        , @reco_fgspin_contention = @spinlock_contention
        print @rptline
        print @blankline

        print "  Exclusive Page"

        select @tmp_total = SUM(convert(bigint, value))
          from #tempmonitors
          where group_name = "lock" and
                        (field_name like "granted%_EX_PAGE" or
                                field_name like "waited%_EX_PAGE")

        if @tmp_total = 0               /* Avoid Divide by Zero Errors */
        begin
                select @rptline = "    Total EX-Page Requests            0.0           0.0           0       n/a"
                print @rptline
        end
        else
          begin

                select @tmp_int = SUM(convert(bigint, value))
                  from #tempmonitors
                  where group_name = "lock" and
                                field_name like "granted%_EX_PAGE"

                select @rptline = "    Granted" + space(18) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
                print @rptline

                select @tmp_int = SUM(convert(bigint, value))
                  from #tempmonitors
                  where group_name = "lock" and
                                field_name like "waited%_EX_PAGE"

                select @rptline = "    Waited" + space(19) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
                print @rptline

                print @sum1line
                select @rptline = "  Total EX-Page Requests" + space(5) +
                        str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_total / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_total,11) + space(5) +
                        str(100.0 * @tmp_total / @TotalLocks,5,1) + @psign
                print @rptline
          end
        print @blankline

        print "  Update Page"

        select @tmp_total = SUM(convert(bigint, value))
          from #tempmonitors
          where group_name = "lock" and
                        (field_name like "granted%_UP_PAGE" or
                                field_name like "waited%_UP_PAGE")

        if @tmp_total = 0               /* Avoid Divide by Zero Errors */
        begin
                select @rptline = "    Total UP-Page Requests            0.0           0.0           0       n/a"
                print @rptline
        end
        else
          begin

                select @tmp_int = SUM(convert(bigint, value))
                  from #tempmonitors
                  where group_name = "lock" and
                                field_name like "granted%_UP_PAGE"

                select @rptline = "    Granted" + space(18) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
                print @rptline

                select @tmp_int = SUM(convert(bigint, value))
                  from #tempmonitors
                  where group_name = "lock" and
                                field_name like "waited%_UP_PAGE"

                select @rptline = "    Waited" + space(19) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
                print @rptline

                print @sum1line
                select @rptline = "  Total UP-Page Requests" + space(5) +
                        str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_total / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_total,11) + space(5) +
                        str(100.0 * @tmp_total / @TotalLocks,5,1) + @psign
                print @rptline
          end
        print @blankline

        print "  Shared Page"

        select @tmp_total = SUM(convert(bigint, value))
          from #tempmonitors
          where group_name = "lock" and
                        (field_name like "granted%_SH_PAGE" or
                                field_name like "waited%_SH_PAGE")

        if @tmp_total = 0               /* Avoid Divide by Zero Errors */
        begin
                select @rptline = "    Total SH-Page Requests            0.0           0.0           0       n/a"
                print @rptline
        end
        else
          begin

                select @tmp_int = SUM(convert(bigint, value))
                  from #tempmonitors
                  where group_name = "lock" and
                                field_name like "granted%_SH_PAGE"

                select @rptline = "    Granted" + space(18) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
                print @rptline

                select @tmp_int = SUM(convert(bigint, value))
                  from #tempmonitors
                  where group_name = "lock" and
                                field_name like "waited%_SH_PAGE"

                select @rptline = "    Waited" + space(19) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
                print @rptline

                print @sum1line
                select @rptline = "  Total SH-Page Requests" + space(5) +
                        str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_total / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_total,11) + space(5) +

                        str(100.0 * @tmp_total / @TotalLocks,5,1) + @psign
                print @rptline
                print @blankline
          end
        print @blankline

        print "  Exclusive Row"

        select @tmp_total = SUM(convert(bigint, value))
          from #tempmonitors
          where group_name = "lock" and
                        (field_name like "granted%_EX_ROW" or
                                field_name like "waited%_EX_ROW")

        if @tmp_total = 0               /* Avoid Divide by Zero Errors */
        begin
                select @rptline = "    Total EX-Row Requests             0.0           0.0           0       n/a"
                print @rptline
        end
        else
          begin

                select @tmp_int = SUM(convert(bigint, value))
                  from #tempmonitors
                  where group_name = "lock" and
                                field_name like "granted%_EX_ROW"

                select @rptline = "    Granted" + space(18) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
                print @rptline

                select @tmp_int = SUM(convert(bigint, value))
                  from #tempmonitors
                  where group_name = "lock" and
                                field_name like "waited%_EX_ROW"

                select @rptline = "    Waited" + space(19) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
                print @rptline

                print @sum1line
                select @rptline = "  Total EX-Row Requests" + space(6) +
                        str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_total / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_total,11) + space(5) +
                        str(100.0 * @tmp_total / @TotalLocks,5,1) + @psign
                print @rptline
          end
        print @blankline

        print "  Update Row"

        select @tmp_total = SUM(convert(bigint, value))
          from #tempmonitors
          where group_name = "lock" and
                        (field_name like "granted%_UP_ROW" or
                                field_name like "waited%_UP_ROW")

        if @tmp_total = 0               /* Avoid Divide by Zero Errors */
        begin
                select @rptline = "    Total UP-Row Requests             0.0           0.0           0       n/a"
                print @rptline
        end
        else
          begin

                select @tmp_int = SUM(convert(bigint, value))
                  from #tempmonitors
                  where group_name = "lock" and
                                field_name like "granted%_UP_ROW"

                select @rptline = "    Granted" + space(18) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
                print @rptline

                select @tmp_int = SUM(convert(bigint, value))
                  from #tempmonitors
                  where group_name = "lock" and
                                field_name like "waited%_UP_ROW"

                select @rptline = "    Waited" + space(19) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
                print @rptline

                print @sum1line
                select @rptline = "  Total UP-Row Requests" + space(6) +
                        str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_total / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_total,11) + space(5) +
                        str(100.0 * @tmp_total / @TotalLocks,5,1) + @psign
                print @rptline
          end
        print @blankline

        print "  Shared Row"

        select @tmp_total = SUM(convert(bigint, value))
          from #tempmonitors
          where group_name = "lock" and
                        (field_name like "granted%_SH_ROW" or
                                field_name like "waited%_SH_ROW")

        if @tmp_total = 0               /* Avoid Divide by Zero Errors */
        begin
                select @rptline = "    Total SH-Row Requests             0.0           0.0           0       n/a"
                print @rptline
        end
        else
          begin

                select @tmp_int = SUM(convert(bigint, value))
                  from #tempmonitors
                  where group_name = "lock" and
                                field_name like "granted%_SH_ROW"

                select @rptline = "    Granted" + space(18) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
                print @rptline

                select @tmp_int = SUM(convert(bigint, value))
                  from #tempmonitors
                  where group_name = "lock" and
                                field_name like "waited%_SH_ROW"

                select @rptline = "    Waited" + space(19) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
                print @rptline

                print @sum1line
                select @rptline = "  Total SH-Row Requests" + space(6) +
                        str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_total / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_total,11) + space(5) +
                        str(100.0 * @tmp_total / @TotalLocks,5,1) + @psign
                print @rptline
                print @blankline
          end
        print @blankline

        print "  Next-Key"

        select @tmp_total = SUM(convert(bigint, value))
          from #tempmonitors
          where group_name = "lock" and
                        (field_name like "granted%_SH_NKL" or
                                field_name like "waited%_SH_NKL")

        if @tmp_total = 0               /* Avoid Divide by Zero Errors */
        begin
                select @rptline = "    Total Next-Key Requests           0.0           0.0           0       n/a"
                print @rptline
        end
        else
          begin

                select @tmp_int = SUM(convert(bigint, value))
                  from #tempmonitors
                  where group_name = "lock" and
                                field_name like "granted%_SH_NKL"

                select @rptline = "    Granted" + space(18) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
                print @rptline

                select @tmp_int = SUM(convert(bigint, value))
                  from #tempmonitors
                  where group_name = "lock" and
                                field_name like "waited%_SH_NKL"

                select @rptline = "    Waited" + space(19) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
                print @rptline

                print @sum1line
                select @rptline = "  Total Next-Key Requests" + space(4) +
                        str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_total / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_total,11) + space(5) +
                        str(100.0 * @tmp_total / @TotalLocks,5,1) + @psign
                print @rptline
                print @blankline
          end
        print @blankline

        print "  Address Lock Hashtable"
        select @tmp_int = value
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "hashtab_lookups_address_lock"

        select @rptline = "    Lookups" + space(18) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(7) +
                                @na_str
        print @rptline

        /* Avoid divide by 0 error */
        if ( @tmp_int > 0 )
        begin
            select @tmp_int2 = value
              from #tempmonitors
              where group_name = "lock" and
                            field_name = "hashtab_overflow_address_lock"

            select @rptline = "    Avg Chain Length" +space(18)+
                                    @na_str + space(11) +
                                    @na_str + space(2) +
                                    str(convert(real, @tmp_int2) / @tmp_int, 10, 5) +
                                    space(7) + @na_str
            print @rptline
        end

        select @spinlock_contention = isnull(100.0*(sum(convert(float,waits))/sum(convert(float,grabs))), 0)
          from #foo
         where name = 'addrlockspins'
           and grabs > 0

        select @rptline = "    Spinlock Contention" + space(15) +
                                        @na_str + space(11) +
                                        @na_str + space(9) +
                                        @na_str + space(5) +
                                        str( @spinlock_contention,5,1)
                                                + @psign
                        , @reco_addrspin_contention = @spinlock_contention
        print @rptline
        print @blankline

        print "  Exclusive Address"

        select @tmp_total = SUM(convert(bigint, value))
          from #tempmonitors
          where group_name = "lock" and
                        (field_name like "granted_%EX_ADDR" or
                                field_name like "waited_%EX_ADDR")

        if @tmp_total = 0               /* Avoid Divide by Zero Errors */
        begin
                select @rptline = "    Total EX-Address Requests         0.0           0.0           0       n/a"
                print @rptline
        end
        else
          begin

                select @tmp_int = SUM(convert(bigint, value))
                  from #tempmonitors
                  where group_name = "lock" and
                                field_name like "granted_%EX_ADDR"

                select @rptline = "    Granted" + space(18) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
                print @rptline

                select @tmp_int = SUM(convert(bigint, value))
                  from #tempmonitors
                  where group_name = "lock" and
                                field_name like "waited_%EX_ADDR"

                select @rptline = "    Waited" + space(19) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
                print @rptline

                print @sum1line
                select @rptline = "  Total EX-Address Requests  " +
                        str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_total / convert(real,@NumXacts),12,1) +
                        space(1) +
                        str(@tmp_total,11) + space(5) +
                        str(100.0 * @tmp_total / @TotalLocks,5,1) + @psign
                print @rptline

          end
        print @blankline

        print "  Shared Address"

        select @tmp_total = SUM(convert(bigint, value))
          from #tempmonitors
          where group_name = "lock" and
                        (field_name like "granted_%SH_ADDR" or
                                field_name like "waited_%SH_ADDR")

        if @tmp_total = 0               /* Avoid Divide by Zero Errors */
        begin
                select @rptline = "    Total SH-Address Requests         0.0           0.0           0       n/a"
                print @rptline
        end
        else
          begin

                select @tmp_int = SUM(convert(bigint, value))
                  from #tempmonitors
                  where group_name = "lock" and
                                field_name like "granted_%SH_ADDR"

                select @rptline = "    Granted" + space(18) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
                print @rptline

                select @tmp_int = SUM(convert(bigint, value))
                  from #tempmonitors
                  where group_name = "lock" and
                                field_name like "waited_%SH_ADDR"

                select @rptline = "    Waited" + space(19) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
                print @rptline

                print @sum1line
                select @rptline = "  Total SH-Address Requests  " +
                        str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_total / convert(real,@NumXacts),12,1) +
                        space(1) +
                        str(@tmp_total,11) + space(5) +
                        str(100.0 * @tmp_total / @TotalLocks,5,1) + @psign
                print @rptline

                print @blankline
          end
        print @blankline

        print "  Last Page Locks on Heaps"

        select @tmp_total = SUM(convert(bigint, value))
          from #tempmonitors
          where group_name = "access" and
                field_name = "locklastpage"

        if @tmp_total = 0               /* Avoid Divide by Zero Errors */
        begin
                select @rptline = "    Total Last Pg Locks               0.0           0.0           0       n/a"
                print @rptline
        end
        else
          begin

                select @tmp_int2 = value
                  from #tempmonitors
                  where group_name = "access" and
                                field_name = "lklastpg_wait"

                select @tmp_int = @tmp_total - @tmp_int2

                select @rptline = "    Granted" + space(18) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
                print @rptline

            select @reco_lastpg_wait_percent = convert(int,
                                100.0 * ((1.0* @tmp_int2) / @tmp_total))

                select @rptline = "    Waited" + space(19) +
                                str(@tmp_int2 / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int2 / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int2, 11) + space(5) +
                                str(100.0 * @tmp_int2 / @tmp_total,5,1) + @psign
                print @rptline
                print @sum1line
                select @rptline = "  Total Last Pg Locks"+ space(8) +
                        str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_total / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_total,11) + space(5) +
                        str(100.0 * @tmp_total / @tmp_total,5,1) + @psign
                print @rptline
                print @blankline
          end
        print @blankline
  end

print "  Deadlocks by Lock Type          per sec      per xact       count  %% of total"
print @sum1line

select @tmp_total = value
  from #tempmonitors
  where group_name = "lock" and
                field_name = "deadlocks"

select @totaldeadlocks = SUM(convert(bigint, value))
  from #tempmonitors
  where group_name like "buffer_%" and
                field_name like "physical_lock_deadlock"

select @tmp_access = SUM(convert(bigint, value))
  from #tempmonitors
  where group_name = "access" and
                field_name in ("getrootpg_deadlock",
                               "lkindex_TSCK_deadlock",
                               "lkindex_deadlock",
                               "lkindDS_P_deadlock",
                               "lkindDS_C_deadlock",
                               "split_index_deadlock",
                               "log_lock_deadlock")

select @tmp_xls = value
  from #tempmonitors
  where group_name = "xls" and
                field_name = "log_lock_deadlock"

select @tmp_total = @tmp_total + @totaldeadlocks + @tmp_access + @tmp_xls

if @tmp_total = 0                       /* Avoid Divide by Zero Errors */
 begin
        select @rptline = "  Total Deadlocks                     0.0           0.0           0       n/a"
        print @rptline
 end
else
  begin

        select @tmp_int = value
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "deadlock_EX_TAB"

        select @rptline = "    Exclusive Table" + space(10) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
        print @rptline

        select @tmp_int = value
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "deadlock_SH_TAB"

        select @rptline = "    Shared Table" + space(13) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
        print @rptline

        select @tmp_int = value
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "deadlock_EX_INT"

        select @rptline = "    Exclusive Intent" + space(9) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
        print @rptline

        select @tmp_int = value
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "deadlock_SH_INT"

        select @rptline = "    Shared Intent" + space(12) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
        print @rptline

        select @tmp_int = value
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "deadlock_EX_PTN"

        select @rptline = "    Exclusive Partition" + space(6) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
        print @rptline

        select @tmp_int = value
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "deadlock_SH_PTN"

        select @rptline = "    Shared Partition" + space(9) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
        print @rptline

        select @tmp_int = value
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "deadlock_EX_INT_PTN"

        select @rptline = "    Exclusive Ptn_Intent" + space(5) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
        print @rptline

        select @tmp_int = value
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "deadlock_SH_INT_PTN"

        select @rptline = "    Shared Ptn_Intent" + space(8) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
        print @rptline

        select @tmp_int = value
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "deadlock_SH_CPTN"

        select @rptline = "    Shared CPtn_Intent" + space(7) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
        print @rptline


        select @tmp_int = value
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "deadlock_EX_CPTN"

        select @rptline = "    Exclusive CPtn_Intent" + space(4) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
        print @rptline

        select @tmp_int = value
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "deadlock_EX_PAGE"

        select @rptline = "    Exclusive Page" + space(11) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
        print @rptline

        select @tmp_int = value
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "deadlock_UP_PAGE"

        select @rptline = "    Update Page" + space(14) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
        print @rptline
        select @tmp_int = value
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "deadlock_SH_PAGE"

        select @rptline = "    Shared Page" + space(14) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
        print @rptline

        select @tmp_int = value
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "deadlock_EX_ROW"

        select @rptline = "    Exclusive Row" + space(12) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
        print @rptline

        select @tmp_int = value
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "deadlock_UP_ROW"

        select @rptline = "    Update Row" + space(15) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
        print @rptline

        select @tmp_int = value
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "deadlock_SH_ROW"

        select @rptline = "    Shared Row" + space(15) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
        print @rptline

        select @tmp_int = value
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "deadlock_SH_NKL"

        select @rptline = "    Shared Next-Key" + space(10) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
        print @rptline


        select @tmp_int = value
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "deadlock_EX_ADDR"

        select @rptline = "    Exclusive Address" + space(8) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
        print @rptline

        select @tmp_int = value
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "deadlock_SH_ADDR"

        select @rptline = "    Shared Address" + space(11) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
        print @rptline

        /* Get the deadlocks for physical lock acquisition */
        select @rptline = "    Physical Locks      " + space(5) +
                        str(@totaldeadlocks / @NumElapsedSec,12,1) +
                        space(2) +
                        str(@totaldeadlocks / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@totaldeadlocks, 11) + space(5) +
                        str(100.0 * @totaldeadlocks / @tmp_total,5,1) + @psign
        print @rptline

        /* Get the deadlocks for "access" group */
        select @tmp_access = SUM(convert(bigint, value))
         from #tempmonitors
         where group_name = "access" and
                        field_name in ("getrootpg_deadlock",
                                        "lkindex_TSCK_deadlock",
                                        "lkindex_deadlock",
                                        "lkindDS_P_deadlock",
                                        "lkindDS_C_deadlock",
                                        "split_index_deadlock",
                                        "log_lock_deadlock")

        /* Get the deadlocks for "xls" group */
        select @tmp_xls = value
         from #tempmonitors
         where group_name = "xls" and
                        field_name = "log_lock_deadlock"

        /* Get the sum of the deadlocks(other than belonging to group locks) */
        select @tmp_int = @tmp_access + @tmp_xls

        select @rptline = "    Others" + space(19) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
        print @rptline


        print @sum2line
        select @rptline = "  Total Deadlocks" + space(12) +
                        str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_total / convert(real, @NumXacts),12,1) +
                        space(2) +
                        str(@tmp_total,10)
        print @rptline
  end

print @blankline
select @tmp_total = value
  from #tempmonitors
  where group_name = "locks" and
                field_name = "clm_deadlocks"

if @tmp_total != 0                      /* Avoid Divide by Zero Errors */
begin

        select @rptline = "  Total Cluster Deadlocks" + space(4) +
                        str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_total / convert(real, @NumXacts),12,1) +
                        space(2) +
                        str(@tmp_total,10)
        print @rptline
end

print @blankline
print @blankline

select @tmp_int2 = @tmp_total   /* save for deadlock search calc */

print "  Deadlock Detection"

select @tmp_total = value
  from #tempmonitors
  where group_name = "lock" and
                field_name = "deadlock_search"

        select @rptline = "    Deadlock Searches" + space(8) +
                        str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_total / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_total, 11) + space(7) +
                        @na_str
print @rptline

if @tmp_total != 0                      /* Avoid Divide by Zero Errors */
  begin

        select @tmp_int = value
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "deadlock_alarm_skipped"

        select @rptline = "    Searches Skipped" + space(9) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
        print @rptline

        select @rptline = "    Avg Deadlocks per Search" + space(10) +
                        @na_str +
                        space(11) +
                        @na_str +
                        space(2) +
                        str(convert(real,@tmp_int2) / @tmp_total,10,5) +
                        space(7) +
                        @na_str
                print @rptline
  end
print @blankline
print @blankline

print "  Lock Promotions"

select @tmp_total = SUM(convert(bigint, value))
  from #tempmonitors
  where group_name = "lock" and
        (       field_name like "promoted_%_PAGE"
        or      field_name like "promoted_%_ROW"
        or      field_name like "promoted_%_NKL")
if @tmp_total = 0                       /* Avoid Divide by Zero Errors */
 begin
        select @rptline = "    Total Lock Promotions             0.0           0.0           0       n/a"
        print @rptline
 end
else
  begin

        select @tmp_int = SUM(convert(bigint, value))
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "promoted_EX_PAGE"

        select @rptline = "    Ex-Page to Ex-Table" + space(6) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
        print @rptline

        select @tmp_int = SUM(convert(bigint, value))
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "promoted_UP_PAGE"

        select @rptline = "    Up-Page to Ex-Table" + space(6) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
        print @rptline

	select @tmp_int = SUM(convert(bigint, value))
	  from #tempmonitors
	  where group_name = "lock" and
			field_name = "promoted_SH_PAGE"

        select @rptline = "    Sh-Page to Sh-Table" + space(6) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
        print @rptline

        select @tmp_int = SUM(convert(bigint, value))
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "promoted_EX_ROW"

        select @rptline = "    Ex-Row to Ex-Table" + space(7) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
        print @rptline

        select @tmp_int = SUM(convert(bigint, value))
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "promoted_UP_ROW"

        select @rptline = "    Up-Row to Ex-Table" + space(7) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
        print @rptline


	select @tmp_int = SUM(convert(bigint, value))
	  from #tempmonitors
	  where group_name = "lock" and
			field_name = "promoted_SH_ROW"

	select @rptline = "    Sh-Row to Sh-Table" + space(7) +
			str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) + 
			space(2) +
			str(@tmp_int / convert(real, @NumXacts),12,1) + 
			space(1) +
			str(@tmp_int, 11) + space(5) +
			str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
	print @rptline

        select @tmp_int = SUM(convert(bigint, value))
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "promoted_SH_NKL"

        select @rptline = "    Sh-Next-Key to Sh-Table" + space(2) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
        print @rptline

        print @sum2line
        select @rptline = "  Total Lock Promotions" + space(6) +
                        str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_total / convert(real, @NumXacts),12,1) +
                        space(2) +
                        str(@tmp_total,10)
        print @rptline
  end
print @blankline
print @blankline

print "  Lock Timeouts by Lock Type      per sec      per xact       count  %% of total"
print @sum1line

select @tmp_total = SUM(convert(bigint, value))
  from #tempmonitors
  where group_name = "lock" and
                field_name like "timedout%"

if @tmp_total = 0                       /* Avoid Divide by Zero Errors */
 begin
        select @rptline = "  Total Timeouts                      0.0           0.0           0       n/a"
        print @rptline
 end
else
  begin

        select @tmp_int = value
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "timedout_EX_TAB"

                select @rptline = "    Exclusive Table" + space(10) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
        print @rptline

        select @tmp_int = value
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "timedout_SH_TAB"

        select @rptline = "    Shared Table" + space(13) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
        print @rptline

        select @tmp_int = value
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "timedout_EX_INT"

        select @rptline = "    Exclusive Intent" + space(9) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
        print @rptline

        select @tmp_int = value
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "timedout_SH_INT"

        select @rptline = "    Shared Intent" + space(12) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
        print @rptline

        select @tmp_int = value
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "timedout_EX_PAGE"

        select @rptline = "    Exclusive Page" + space(11) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
        print @rptline

        select @tmp_int = value
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "timedout_UP_PAGE"

        select @rptline = "    Update Page" + space(14) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
        print @rptline

        select @tmp_int = value
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "timedout_SH_PAGE"

        select @rptline = "    Shared Page" + space(14) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
        print @rptline

        select @tmp_int = value
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "timedout_EX_ROW"

        select @rptline = "    Exclusive Row" + space(12) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
        print @rptline

        select @tmp_int = value
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "timedout_UP_ROW"

        select @rptline = "    Update Row" + space(15) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
        print @rptline

        select @tmp_int = value
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "timedout_SH_ROW"

        select @rptline = "    Shared Row" + space(15) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
        print @rptline

        select @tmp_int = value
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "timedout_EX_ADDR"

        select @rptline = "    Exclusive Address" + space(8) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
        print @rptline

        select @tmp_int = value
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "timedout_SH_ADDR"

        select @rptline = "    Shared Address" + space(11) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
        print @rptline

        select @tmp_int = value
          from #tempmonitors
          where group_name = "lock" and
                        field_name = "timedout_SH_NKL"

        select @rptline = "    Shared Next-Key" + space(10) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
        print @rptline

        print @sum2line

        select @rptline = "  Total Lock Timeouts" + space(8) +
                        str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_total / convert(real, @NumXacts),12,1) +
                        space(2) +
                        str(@tmp_total,10)
        print @rptline
end


/*****************  Tuning Recommendations  ************************/

if @Reco = 'Y'
begin
        select @reco_hdr_prn = 0
        print @blankline

        select @deadlocks = value from #tempmonitors
                            where group_name = "lock"
                            and field_name ="deadlocks"

        select @deadlock_search = value from #tempmonitors
                                  where group_name="lock"
                                  and field_name="deadlock_search"

        /*
        ** If the number of deadlocks is 0 and the
        ** number of times deadlock search was done
        ** is greater than 0, consider increasing the
        ** 'deadlock checking period' parameter
        */
        if (@deadlocks = 0 and @deadlock_search >0)
        begin
                if (@reco_hdr_prn = 0)
                begin
                        print @recotxt
                        print @recoline
                        select @reco_hdr_prn = 1
                end
                print "  - Consider increasing the 'deadlock checking period' parameter"
                print "    by 50 ms."
                print @blankline
        end
        /*
        ** If the number of deadlocks is greated than 0 and the
        ** number of times deadlock search was done is 0,
        ** consider decreasing the 'deadlock checking period' parameter
        */
        else if (@deadlocks > 0 and @deadlock_search=0)
        begin
                if (@reco_hdr_prn = 0)
                begin
                        print @recotxt
                        print @recoline
                        select @reco_hdr_prn = 1
                end
                print "  - Consider decreasing the 'deadlock checking period' parameter"
                print "    by 50 ms."
                print @blankline
        end

        /*
        ** If the percentage of waits on the last page
        ** is > 10% consider partitioning the table or
        ** increasing the number of partitions if the
        ** table is already partitioned
        */
        if (@reco_lastpg_wait_percent > 10)
        begin
                if (@reco_hdr_prn = 0)
                begin
                        print @recotxt
                        print @recoline
                        select @reco_hdr_prn = 1
                end
                print "  - Consider partitioning the heap tables or increasing the"
                print "    number of partitions on already partitioned heap tables."
                print @blankline
        end

        /*
        ** If the average length of overflow chain for page & row lock
        ** hashtable  is > 4 consider increasing the 'lock hashtable size'
        ** to the next power of 2 from the current configured value.
        */
        if (@reco_avg_chain_length_pagerow > 4)
        begin
                if (@reco_hdr_prn = 0)
                begin
                        print @recotxt
                        print @recoline
                        select @reco_hdr_prn = 1
                end
                print "  - Consider increasing the value of 'lock hashtable size' "
                print "    configuration option. The value for this configuration "
                print "    option must be a power of 2."
                print @blankline
        end

        /*
        ** If the number of engines is > 1 report recommendation for lock
        ** manager related spinlock contentions.
        */
        if (@NumEngines > 1)
        begin /* { */
                /*
                ** if the contention on the fglock hashtable spinlocks
                ** is >= 10%, consider decreasing the 'lock spinlock ratio'
                ** config option.
                */
                if (@reco_fgspin_contention >= 10)
                begin
                        if (@reco_hdr_prn = 0)
                        begin /* { */
                                print @recotxt
                                print @recoline
                                select @reco_hdr_prn = 1
                        end /* } */
                        print "    - Consider reducing the 'lock spinlock ratio'."
                        print @blankline
                end
                /*
                ** if the contention on the table lock hashtable spinlocks
                ** is >= 10%, consider decreasing the 'lock table spinlock
                ** ratio' config option.
                */
                if (@reco_tabspin_contention >= 10)
                begin
                        if (@reco_hdr_prn = 0)
                        begin /* { */
                                print @recotxt
                                print @recoline
                                select @reco_hdr_prn = 1
                        end /* } */
                        print "    - Consider reducing the 'lock table spinlock ratio'."
                        print @blankline
                end
                /*
                ** if the contention on the address lock hashtable spinlocks
                ** is >= 10%, consider decreasing the 'lock address spinlock
                ** ratio' config option.
                */
                if (@reco_addrspin_contention >= 10)
                begin
                        if (@reco_hdr_prn = 0)
                        begin /* { */
                                print @recotxt
                                print @recoline
                                select @reco_hdr_prn = 1
                        end /* } */
                        print "    - Consider reducing the 'lock address spinlock ratio'."
                        print @blankline
                end
         end /* } */
end
print @blankline
return 0

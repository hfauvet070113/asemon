/* This stored procedure produces a report containing a summary of
** of disk activity.
*/
create procedure sp_sysmon_diskio_PDO_V16
	@NumEngines smallint,	/* number of engines online */
	@NumElapsedMs int,	/* for "per Elapsed second" calculations */
	@NumXacts int,		/* for per transactions calculations */
	@Reco	char(1),		/* Flag for recommendations */
        @kernelmode  varchar(10)       /* added for asemon_report */
as


/* --------- declare local variables --------- */
declare @SybDiskName varchar(265) /* cursor var for logical disk name - 
				** sysdevices.name */ 
declare @PhyDiskName varchar(127) /* cursor var for physical disk name - 
				  ** sysdevices.phyname */


declare @i smallint		/* loop index to iterate through multi-group
				**  counters (engine, disk, & buffer) */
declare @tmp_grp varchar(25)	/* temp var for build group_name's - ie., 
				** engine_N, disk_N */
declare @tmp_int bigint		/* temp var for integer storage */
declare @tmp_int2 bigint	/* temp var for integer storage */
declare @tmp_int3 int           /* temp var for integer storage */
declare @tmp_int4 int           /* temp var for integer storage */
declare @tmp_total bigint       /* temp var for summing 'total #s' data */
declare @tmp_total_async bigint /* temp var for summing total #s of
                                ** asynchronous IOs completed */
declare @tmp_total_sync int     /* temp var for summing total #s of synchronous
                                ** IOs completed */
declare @tmp_total_ios int      /* temp var for summing total #s of IOs
                                ** completed.
                                ** @tmp_total_ios = @tmp_total_async + 
				** @tmp_total_sync
                                */
declare @sum1line char(80)	/* string to delimit total lines without 
				** percent calc on printout */	
declare @sum2line char(80)	/* string to delimit total lines without 
				** percent calc on printout */	
declare @subsection char(80)	/* delimit disk sections */
declare @blankline char(1)	/* to print blank line */
declare @psign char(3)		/* hold a percent sign (%) for print out */
declare @na_str char(3)		/* holds 'n/a' for 'not applicable' strings */
declare @rptline char(80)	/* formatted stats line for print statement */
declare @section char(80)       /* string to delimit sections on printout */


/* ------------- Variables for Tuning Recommendations ------------*/
declare @recotxt char(80)       /* Header for tuning recommendation */
declare @recoline char(80)      /* to underline recotxt */
declare @reco_hdr_prn bit       /* to indicate if the recotxt is already printed */
declare @reco_total_diskio int
declare @reco_diskio_struct_delay int
declare @reco_maxaio_server bigint
declare @reco_maxaio_engine bigint
declare @reco_aio_os_limit bigint


/* --------- Setup Environment --------- */
set nocount on			/* disable row counts being sent to client */


select @sum1line   = "  -------------------------  ------------  ------------  ----------  ----------"
select @sum2line   = "  -------------------------  ------------  ------------  ----------"
select @subsection = "  -----------------------------------------------------------------------------"
select @blankline  = " "
select @psign      = " %"		/* extra % symbol because '%' is escape char in print statement */
select @na_str     = "n/a"
select @section = "==============================================================================="


exec asemon_print @section
exec asemon_print @blankline
exec asemon_print "Disk I/O Management"
exec asemon_print "-------------------"
exec asemon_print @blankline
exec asemon_print "  Max Outstanding I/Os            per sec      per xact       count  % of total"
exec asemon_print @sum1line


select @tmp_int = value
  from #tempmonitors
  where group_name = "kernel" and
		field_name = "max_outstanding_AIOs_server"


select @rptline = "    Server" + space(28) +
				@na_str + space(11) +
				@na_str + space(1) +
				str(@tmp_int, 11) + space(7) +
				@na_str
exec asemon_print @rptline


select @i = 0
while @i < @NumEngines		/* for each engine */
  begin
	/* build group_name string */
	select @tmp_grp = "engine_" + convert(varchar(4), @i)
 
	/* If an engine's clock_ticks counter is 0, this means this engine
	** is in offline status. We should skip this engine when priting
	** the statistic information.
	*/
	if (select value
		from #tempmonitors where field_name="clock_ticks"
			and group_name=@tmp_grp) > 0
	begin
		select @tmp_int = value
	  	from #tempmonitors
	  	where group_name = @tmp_grp and
          	  field_name = "max_outstanding_AIOs_engine"
  
		select @rptline = "    Engine " + convert(char(4), @i) + space(23) +
						@na_str + space(11) +
						@na_str + space(1) +
						str(@tmp_int, 11) + space(7) +
						@na_str
		exec asemon_print @rptline
	end


	select @i = @i + 1
  end


exec asemon_print @blankline
exec asemon_print @blankline
exec asemon_print "  I/Os Delayed by"


select @tmp_int = value, @reco_diskio_struct_delay = value
  from #tempmonitors
  where group_name = "kernel" and
		field_name = "udalloc_sleeps"


select @rptline = "    Disk I/O Structures" + space(15) +
				@na_str + space(11) +
				@na_str + space(1) +
				str(@tmp_int, 11) + space(7) +
				@na_str
exec asemon_print @rptline


select @tmp_int = SUM(convert(bigint, value)), @reco_maxaio_server = SUM(convert(bigint, value))
  from #tempmonitors
  where group_name like "engine_%" and
		field_name = "AIOs_delayed_due_to_server_limit"


select @rptline = "    Server Config Limit" + space(15) +
				@na_str + space(11) +
				@na_str + space(1) +
				str(@tmp_int, 11) + space(7) +
				@na_str
exec asemon_print @rptline


select @tmp_int = SUM(convert(bigint, value)), @reco_maxaio_engine = SUM(convert(bigint, value))
  from #tempmonitors
  where group_name like "engine_%" and
		field_name = "AIOs_delayed_due_to_engine_limit"


select @rptline = "    Engine Config Limit" + space(15) +
				@na_str + space(11) +
				@na_str + space(1) +
				str(@tmp_int, 11) + space(7) +
				@na_str
exec asemon_print @rptline


select @tmp_int = SUM(convert(bigint, value)), @reco_aio_os_limit = SUM(convert(bigint, value))
  from #tempmonitors
  where group_name like "engine_%" and
		field_name = "AIOs_delayed_due_to_os_limit"


select @rptline = "    Operating System Limit" + space(12) +
				@na_str + space(11) +
				@na_str + space(1) +
				str(@tmp_int, 11) + space(7) +
				@na_str
exec asemon_print @rptline


exec asemon_print @blankline
exec asemon_print @blankline


select @tmp_int = value , @reco_total_diskio = value
  from #tempmonitors
  where group_name = "kernel" and
		field_name = "udalloc_calls"


select @rptline = "  Total Requested Disk I/Os" + space(2) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_int, 10) 
exec asemon_print @rptline
exec asemon_print @blankline
exec asemon_print "  Completed Disk I/O's"


select @tmp_total_async = isnull(SUM(convert(bigint, value)), 0)
  from #tempmonitors
  where group_name like "engine_%" and
		field_name = "total_dpoll_completed_aios"


select @tmp_total_sync = value
  from #tempmonitors
  where group_name like "kernel" and
		field_name = "total_sync_completed_ios"


select @tmp_total_ios = @tmp_total_async + @tmp_total_sync


exec asemon_print "    Asynchronous I/O's"
if @tmp_total_async = 0
 begin
	select @rptline = "      Total Completed I/Os            0.0           0.0           0       n/a"
  	exec asemon_print @rptline
 end
else
begin
  if @kernelmode = "process"
  begin
	select @i = 0
	while @i < @NumEngines		/* for each engine */
	  begin
		/* build group_name string */
		select @tmp_grp = "engine_" + convert(varchar(4), @i)
  
		/* If an engine's clock_ticks counter is 0, this means this engine
		** is in offline status. We should skip this engine when priting
		** the statistic information.
		*/
		if (select value
			from #tempmonitors where field_name="clock_ticks"
				and group_name=@tmp_grp) > 0
		begin
			select @tmp_int = value
		  	from #tempmonitors
		  	where group_name = @tmp_grp and
					field_name = "total_dpoll_completed_aios"
  
			select @rptline = "      Engine " + convert(char(4), @i) + 
					space(12) +
					str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
					space(2) +
					str(@tmp_int / convert(real, @NumXacts),12,1) +
					space(1) +
					str(@tmp_int, 11) + space(5) +
					str(100.0 * @tmp_int / @tmp_total_async,5,1) + @psign
			exec asemon_print @rptline
		end


		select @i = @i + 1
	  end	/* while loop */
  end	/* else */
  else
  begin	/* threaded kernel */
	select @rptline = "      Total Completed I/Os" +
		space(3) +
		str(@tmp_total_async / (@NumElapsedMs / 1000.0),12,1) +
		space(2) +
		str(@tmp_total_async / convert(real, @NumXacts),12,1) +
		space(1) +
		str(@tmp_total_async, 11) + space(5) +
		str(100.0 * @tmp_total_async / @tmp_total_ios,5,1) + @psign
	exec asemon_print @rptline
  end
end


exec asemon_print "    Synchronous I/O's"
if @tmp_total_sync = 0 
 begin
	select @rptline = "      Total Completed I/Os            0.0           0.0           0       n/a"
  	exec asemon_print @rptline
 end
else
  begin
		select @rptline = "      Total Completed I/Os   " +
				str(@tmp_total_sync / (@NumElapsedMs / 1000.0),12,1) + 
				space(2) +
				str(@tmp_total_sync / convert(real, @NumXacts),12,1) +
				space(1) +
				str(@tmp_total_sync, 11) + space(5) +
				str(100.0,5,1) + @psign
		exec asemon_print @rptline
  end	/* else */


exec asemon_print @sum2line


select @rptline = "  Total Completed I/Os" + space(7) +
			str(@tmp_total_ios / (@NumElapsedMs / 1000.0),12,1) + 
			space(2) +
			str(@tmp_total_ios / convert(real, @NumXacts),12,1) + 
			space(2) +
			str(@tmp_total_ios, 10)
exec asemon_print @rptline
exec asemon_print @blankline
exec asemon_print @blankline
exec asemon_print "  Device Activity Detail"
exec asemon_print "  ----------------------"
exec asemon_print @blankline


/* get total number of I/Os to all devices to calc each device's percentage */
select @tmp_total = isnull(SUM(convert(bigint, value)), 0)
  from #tempmonitors
  where group_name like "disk_%" and
		(field_name = "total_reads" or field_name = "total_writes")


if @tmp_total = 0
  begin
	exec asemon_print "    No Disk I/O in Given Sample Period"
	exec asemon_print @blankline
  end
else
  begin
        declare disk_info cursor for
                select name, phyname,group_name 
                  from #devicemap
                  order by phyname
                  for read only


	open disk_info
	fetch disk_info into @SybDiskName, @PhyDiskName, @tmp_grp


	while (@@sqlstatus = 0)
	  begin


		select @rptline = "  Device:"
		exec asemon_print @rptline
		select @rptline = space(4) + substring(@PhyDiskName, 1, 76)
		exec asemon_print @rptline
		select @rptline = space(4) + convert(char(25), 
			substring(@SybDiskName, 1, 25)) + 
			"     per sec      per xact       count  % of total"
		exec asemon_print @rptline 


		exec asemon_print @sum1line


		select @tmp_int2 = isnull(SUM(convert(bigint, value)), 0)
		  from #tempmonitors
		  where group_name = @tmp_grp and
				(field_name = "total_reads" or 
					field_name = "total_writes")


		if @tmp_int2 = 0
 		begin
			select @rptline = "  Total I/Os                          0.0           0.0           0       n/a"
  			exec asemon_print @rptline
 		end
		else
		  begin
			select @tmp_int = value
			  from #tempmonitors
			  where group_name = @tmp_grp and
					field_name = "total_reads"
			if not exists(select * 
					from #tempmonitors
					where group_name = @tmp_grp and 
					field_name="apf_physical_reads")


			begin /*{ begin to check existence of apf counters*/
	                       select @rptline = "    Reads" + space(20) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_int2,5,1) + @psign
       		                 exec asemon_print @rptline
			end /*} end for apf counter check*/
			
			else
			begin	/*{begin in case apf counters exist*/
                        	select @tmp_int3 = value
                          	from #tempmonitors
                          	where group_name = @tmp_grp and
                                        field_name = "apf_physical_reads"


                        	select @tmp_int4 = @tmp_int - @tmp_int3


                        	select @rptline = "    Reads"
                        	exec asemon_print @rptline


                        	select @rptline = "      APF" + space(20) +
                                str(@tmp_int3 / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int3 / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int3, 11) + space(5) +
                                str(100.0 * @tmp_int3 / @tmp_int2,5,1) + @psign
                        	exec asemon_print @rptline


                        	select @rptline = "      Non-APF" + space(16) +
                                str(@tmp_int4 / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int4 / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int4, 11) + space(5) +
                                str(100.0 * @tmp_int4 / @tmp_int2,5,1) + @psign
                        	exec asemon_print @rptline
			end /*} end in case where apf counters exist*/


			select @tmp_int = value
			  from #tempmonitors
			  where group_name = @tmp_grp and
					field_name = "total_writes"


			select @rptline = "    Writes" + space(19) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(1) +
				str(@tmp_int, 11) + space(5) +
				str(100.0 * @tmp_int / @tmp_int2,5,1) + @psign
			exec asemon_print @rptline


		  end	/* else @tmp_int2 != 0 */


		exec asemon_print @sum1line


		select @rptline = "  Total I/Os" + space(17) +
			str(@tmp_int2 / (@NumElapsedMs / 1000.0),12,1) + 
			space(2) +
			str(@tmp_int2 / convert(real, @NumXacts),12,1) + 
			space(1) +
			str(@tmp_int2, 11) + space(5) +
			str(100.0 * @tmp_int2 / @tmp_total,5,1) + @psign
		exec asemon_print @rptline
		exec asemon_print @blankline


		select @tmp_int2 = isnull(SUM(convert(bigint, value)), 0)
		  from #tempmonitors
		  where group_name = @tmp_grp and
			(field_name = "p_hits" or field_name = "p_misses")


		if @tmp_int2 != 0
		  begin


			select @tmp_int = value
			  from #tempmonitors
			  where group_name = @tmp_grp and
					field_name = "p_hits"


			select @rptline = "  Mirror Semaphore Granted" + 
				space(3) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(1) +
				str(@tmp_int, 11) + space(5) +
				str(100.0 * @tmp_int / @tmp_int2,5,1) + @psign
			exec asemon_print @rptline


			select @tmp_int = value
			  from #tempmonitors
			  where group_name = @tmp_grp and
					field_name = "p_misses"


			select @rptline = "  Mirror Semaphore Waited" + 
				space(4) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(1) +
				str(@tmp_int, 11) + space(5) +
				str(100.0 * @tmp_int / @tmp_int2,5,1) + @psign
			exec asemon_print @rptline
		  end	/* else @tmp_int2 != 0 */ 


		exec asemon_print @blankline
		exec asemon_print @subsection
		exec asemon_print @blankline


		fetch disk_info into @SybDiskName, @PhyDiskName, @tmp_grp


	  end	/* while @@sqlstatus */


	close disk_info 
	deallocate cursor disk_info


  end	/* else @tmp_total != 0 */


exec asemon_print @blankline


if (@Reco = 'Y' and @reco_total_diskio != 0)
 begin
	select @recotxt = "  Tuning Recommendations for Disk I/O Management"
	select @recoline = "  ----------------------------------------------"
	select @reco_hdr_prn = 0


	select @reco_diskio_struct_delay = convert(int, 
		(100.0 * ((1.0 *@reco_diskio_struct_delay)/@reco_total_diskio)))
	select @reco_maxaio_server = convert(int,
		(100.0 * ((1.0 *@reco_maxaio_server)/@reco_total_diskio)))
	select @reco_maxaio_engine = convert(int,
		(100.0 * ((1.0 *@reco_maxaio_engine)/@reco_total_diskio)))
	select @reco_aio_os_limit = convert(int,
		(100.0 * ((1.0 *@reco_aio_os_limit)/@reco_total_diskio)))


	/*
	** If the % of I/O's delayed on account of
	** number of disk I/O structures is > 5%
	** consider increasing the number of disk i/o
	** structures
	*/
	if @reco_diskio_struct_delay > 5
	begin
                if (@reco_hdr_prn = 0)
                begin
                        exec asemon_print @recotxt
                        exec asemon_print @recoline
                        select @reco_hdr_prn = 1
                end
		
		exec asemon_print "  - Consider increasing the 'disk i/o structures'"
		exec asemon_print "    configuration parameter."
		exec asemon_print @blankline
		select @reco_hdr_prn = 1
	end


	/*
	** If the % of the number of I/O's delayed on account of
	** the server limit is > 5
	** consider increasing the 'max async I/Os per server'
	** configuration parameter 
	*/
	if @reco_maxaio_server > 5
	begin
                if (@reco_hdr_prn = 0)
                begin
                        exec asemon_print @recotxt
                        exec asemon_print @recoline
                        select @reco_hdr_prn = 1
                end


		exec asemon_print "  - Consider increasing the 'max async I/Os per server'"
		exec asemon_print "    configuration parameter."
		exec asemon_print @blankline
		select @reco_hdr_prn = 1
	end


	/*
	** If the % of the number of I/O's delayed on account of
	** the engine limit is > 5
	** consider increasing 'max async I/Os per engine'
	*/
	if @reco_maxaio_engine > 5
	begin
                if (@reco_hdr_prn = 0)
                begin
                        exec asemon_print @recotxt
                        exec asemon_print @recoline
                        select @reco_hdr_prn = 1
                end


		exec asemon_print "  - Consider increasing the 'max async I/Os per engine'"
		exec asemon_print "    configuration parameter."
		exec asemon_print @blankline
		select @reco_hdr_prn = 1
	end


	/*
	** If the % of the number of I/O's delayed on account of
	** operating system parameters governing async I/O
	** is greater than 5, then consider increasing that
	** parameter.
	*/
	if @reco_aio_os_limit > 5
	begin
                if (@reco_hdr_prn = 0)
                begin
                        exec asemon_print @recotxt
                        exec asemon_print @recoline
                        select @reco_hdr_prn = 1
                end


		exec asemon_print "  - Consider increasing the operating system parameter"
		exec asemon_print "    governing the number of asynchronous I/O's."
		exec asemon_print @blankline
		select @reco_hdr_prn = 1
	end


 end


exec asemon_print @blankline


return 0

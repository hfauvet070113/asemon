/* This stored procedure produces a report containing a summary of
** the type of activites performed by transactions running during
** the sampling period, including the number of transactions and 
** a summary of insert, update and delete activity.
**
*/
create procedure sp_sysmon_xactsum_PDO_V125
	@NumElapsedMs int,	/* for "per Elapsed second" calculations */
	@NumXacts int		/* for per transactions calculations */
as


/* --------- declare local variables --------- */
declare @NumXactOps int		/* total # of rows affected by 
				** inserts/updates/deletes */
declare @tmp_int int		/* temp var for integer storage */
declare @tmp_int2 int		/* temp var for integer storage */
declare @tmp_total int		/* temp var for summing 'total #s' data */
declare @sum1line char(80)	/* string to delimit total lines without 
				** percent calc on printout */	
declare @sum2line char(67)	/* string to delimit total lines with percent 
				** calc on printout */
declare @sum3line char(67)	/* string to delimit total lines with percent 
				** calc on printout */
declare @blankline char(1)	/* to print blank line */
declare @psign char(3)		/* hold a percent sign (%) for print out */
declare @na_str char(3)		/* holds 'n/a' for 'not applicable' strings */
declare @rptline char(80)	/* formatted stats line for print statement */
declare @section char(80)	/* string to delimit sections on printout */
/* --------- Setup Environment --------- */
set nocount on			/* disable row counts being sent to client */


select @sum1line   = "  -------------------------  ------------  ------------  ----------  ----------"
select @sum2line   = "  -------------------------  ------------  ------------  ----------"
select @sum3line   = "  =========================  ============  ============  =========="
select @blankline  = " "
select @psign      = " %"		/* extra % symbol because '%' is escape char in print statement */
select @na_str     = "n/a"
select @section = "==============================================================================="


/* ================ Transaction Profile Section ================= */
exec asemon_print @section
exec asemon_print @blankline
exec asemon_print "Transaction Profile"
exec asemon_print "-------------------"
exec asemon_print @blankline


/* -------- transaction summary ------------*/
exec asemon_print "  Transaction Summary             per sec      per xact       count  % of total"
exec asemon_print @sum1line


select @rptline = "    Committed Xacts" + space(10) +
			str(@NumXacts / (@NumElapsedMs / 1000.0),12,1) + 
			space(11) + @na_str + space(2) +
			str(@NumXacts,10) + space(5) +	@na_str
exec asemon_print @rptline
exec asemon_print @blankline
  
/*
** transaction detail
*/


exec asemon_print "  Transaction Detail              per sec      per xact       count  % of total"
exec asemon_print @sum1line


/* 
**  get total number of Transaction Operations for percentage 
**  calculations on total lines 
*/
select @NumXactOps = SUM(value)
  from #tempmonitors
  where (group_name = 'access' and field_name IN	
			("ncinsert", "cinsert","deferred_update",
			 "direct_inplace_update","direct_notinplace_update",
			 "direct_expensive_update","delete"))
     OR (group_name = 'dolaccess' and field_name IN	
			("dolinsert","dolupdates", "doldelete_total"))


if @NumXactOps = 0			/* Avoid Divide by Zero Errors */
 begin
	select @rptline = "    Total Rows Affected               0.0           0.0           0       n/a"
  	exec asemon_print @rptline
 end
else              
  begin
	exec asemon_print "    Inserts"


	select @tmp_total = SUM(value)
	  from #tempmonitors
	  where (group_name = 'access' and
			field_name IN ("ncinsert", "cinsert"))
	     or (group_name = 'dolaccess' and
			field_name = "dolinsert")


	if @tmp_total = 0		/* Avoid Divide by Zero Errors */
 	begin
		select @rptline = "      Total Rows Inserted             0.0           0.0           0       n/a"
  		exec asemon_print @rptline
 	end
	else
	  begin


		select @tmp_int = value
		  from #tempmonitors
		  where group_name = 'access' and
				field_name = "ncinsert"


		select @rptline = "      APL Heap Table" + space(9) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_int, 10) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
		exec asemon_print @rptline


		select @tmp_int = value
		  from #tempmonitors
		  where group_name = 'access' and
				field_name = "cinsert"


		select @rptline = "      APL Clustered Table" + space(4) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_int, 10) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
		exec asemon_print @rptline


		select @tmp_int = value
		  from #tempmonitors
		  where group_name = 'dolaccess' and
				field_name = "dolinsert"


		select @rptline = "      Data Only Lock Table" + space(3) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_int, 10) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
		exec asemon_print @rptline


	  end		/* else */ 


	exec asemon_print @sum1line 
	select @rptline = "    Total Rows Inserted" + space(6) +
			str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
			space(2) +
			str(@tmp_total / convert(real, @NumXacts),12,1) +
			space(2) +
			str(@tmp_total,10) + space(5) +
			str(100.0 * @tmp_total / @NumXactOps,5,1) + @psign
	exec asemon_print @rptline
	exec asemon_print @blankline


	exec asemon_print "    Updates"


	select @tmp_total = SUM(value)
	  from #tempmonitors
	  where (group_name = 'access' and field_name IN 
		("deferred_update","direct_inplace_update",
		 "direct_notinplace_update","direct_expensive_update"))
	     OR (group_name = 'dolaccess' and field_name = "dolupdates")


	if @tmp_total = 0		/* Avoid Divide by Zero Errors */
 	begin
		select @rptline = "      Total Rows Updated              0.0           0.0           0       n/a"
  		exec asemon_print @rptline
 	end
	else
	  begin


		select @tmp_int = value
		  from #tempmonitors
		  where group_name = 'access' and
				field_name = "deferred_update"


		select @rptline = "      APL Deferred" + space(11) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_int, 10) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
		exec asemon_print @rptline


		select @tmp_int = value
		  from #tempmonitors
		  where group_name = 'access' and
				field_name = "direct_inplace_update"


		select @rptline = "      APL Direct In-place" + space(4) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(2) + 
				str(@tmp_int, 10) +space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
		exec asemon_print @rptline


		select @tmp_int = value
		  from #tempmonitors
		  where group_name = 'access' and
				field_name = "direct_notinplace_update"


		select @rptline = "      APL Direct Cheap" + space(7) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_int, 10) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
		exec asemon_print @rptline


		select @tmp_int = value
		  from #tempmonitors
		  where group_name = 'access' and
				field_name = "direct_expensive_update"


		select @rptline = "      APL Direct Expensive" + space(3) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_int, 10) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
		exec asemon_print @rptline


		select @tmp_int2 = value
		  from #tempmonitors
		  where group_name = 'dolaccess' and
				field_name = "dolupdate_deferred"


		select @rptline = "      DOL Deferred" + space(11) +
				str(@tmp_int2 / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int2 / convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_int2, 10) + space(5) +
				str(100.0 * @tmp_int2 / @tmp_total,5,1) + @psign
		exec asemon_print @rptline


		select @tmp_int = value - @tmp_int2
		  from #tempmonitors
		  where group_name = 'dolaccess' and
				field_name = "dolupdates"


		select @rptline = "      DOL Direct" + space(13) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_int, 10) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
		exec asemon_print @rptline


	  end


	exec asemon_print @sum1line 
	select @rptline = "    Total Rows Updated" + space(7) +
			str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
			space(2) +
			str(@tmp_total / convert(real, @NumXacts),12,1) +
			space(2) +
			str(@tmp_total,10) + space(5) +
			str(100.0 * @tmp_total / @NumXactOps,5,1) + @psign
	exec asemon_print @rptline
	exec asemon_print @blankline




	exec asemon_print "    Data Only Locked Updates"


	select @tmp_total = SUM(value)
	  from #tempmonitors
	  where group_name = 'dolaccess' and field_name IN 
		("dolupdate_replace", "dolupdate_shrink",
		 "dolupdate_expand_incfs", "dolupdate_expand_shift",
		 "dolupdate_expand_after_gc", "dolupdate_forward_firstlvl",
		 "dolupdate_forward_secondlvl", "dolupdate_migrate_rowhome")


	if @tmp_total = 0		/* Avoid Divide by Zero Errors */
 	begin
		select @rptline = "      Total Rows Updated              0.0           0.0           0       n/a"
  		exec asemon_print @rptline
 	end
	else
	  begin


		select @tmp_int = value
		  from #tempmonitors
		  where group_name = 'dolaccess' and
				field_name = "dolupdate_replace"


		select @rptline = "      DOL Replace" + space(12) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_int, 10) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
		exec asemon_print @rptline


		select @tmp_int = value
		  from #tempmonitors
		  where group_name = 'dolaccess' and
				field_name = "dolupdate_shrink"


		select @rptline = "      DOL Shrink" + space(13) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_int, 10) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
		exec asemon_print @rptline


		select @tmp_int = value
		  from #tempmonitors
		  where group_name = 'dolaccess' and
				field_name = "dolupdate_expand_incfs"


		select @rptline = "      DOL Cheap Expand" + space(7) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_int, 10) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
		exec asemon_print @rptline


		select @tmp_int = SUM(value)
		  from #tempmonitors
		  where group_name = 'dolaccess' and
				field_name in ("dolupdate_expand_shift",
				               "dolupdate_expand_after_gc" )


		select @rptline = "      DOL Expensive Expand" + space(3) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_int, 10) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
		exec asemon_print @rptline


		select @tmp_int = SUM(value)
		  from #tempmonitors
		  where group_name = 'dolaccess' and
				field_name in ("dolupdate_forward_firstlvl",
				               "dolupdate_forward_secondlvl")


		select @rptline = "      DOL Expand & Forward" + space(3) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_int, 10) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
		exec asemon_print @rptline


		select @tmp_int = value
		  from #tempmonitors
		  where group_name = 'dolaccess' and
				field_name = "dolupdate_migrate_rowhome"


		select @rptline = "      DOL Fwd Row Returned" + space(3) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_int, 10) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
		exec asemon_print @rptline


	  end


	exec asemon_print @sum1line 
	select @rptline = "    Total DOL Rows Updated" + space(3) +
			str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
			space(2) +
			str(@tmp_total / convert(real, @NumXacts),12,1) +
			space(2) +
			str(@tmp_total,10) + space(5) +
			str(100.0 * @tmp_total / @NumXactOps,5,1) + @psign
	exec asemon_print @rptline
	exec asemon_print @blankline


	exec asemon_print "    Deletes"


	select @tmp_total = SUM(value)
	  from #tempmonitors
	  where (group_name = 'access' and 
			field_name = "delete")
	     or (group_name = 'dolaccess' and
			field_name = "doldelete_total")


	if @tmp_total = 0		/* Avoid Divide by Zero Errors */
 	begin
		select @rptline = "      Total Rows Deleted              0.0           0.0           0       n/a"
  		exec asemon_print @rptline
 	end
	else
	  begin


		select @tmp_int = value
		  from #tempmonitors
		  where group_name = 'access' and
				field_name = "delete_deferred"


		select @rptline = "      APL Deferred" + space(11) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_int, 10) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
		exec asemon_print @rptline


		/* Calc Direct Deletes as access.delete - access.delete_deferred */


		select @tmp_int2 = value - @tmp_int
		  from #tempmonitors
		  where group_name = 'access' and
				field_name = "delete"


		select @rptline = "      APL Direct" + space(13) +
				str(@tmp_int2 / (@NumElapsedMs / 1000.0),12,1) + 
				space(2) +
				str(@tmp_int2 / convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_int2, 10) + space(5) +
				str(100.0 * @tmp_int2 / @tmp_total,5,1) + @psign
			exec asemon_print @rptline


		select @tmp_int = value
		  from #tempmonitors
		  where group_name = 'dolaccess' and
				field_name = "doldelete_total"


		select @rptline = "      DOL" + space(20) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_int, 10) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
		exec asemon_print @rptline


		exec asemon_print @sum1line 
		select @rptline = "    Total Rows Deleted" + space(7) +
			str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
			space(2) +
			str(@tmp_total / convert(real, @NumXacts),12,1) +
			space(2) +
			str(@tmp_total,10) + space(5) +
			str(100.0 * @tmp_total / @NumXactOps,5,1) + @psign
		exec asemon_print @rptline
	  end


	exec asemon_print @sum3line 
	select @rptline = "    Total Rows Affected " + space(5) +
			str(@NumXactOps / (@NumElapsedMs / 1000.0),12,1) +
			space(2) +
			str(@NumXactOps / convert(real, @NumXacts),12,1) +
			space(2) +
			str(@NumXactOps,10)
	exec asemon_print @rptline
  end		/* else @NumXactOps != 0 */


exec asemon_print @blankline
return 0

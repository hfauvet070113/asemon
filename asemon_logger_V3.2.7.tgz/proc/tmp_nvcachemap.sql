create table #nvcachemap (
	ssid smallint,
        name varchar(255),
	group_name varchar(255))

create table #asemon_print (id int identity, msg varchar(512) null)

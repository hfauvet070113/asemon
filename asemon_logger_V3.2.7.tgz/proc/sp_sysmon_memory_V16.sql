/* This stored procedure produces a report containing a summary of
** memory use within the SQL server's pool of available memory.
*/
create procedure sp_sysmon_memory_V16
	@NumElapsedMs int,	/* for "per Elapsed second" calculations */
	@NumXacts int		/* for per transactions calculations */
as


/* --------- declare local variables --------- */
declare @tmp_int int		/* temp var for integer storage */
declare @sum1line char(80)	/* string to delimit total lines without 
				percent calc on printout */	
declare @blankline char(1)	/* to print blank line */
declare @na_str char(3)		/* holds 'n/a' for 'not applicable' strings */
declare @rptline char(80)	/* formatted stats line for print statement */
declare @section char(80)	/* string to delimit sections on printout */


/* --------- Setup Environment --------- */
set nocount on			/* disable row counts being sent to client */


select @sum1line   = "---------------------------  ------------  ------------  ----------  ----------"
select @blankline  = " "
select @na_str     = "n/a"
select @section = "==============================================================================="


print @section
print @blankline


print "Memory Management                 per sec      per xact       count  %% of total"
print @sum1line


select @tmp_int = value
  from #tempmonitors
  where group_name = "memory" and
		field_name = "mempages_alloced"


select @rptline = "  Pages Allocated" + space(12) +
			str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) + 
			space(2) +
			str(@tmp_int / convert(real, @NumXacts),12,1) + 
			space(2) +
			str(@tmp_int, 10) + space(7) +
			@na_str
print @rptline


select @tmp_int = value
  from #tempmonitors
  where group_name = "memory" and
		field_name = "mempages_freed"


select @rptline = "  Pages Released" + space(13) +
			str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) + 
			space(2) +
			str(@tmp_int / convert(real, @NumXacts),12,1) + 
			space(2) +
			str(@tmp_int, 10) + space(7) +
			@na_str
print @rptline


print @blankline
return 0

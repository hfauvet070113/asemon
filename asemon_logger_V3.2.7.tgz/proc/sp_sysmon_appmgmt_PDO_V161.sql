/* This stored procedure produces a report describing the scheduling
** of user tasks.
**
*/
create procedure sp_sysmon_appmgmt_PDO_V161


        @NumEngines smallint,    /* number of engines online */
        @NumElapsedMs int,      /* for "per Elapsed second" calculations */
        @NumXacts int,           /* for per transactions calculations */
        @applmon char(14)	/* Application monitoring option */
as


/* --------- declare local variables --------- */
declare @i smallint             /* loop index to iterate through multi-group 
                                ** counters (engine, disk, & buffer) */
declare @tmp_grp varchar(25)    /* temp var for building group_names 
                                ** ie. engine_N, disk_N */
declare @appl_name varchar(80)  /* application name */
declare @tmp_int bigint         /* temp var for integer storage */
declare @tmp_total bigint       /* temp var for integer storage, totals */
declare @sum1line char(80)      /* string to delimit total lines without 
                                ** percent calc on printout */  
declare @sum2line char(67)      /* string to delimit total lines with percent 
                                ** calc on printout */
declare @blankline char(1)      /* to print blank line */ 
declare @psign char(3)          /* hold a percent sign (%) for print out */
declare @na_str char(3)         /* holds 'n/a' for 'not applicable' strings */
declare @rptline char(80)       /* formatted stats line for print statement */
declare @section char(80)	/* string to delimit sections on printout */
declare @subsection char(80)	/* string to delimit sections on printout */
declare @applstr char(24)	/* application report string	*/
/* --------- Setup Environment --------- */
set nocount on                  /* disable row counts being sent to client */


select @sum1line   = "  -------------------------  ------------  ------------  ----------  ----------"
select @sum2line   = "  -------------------------  ------------  ------------  ----------"
select @blankline  = " "
select @psign      = " %"              /* extra % symbol because '%' is escape char in print statement */
select @na_str     = "n/a"
select @section    = "==============================================================================="
select @subsection = "-------------------------------------------------------------------------------"




/* =========================  Application Management Section ==================== */
if not exists(select *
                from #tempmonitors
                where group_name = "kernel" and
                field_name = "priority_med")
begin
        exec asemon_print @blankline
        return 0
end


exec asemon_print @section
exec asemon_print @blankline
exec asemon_print "Application Management"
exec asemon_print "----------------------"
exec asemon_print @blankline
/*
** ------ 
*/
exec asemon_print "  Application Statistics Summary (All Applications)"
exec asemon_print "  -------------------------------------------------"
exec asemon_print "  Priority Changes                per sec      per xact       count  % of total"
exec asemon_print @sum1line
select @tmp_total = SUM(convert(bigint, value))
  from #tempmonitors
  where group_name like "kernel"
        and field_name in ("priority_high", "priority_med", "priority_low")


if @tmp_total = 0       /* Avoid divide by zero errors - just print zero's */
 begin
	select @rptline = "  Total Priority Changes              0.0           0.0           0       n/a"
  	exec asemon_print @rptline
	exec asemon_print @blankline
 end
else
begin


	select @tmp_int = value
		from #tempmonitors
		where group_name = "kernel" and
       		   field_name = "priority_high"


	select @rptline = "    To High Priority" + space(9) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
	exec asemon_print @rptline
	select @tmp_int = value
		from #tempmonitors
		where group_name = "kernel" and
       		   field_name = "priority_med"


	select @rptline = "    To Medium Priority" + space(7) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
	exec asemon_print @rptline
	select @tmp_int = value
	from #tempmonitors
	where group_name = "kernel" and
          field_name = "priority_low"


	select @rptline = "    To Low Priority" + space(10) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign


	exec asemon_print @rptline


	exec asemon_print @sum2line
	select @rptline = "  Total Priority Changes" + space(5) +
                        str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) + 
                        space(2) +
                        str(@tmp_total / convert(real, @NumXacts),12,1) + 
                        space(2) +
                        str(@tmp_total,10) 
	exec asemon_print @rptline
	exec asemon_print @blankline
end


select @tmp_total = SUM(convert(bigint, value))
  		from #tempmonitors
  		where group_name like "kernel"
       		 and field_name in ("tslice_high", "tslice_med", "tslice_low")


exec asemon_print "  Allotted Slices Exhausted       per sec      per xact       count  % of total"
exec asemon_print @sum1line
if @tmp_total = 0       /* Avoid divide by zero errors - just print zero's */
 begin
	select @rptline = "  Total Slices Exhausted              0.0           0.0           0       n/a"
  	exec asemon_print @rptline
 end
else
begin
        select @tmp_int = value
        from #tempmonitors
        where group_name = "kernel" and
                  field_name = "tslice_high"
        
        select @rptline = "    High Priority" + space(12) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
        exec asemon_print @rptline
        select @tmp_int = value
        from #tempmonitors
        where group_name = "kernel" and
                  field_name = "tslice_med"
        
        select @rptline = "    Medium Priority" + space(10) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
        exec asemon_print @rptline
        select @tmp_int = value
        from #tempmonitors
        where group_name = "kernel" and
                  field_name = "tslice_low"
        
        select @rptline = "    Low Priority" + space(13) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
        exec asemon_print @rptline


	exec asemon_print @sum2line
	select @rptline = "  Total Slices Exhausted  " + space(3) +
                        str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) + 
                        space(2) +
                        str(@tmp_total / convert(real, @NumXacts),12,1) + 
                        space(2) +
                        str(@tmp_total,10) 
	exec asemon_print @rptline
end
exec asemon_print @blankline
exec asemon_print "  Skipped Tasks By Engine         per sec      per xact       count  % of total"
exec asemon_print @sum1line


select @tmp_total = SUM(convert(bigint, value))
  from #tempmonitors
  where group_name like "engine_%" and
        field_name = "incompatible_engine_task"


if @tmp_total = 0       /* Avoid divide by zero errors - just print zero's */
 begin
        select @rptline = "  Total Engine Skips                  0.0           0.0           0       n/a"
  	exec asemon_print @rptline
 end
else
  begin
        select @i = 0
        while @i < @NumEngines          /* for each engine */
          begin
                /* build group_name string */
                select @tmp_grp= "engine_" + convert(varchar(4), @i) 


		/* If an engine's clock_ticks counter is 0, this means this engine
		** is in offline status. We should skip this engine when priting
		** the statistic information.
		*/
		if (select value
			from #tempmonitors where field_name="clock_ticks"
				and group_name=@tmp_grp) > 0
		begin
                	select @tmp_int = value
                  	from #tempmonitors
                  	where group_name = @tmp_grp and
                            field_name = "incompatible_engine_task"


             		select @rptline = "    Engine " + convert(char(4),@i) + 
                                        space(14) +
                                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) 
                                        + space(2) +
                                        str(@tmp_int / convert(real, @NumXacts),12,1) 
                                        + space(1) +
                                        str(@tmp_int, 11) + space(5) +
                                        str(100.0 * @tmp_int / @tmp_total,5,1) 
                                        + @psign
        	        exec asemon_print @rptline
		end
               select @i = @i + 1
          end


        if @NumEngines > 1
          begin
                exec asemon_print @sum2line 
                select @rptline = "  Total Engine Skips " + space(8) +
                                        str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) 
                                        + space(2) +
                                        str(@tmp_total / convert(real,@NumXacts),12,1) 
                                        + space(2) + str(@tmp_total,10)
                exec asemon_print @rptline
          end
  end
exec asemon_print @blankline


select @tmp_int = value
from #tempmonitors
where group_name = "kernel" and
          field_name = "calls_to_upsetenginemask"


select @rptline = "  Engine Scope Changes" + space(7) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) + 
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) + 
                        space(1) +
                        str(@tmp_int,11) + space(7) +
                        @na_str
exec asemon_print @rptline
exec asemon_print @blankline


/* 
** If application monitoring was not requested
** return, otherwise, create a temporary table
** of application counters, based on application 
** monitoring option
*/


if (@applmon = "no_appl")
 begin
	return 0
 end
else 
 begin
	select field_name,group_name, value
	into #tempappl 
	from #tempmonitors
	where 1=2
	
	if (@applmon = "appl_only")
	 begin
		insert into #tempappl
			select isnull(substring(field_name,1,
						patindex("%->%",field_name)-1),
						"Unknown")
				as field_name, group_name, value
          		from #tempmonitors
          		where group_name like "appl_%" and field_name is not null


        	select @applstr = space(2) + "Application: "
	 end


	else if (@applmon = "appl_and_login")
 	 begin
		insert into #tempappl
        		select field_name, group_name, value
          		from #tempmonitors
          		where group_name like "appl_%" and field_name is not null
        	select @applstr = space(2) + "Application->Login: "
	 end
 end


/*
** Declare cursor for fetching application specific statistics
*/
declare appl_stats cursor for
   select distinct field_name
   from #tempappl
   for read only
open appl_stats
fetch appl_stats into @appl_name


while (@@sqlstatus = 0)
 begin
        exec asemon_print @subsection
        select @rptline = @applstr + @appl_name
        exec asemon_print @rptline
        exec asemon_print @blankline
        exec asemon_print "  Application Activity            per sec      per xact       count  % of total"
        exec asemon_print @sum2line


        select @tmp_total = SUM(convert(bigint, value))
                from #tempappl
        where group_name like "appl_%_ticks%"
        and field_name = @appl_name 
	
        if @tmp_total = 0       /* Avoid divide by zero errors - just print zero's */
         begin
                select @rptline = "  Total Activity                      0.0           0.0           0       n/a"
                exec asemon_print @rptline
                exec asemon_print @blankline
         end
	else
	 begin
			select @tmp_int = SUM(convert(bigint, value))
                		from #tempappl
        			where group_name like "appl_cpu_ticks%"
          			and field_name = @appl_name   	


       			select @rptline = "    CPU Busy" + space(17) +   
         			str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                		space(2) +
                		str(@tmp_int / convert(real, @NumXacts),12,1) +
                		space(1) +
 				str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) + @psign      
			exec asemon_print @rptline
			select @tmp_int = SUM(convert(bigint, value))
                		from #tempappl
        			where group_name like "appl_io_ticks%"
          			and field_name = @appl_name   	
       			select @rptline = "    I/O Busy" + space(17) +   
         			str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                		space(2) +
                		str(@tmp_int / convert(real, @NumXacts),12,1) +
                		space(1) +
 				str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) + @psign      
			exec asemon_print @rptline
			select @tmp_int = SUM(convert(bigint, value))
                		from #tempappl
        			where group_name like "appl_idle_ticks%"
          			and field_name = @appl_name   	
       			select @rptline = "    Idle    " + space(17) +   
         			str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                		space(2) +
                		str(@tmp_int / convert(real, @NumXacts),12,1) +
                		space(1) +
 				str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) + @psign      
			exec asemon_print @rptline
	 end


        exec asemon_print @blankline
        select @tmp_int = SUM(convert(bigint, value))
        from #tempappl
        where group_name like "appl_sched_count%"
        and field_name = @appl_name


        select @rptline = "    Number of Times Scheduled" + 
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                        	str(@tmp_int,11) + space(7) +
                        	@na_str
        exec asemon_print @rptline
        exec asemon_print @blankline


	exec asemon_print "  Application Priority Changes    per sec      per xact       count  % of total"
	exec asemon_print @sum1line
	select @tmp_total = SUM(convert(bigint, value))
  	from #tempappl
  	where group_name like "appl_%_pri%"
        and field_name = @appl_name


	if @tmp_total = 0       /* Avoid divide by zero errors - just print zero's */
	 begin
        	select @rptline = "  Total Priority Changes              0.0           0.0           0       n/a"
        	exec asemon_print @rptline
        	exec asemon_print @blankline
 	 end
	else
	 begin


        	select @tmp_int = sum(convert(bigint, value))
               	 from #tempappl
  			where group_name like "appl_hi_pri%"
        		and field_name = @appl_name


        	select @rptline = "    To High Priority" + space(9) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
        	exec asemon_print @rptline
        	select @tmp_int = sum(convert(bigint, value))
               		 from #tempappl
  			where group_name like "appl_med_pri%"
        		and field_name = @appl_name


        	select @rptline = "    To Medium Priority" + space(7) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
        	exec asemon_print @rptline
                select @tmp_int = sum(convert(bigint, value))
                         from #tempappl
                        where group_name like "appl_low_pri%"
                        and field_name = @appl_name


                select @rptline = "    To Low Priority" + space(10) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
                exec asemon_print @rptline
		exec asemon_print @sum2line
        	select @rptline = "  Total Priority Changes" + space(5) +
                        str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_total / convert(real, @NumXacts),12,1) +
                        space(2) +
                        str(@tmp_total,10)
        	exec asemon_print @rptline
        	exec asemon_print @blankline
	 end


        exec asemon_print "  Application I/Os Completed     per sec      per xact       count  % of total"
        exec asemon_print @sum1line
        select @tmp_total = SUM(convert(bigint, value))
        from #tempappl
        where group_name like "appl_%io_count%"
        and field_name = @appl_name


        if @tmp_total = 0       /* Avoid divide by zero errors - just print zero's */
         begin
                select @rptline = "  Total I/Os Completed                0.0           0.0           0       n/a"
                exec asemon_print @rptline
                exec asemon_print @blankline
         end
        else
         begin


                select @tmp_int = sum(convert(bigint, value))
                 from #tempappl
                        where group_name like "appl_disk_io_count%"
                        and field_name = @appl_name


                select @rptline = "    Disk I/Os Completed" + space(6) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
                exec asemon_print @rptline
                select @tmp_int = sum(convert(bigint, value))
                         from #tempappl
                        where group_name like "appl_net_io_count%"
                        and field_name = @appl_name


                select @rptline = "    Network I/Os Completed" + space(3) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
                exec asemon_print @rptline
                exec asemon_print @sum2line
                select @rptline = "  Total I/Os Completed" + space(7) +
                        str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_total / convert(real, @NumXacts),12,1) +
                        space(2) +
                        str(@tmp_total,10)
                exec asemon_print @rptline
                exec asemon_print @blankline


	 end




        exec asemon_print "  Resource Limits Violated	per sec      per xact       count  % of total"
        exec asemon_print @sum1line


        select @tmp_total = SUM(convert(bigint, value))
                from #tempappl
        where group_name like "%appl_%_lim_xcd%"
        and field_name = @appl_name 
	
        if (@tmp_total = 0) or (@tmp_total is null)       /* Avoid divide by zero errors - just print zero's */
         begin
                select @rptline = "  Total Limits Violated               0.0           0.0           0       n/a"
                exec asemon_print @rptline
                exec asemon_print @blankline
         end
	else
	 begin


			select @tmp_int = SUM(convert(bigint, value))
                		from #tempappl
        			where group_name like "appl_est_io_lim_xcd%"
          			and field_name = @appl_name   	


       			select @rptline = "    IO Limit Violations" 
			exec asemon_print @rptline
       			select @rptline = "      Estimated" + space(14) +   
         			str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                		space(2) +
                		str(@tmp_int / convert(real, @NumXacts),12,1) +
                		space(1) +
 				str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) + @psign      
			exec asemon_print @rptline




			select @tmp_int = SUM(convert(bigint, value))
                		from #tempappl
        			where group_name like "appl_act_io_lim_xcd%"
          			and field_name = @appl_name   	


       			select @rptline = "      Actual" + space(17) +   
         			str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                		space(2) +
                		str(@tmp_int / convert(real, @NumXacts),12,1) +
                		space(1) +
 				str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) + @psign      
			exec asemon_print @rptline
                	exec asemon_print @blankline




			select @tmp_int = SUM(convert(bigint, value))
                		from #tempappl
        			where group_name like "appl_batch_et_lim_xcd%"
          			and field_name = @appl_name   	


       			select @rptline = "    Time Limit Violations"
       			exec asemon_print @rptline


                	select @rptline = "      Batch" + space(18) +
         			str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                		space(2) +
                		str(@tmp_int / convert(real, @NumXacts),12,1) +
                		space(1) +
 				str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) + @psign      
			exec asemon_print @rptline




			select @tmp_int = SUM(convert(bigint, value))
                		from #tempappl
        			where group_name like "appl_xact_et_lim_xcd%"
          			and field_name = @appl_name   	


                	select @rptline = "      Xact" + space(19) +
         			str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                		space(2) +
                		str(@tmp_int / convert(real, @NumXacts),12,1) +
                		space(1) +
 				str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) + @psign      
			exec asemon_print @rptline
                	exec asemon_print @blankline




			select @tmp_int = SUM(convert(bigint, value))
                		from #tempappl
        			where group_name like "appl_rowcount_lim_xcd%"
          			and field_name = @appl_name   	


       			select @rptline = "    RowCount Limit Violations" +
         			str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                		space(2) +
                		str(@tmp_int / convert(real, @NumXacts),12,1) +
                		space(1) +
 				str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) + @psign      
			exec asemon_print @rptline


                	exec asemon_print @sum2line
                	select @rptline = "  Total Limits Violated" + space(6) +
                        	str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
                        	space(2) +
                        	str(@tmp_total / convert(real, @NumXacts),12,1) +
                        	space(2) +
                        	str(@tmp_total,10)
                	exec asemon_print @rptline
                	exec asemon_print @blankline
	 end


	fetch appl_stats into @appl_name
	
 end
return 0

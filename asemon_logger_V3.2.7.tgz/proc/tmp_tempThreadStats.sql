create table #tempThreadStats (         
        InstanceID int,                 
        ThreadID int,                   
        ThreadPoolID int,               
        MinorFaults bigint,             
        MajorFaults bigint,             
        UserTime bigint,                
        SystemTime bigint,              
        VoluntaryCtxtSwitches bigint,   
        NonVoluntaryCtxtSwitches bigint,
        TaskName varchar(30) null)
create table #devicemap(name char(40),      
                        phyname char(127),  
                        group_name char(24))
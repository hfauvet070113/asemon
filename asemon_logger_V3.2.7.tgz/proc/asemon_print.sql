create procedure asemon_print @msg varchar(512)
as
insert into #asemon_print(msg) values (@msg)
/* This stored procedure produces a report containing a summary of
** network activity.
*/
create procedure sp_sysmon_netio_V150
	@NumEngines tinyint,	/* number of engines online */
	@NumElapsedMs int,	/* for "per Elapsed second" calculations */
	@NumXacts int,		/* for per transactions calculations */
        @kernelmode  varchar(10)       /* added for asemon_report */
as


/* --------- declare local variables --------- */
declare @i smallint		/* loop index to iterate through multi-group 
				** counters (engine, disk, & buffer) */
declare @tmp_grp varchar(25)	/* temp var for build group_names 
				** ie. engine_N, disk_N */
declare @tmp_int int		/* temp var for integer storage */
declare @tmp_int2 int		/* temp var for integer storage */
declare @tmp_total int		/* temp var for summing 'total #s' data */
declare @sum1line char(80)	/* string to delimit total lines without 
				** percent calc on printout */	
declare @sum2line char(80)	/* string to delimit total lines without 
				** percent calc on printout */	
declare @subsection char(80)	/* delimit disk sections */
declare @blankline char(1)	/* to print blank line */
declare @psign char(3)		/* hold a percent sign (%) for print out */
declare @na_str char(3)		/* holds 'n/a' for 'not applicable' strings */
declare @rptline char(80)	/* formatted stats line for print statement */
declare @section char(80)	/* string to delimit sections on printout */


/* --------- Setup Environment --------- */
set nocount on			/* disable row counts being sent to client */


select @sum1line   = "  -------------------------  ------------  ------------  ----------  ----------"
select @sum2line   = "  -------------------------  ------------  ------------  ----------"
select @subsection = "  -----------------------------------------------------------------------------"
select @blankline  = " "
select @psign      = " %%"		/* extra % symbol because '%' is escape char in print statement */
select @na_str     = "n/a"
select @section = "==============================================================================="


print @section
print @blankline
print "Network I/O Management"
print "----------------------"
print @blankline


select @tmp_total = value
  from #tempmonitors
  where group_name = "kernel" and
		field_name = "ksalloc_calls"


select @rptline = "  Total Network I/O Requests " + 
			str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) + 
			space(2) +
			str(@tmp_total / convert(real, @NumXacts),12,1) + 
			space(2) +
			str(@tmp_total, 10) + space(7) +
			@na_str
print @rptline


if @tmp_total != 0
  begin
	select @tmp_int = value
	  from #tempmonitors
	  where group_name = "kernel" and
			field_name = "ksalloc_sleeps"


	select @rptline = "    Network I/Os Delayed" + space(5) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_int, 10) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
	print @rptline
  end
print @blankline
print @blankline


print "  Total TDS Packets Received      per sec      per xact       count  %% of total"
print @sum1line


select @tmp_total = SUM(value)
  from #tempmonitors
  where group_name like "engine_%" and
		field_name = "no_packets_received"


if @tmp_total = 0
 begin
	select @rptline = "  Total TDS Packets Rec'd             0.0           0.0           0       n/a"
  	print @rptline
 end
else
  begin
	select @i = 0
	while @i < @NumEngines		/* for each engine */
	  begin
		/* build group_name string */
		select @tmp_grp = "engine_" + convert(varchar(2), @i)
  
		select @tmp_int = value
		  from #tempmonitors
		  where group_name = @tmp_grp and
				field_name = "no_packets_received"
  
		select @rptline = "    Engine " + convert(char(2), @i) + 
				space(16) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_int, 10) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
		print @rptline


		select @i = @i + 1
	  end	/* while loop */


	print @sum2line


	select @rptline = "  Total TDS Packets Rec'd" + space(4) +
			str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) + 
			space(2) +
			str(@tmp_total / convert(real, @NumXacts),12,1) + 
			space(2) +
			str(@tmp_total, 10)
	print @rptline
  end
print @blankline
print @blankline


/* 
** save total packets rec'd for avg bytes / pkt calc 
*/ 
select @tmp_int2 = @tmp_total	


print "  Total Bytes Received            per sec      per xact       count  %% of total"
print @sum1line


select @tmp_total = SUM(value)
  from #tempmonitors
  where group_name like "engine_%" and
		field_name = "no_bytes_received"


if @tmp_total = 0
 begin
	select @rptline = "  Total Bytes Rec'd                   0.0           0.0           0       n/a"
  	print @rptline
 end
else
  begin
	select @i = 0
	while @i < @NumEngines		/* for each engine */
	  begin
		/* build group_name string */
		select @tmp_grp = "engine_" + convert(varchar(2), @i)
  
		select @tmp_int = value
		  from #tempmonitors
		  where group_name = @tmp_grp and
				field_name = "no_bytes_received"
  
		select @rptline = "    Engine " + convert(char(2), @i) + 
				space(16) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_int, 10) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
		print @rptline


		select @i = @i + 1
	  end	/* while loop */


	print @sum2line


	select @rptline = "  Total Bytes Rec'd" + space(10) +
			str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) + 
			space(2) +
			str(@tmp_total / convert(real, @NumXacts),12,1) + 
			space(2) +
			str(@tmp_total, 10)
	print @rptline
  end	/* else */
print @blankline
print @blankline


if @tmp_int2 != 0		/* Avoid divide by zero. */
  begin
	select @rptline = "   Avg Bytes Rec'd per Packet" + space(10) +
				@na_str + space(11) +
				@na_str + space(2) +
				str(@tmp_total / @tmp_int2, 10) + space(7) +
				@na_str
	print @rptline
	print @blankline
  end
print @subsection
print @blankline


print "  Total TDS Packets Sent          per sec      per xact       count  %% of total"
print @sum1line


select @tmp_total = SUM(value)
  from #tempmonitors
  where group_name like "engine_%" and
		field_name = "no_packets_sent"


if @tmp_total = 0
 begin
	select @rptline = "  Total TDS Packets Sent              0.0           0.0           0       n/a"
  	print @rptline
 end
else
  begin
	select @i = 0
	while @i < @NumEngines		/* for each engine */
	  begin
		/* build group_name string */
		select @tmp_grp = "engine_" + convert(varchar(2), @i)
  
		select @tmp_int = value
		  from #tempmonitors
		  where group_name = @tmp_grp and
				field_name = "no_packets_sent"
  
		select @rptline = "    Engine " + convert(char(2), @i) + 
				space(16) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_int, 10) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
		print @rptline


		select @i = @i + 1
	  end	/* while loop */


	print @sum2line


	select @rptline = "  Total TDS Packets Sent" + space(5) +
			str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) + 
			space(2) +
			str(@tmp_total / convert(real, @NumXacts),12,1) + 
			space(2) +
			str(@tmp_total, 10)
	print @rptline
  end	/* else */
print @blankline
print @blankline


/* save total packets sent for avg bytes / pkt calc */ 
select @tmp_int2 = @tmp_total


print "  Total Bytes Sent                per sec      per xact       count  %% of total"
print @sum1line


select @tmp_total = SUM(value)
  from #tempmonitors
  where group_name like "engine_%" and
		field_name = "no_bytes_sent"


if @tmp_total = 0
 begin
	select @rptline = "  Total Bytes Sent                    0.0           0.0           0       n/a"
  	print @rptline
 end
else
  begin
	select @i = 0
	while @i < @NumEngines		/* for each engine */
	  begin
		/* build group_name string */
		select @tmp_grp = "engine_" + convert(varchar(2), @i)
  
		select @tmp_int = value
		  from #tempmonitors
		  where group_name = @tmp_grp and
				field_name = "no_bytes_sent"
  
		select @rptline = "    Engine " + convert(char(2), @i) + 
				space(16) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_int, 10) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
		print @rptline


		select @i = @i + 1
	  end	/* while loop */


	print @sum2line


	select @rptline = "  Total Bytes Sent" + space(11) +
			str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) + 
			space(2) +
			str(@tmp_total / convert(real, @NumXacts),12,1) + 
			space(2) +
			str(@tmp_total, 10)
	print @rptline
  end	/* else */
print @blankline
print @blankline


if @tmp_int2 != 0 		/* Avoid divide by zero. */
  begin
	select @rptline = "  Avg Bytes Sent per Packet" + space(11) +
					@na_str + space(11) +
					@na_str + space(2) +
					str(@tmp_total / @tmp_int2, 10) + 
					space(7) +
					@na_str
	print @rptline
	print @blankline
  end


return 0

create procedure sp_sysmon_nvcache_dtl_PDO_V16SP3
        @NumEngines smallint,    /* number of engines online */
        @NumElapsedMs int,      /* for "per Elapsed second" calculations */
        @NumXacts int,          /* for per transactions calculations */
        @Reco   char(1)         /* Flag for recommendations             */
as

/* ------------- Declare Local Variables --------- */
declare @CacheName	varchar(255)	/* Cache Name from cache id lookup */
declare @CacheID	smallint	/* Cache ID to map to buffer_N group */
declare @TotalSearches	bigint   	/* Total Cache Searches on All Caches */
declare @subsection	char(80)	/* string to delimit subsections on printout */
declare @sum1line	char(80)	/* string to delimit total lines without
					** percent calc on printout */
declare @sum2line	char(67)	/* string to delimit total lines with
					** percent calc on printout */
declare @blankline	char(1)		/* to print blank line */
declare @psign		char(3)		/* hold a percent sign (%) for print out */
declare @na_str		char(3)		/* holds 'n/a' for 'not applicable' strings */
declare @zero_str	char(80)	/* hold an output string for zero "  0.0" for
					** printing zero "% of total" */
declare @rptline	varchar(530)	/* formatted stats line for print statement */
declare @section	char(80)	/* string to delimit sections on printout */
declare @tmp_grp	varchar(25)	/* temp var for build group_name's
					** ie. engine_N, disk_N */
declare @tmp_int	bigint		/* temp var for integer storage */
declare @tmp_int2	int		/* temp var for integer storage */
declare @tmp_int3	int		/* temp var for integer storage */
declare @tmp_int4	int		/* temp var for integer storage */
declare @tmp_total	bigint		/* temp var for summing 'total #s' data */
declare @tmp_float	float		/* temp var for float storage */
declare @tmp_float2	float		/* temp var for float storage */

/* ------------- Variables for Tuning Recommendations ------------*/
declare @spinlock_contention	float
declare @recotxt		varchar(300)
declare @recoline		char(80)
declare @reco_hdr_prn		bit

/* ------------- Setup Environment --------- */
set nocount on			/* disable row counts being sent to client */

select @subsection = "-------------------------------------------------------------------------------"
select @sum1line   = "  -------------------------  ------------  ------------  ----------  ----------"
select @sum2line   = "  -------------------------  ------------  ------------  ----------"
select @blankline  = " "
select @psign      = " %"              /* extra % symbol because '%' is escape char in print statement */
select @na_str     = "n/a"
select @zero_str   = "                                      0.0           0.0           0       n/a"
select @section = "==============================================================================="

/*
** create a temp table for cache information. We should not be iterating on system catalogs (sysconfigures)
** while reporting monitoring counters. Also the temp table might be useful in future.
*/

/*
   modif asemon (table #nvcachemap is populated thru collector SysNVCach)
if ((select object_id("#nvcachemap")) is not NULL)
begin
	drop table #nvcachemap
end

create table #nvcachemap (
	ssid smallint,
        name varchar(255),
	group_name varchar(255))
*/


/* Total Searches across all caches */
select @TotalSearches = SUM(convert(bigint, value))
  from #tempmonitors
  where group_name like "nvbuffer_%" and
                field_name = "nvcache_searches"
/*
** Iterate sysconfigures for NV Cache definitions and populate #nvcachemap
*/

/*
   modif asemon
declare cache_info cursor for
select name from master..sysconfigures
	where config = 53 and parent = 53

open cache_info
fetch cache_info into @CacheName

while (@@sqlstatus = 0)
begin
        select @CacheID = config_admin(39,0,0,0,NULL,@CacheName)
	insert into #nvcachemap values (@CacheID, @CacheName, "nvbuffer_" + convert(varchar(3), @CacheID))
	fetch cache_info into @CacheName
end

close cache_info
deallocate cursor cache_info
*/

/*
** Get all Spinlock related counters and cache names
** for printing potential spinlock contention.
*/
select  P.field_name as name,
	P.value as grabs,
	W.value as waits,
	S.value as spins into #nvspinlocks
from #tempmonitors P, #tempmonitors W, #tempmonitors S
where
	    P.group_name = "spinlock_p"
	and W.group_name = "spinlock_w"
	and S.group_name = "spinlock_s"
	and P.field_id = W.field_id
	and P.field_id = S.field_id
	and P.field_name in ( select name from #nvcachemap )

/* Use cursor to iterate cache definitions stored in temp table */
declare cache_info cursor for
	select ssid, name, group_name
	  from #nvcachemap
	  order by name
	  for read only

open cache_info
fetch cache_info into @CacheID, @CacheName, @tmp_grp
while (@@sqlstatus = 0)	/* { */
begin
	exec asemon_print @subsection
	select @rptline = space(2) + "Cache: " + @CacheName
	exec asemon_print @rptline
	exec asemon_print "                                  per sec      per xact       count  % of total"
	exec asemon_print @sum1line

	select @spinlock_contention =
			isnull(100.0*(sum(convert(float,waits))/sum
				(case when grabs >= 0 then convert(float,grabs)
				else (power(2.0,32) + convert(float,grabs)) end)), 0)
	from #nvspinlocks
	where name = @CacheName
	and grabs != 0

	/* ----------------- Spinlock Contention ------------- */
	select @rptline = "    Spinlock Contention" + space(15) +
						@na_str + space(11) +
						@na_str + space(9) +
						@na_str + space(5) +
						str( @spinlock_contention,5,1)
							+ @psign
	exec asemon_print @rptline
	exec asemon_print @blankline

	/* ----------------- Cache Utilization ---------------- */
	if @TotalSearches != 0
	  begin
		select @tmp_int = value
		  from #tempmonitors
		  where group_name = @tmp_grp and
				field_name = "nvcache_searches"

		select @rptline = "    Utilization " + space(22) +
						@na_str + space(11) +
						@na_str + space(9) +
						@na_str + space(5) +
						str(100.0 * @tmp_int /
							@TotalSearches,5,1) +
						@psign

		exec asemon_print @rptline
		exec asemon_print @blankline
	  end

	/* -------------Cache Searches, Hits, Misses ---------- */
	exec asemon_print "    Cache Searches"

	select @tmp_total = value
	  from #tempmonitors
	  where group_name = @tmp_grp and
			field_name = "nvcache_searches"

	if @tmp_total = 0		/* Avoid Divide by Zero Errors */
 	begin
		select @rptline = "      Total Cache Searches            0.0           0.0           0       n/a"
  		exec asemon_print @rptline
 	end
	else
	  begin	/* { */

		select @tmp_int = value
		  from #tempmonitors
		  where group_name = @tmp_grp and
				field_name = "nvcache_hits"

		select @rptline = "      Cache Hits" + space(13) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(1) +
				str(@tmp_int, 11) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) +
				@psign
		exec asemon_print @rptline

		/* save hits for wash % and missed calc */
		select @tmp_int2 = @tmp_int

		select @tmp_int = @tmp_total - @tmp_int2  /* missed searches */

		select @rptline = "      Cache Misses" + space(11) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(1) +
				str(@tmp_int, 11) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) +
				@psign
		exec asemon_print @rptline
	end	/* } else @tmp_total = 0 */
	exec asemon_print @sum2line
	select @rptline = "    Total Cache Searches" + space(5) +
			str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
			space(2) +
			str(@tmp_total / convert(real, @NumXacts),12,1) +
			space(2) +
			str(@tmp_total,10)
	exec asemon_print @rptline

	/* -------------------- Grab Related Reports --------------------- */

	exec asemon_print @blankline
	exec asemon_print "    Cache Turnover"
	select	@tmp_total = value
	from	#tempmonitors
	where   group_name = @tmp_grp and
	field_name = "nvcache_grabs"
	select @rptline = "      Buffer Grabs" + space(11) +
			str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
			space(2) +
			str(@tmp_total / convert(real, @NumXacts),12,1) +
			space(1) +
			str(@tmp_total, 11) + space(7) +
			@na_str
	exec asemon_print @rptline

	if @tmp_total != 0			/* Avoid Divide by Zero Errors */
	  begin	/* { */

		/* Number of times grabbing a buffer in NV cache failed */
		select @tmp_int = SUM(convert(bigint, value))
		  from #tempmonitors
		  where group_name = @tmp_grp and
				field_name = "nvcache_grabfails"

		select @rptline = "      Failed Buffer Grabs" + space(4) +
					str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
					space(2) +
					str(@tmp_int / convert(real, @NumXacts),12,1) +
					space(1) +
					str(@tmp_int, 11) + space(5) +
					str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
		exec asemon_print @rptline

		/* Number of times task had to retry inside grab routine to grab a buffer */
		select @tmp_int = SUM(convert(bigint, value))
		  from #tempmonitors
		  where group_name = @tmp_grp and
				field_name = "nvcache_retrygrab"

		select @rptline = "      Buffer Grabs Retries" + space(3) +
					str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
					space(2) +
					str(@tmp_int / convert(real, @NumXacts),12,1) +
					space(1) +
					str(@tmp_int, 11) + space(5) +
					str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
		exec asemon_print @rptline

		/* Average number of buffers skipped when a grab succeeded */
		select @tmp_int = SUM(convert(bigint, value))
		  from #tempmonitors
		  where group_name = @tmp_grp and
				field_name = "nvcache_skipped_bufs"

		select @rptline = "      Grab Effort" + space(12) +
					str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
					space(2) +
					str(@tmp_int / convert(real, @NumXacts),12,1) +
					space(1) +
					str(@tmp_int, 11) + space(7) +
					@na_str
		exec asemon_print @rptline

		/* Number of times task grabbing buffer had to pause */
		select @tmp_int = value
		  from #tempmonitors
		  where group_name = @tmp_grp and
				field_name = "nvcache_grabpauses"

		select @rptline = "      Pauses During Grab" + space(5) +
					str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
					space(2) +
					str(@tmp_int / convert(real, @NumXacts),12,1) +
					space(1) +
					str(@tmp_int, 11) + space(5) +
					str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
		exec asemon_print @rptline

	  end	/* } */

	/* ------------ Reads and Writes ---------------------- */
	exec asemon_print @blankline
	exec asemon_print "    Cache Device Reads"

	select	@tmp_int = value
	from	#tempmonitors
	where   group_name = @tmp_grp and
	field_name = "nvcache_pagereads"

	select	@tmp_int2 = value
	from	#tempmonitors
	where   group_name = @tmp_grp and
	field_name = "nvcache_metadata_reads"

	select @tmp_total = @tmp_int + @tmp_int2

	if @tmp_total != 0			/* Avoid Divide by Zero Errors */
	  begin	/* { */
		select @rptline = "      Page Reads" + space(13) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(1) +
				str(@tmp_int, 11) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) +
				@psign
		exec asemon_print @rptline

		select @rptline = "      Metadata Reads" + space(9) +
				str(@tmp_int2 / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int2 / convert(real, @NumXacts),12,1) +
				space(1) +
				str(@tmp_int2, 11) + space(5) +
				str(100.0 * @tmp_int2 / @tmp_total,5,1) +
				@psign
		exec asemon_print @rptline

		exec asemon_print @sum2line
		select @rptline = "    Total Reads" + space(14) +
				str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_total / convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_total,10)
		exec asemon_print @rptline
	  end	/* } */

	exec asemon_print @blankline
	exec asemon_print "    Cache Device Writes"

	select	@tmp_int = value
	from	#tempmonitors
	where   group_name = @tmp_grp and
	field_name = "nvcache_pagewrites"

	select	@tmp_int2 = value
	from	#tempmonitors
	where   group_name = @tmp_grp and
	field_name = "nvcache_metadata_writes"

	select	@tmp_int3 = value
	from	#tempmonitors
	where   group_name = @tmp_grp and
	field_name = "nvcache_dirtywrites"

	select	@tmp_int4 = value
	from	#tempmonitors
	where   group_name = @tmp_grp and
	field_name = "nvcache_dualwrites"

	/*
	** All writes are divided as follows:
	**
	** Page writes			@tmp_int
	**	- Dirty Page Writes	@tmp_int3
	**	- Clean Page Writes	@tmp_int - @tmp_int3
	** Meta Data Writes		@tmp_int2
	** ---------------------------------------------------
	** Total Writes			@tmp_int + @tmp_int2
	*/
	select @tmp_total = @tmp_int + @tmp_int2

	if @tmp_total != 0			/* Avoid Divide by Zero Errors */
	  begin	/* { */
		select @rptline = "      Page Writes" + space(12) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(1) +
				str(@tmp_int, 11) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) +
				@psign
		exec asemon_print @rptline

		select @rptline = "        Dirty Page Writes" + space(4) +
				str(@tmp_int3 / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int3 / convert(real, @NumXacts),12,1) +
				space(1) +
				str(@tmp_int3, 11) + space(5) +
				str(100.0 * @tmp_int3 / @tmp_int,5,1) +
				@psign
		exec asemon_print @rptline

		select @rptline = "        Clean Page Writes" + space(4) +
				str((@tmp_int - @tmp_int3)/ (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str((@tmp_int - @tmp_int3) / convert(real, @NumXacts),12,1) +
				space(1) +
				str((@tmp_int - @tmp_int3), 11) + space(5) +
				str(100.0 * (@tmp_int - @tmp_int3) / @tmp_int,5,1) +
				@psign
		exec asemon_print @rptline

		select @rptline = "      Metadata Writes" + space(8) +
				str(@tmp_int2 / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int2 / convert(real, @NumXacts),12,1) +
				space(1) +
				str(@tmp_int2, 11) + space(5) +
				str(100.0 * @tmp_int2 / @tmp_total,5,1) +
				@psign
		exec asemon_print @rptline

		exec asemon_print @sum2line
		select @rptline = "    Total Writes" + space(13) +
				str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_total / convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_total,10)
		exec asemon_print @rptline
		exec asemon_print @sum2line

		select @rptline = "    Dual Writes" + space(14) +
				str(@tmp_int4 / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int4 / convert(real, @NumXacts),12,1) +
				space(1) +
				str(@tmp_int4, 11) + space(5) +
				str(100.0 * @tmp_int4 / @tmp_int,5,1) +
				@psign
		exec asemon_print @rptline
		exec asemon_print @blankline
	  end	/* } */

	/*
	** Page Write skipped being cached in NV cache
	** If page was dirty in main memory cache,
	** 	then page would have been written to HDD
	** If page was clean in main memory cache,
	**	then page would not have been written to HDD
	*/
	exec asemon_print "    Page Write Skipped NV Cache"

	select	@tmp_int = value
	from	#tempmonitors
	where   group_name = @tmp_grp and
	field_name = "nvcache_cleanpage_evict"

	select	@tmp_int2 = value
	from	#tempmonitors
	where   group_name = @tmp_grp and
	field_name = "nvcache_selectivity_failed"

	select	@tmp_int3 = value
	from	#tempmonitors
	where   group_name = @tmp_grp and
	field_name = "nvcache_skip_caching"

	select	@tmp_int4 = value
	from	#tempmonitors
	where   group_name = @tmp_grp and
	field_name = "nvcache_grabfails"

	select @tmp_total = @tmp_int + @tmp_int2 + @tmp_int3 + @tmp_int4

	if @tmp_total != 0			/* Avoid Divide by Zero Errors */
	  begin	/* { */
	        /* NV caching skipped because a clean page was already present in NV cache */
		select @rptline = "      Clean page in NV cache" + space(1) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(1) +
				str(@tmp_int, 11) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) +
				@psign
		exec asemon_print @rptline

		/*
		** NV caching skipped because selectivity failed.
		** Page's access frequence was lower than NV cache's configured threshold
		*/
		select @rptline = "      Selectivity Failed" + space(5) +
				str(@tmp_int2 / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int2 / convert(real, @NumXacts),12,1) +
				space(1) +
				str(@tmp_int2, 11) + space(5) +
				str(100.0 * @tmp_int2 / @tmp_total,5,1) +
				@psign
		exec asemon_print @rptline

		/* NV caching skipped due to directive from layers above NV cache */
		select @rptline = "      Skip NV Caching" + space(8) +
				str(@tmp_int3 / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int3 / convert(real, @NumXacts),12,1) +
				space(1) +
				str(@tmp_int3, 11) + space(5) +
				str(100.0 * @tmp_int3 / @tmp_total,5,1) +
				@psign
		exec asemon_print @rptline

		/* NV caching skipped due to buffer grab failure */
		select @rptline = "      Failed Buffer Grabs" + space(4) +
				str(@tmp_int4 / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int4 / convert(real, @NumXacts),12,1) +
				space(1) +
				str(@tmp_int4, 11) + space(5) +
				str(100.0 * @tmp_int4 / @tmp_total,5,1) +
				@psign
		exec asemon_print @rptline

		exec asemon_print @sum2line
		select @rptline = "    Total Page Write Skips" + space(3) +
				str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_total / convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_total,10)
		exec asemon_print @rptline
		exec asemon_print @blankline

	  end	/* } */

	exec asemon_print @blankline

	/* Number of times user task had to wait on a buffer to write a page to NV cache */
	exec asemon_print "    Page Write Waits"

	/* Write waits because lazy cleaner was cleaning this page */

	/* Write waits because dual write was going on the page */
	exec asemon_print @blankline

	/* ------------ Lazy Cleaning ---------------------- */
	exec asemon_print @blankline
	exec asemon_print "    Lazy Cleaning"

	select	@tmp_total = value
	from	#tempmonitors
	where   group_name = @tmp_grp and
	field_name = "nvcache_lc_cleaned"

	select @rptline = "      Cache Cleans" + space(11) +
			str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
			space(2) +
			str(@tmp_total / convert(real, @NumXacts),12,1) +
			space(1) +
			str(@tmp_total, 11) + space(7)
	exec asemon_print @rptline

	select	@tmp_total = value
	from	#tempmonitors
	where   group_name = @tmp_grp and
	field_name = "nvcache_page_cleans"

	select @rptline = "      Pages Cleaned" + space(10) +
			str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
			space(2) +
			str(@tmp_total / convert(real, @NumXacts),12,1) +
			space(1) +
			str(@tmp_total, 11)
	exec asemon_print @rptline
	exec asemon_print @blankline

	if @Reco = 'Y'
 	begin /* { */
		select @recotxt =   "    Tuning Recommendations for NV Cache : "+@CacheName
		select @recoline =  "    -------------------------------------"
       	 	select @reco_hdr_prn = 0

		/*
		** If Cache Hit Rate is less than 80% and grabs are more than 20%
		** then consider increasing the cache size
		*/
		select @tmp_float = convert(int, (100.0*a.value/b.value))
		from   #tempmonitors a, #tempmonitors b
		where  a.group_name = @tmp_grp and
		  	 b.group_name = @tmp_grp and
			 a.group_name = b.group_name and
			 a.field_name = "nvcache_hits" and
			 b.field_name = "nvcache_searches" and
			 b.value != 0

		if (@tmp_float is not null)
		begin	/* { */
			select @tmp_float2 = 0
			select @tmp_float2 = (100.0*a.value)/b.value
	  		from   #tempmonitors a, #tempmonitors b
	  		where  a.group_name = @tmp_grp and
		  		 b.group_name = @tmp_grp and
				 a.group_name = b.group_name and
				 a.field_name = "nvcache_grabs" and
				 b.field_name = "nvcache_searches" and
				 b.value != 0

			if (@tmp_float2 is null)
				select @tmp_float2 = 0

			if (@tmp_float <= 80.0 and @tmp_float2 >= 20.0)
			begin
				exec asemon_print "    - Consider increase size for this cache."
			end
		end	/* } */

		/*
		** If Dirty Grab ratio is greater then 5%
		** then consider making the NV cache lazy cleaner less aggressive
		** or consider the size ratio of NV caches and main memory caches associated with it
		*/

		select @tmp_float = convert(int, (100.0*a.value/b.value))
		from   #tempmonitors a, #tempmonitors b
		where  a.group_name = @tmp_grp and
		  	 b.group_name = @tmp_grp and
			 a.group_name = b.group_name and
			 a.field_name = "nvcache_dirtygrabs" and
			 b.field_name = "nvcache_grabs" and
			 b.value != 0

		if (@tmp_float is null)
			select @tmp_float = 0

		if (@tmp_float > 5.0)
		begin
			exec asemon_print "    - Consider making NV cache lazy cleaner more aggressive."
			exec asemon_print "    - Or consider ratio of sizes of NV cache and"
			exec asemon_print "      main memory caches associated with it"
		end


		/*
		** If ratio of total meta data writes and total cache writes is more than 10%
		** then consider making the NV cache lazy cleaner less aggressive
		** or consinder the size ratio of NV caches and main memory caches associated with it
		*/

		/* total cache writes = metadata writes + page writes */
		select @tmp_float = convert(int, (100.0*a.value/(a.value + b.value)))
		from   #tempmonitors a, #tempmonitors b
		where  a.group_name = @tmp_grp and
		  	 b.group_name = @tmp_grp and
			 a.group_name = b.group_name and
			 a.field_name = "nvcache_metadata_writes" and
			 b.field_name = "nvcache_pagewrites" and
			 b.value != 0

		if (@tmp_float is null)
			select @tmp_float = 0

		if (@tmp_float > 10.0)
		begin
			exec asemon_print "    - Consider making NV cache lazy cleaner less aggressive."
			exec asemon_print "    - Or consider ratio of sizes of NV cache and"
			exec asemon_print "      main memory caches associated with it"
		end

	end /* } */

	fetch cache_info into @CacheID, @CacheName, @tmp_grp
end			/* } while @@sqlstatus */

close cache_info
deallocate cursor cache_info

/* NVC_TODO(pagarwal): don't drop the table if table required by other procs */
if ((select object_id("#nvcachemap")) is not NULL)
begin
        drop table #nvcachemap
end

return 0

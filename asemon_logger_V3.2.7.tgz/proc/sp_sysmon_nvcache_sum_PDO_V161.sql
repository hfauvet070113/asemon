
/* Stored procedure to produce summary of usage of NV caches */

create procedure sp_sysmon_nvcache_sum_PDO_V161
        @NumEngines smallint,    /* number of engines online */
        @NumElapsedMs int,      /* for "per Elapsed second" calculations */
        @NumXacts int,          /* for per transactions calculations */
        @Reco   char(1),        /* Flag for recommendations             */
	@instid smallint = NULL	/* optional SDC instance id */

as
/* --------- Declare Local Variables --------------- --------- */
declare @TotalSearches	bigint	/* Total Cache Searches on All Caches */
declare @tmp_int	bigint	/* temp var for integer storage */
declare @tmp_int2	int	/* temp var for integer storage */
declare @tmp_int3	int	/* temp var for integer storage */
declare @tmp_int4	int	/* temp var for integer storage */
declare @tmp_total	bigint	/* temp var for summing 'total #s' data */
declare @sum2line char(67)	/* string to delimit total lines with
				** percent calc on printout */
declare @blankline char(1)	/* to print blank line */
declare @psign char(3)		/* hold a percent sign (%) for print out */
declare @na_str char(3)		/* holds 'n/a' for 'not applicable' strings */
declare @zero_str char(80)	/* hold an output string for zero "  0.0" for
				** printing zero "% of total" */
declare @rptline char(80)	/* formatted stats line for print statement */
declare @section char(80)	/* string to delimit sections on printout */

/* --------- Variables for Tuning Recommendations ------------*/

/* --------- Setup Environment --------- */
set nocount on			/* disable row counts being sent to client */

select @sum2line   = "  -------------------------  ------------  ------------  ----------"
select @blankline  = " "
select @psign      = " %"		/* extra % symbol because '%' is escape char in print statement */
select @na_str     = "n/a"
select @zero_str   = "                                      0.0           0.0           0       n/a"
select @section = "==============================================================================="

exec asemon_print @section
exec asemon_print @blankline
exec asemon_print "NV Cache Management"
exec asemon_print "---------------------"
exec asemon_print @blankline
exec asemon_print "  Cache Statistics Summary (All NV Caches)"
exec asemon_print "  ----------------------------------------"
exec asemon_print "                                  per sec      per xact       count  % of total"
exec asemon_print "                             ------------  ------------  ----------  ----------"
exec asemon_print @blankline
exec asemon_print "    Cache Search Summary"

/*
** get total cache searches on all caches
*/
select @TotalSearches = SUM(convert(bigint, value))
  from #tempmonitors
  where group_name like "nvbuffer_%" and
		field_name = "nvcache_searches"

select @tmp_int = SUM(convert(bigint, value))		/* get cache hits on all caches */
  from #tempmonitors
  where group_name like "nvbuffer_%" and
		field_name = "nvcache_hits"

select @tmp_int2 = @TotalSearches - @tmp_int

/* Initilize some variables to avoid divide by zero error */
if @NumElapsedMs = 0
begin
	select @NumElapsedMs = 1
end

if @NumXacts = 0
begin
	select @NumXacts = 1
end

/*-------------------- Cache Searches, Hits and Misses -----------------*/

if @TotalSearches = 0			/* Avoid Divide by Zero Errors */
	exec asemon_print @zero_str
else
  begin	/* { */
	select @rptline = "      Total Cache Hits" + space(7) +
			str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
			space(2) +
			str(@tmp_int / convert(real, @NumXacts),12,1) +
			space(1) +
			str(@tmp_int, 11) + space(5) +
			str(100.0 * @tmp_int / @TotalSearches,5,1) +
			@psign
	exec asemon_print @rptline

	select @rptline="      Total Cache Misses" + space(5) +
			str(@tmp_int2 / (@NumElapsedMs / 1000.0),12,1) +
			space(2) +
			str(@tmp_int2 / convert(real, @NumXacts),12,1) +
			space(1) +
			str(@tmp_int2, 11) + space(5) +
			str(100.0 * @tmp_int2 / @TotalSearches,5,1) +
			@psign
	exec asemon_print @rptline

	exec asemon_print @sum2line
	select @rptline = "    Total Cache Searches" + space(5) +
			str(@TotalSearches / (@NumElapsedMs / 1000.0),12,1) +
			space(2) +
			str(@TotalSearches / convert(real, @NumXacts),12,1) +
			space(2) +
			str(@TotalSearches, 10)
	exec asemon_print @rptline
  end	/* } */

/*-------------------- Cache Turnover: Grabs and Dirty Grabs -----------------*/

exec asemon_print @blankline
exec asemon_print "    Cache Turnover"

select @tmp_total = SUM(convert(bigint, value))
  from #tempmonitors
  where group_name like "nvbuffer_%" and
		field_name = "nvcache_grabs"

select @rptline = "      Buffer Grabs" + space(11) +
			str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
			space(2) +
			str(@tmp_total / convert(real, @NumXacts),12,1) +
			space(1) +
			str(@tmp_total, 11) + space(7) +
			@na_str
exec asemon_print @rptline

if @tmp_total != 0			/* Avoid Divide by Zero Errors */
  begin	/* { */

	/* Number of times grabbing a buffer in NV cache failed */
	select @tmp_int = SUM(convert(bigint, value))
	  from #tempmonitors
	  where group_name like "nvbuffer_%" and
			field_name = "nvcache_grabfails"

	select @rptline = "      Failed Buffer Grabs" + space(4) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(1) +
				str(@tmp_int, 11) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
	exec asemon_print @rptline
  end	/* } */

/*  Reads and Writes */
exec asemon_print @blankline
exec asemon_print "    Cache Device Reads"

select	@tmp_int = value
from	#tempmonitors
where   group_name like "nvbuffer_%" and
field_name = "nvcache_pagereads"

select	@tmp_int2 = value
from	#tempmonitors
where   group_name like "nvbuffer_%" and
field_name = "nvcache_metadata_reads"

select @tmp_total = @tmp_int + @tmp_int2

if @tmp_total != 0			/* Avoid Divide by Zero Errors */
  begin	/* { */
	select @rptline = "      Page Reads" + space(13) +
			str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
			space(2) +
			str(@tmp_int / convert(real, @NumXacts),12,1) +
			space(1) +
			str(@tmp_int, 11) + space(5) +
			str(100.0 * @tmp_int / @tmp_total,5,1) +
			@psign
	exec asemon_print @rptline

	select @rptline = "      Metadata Reads" + space(9) +
			str(@tmp_int2 / (@NumElapsedMs / 1000.0),12,1) +
			space(2) +
			str(@tmp_int2 / convert(real, @NumXacts),12,1) +
			space(1) +
			str(@tmp_int2, 11) + space(5) +
			str(100.0 * @tmp_int2 / @tmp_total,5,1) +
			@psign
	exec asemon_print @rptline

	exec asemon_print @sum2line
	select @rptline = "    Total Reads" + space(14) +
			str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
			space(2) +
			str(@tmp_total / convert(real, @NumXacts),12,1) +
			space(2) +
			str(@tmp_total,10)
	exec asemon_print @rptline
	exec asemon_print @blankline
  end	/* } */

exec asemon_print "    Cache Device Writes"

select	@tmp_int = value
from	#tempmonitors
where   group_name like "nvbuffer_%" and
field_name = "nvcache_pagewrites"

select	@tmp_int2 = value
from	#tempmonitors
where   group_name like "nvbuffer_%" and
field_name = "nvcache_metadata_writes"

select @tmp_total = @tmp_int + @tmp_int2

if @tmp_total != 0			/* Avoid Divide by Zero Errors */
  begin	/* { */
	select @rptline = "      Page Writes" + space(12) +
			str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
			space(2) +
			str(@tmp_int / convert(real, @NumXacts),12,1) +
			space(1) +
			str(@tmp_int, 11) + space(5) +
			str(100.0 * @tmp_int / @tmp_total,5,1) +
			@psign
	exec asemon_print @rptline

	select @rptline = "      Metadata Writes" + space(8) +
			str(@tmp_int2 / (@NumElapsedMs / 1000.0),12,1) +
			space(2) +
			str(@tmp_int2 / convert(real, @NumXacts),12,1) +
			space(1) +
			str(@tmp_int2, 11) + space(5) +
			str(100.0 * @tmp_int2 / @tmp_total,5,1) +
			@psign
	exec asemon_print @rptline
	exec asemon_print @sum2line

	select @rptline = "    Total Writes" + space(13) +
			str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
			space(2) +
			str(@tmp_total / convert(real, @NumXacts),12,1) +
			space(2) +
			str(@tmp_total,10)
	exec asemon_print @rptline
	exec asemon_print @sum2line
  end	/* } */


select	@tmp_int = value
from	#tempmonitors
where   group_name like "nvbuffer_%"  and
field_name = "nvcache_cleanpage_evict"

select	@tmp_int2 = value
from	#tempmonitors
where   group_name  like "nvbuffer_%" and
field_name = "nvcache_selectivity_failed"

select	@tmp_int3 = value
from	#tempmonitors
where   group_name  like "nvbuffer_%" and
field_name = "nvcache_skip_caching"

select	@tmp_int4 = value
from	#tempmonitors
where   group_name  like "nvbuffer_%" and
field_name = "nvcache_grabfails"

select @tmp_total = @tmp_int + @tmp_int2 + @tmp_int3 + @tmp_int4

/* NV caching skipped because a clean page was already present in NV cache */
exec asemon_print @blankline
select @rptline = "    Page Writes Skipped" + space(6) +
		str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
		space(2) +
		str(@tmp_int / convert(real, @NumXacts),12,1) +
		space(1) +
		str(@tmp_int, 11)
exec asemon_print @rptline

/* ------------ Lazy Cleaning ---------------------- */
exec asemon_print @blankline
exec asemon_print "    Lazy Cleaning"

select @tmp_total = SUM(convert(bigint, value))
  from #tempmonitors
  where group_name like "nvbuffer_%" and
		field_name = "nvcache_lc_cleaned"

select @rptline = "      Cache Cleans" + space(11) +
		str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
		space(2) +
		str(@tmp_total / convert(real, @NumXacts),12,1) +
		space(1) +
		str(@tmp_total, 11)
exec asemon_print @rptline

select	@tmp_total = value
from	#tempmonitors
where   group_name like "nvbuffer_%" and
field_name = "nvcache_page_cleans"

select @rptline = "      Pages Cleaned" + space(10) +
		str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
		space(2) +
		str(@tmp_total / convert(real, @NumXacts),12,1) +
		space(1) +
		str(@tmp_total, 11)
exec asemon_print @rptline
exec asemon_print @blankline

return 0

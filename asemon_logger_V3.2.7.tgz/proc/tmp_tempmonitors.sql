create table #tempmonitors (
field_name  char     ( 79) not null,
group_name  char     ( 25) not null,
field_id    smallint       not null,
value       int            not null,
description varchar  (255) null,
nodeid      tinyint        null
)

/* This stored procedure produces a report containing a summary of
** index behavior including deadlocks and page splits.
*/
create procedure sp_sysmon_index_V125
	@NumElapsedMs int,	/* for "per Elapsed second" calculations */
	@NumXacts int		/* for per transactions calculations */
as


/* --------- declare local variables --------- */
declare @tmp_int int		/* temp var for integer storage */
declare @tmp_total int		/* temp var for summing 'total #s' data */
declare @sum1line char(80)	/* string to delimit total lines without 
				** percent calc on printout */	
declare @sum2line char(80)
declare @blankline char(1)	/* to print blank line */
declare @psign char(3)		/* hold a percent sign (%) for print out */
declare @na_str char(3)		/* holds 'n/a' for 'not applicable' strings */
declare @rptline char(80)	/* formatted stats line for print statement */
declare @section char(80)	/* string to delimit sections on printout */
/* --------- Setup Environment --------- */
set nocount on			/* disable row counts being sent to client */


select @sum1line   = "  -------------------------  ------------  ------------  ----------  ----------"
select @sum2line   = "                             ------------  ------------  ----------"


select @blankline  = " "
select @psign      = " %%"		/* extra % symbol because '%' is escape char in print statement */
select @na_str     = "n/a"
select @section = "==============================================================================="


print @section
print @blankline


print "Index Management"
print "----------------"
print @blankline


print "  Nonclustered Maintenance        per sec      per xact       count  %% of total"
print @sum1line


select @tmp_total = value
  from #tempmonitors
  where group_name = 'access' and
		field_name = "ncupdate"


select @rptline = "    Ins/Upd Requiring Maint" + space(2) +
			str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) + 
			space(2) +
			str(@tmp_total / convert(real, @NumXacts),12,1) + 
			space(2) +
			str(@tmp_total, 10) + space(7) +
			@na_str
print @rptline


select @tmp_int = value
  from #tempmonitors
  where group_name = 'access' and
		field_name = "ncupdate_indexes"


select @rptline = "      # of NC Ndx Maint" + space(6) +
			str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) + 
			space(2) +
			str(@tmp_int / convert(real, @NumXacts),12,1) + 
			space(2) +
			str(@tmp_int, 10) + space(7) +
			@na_str
print @rptline


if @tmp_total != 0
  begin
	select @rptline = "      Avg NC Ndx Maint / Op" + space(11) +
			@na_str + space(11) +
			@na_str +space(2) +
			str(convert(real, @tmp_int) / @tmp_total, 10,5) + 
			space(7) +
			@na_str
	print @rptline
  end


print @blankline


select @tmp_total = value
  from #tempmonitors where
  group_name = 'access' and
  field_name = "ncdelete"


select @rptline = "    Deletes Requiring Maint" + space(2) +
			str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) + 
			space(2) +
			str(@tmp_total / convert(real, @NumXacts),12,1) + 
			space(2) +
			str(@tmp_total, 10) + space(7) +
			@na_str
print @rptline


select @tmp_int = value
  from #tempmonitors
  where group_name = 'access' and
		field_name = "ncdelete_indexes"


select @rptline = "      # of NC Ndx Maint" + space(6) +
			str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) + 
			space(2) +
			str(@tmp_int / convert(real, @NumXacts),12,1) + 
			space(2) +
			str(@tmp_int, 10) + space(7) +
			@na_str
print @rptline


if @tmp_total != 0
  begin
	select @rptline = "      Avg NC Ndx Maint / Op" + space(11) +
			@na_str + space(11) +
			@na_str +space(2) +
			str(convert(real, @tmp_int) / @tmp_total, 10,5) + 
			space(7) +
			@na_str
	print @rptline
  end


print @blankline


select @tmp_total = value
  from #tempmonitors
  where group_name = 'access' and
		field_name = "ncrid_update"


select @rptline = "    RID Upd from Clust Split " +
			str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) + 
			space(2) +
			str(@tmp_total / convert(real, @NumXacts),12,1) + 
			space(2) +
			str(@tmp_total, 10) + space(7) +
			@na_str
print @rptline


select @tmp_int = value
  from #tempmonitors
  where group_name = 'access' and
		field_name = "ncrid_update_indexes"


select @rptline = "      # of NC Ndx Maint" + space(6) +
			str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) + 
			space(2) +
			str(@tmp_int / convert(real, @NumXacts),12,1) + 
			space(2) +
			str(@tmp_int, 10) + space(7) +
			@na_str
print @rptline


if @tmp_total != 0
  begin
	select @rptline = "      Avg NC Ndx Maint / Op" + space(11) +
			@na_str + space(11) +
			@na_str +space(2) +
			str(convert(real, @tmp_int) / @tmp_total, 10,5) + 
			space(7) +
			@na_str
	print @rptline
  end


print @blankline




select @tmp_total = value
  from #tempmonitors
  where group_name = 'dolaccess' and
		field_name = "dolncdelete"


select @rptline = "    Upd/Del DOL Req Maint" + space(4) +
			str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) + 
			space(2) +
			str(@tmp_total / convert(real, @NumXacts),12,1) + 
			space(2) +
			str(@tmp_total, 10) + space(7) +
			@na_str
print @rptline


select @tmp_int = value
  from #tempmonitors
  where group_name = 'dolaccess' and
		field_name = "dolncdelete_indexes"


select @rptline = "      # of DOL Ndx Maint" + space(5) +
			str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) + 
			space(2) +
			str(@tmp_int / convert(real, @NumXacts),12,1) + 
			space(2) +
			str(@tmp_int, 10) + space(7) +
			@na_str
print @rptline


if @tmp_total != 0
  begin
	select @rptline = "      Avg DOL Ndx Maint / Op" + space(10) +
			@na_str + space(11) +
			@na_str +space(2) +
			str(convert(real, @tmp_int) / @tmp_total, 10,5) + 
			space(7) +
			@na_str
	print @rptline
  end


print @blankline


select @tmp_total = sum(value)
  from #tempmonitors
  where (group_name = "access" and
		field_name IN ("split_index", "split_root"))
     OR (group_name = "btree" and
		field_name IN ("bt_leafsplit_count", "bt_noleafsplit_count"))


select @rptline = "  Page Splits" + space(16) +
			str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) + 
			space(2) +
			str(@tmp_total / convert(real, @NumXacts),12,1) + 
			space(2) +
			str(@tmp_total, 10) + space(7) +
			@na_str
print @rptline


if @tmp_total != 0			/* Avoid Divide by Zero Errors */
  begin
	select @tmp_int = value
	  from #tempmonitors
	  where group_name = "access" and
			field_name = "split_index_retry"


	select @rptline = "    Retries" + space(18) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_int, 10) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
	print @rptline


	select @tmp_int = value
	  from #tempmonitors
	  where group_name = "access" and
			field_name = "split_index_deadlock"


	select @rptline = "    Deadlocks" + space(16) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_int, 10) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
	print @rptline


	select @tmp_int = value
	  from #tempmonitors
	  where (group_name = "access" and
			field_name = "add_ind_level")
	     OR (group_name = "btree" and
			field_name = "bt_add_ind_level")


	select @rptline = "    Add Index Level" + space(10) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_int, 10) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
	print @rptline


  end


print @blankline


select @tmp_total = SUM(value)
  from #tempmonitors
  where (group_name = "access" and
		field_name like "shrink%")
     OR (group_name = "btree" and
		field_name IN ("bt_shrink_bylastdel", "bt_shrink_byscan",
			       "bt_shrink_nonleaf"))


select @rptline = "  Page Shrinks" + space(15) +
			str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) + 
			space(2) +
			str(@tmp_total / convert(real, @NumXacts),12,1) +
			space(2) +
			str(@tmp_total, 10) + space(7) +
			@na_str
print @rptline




if @tmp_total != 0			/* Avoid Divide by Zero Errors */
  begin
	select @tmp_int = SUM(value)
	  from #tempmonitors
	  where group_name = "access" and
			field_name IN ("am_split_shrink_LOSTP", "am_split_shrink_WDP",
				"am_split_shrink_NWFP", "am_split_shrink_WDC",
				"am_split_shrink_NWFC", "am_split_shrink_WDNXT", 
				"am_split_shrink_NWFNX", "am_split_shrink_WDPRV",
				"am_split_shrink_NWFPRV")




	select @rptline = "    Deadlocks" + space(16) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_int, 10) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
	print @rptline


	select @tmp_int = value
	  from #tempmonitors
	  where group_name = "access" and
			field_name = "split_shrink_retries_exceeded"


	select @rptline = "    Deadlock Retries Exceeded" + 
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_int, 10) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
	print @rptline
  end
if exists(select *
                from #tempmonitors
                where group_name = "access" and
                field_name = "forward_scans")
begin
print @blankline
print "  Index Scans                     per sec      per xact       count  %% of total"
print @sum1line


select @tmp_total = sum(value)
  from #tempmonitors
  where (group_name = 'access' and
                field_name in ("forward_scans","backward_scans"))
     OR (group_name = 'btree' and
                field_name in ("bt_forward_scans","bt_backward_scans"))


if @tmp_total = 0
 begin
	select @rptline = "    Total Scans                       0.0           0.0           0       n/a"
  	print @rptline
 end
else
  begin
	select @tmp_int = value
          from #tempmonitors
          where group_name = "access" and
                        field_name = "forward_scans"


	select @rptline = "    Ascending Scans        " + space(2) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(2) +
                        str(@tmp_int, 10) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
	print @rptline


	select @tmp_int = value
          from #tempmonitors
          where group_name = "btree" and
                        field_name = "bt_forward_scans"


	select @rptline = "    DOL Ascending Scans    " + space(2) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(2) +
                        str(@tmp_int, 10) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
	print @rptline


	select @tmp_int = value
          from #tempmonitors
          where group_name = "access" and
                        field_name = "backward_scans"


	select @rptline = "    Descending Scans       " + space(2) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(2) +
                        str(@tmp_int, 10) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
	print @rptline


	select @tmp_int = value
          from #tempmonitors
          where group_name = "btree" and
                        field_name = "bt_backward_scans"


	select @rptline = "    DOL Descending Scans   " + space(2) +
                        str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_int / convert(real, @NumXacts),12,1) +
                        space(2) +
                        str(@tmp_int, 10) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
	print @rptline


	print @sum2line


	select @rptline = "    Total Scans            " + space(2) +
                        str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_total / convert(real, @NumXacts),12,1) +
                        space(2) +
                        str(@tmp_total, 10)
	print @rptline


  end
end
print @blankline
return 0

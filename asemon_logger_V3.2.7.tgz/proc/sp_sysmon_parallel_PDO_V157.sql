/* This stored procedure produces a report describing the parallel
** features: activity.
**
*/
create procedure sp_sysmon_parallel_PDO_V157
	@NumElapsedMs int,	/* for "per Elapsed second" calculations */
	@NumXacts int,		/* for per transactions calculations */
	@Reco char(1)		/* Flag for recommendations             */
as


/* --------- declare local variables --------- */
declare @NumTaskSwitch int	/* Total Number of Task Context Switches 
				** across all engines */
declare @KnownTaskSwitch int	/* Count of Number of Task Context Switches 
				** by Known Causes */
declare @i smallint		/* loop index to iterate through multi-group 
				** counters (engine, disk, & buffer) */
declare @tmp_grp varchar(25)	/* temp var for building group_names 
				** ie. engine_N, disk_N */
declare @tmp_int bigint		/* temp var for integer storage */
declare @tmp_total bigint	/* temp var for integer storage, totals */
declare @sum1line char(80)	/* string to delimit total lines without 
				** percent calc on printout */	
declare @sum2line char(67)	/* string to delimit total lines with percent 
				** calc on printout */
declare @blankline char(1)	/* to print blank line */
declare @psign char(3)		/* hold a percent sign (%) for print out */
declare @na_str char(3)		/* holds 'n/a' for 'not applicable' strings */
declare @rptline char(80)	/* formatted stats line for print statement */
declare @section char(80)	/* string to delimit sections on printout */


/* ------------- Variables for Tuning Recommendations ------------*/
declare @reco_no_thread_adjusts int
declare @recotxt char(80)
declare @recoline char(80)
declare @reco_hdr_prn bit
declare @reco_total_waits int
declare @reco_runtime_adjust int
declare @reco_total_queries int	


/* --------- Setup Environment --------- */
set nocount on			/* disable row counts being sent to client */


select @sum1line   = "  -------------------------  ------------  ------------  ----------  ----------"
select @sum2line   = "  -------------------------  ------------  ------------  ----------"
select @blankline  = " "
select @psign      = " %"		/* extra % symbol because '%' is escape char in print statement */
select @na_str     = "n/a"
select @section = "==============================================================================="


/* ===================== Parallel Query Management Section ============== */


if not exists(select *
		from #tempmonitors
		where group_name = "parallel" and
		field_name = "pll_total_number_parallel_queries")
begin
	exec asemon_print @blankline
	return 0
end


exec asemon_print @section
exec asemon_print @blankline
/*
** ------ 
*/
exec asemon_print "Parallel Query Management"
exec asemon_print "-------------------------"
exec asemon_print @blankline




select @tmp_total = value, @reco_total_queries = value
	from #tempmonitors
	where group_name = "parallel" and
	field_name = "pll_total_number_parallel_queries"


select @reco_no_thread_adjusts = 0
select @reco_runtime_adjust = 0
select @reco_total_waits = 0


exec asemon_print "  Parallel Query Usage            per sec      per xact       count  % of total"
exec asemon_print @sum1line
select @rptline = "  Total Parallel Queries" + space(5) +
			str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) + 
			space(2) +
			str(@tmp_total / convert(real, @NumXacts),12,1) + 
			space(1) +
			str(@tmp_total,11) + space(7) +
			@na_str
exec asemon_print @rptline
if @tmp_total > 0
begin
	select @tmp_int = value
	from #tempmonitors
	where group_name = "parallel" and
	  	field_name = "pll_runtime_adjust_to_thread_limit"


	select @reco_runtime_adjust = convert(int, 
			100.0 * ((1.0* @tmp_int)/@reco_total_queries))


	select @rptline = "  WP Adjustments Made"
	exec asemon_print @rptline


	select @rptline = "    Due to WP Limit " + space(9) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
	exec asemon_print @rptline




	select @tmp_int = value
	from #tempmonitors
	where group_name = "parallel" and
	  	field_name = "pll_runtime_adjust_dueto_nothreads"


	select @reco_no_thread_adjusts = convert(int, 
			100.0 * ((1.0* @tmp_int)/@reco_total_queries))


	select @rptline = "    Due to No WPs" + space(12) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
	exec asemon_print @rptline
end








exec asemon_print @blankline
select @tmp_total = SUM(convert(bigint, value))
  from #tempmonitors
  where group_name = "parallel"
	and field_name like "pll_%lock_%"
exec asemon_print "  Merge Lock Requests             per sec      per xact       count  % of total"
exec asemon_print @sum1line


if @tmp_total = 0
begin
	select @rptline   = "  Total # of Requests                 0.0           0.0           0       n/a"
	exec asemon_print @rptline
end
else
begin
	select @rptline = "    Network Buffer Merge Locks"
	exec asemon_print @rptline


	select @tmp_int = SUM(convert(bigint, value))
	from #tempmonitors
	where group_name = "parallel" and
		  field_name like "pll_tbm_lock_immed%"


	select @rptline = "      Granted with no wait" + space(3) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
	exec asemon_print @rptline
	select @tmp_int = SUM(convert(bigint, value))
	from #tempmonitors
	where group_name = "parallel" and
		  field_name like "pll_tbm_lock_waited%"


	select @rptline = "      Granted after wait" + space(5) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
	exec asemon_print @rptline
	exec asemon_print @blankline


	select @rptline = "    Result Buffer Merge Locks"
	exec asemon_print @rptline


	select @tmp_int = SUM(convert(bigint, value))
	from #tempmonitors
	where group_name = "parallel" and
		  field_name like "pll_rbm_lock_immed%"


	select @rptline = "      Granted with no wait" + space(3) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
	exec asemon_print @rptline


	select @tmp_int = SUM(convert(bigint, value))
	from #tempmonitors
	where group_name = "parallel" and
		  field_name like "pll_rbm_lock_waited%"


	select @rptline = "      Granted after wait" + space(5) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
	exec asemon_print @rptline
	exec asemon_print @blankline


	select @rptline = "    Work Table Merge Locks"
	exec asemon_print @rptline


	select @tmp_int = SUM(convert(bigint, value))
	from #tempmonitors
	where group_name = "parallel" and
		  field_name like "pll_wkm_lock_immed%"


	select @rptline = "      Granted with no wait" + space(3) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
	exec asemon_print @rptline


	select @tmp_int = SUM(convert(bigint, value))
	from #tempmonitors
	where group_name = "parallel" and
		  field_name like "pll_wkm_lock_waited%"


	select @rptline = "      Granted after wait" + space(5) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
	exec asemon_print @rptline


	exec asemon_print @sum2line
	select @rptline = "  Total # of Requests" + space(8) +
			str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) + 
			space(2) +
			str(@tmp_total / convert(real, @NumXacts),12,1) + 
			space(2) +
			str(@tmp_total,10)
	exec asemon_print @rptline
end


exec asemon_print @blankline
select @tmp_total = SUM(convert(bigint, value))
  from #tempmonitors
  where group_name = "parallel"
	and field_name like "pll_pipe_%buf_waited"


if (@reco_total_queries > 0)
begin
select @reco_total_waits = convert(int, 
		100.0 * ((1.0* @tmp_total)/@reco_total_queries))
end


exec asemon_print "  Sort Buffer Waits               per sec      per xact       count  % of total"
exec asemon_print @sum1line


if @tmp_total = 0
begin
	select @rptline   = "  Total # of Waits                    0.0           0.0           0       n/a"
	exec asemon_print @rptline
end
else
begin
	select @tmp_int = value
	from #tempmonitors
	where group_name = "parallel" and
	  	field_name = "pll_pipe_allocbuf_waited"


	select @rptline = "    Producer Waits" + space(11) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign


	exec asemon_print @rptline
	select @tmp_int = value
	from #tempmonitors
	where group_name = "parallel" and
		  field_name = "pll_pipe_recvbuf_waited"


	select @rptline = "    Consumer Waits" + space(11) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign


	exec asemon_print @rptline
	exec asemon_print @sum2line
	select @rptline = "  Total # of Waits" + space(11) +
			str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) + 
			space(2) +
			str(@tmp_total / convert(real, @NumXacts),12,1) + 
			space(2) +
			str(@tmp_total,10)
	exec asemon_print @rptline
end
exec asemon_print @blankline
if @Reco = 'Y'
 begin
        select @recotxt =     "  Tuning Recommendations for Parallel Query Management"
        select @recoline = "  ----------------------------------------------------"
   	select @reco_hdr_prn = 0


	/*
	** If the % of number of thread adjusts due to no threads 
	** to the number of parallel queries run is > 10%, 
	** then consider increasing the 'number of worker processes' 
	** configuration parameter
	*/
        if (@reco_no_thread_adjusts > 10)
        begin
                if (@reco_hdr_prn = 0)
                begin
                        exec asemon_print @recotxt
                        exec asemon_print @recoline
                        select @reco_hdr_prn = 1
                end
                exec asemon_print "  - Consider increasing the 'number of worker processes'"
		exec asemon_print "    configuration parameter."
                exec asemon_print @blankline 
        end


	/*
	** If the number of thread adjusts due to worker process limit
	** to the number of parallel queries run is > 10% 
	** then consider tuning your session level limits
	*/
	if (@reco_runtime_adjust > 10)
	begin
		if (@reco_hdr_prn = 0)
		begin
			exec asemon_print @recotxt
			exec asemon_print @recoline
			select @reco_hdr_prn = 1
		end
		exec asemon_print "  - Consider re-evaluating your session level limts set with"
		exec asemon_print "   'set scan_parallel_degree' or 'set parallel_degree'."
		exec asemon_print @blankline
	end
	/*
	** If the number of waits due to pipe buffers is greater 
	** to the number of parallel queries run in > 5%
	** consider increasing the 'number of sort buffers'
	*/
        if (@reco_total_waits > 5)
        begin
                if (@reco_hdr_prn = 0)
                begin
                        exec asemon_print @recotxt
                        exec asemon_print @recoline
                        select @reco_hdr_prn = 1
                end
                exec asemon_print "  - Consider increasing the 'number of sort buffers'"
		exec asemon_print "    configuration parameter."
                exec asemon_print @blankline
	end
  end
return 0

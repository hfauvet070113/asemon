/* This stored procedure produces a report containing a summary of
** log activity including activity in the user log caches.
*/
create procedure sp_sysmon_xactmgmt_PDO_V150


	@NumElapsedMs int,	/* for "per Elapsed second" calculations */
	@NumXacts int,		/* for per transactions calculations */
	@Reco	char(1)		/* Flag for recommendations */
as


/* --------- declare local variables --------- */
declare @tmp_int int		/* temp var for integer storage */
declare @tmp_int2 int		/* temp var for integer storage */
declare @tmp_total int		/* temp var for summing 'total #s' data */
declare @sum1line char(80)	/* string to delimit total lines without 
				** percent calc on printout */	
declare @sum2line char(67)	/* string to delimit total lines with 
				** percent calc on printout */
declare @blankline char(1)	/* to print blank line */
declare @psign char(3)		/* hold a percent sign (%) for print out */
declare @na_str char(3)		/* holds 'n/a' for 'not applicable' strings */
declare @rptline char(80)	/* formatted stats line for print statement */
declare @section char(80)	/* string to delimit sections on printout */


/* ------------- Variables for Tuning Recommendations ------------*/
declare @recotxt char(80)	/* Header for tuning recommendation */
declare @recoline char(80)	/* to underline recotxt */
declare @reco_hdr_prn bit	/* to indicate if the recotxt is already printed */
declare @reco_by_slr real 	
declare @reco_by_full_ulc real


/* --------- Setup Environment --------- */
set nocount on					/* disable row counts being sent to client */


select @sum1line   = "  -------------------------  ------------  ------------  ----------  ----------"
select @sum2line   = "  -------------------------  ------------  ------------  ----------"
select @blankline  = " "
select @psign      = " %"		/* extra % symbol because '%' is escape char in print statement */
select @na_str     = "n/a"
select @section = "==============================================================================="




exec asemon_print @section
exec asemon_print @blankline


exec asemon_print "Transaction Management"
exec asemon_print "----------------------"
exec asemon_print @blankline
exec asemon_print "  ULC Flushes to Xact Log         per sec      per xact       count  % of total"
exec asemon_print @sum1line


select @tmp_total = SUM(value)
  from #tempmonitors
  where group_name = 'xls' and
		field_name like "plc_flush_%" and
		field_name != "plc_flush_discard"


if @tmp_total = 0			/* Avoid Divide by Zero Errors */
 begin
	select @rptline = "  Total ULC Flushes                   0.0           0.0           0       n/a"
  	exec asemon_print @rptline
 end 
else              
  begin
	select @tmp_int = value
	  from #tempmonitors
	  where group_name = 'xls' and
			field_name = "plc_flush_full"


	select @rptline = "    by Full ULC" + space(14) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_int, 10) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) + 
				@psign
	exec asemon_print @rptline


	select @reco_by_full_ulc = convert(int, 
			100.0 * ((1.0* @tmp_int)/@tmp_total))


	select @tmp_int = value
	  from #tempmonitors
	  where group_name = 'xls' and
			field_name = "plc_flush_endxact"


	select @rptline = "    by End Transaction" + space(7) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_int, 10) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) + 
				@psign
	exec asemon_print @rptline


	select @tmp_int = value
	  from #tempmonitors
	  where group_name = 'xls' and
			field_name = "plc_flush_xdeschange"


	select @rptline = "    by Change of Database" + space(4) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_int, 10) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) + 
				@psign
	exec asemon_print @rptline


	select @tmp_int = value
	  from #tempmonitors
	  where group_name = 'xls' and
			field_name = "plc_flush_slr_xact"


	select @rptline = "    by Single Log Record" + space(5) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_int, 10) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) + 
				@psign
	exec asemon_print @rptline


    select @reco_by_slr = convert(int, 100.0 * ((1.0* @tmp_int) / @tmp_total))


	select @tmp_int = value
	  from #tempmonitors
	  where group_name = 'xls' and
			field_name = "plc_flush_unpin"


	select @rptline = "    by Unpin" + space(17) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_int, 10) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) + 
				@psign
	exec asemon_print @rptline




	select @tmp_int = SUM(value)
	  from #tempmonitors
	  where group_name = 'xls' and field_name IN 
		("plc_flush_pmscan")


	select @rptline = "    by Log markers" + space(11) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_int, 10) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) + 
				@psign
	exec asemon_print @rptline


	exec asemon_print @sum2line 
	select @rptline = "  Total ULC Flushes" + space(10) +
			str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
			space(2) +
			str(@tmp_total / convert(real, @NumXacts),12,1) +
			space(2) +
			str(@tmp_total,10)
	exec asemon_print @rptline
  end


exec asemon_print @blankline
exec asemon_print "  ULC Flushes Skipped             per sec      per xact       count  % of total"
exec asemon_print @sum1line


select @tmp_total = SUM(value)
  from #tempmonitors
  where group_name = 'xls' and
                field_name in ("plc_flush_discard")


if @tmp_total = 0                       /* Avoid Divide by Zero Errors */
 begin
        select @rptline = "  Total ULC Skips                     0.0           0.0           0       n/a"
        exec asemon_print @rptline
 end
else
  begin
        select @tmp_int = value
          from #tempmonitors
          where group_name = 'xls' and
                        field_name = "plc_flush_discard"


        select @rptline = "    by PLC Discards" + space(10) +
                                str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(2) +
                                str(@tmp_int, 10) + space(5) +
                                str(100.0 * @tmp_int / @tmp_total,5,1) +
                                @psign
        exec asemon_print @rptline


        exec asemon_print @sum2line
        select @rptline = "  Total ULC Discards" + space(9) +
                        str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
                        space(2) +
                        str(@tmp_total / convert(real, @NumXacts),12,1) +
                        space(2) +
                        str(@tmp_total,10)
        exec asemon_print @rptline


  end


exec asemon_print @blankline


select @tmp_int = value
  from #tempmonitors
  where group_name = 'xls' and
		field_name = "plc_logrecs"


select @rptline = "  ULC Log Records" + space(12) +
			str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
			space(2) +
			str(@tmp_int / convert(real, @NumXacts),12,1) +
			space(2) +
			str(@tmp_int, 10) + space(7) +
			@na_str
exec asemon_print @rptline


select @tmp_int = value
  from #tempmonitors
  where group_name = 'xls' and
		field_name = "plc_maxused"


select @rptline = "  Max ULC Size During Sample" + space(10) +
				@na_str + space(11) +
				@na_str + space(2) +
				str(@tmp_int, 10) + space(7) +
				@na_str
exec asemon_print @rptline
exec asemon_print @blankline


exec asemon_print "  ULC Semaphore Requests"


select @tmp_total = value
  from #tempmonitors
  where group_name = 'xls' and
		field_name = "plc_lock_calls"


if @tmp_total = 0			/* Avoid Divide by Zero Errors */
 begin
	select @rptline = "    Total ULC Semaphore Req           0.0           0.0           0       n/a"
  	exec asemon_print @rptline
 end
else              
  begin
	select @tmp_int2 = value
	  from #tempmonitors
	  where group_name = 'xls' and
			field_name = "plc_lock_waits"


	/* calculate "immediately granted" spinlocks */
	select @tmp_int = @tmp_total - @tmp_int2




	select @rptline = "    Granted" + space(18) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int/convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_int, 10) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) + 
				@psign
	exec asemon_print @rptline


	select @rptline = "    Waited" + space(19) +
			str(@tmp_int2 / (@NumElapsedMs / 1000.0),12,1) +
			space(2) +
			str(@tmp_int2 / convert(real, @NumXacts),12,1) +
			space(2) +
			str(@tmp_int2, 10) + space(5) +
			str(100.0 * @tmp_int2 / @tmp_total,5,1) + 
			@psign
	exec asemon_print @rptline


	exec asemon_print @sum2line 
	select @rptline = "  Total ULC Semaphore Req" + space(4) +
			str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
			space(2) +
			str(@tmp_total / convert(real, @NumXacts),12,1) +
			space(2) +
			str(@tmp_total,10)




	exec asemon_print @rptline
  end	/* else @tmp_total != 0 */


exec asemon_print @blankline


exec asemon_print "  Log Semaphore Requests"


select @tmp_total = SUM(value)
  from #tempmonitors
  where group_name = 'xls' and
		field_name IN ("log_lock_granted", "log_lock_waited")


if @tmp_total = 0			/* Avoid Divide by Zero Errors */
 begin
	select @rptline = "    Total Log Semaphore Req           0.0           0.0           0       n/a"
  	exec asemon_print @rptline
 end
else              
  begin
	select @tmp_int = value
	  from #tempmonitors
	  where group_name = 'xls' and
			field_name = "log_lock_granted"


	select @rptline = "    Granted" + space(18) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_int, 10) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
	exec asemon_print @rptline


	select @tmp_int = value
	  from #tempmonitors
	  where group_name = 'xls' and
			field_name = "log_lock_waited"


	select @rptline = "    Waited" + space(19) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_int, 10) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1) + 
				@psign
	exec asemon_print @rptline


	exec asemon_print @sum2line 
	select @rptline = "  Total Log Semaphore Req" + space(4) +
			str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) + 
			space(2) +
			str(@tmp_total / convert(real, @NumXacts),12,1) + 
			space(2) +
			str(@tmp_total,10)
	exec asemon_print @rptline
  end


exec asemon_print @blankline






select @tmp_int = SUM(value)
  from #tempmonitors
  where group_name like "buffer_%" and
		field_name = "last_log_page_writes"


select @tmp_int = SUM(value)
  from #tempmonitors
  where group_name like "buffer_%" and
		field_name = "log_page_writes"


select @rptline = "  Transaction Log Writes" + space(5) +
			str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) + 
			space(2) +
			str(@tmp_int / convert(real, @NumXacts),12,1) + 
			space(2) +
			str(@tmp_int, 10) + space(7) +
			@na_str
exec asemon_print @rptline


select @tmp_int2 = value
  from #tempmonitors
  where group_name = "access" and
		field_name = "log_page_allocations"         


select @rptline = "  Transaction Log Alloc" + space(6) +
			str(@tmp_int2 / (@NumElapsedMs / 1000.0),12,1) + 
			space(2) +
			str(@tmp_int2 / convert(real, @NumXacts),12,1) + 
			space(2) +
			str(@tmp_int2, 10) + space(7) +
			@na_str
exec asemon_print @rptline


if @tmp_int2 != 0	/* avoid divide by zero errors */
  begin
	select @rptline = "  Avg # Writes per Log Page" + space(11) +
					@na_str + space(11) +
					@na_str + space(2) + 
					str(convert(real, @tmp_int) / @tmp_int2, 10,5) + space(7) +
					@na_str
	exec asemon_print @rptline
  end


exec asemon_print @blankline


if @Reco = 'Y'
 begin
	select @recotxt = "  Tuning Recommendations for Transaction Management"
	select @recoline = "  -------------------------------------------------"
	select @reco_hdr_prn = 0


	/*
	** If the % of flushes on account of ULC being full is > 20%
	** consider increasing the 'user log cache size'
	*/
	if @reco_by_full_ulc > 20
	 begin
                if (@reco_hdr_prn = 0)
                begin
                        exec asemon_print @recotxt
                        exec asemon_print @recoline
                        select @reco_hdr_prn = 1
                end
		
		exec asemon_print "  - Consider increasing the 'user log cache size'"
		exec asemon_print "    configuration parameter."
		exec asemon_print @blankline
		select @reco_hdr_prn = 1	
	 end


	/*
	** If the % of flushes on account of SLR is > 20%
	** and the % of flushes on account of ULC being full
	** is < 20% consider decreasing the user log cache size
	*/
	if @reco_by_slr > 20 and @reco_by_full_ulc < 20
	 begin
                if (@reco_hdr_prn = 0)
                begin
                        exec asemon_print @recotxt
                        exec asemon_print @recoline
                        select @reco_hdr_prn = 1
                end


		exec asemon_print "  - Consider decreasing the 'user log cache size'"
		exec asemon_print "    configuration parameter if it is greater than the"
                exec asemon_print "    logical database page size."
		exec asemon_print @blankline
		select @reco_hdr_prn = 1
	 end
 end


return 0

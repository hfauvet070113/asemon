/* This stored procedure produces a report containing a summary of
** SQL Server housekeeper activities.
*/
create procedure sp_sysmon_hk_V16SP3
	@NumElapsedMs int,	/* for "per Elapsed second" calculations */
	@NumXacts int,		/* for per transactions calculations */
	@Reco	char(1),	/* Flag for recommendations */
  @NumEngines smallint /* added for asemon */
as


/* --------- declare local variables --------- */
declare @tmp_int int		/* temp var for integer storage */
declare @tmp_int2 bigint	/* temp var for integer storage */
declare @tmp_total bigint	/* temp var for summing 'total #s' data */
declare @sum2line char(80)	
declare @blankline char(1)	/* to print blank line */
declare @psign char(3)		/* hold a percent sign (%) for print out */
declare @na_str char(3)		/* holds 'n/a' for 'not applicable' strings */
declare @rptline char(80)	/* formatted statistics line for print 
				** statement */
declare @section char(80)	/* string to delimit sections on printout */
/* ------------- Variables for Tuning Recommendations ------------*/
declare @recotxt char(80)
declare @recoline char(80)
declare @reco_hdr_prn bit
declare @char_str varchar(30)
declare @char_trimmed varchar(30)
declare @engines smallint
declare @eng_count int
declare @tmp_grp_name varchar(80)
declare @reco_avg_busy real     /* Avg cpu busy utilization */
declare @reco_percent real	/* temp var for percentage storage */
declare @reco_idle_ticks real	/* temp var for percentage storage */
declare @reco_clock_ticks real	/* temp var for percentage storage */
declare @reco_dirty real
declare @reco_clean real


declare @i int


/* --------- Setup Environment --------- */
set nocount on			/* disable row counts being sent to client */


select @blankline  = " "
select @psign      = " %%"		/* extra % symbol because '%' is escape char in print statement */
select @na_str     = "n/a"
select @sum2line   = "                             ------------  ------------  ----------"
select @section = "==============================================================================="


/* ======================= Housekeeper Section =================== */
print @section
print @blankline
print "Housekeeper Task Activity"
print "-------------------------"
print "                                  per sec      per xact       count  %% of total"
print @sum2line


select @tmp_total = SUM(convert(bigint, value))
  from #tempmonitors
  where group_name like "buffer_%" and
        field_name = "hk_wash"


if (@tmp_total > 0 )
begin
  select @rptline = "Buffer Cache Washes"
  
  print @rptline
  
  select @tmp_int2 = SUM(convert(bigint, value))
    from #tempmonitors
    where group_name like "buffer_%" and
          field_name = "hk_washclean"
  
  select @rptline = "  Clean" + space(22) +
  			str(@tmp_int2 / (@NumElapsedMs / 1000.0),11,1) 
  			+ space(2) +
  			str(@tmp_int2 / convert(real, @NumXacts),12,1) 
  			+ space(1) +
                        str(@tmp_int2, 11) + space(5) +
                        str(100.0 * @tmp_int2 / @tmp_total,5,1) + @psign


  select @reco_clean = convert(int, 100.0 * ((1.0* @tmp_int2) / @tmp_total))


  print @rptline
  
  select @tmp_int = @tmp_total - @tmp_int2
  
  select @rptline = "  Dirty" + space(22) +
  			str(@tmp_int / (@NumElapsedMs / 1000.0),11,1) 
  			+ space(2) +
  			str(@tmp_int / convert(real, @NumXacts),12,1) 
  			+ space(1) +
                        str(@tmp_int, 11) + space(5) +
                        str(100.0 * @tmp_int / @tmp_total,5,1) + @psign


  select @reco_dirty = convert(int, 100.0 * ((1.0* @tmp_int2) / @tmp_total))


  print @rptline
  
  print @sum2line
  
  select @rptline = "Total Washes" + space(17) +
  			str(@tmp_total / (@NumElapsedMs / 1000.0),11,1) 
  			+ space(2) +
  			str(@tmp_total / convert(real, @NumXacts),12,1) 
  			+ space(2) +
  			str(@tmp_total, 10)
  print @rptline
  
  print @blankline
end


select @tmp_int = value
  from #tempmonitors
  where group_name = "housekeeper" and
        field_name = "hk_gc_wakes"


select @rptline = "Garbage Collections" +  space(9) +
			str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) 
			+ space(2) +
			str(@tmp_int / convert(real, @NumXacts),12,1) 
			+ space(1) +
			str(@tmp_int, 11) + space(7) +
			@na_str
print @rptline


select @tmp_int = value
  from #tempmonitors
  where group_name = "housekeeper" and
        field_name = "hk_gc_numgoodpages"


select @rptline = "Pages Processed in GC" + space(8) +
			str(@tmp_int / (@NumElapsedMs / 1000.0),11,1) 
			+ space(2) +
			str(@tmp_int / convert(real, @NumXacts),12,1) 
			+ space(1) +
			str(@tmp_int, 11) + space(7) +
			@na_str
print @rptline


print @blankline


select @tmp_int = value
  from #tempmonitors
  where group_name = "housekeeper" and
        field_name = "hk_stats_wakes"


select @rptline = "Statistics Updates" + space(11) +
			str(@tmp_int / (@NumElapsedMs / 1000.0),11,1) 
			+ space(2) +
			str(@tmp_int / convert(real, @NumXacts),12,1) 
			+ space(1) +
			str(@tmp_int, 11) + space(7) +
			@na_str
print @rptline


print @blankline


if @Reco = 'Y'
 begin
	select @recotxt = "  Tuning Recommendations for Housekeeper"
	select @recoline = "  --------------------------------------"
	select @reco_hdr_prn = 0


	select @i = 0, @eng_count = 0




/* modif asemon
		select @engines = count(engine)
		from master.dbo.sysengines 
		where status != "offline"
*/
select @engines = @NumEngines


	
	select @reco_clock_ticks = SUM(convert(bigint, value))
          	from #tempmonitors
          	where group_name like "engine_%" and
               	 field_name = "clock_ticks" and
               	 value > 0


	select @reco_idle_ticks = SUM(convert(bigint, value))
          	from #tempmonitors
          	where group_name like "engine_%" and
               	 field_name = "idle_ticks" and
               	 value > 0


       	select @reco_percent = 
		100.0 * ((@reco_clock_ticks - @reco_idle_ticks)/@reco_clock_ticks)


	if @engines > 1 
	 begin
		select @reco_avg_busy = @reco_percent/@engines
	 end


	/*
	** If the average CPU busy is > 95% and if the
	** percentage of masses washed clean by HK is
	** greater than 95%, we have an overactive 
	** housekeeper which could be intruding with
	** user tasks, so reduce the 'housekeeper free write
	** percent' configuration parameter.
	*/
	if @reco_avg_busy > 95 AND @reco_clean > 95
	 begin
		if (@reco_hdr_prn = 0)
		begin
			print @recotxt
			print @recoline
			select @reco_hdr_prn = 1
		end


		print "  - Consider decreasing the 'housekeeper free write percent'"
		print "    configuration parameter."
		select @reco_hdr_prn = 1
		print @blankline
	 end


	/*
	** If the average CPU busy is < 5% and if the
	** percentage of masses washed dirty by HK is
	** greater than 50%, we have a lot more washing to do
	** and since we have the cycles to do it, do it.
	*/
	if @reco_avg_busy < 5 AND @reco_dirty > 50
	 begin
		if (@reco_hdr_prn = 0)
		begin
			print @recotxt
			print @recoline
			select @reco_hdr_prn = 1
		end
		print "  - Consider increasing the 'housekeeper free write percent'"
		print "    configuration parameter."
		select @reco_hdr_prn = 1
		print @blankline
	 end
  end




return 0

/* This stored procedure produces a report containing a summary of
** SQL Server engine activity.
*/
create procedure sp_sysmon_kernel_PDO_V125
	@NumEngines tinyint,	/* number of engines online */
	@NumElapsedMs int,	/* for "per Elapsed second" calculations */
	@NumXacts int,		/* for per transactions calculations */
	@Reco char(1)		/* Flag for recommendations */


as


/* --------- declare local variables --------- */
declare @i smallint		/* loop index to iterate through  multi-group
				** counters (engine, disk, & buffer) */
declare @tmp_grp varchar(25)	/* temp var to build group_names
				** ie. engine_N, disk_N */
declare @tmp_int int		/* temp var for integer storage */
declare @tmp_total int		/* temp var for summing 'total #s' data */
declare @cpu_busy real		/* var for cpu busy percentage */
declare @io_busy real		/* var for io busy percentage */
declare @cpu_busy_sum real	/* var for summing cpu busy percentage */
declare @io_busy_sum real	/* var for summing io busy percentage */
declare @cpu_busy_avg real	/* var for averaging cpu busy percentage */
declare @io_busy_avg real	/* var for averaging io busy percentage */
declare @rpsc int           	/* holds cfgvalue for RPSC */
declare @iopc int           	/* holds cfgvalue for I/O polling count */
declare @eng_load_line char(67)	/* string to delimit the engine load lines */
declare @avg1line char(67)	/* string to delimit avg lines on printout */
declare @sum1line char(80)	/* string to delimit total lines without 
				** percent calc on printout */	
declare @sum2line char(67)	/* string to delimit total lines with percent 
				** calc on printout */
declare @blankline char(1)	/* to print blank line */
declare @psign char(3)		/* hold a percent sign (%) for print out */
declare @na_str char(3)		/* holds 'n/a' for 'not applicable' strings */
declare @rptline char(80)	/* formatted statistics line for print 
				** statement */
declare @section char(80)       /* string to delimit sections on printout */


/* ------------- Variables for Tuning Recommendations ------------*/
declare @recotxt char(80)	/* Header for tuning recommendation */
declare @recoline char(80)	/* to underline recotxt */
declare @reco_hdr_prn bit	/* to indicate if the recotxt is already printed */
declare @reco_percent_diskio real /* percentage sucessful disk i/o */


/* --------- Setup Environment --------- */
set nocount on			/* disable row counts being sent to client */


select @avg1line   = "  -----------             ---------------          ----------------"
select @sum1line   = "  -------------------------  ------------  ------------  ----------  ----------"
select @sum2line   = "  -------------------------  ------------  ------------  ----------"
select @blankline  = " "
select @psign      = " %"		/* extra % symbol because '%' is escape char in print statement */
select @na_str     = "n/a"
select @section = "==============================================================================="




/* ======================= Kernel Utilization Section =================== */
exec asemon_print @section
exec asemon_print @blankline
exec asemon_print "Kernel Utilization"
exec asemon_print "------------------"
exec asemon_print @blankline
select @rpsc = value from master..syscurconfigs where config=177
select @rptline= "  Your Runnable Process Search Count is set to " 
			+ convert(varchar, @rpsc)
exec asemon_print @rptline
select @iopc = value from master..syscurconfigs where config=178
select @rptline= "  and I/O Polling Process Count is set to " 
			+ convert(varchar, @iopc)
exec asemon_print @rptline
exec asemon_print @blankline


select 	@i = 0, @cpu_busy_sum = 0, @io_busy_sum = 0, @cpu_busy_avg = 0, 
	@io_busy_avg = 0, @reco_percent_diskio = 0


select @rptline = "  Engine Busy Utilization "+ space(7) 
			+ "CPU Busy" + space(3) 
			+ "I/O Busy" + space(7) 
			+ "Idle"
exec asemon_print @rptline
select @eng_load_line = "  ------------------------" + space(7) 
			+ "--------" + space(3) 
			+ "--------" + space(3) 
			+ "--------"
exec asemon_print @eng_load_line
while @i < @NumEngines                                   /* for each engine */
  begin
	/* build group_name string */
	select @tmp_grp = "engine_" + convert(varchar(2), @i)


	select 	@cpu_busy = isnull(100.0 * convert(real,c.value)/t.value, 0),
		@io_busy = isnull(100.0 * convert(real,i.value)/t.value, 0)
	  from #tempmonitors t, #tempmonitors c, #tempmonitors i
	 where t.group_name = @tmp_grp 
	   and t.group_name = c.group_name
	   and t.group_name = i.group_name
	   and t.field_name = "clock_ticks"
	   and i.field_name = "io_ticks" 
	   and c.field_name = "cpu_ticks" 
	   and t.value > 0


	select 	@cpu_busy_sum = @cpu_busy_sum + @cpu_busy,
		@io_busy_sum = @io_busy_sum + @io_busy


	select @rptline = "    Engine " + convert(char(2), @i) + space(21) 
				+ str(@cpu_busy,5,1) + @psign + space(4) 
				+ str(@io_busy,5,1) + @psign + space(4) 
				+ str(100 - @cpu_busy - @io_busy,5,1) + @psign
	exec asemon_print @rptline
	select @i = @i + 1
  end


if @NumEngines > 1
  begin
	exec asemon_print @eng_load_line
	select @rptline = "  Summary " + space(10) + "Total" +space(7)
				+ str(@cpu_busy_sum,7,1) + @psign + space(2) 
				+ str(@io_busy_sum,7,1) + @psign + space(2) 
				+ str(@NumEngines * 100 - @cpu_busy_sum 
					- @io_busy_sum,7,1) + @psign,
			@cpu_busy_avg = @cpu_busy_sum/@NumEngines,
			@io_busy_avg = @io_busy_sum/@NumEngines
	exec asemon_print @rptline
	select @rptline = space(18) + "Average" + space(9) 
				+ str(@cpu_busy_avg,5,1) + @psign + space(4) 
				+ str(@io_busy_avg,5,1) + @psign + space(4) 
				+ str(100 - @cpu_busy_avg - @io_busy_avg,5,1) 
				+ @psign
	exec asemon_print @rptline
  end


exec asemon_print @blankline
exec asemon_print "  CPU Yields by Engine            per sec      per xact       count  % of total"
exec asemon_print @sum1line


select @tmp_total = SUM(value)
  from #tempmonitors
  where group_name like "engine_%" and
        field_name = "engine_sleeps"


if @tmp_total = 0	/* Avoid divide by zero errors - just print zero's */
 begin
	select @rptline = "  Total CPU Yields                    0.0           0.0           0       n/a"
  	exec asemon_print @rptline
 end
else
  begin
	select @i = 0
	while @i < @NumEngines		/* for each engine */
	  begin
		/* build group_name string */
		select @tmp_grp= "engine_" + convert(varchar(2), @i) 
		select @tmp_int = value
		  from #tempmonitors
		  where group_name = @tmp_grp and
				field_name = "engine_sleeps"


		select @rptline = "    Engine " + convert(char(2),@i) + 
					space(16) +
					str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) 
					+ space(2) +
					str(@tmp_int / convert(real, @NumXacts),12,1) 
					+ space(2) +
					str(@tmp_int, 10) + space(5) +
					str(100.0 * @tmp_int / @tmp_total,5,1) 
					+ @psign
		exec asemon_print @rptline
		select @i = @i + 1
	  end


	if @NumEngines > 1
	  begin 
		exec asemon_print @sum2line 
		select @rptline = "  Total CPU Yields " + space(10) +
					str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) 
					+ space(2) +
					str(@tmp_total / convert(real,@NumXacts),12,1) 
					+ space(2) +
					str(@tmp_total,10)
		exec asemon_print @rptline
	  end
  end
exec asemon_print @blankline


exec asemon_print "  Network Checks"


select @tmp_total = SUM(value)
  from #tempmonitors
  where group_name = "kernel" and
  field_name like "ncheck_%"


if @tmp_total = 0	/* Avoid divide by zero errors - print zero's */
 begin
	select @rptline = "    Total Network I/O Checks          0.0           0.0           0       n/a"
  	exec asemon_print @rptline
 end
else              
  begin
	select @tmp_int = value
	  from #tempmonitors
	  where group_name = "kernel" and
	  		field_name = "ncheck_nonblocking"
	  
	select @rptline = "    Non-Blocking" + space(13) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(2) +
				str(@tmp_int, 10) + space(5) +
				str(100.0 * @tmp_int / @tmp_total,5,1)
				+ @psign
	exec asemon_print @rptline


	select @tmp_int = value
	  from #tempmonitors
	  where group_name = "kernel" and
	  		field_name = "ncheck_blocking"


	select @rptline = "    Blocking" + space(17) +
			str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) + 
			space(2) +
			str(@tmp_int / convert(real, @NumXacts),12,1) + 
			space(2) +
			str(@tmp_int, 10) + space(5) +
			str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
	exec asemon_print @rptline


	exec asemon_print @sum2line 
	select @rptline = "  Total Network I/O Checks " + space(2) +
			str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) +
			space(2) +
			str(@tmp_total / convert(real,@NumXacts),12,1) + 
			space(2) +
			str(@tmp_total,10)
	exec asemon_print @rptline


	select @tmp_int = SUM(value)
	  from #tempmonitors
	  where group_name = "network" and
			field_name like "total_packets_%"


	select @rptline = "  Avg Net I/Os per Check" + space(14) +
				@na_str + space(11) +
				@na_str + space(2) +
				str(convert(real, @tmp_int) / @tmp_total,10,5)+
				space(7) +
				@na_str
	exec asemon_print @rptline
  end
exec asemon_print @blankline


exec asemon_print "  Disk I/O Checks"


select @tmp_total = SUM(value)
  from #tempmonitors
  where group_name like "engine_%" and
		field_name = "dcheck_calls"


if @tmp_total = 0	/* Avoid divide by zero errors - print zero's */
 begin
	select @rptline = "      Total Disk I/O Checks           0.0           0.0           0       n/a"
  	exec asemon_print @rptline
 end
else              
  begin
	select @rptline = "    Total Disk I/O Checks" + space(4) +
			str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) + 
			space(2) +
			str(@tmp_total / convert(real, @NumXacts),12,1) + 
			space(2) +
			str(@tmp_total, 10) + space(7) +
			@na_str
	exec asemon_print @rptline


	select @tmp_int = SUM(value)
	  from #tempmonitors
	  where group_name like "engine_%" and
			field_name = "dchecks_calling_dpoll"


	select @rptline = "    Checks Returning I/O" + space(5) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
 				space(2) +
				str(@tmp_int, 10) + space(5) +
				str(100.0 * @tmp_int/ @tmp_total,5,1) + @psign
	if @tmp_total != 0
	 begin
		select @reco_percent_diskio = 100.0 * (convert(real, @tmp_int)/ @tmp_total)
	 end


	exec asemon_print @rptline


	/* save checks returning i/o value for average calc below */
	select @tmp_total = @tmp_int


	if @tmp_total != 0
	  begin
		select @tmp_int = SUM(value)
		  from #tempmonitors
		  where group_name like "engine_%" and
				field_name = "total_dpoll_completed_aios"


		select @rptline = "    Avg Disk I/Os Returned" + space(12) +
						@na_str + space(11) +
						@na_str + space(2) +
						str(convert(real, @tmp_int) / 
							@tmp_total,10,5) + 
						space(7) +
						@na_str
		exec asemon_print @rptline
	  end
  end


exec asemon_print @blankline
if @Reco = 'Y'
 begin
	select @recotxt = "  Tuning Recommendations for Kernel Utilization"
	select @recoline = "  ---------------------------------------------"	
	select @reco_hdr_prn = 0


	if @NumEngines > 1
	begin
		/*
		** If the average percentage busy on the engines
		** is > 95% consider increasing the number of engines
		*/
		if (@cpu_busy_avg > 95)
		 begin
			if (@reco_hdr_prn = 0)
			begin
				exec asemon_print @recotxt
				exec asemon_print @recoline
				select @reco_hdr_prn = 1
			end


			exec asemon_print "  - Consider bringing more engines online"
			exec asemon_print @blankline
			select @reco_hdr_prn = 1
		 end


		/*
		** If the average percentage busy on the engines is < 5% 
		** consider decreasing the 'runnable process search count' 
		** configuration parameter, if other applications are running
		** on the same machine.  
		** If runnable process search count is already set to 100 or less
		** don't print this recommendation.
		*/
		if (@cpu_busy_avg < 5 and @rpsc > 100)
		 begin
			if (@reco_hdr_prn = 0)
			begin
				exec asemon_print @recotxt
				exec asemon_print @recoline
				select @reco_hdr_prn = 1
			end


			exec asemon_print "  - Consider decreasing the 'runnable process search count'"
			exec asemon_print "    configuration parameter if you require the CPU's on"
			exec asemon_print "    the machine to be used for other applications."
			exec asemon_print @blankline
			select @reco_hdr_prn = 1
		 end
		/*
		** If the average cpu busy percentage on the engines
		** is > 70% and the average busy on the engines
		** is < 90% and the percentage diskio is < 5% consider 
		** increasing the 'i/o polling process count' 
		** configuration parameter.
		** Don't print this recommendation if the config param 
		** is already set to 10000 or higher.
		*/
		if (@cpu_busy_avg > 70 AND @cpu_busy_avg < 90 
				AND  @reco_percent_diskio < 5
				AND @iopc < 10000)
		 begin
			if (@reco_hdr_prn = 0)
			begin
				exec asemon_print @recotxt
				exec asemon_print @recoline
				select @reco_hdr_prn = 1
			end


			exec asemon_print "  - Consider increasing the 'i/o polling process count'"
			exec asemon_print "    configuration parameter."
			exec asemon_print @blankline
			select @reco_hdr_prn = 1
		 end
	end
 end 
exec asemon_print @blankline


return 0

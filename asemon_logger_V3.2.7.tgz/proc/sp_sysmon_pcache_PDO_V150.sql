/* This stored procedure produces a report containing a summary of
** of how effectively the procedure cache is being utilized.
*/
create procedure sp_sysmon_pcache_PDO_V150
	@NumElapsedMs int,	/* for "per Elapsed second" calculations */
	@NumXacts int,		/* for per transactions calculations */
	@Reco	char(1)		/* Flag for recommendations */
as


/* --------- declare local variables --------- */
declare @tmp_int int		/* temp var for integer storage */
declare @tmp_total int		/* temp var for summing 'total #s' data */
declare @tmp_reco_total int	/* temp var for summing 'total #s' data */
declare @sum1line char(80)	/* string to delimit total lines without 
				** percent calc on printout */	
declare @blankline char(1)	/* to print blank line */
declare @psign char(3)		/* hold a percent sign (%) for print out */
declare @na_str char(3)		/* holds 'n/a' for 'not applicable' strings */
declare @rptline char(80)	/* formatted stats line for print statement */
declare @section char(80)	/* string to delimit sections on printout */


/* ------------- Variables for Tuning Recommendations ------------*/
declare @recotxt char(80)       /* Header for tuning recommendation */
declare @recoline char(80)      /* to underline recotxt */
declare @reco_hdr_prn bit       /* to indicate if the recotxt is already printed */
declare @reco_phdr_read_from_disk real


/* --------- Setup Environment --------- */
set nocount on			/* disable row counts being sent to client */


select @sum1line   = "---------------------------  ------------  ------------  ----------  ----------"
select @blankline  = " "
select @psign      = " %"		/* extra % symbol because '%' is escape char in print statement */
select @na_str     = "n/a"
select @section = "==============================================================================="


exec asemon_print @section
exec asemon_print @blankline


exec asemon_print "Procedure Cache Management        per sec      per xact       count  % of total"
exec asemon_print @sum1line


select @tmp_total = value
  from #tempmonitors
  where group_name = "procmgr" and
		field_name = "procedure_requests"


select @rptline = "  Procedure Requests" + space(9) +
			str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) + 
			space(2) +
			str(@tmp_total / convert(real, @NumXacts),12,1) + 
			space(2) +
			str(@tmp_total, 10) + space(7) +
			@na_str
exec asemon_print @rptline


if @tmp_total !=0
  begin
	select @tmp_int = value
	  from #tempmonitors
	  where group_name = "procmgr" and
			field_name = "procedure_reads"


	select @rptline = "  Procedure Reads from Disk" + space(2) +
			str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) + 
			space(2) +
			str(@tmp_int / convert(real, @NumXacts),12,1) + 
			space(2) +
			str(@tmp_int, 10) + space(5) +
			str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
	exec asemon_print @rptline


    select @reco_phdr_read_from_disk = 
			convert(int, 100.0 * ((1.0* @tmp_int) / @tmp_total))


	select @tmp_int = value
	  from #tempmonitors
	  where group_name = "procmgr" and
			field_name = "procedure_writes"


	select @rptline = "  Procedure Writes to Disk" + space(3) +
			str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) + 
			space(2) +
			str(@tmp_int / convert(real, @NumXacts),12,1) + 
			space(2) +
			str(@tmp_int, 10) + space(5) +
			str(100.0 * @tmp_int / @tmp_total,5,1) + @psign
	exec asemon_print @rptline


	select @tmp_int = value
	  from #tempmonitors
	  where group_name = "procmgr" and
			field_name = "procedure_removes"


	select @rptline = "  Procedure Removals" + space(9) +
			str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) + 
			space(2) +
			str(@tmp_int / convert(real, @NumXacts),12,1) + 
			space(2) +
			str(@tmp_int, 10) + space(7) +
			@na_str


	exec asemon_print @rptline


	select @tmp_reco_total = sum(value)
	  from #tempmonitors
	  where group_name = "procmgr" and
			field_name in ("proc_recompilation_exec",
				"proc_recompilation_comp",
				"proc_recompilation_exec_curs",
				"proc_recompilation_redef")


	select @rptline = "  Procedure Recompilations" + space(3) +
			str(@tmp_reco_total / (@NumElapsedMs / 1000.0),12,1) +
			space(2) +
			str(@tmp_reco_total / convert(real, @NumXacts),12,1) +
			space(2) +
			str(@tmp_reco_total, 10) + space(7) +
			@na_str


	exec asemon_print @rptline


	if (@tmp_reco_total != 0)
	  begin
		exec asemon_print @blankline


		exec asemon_print "  Recompilations Requests:"


		select @tmp_int = value
		  from #tempmonitors
		  where group_name = "procmgr" and
			field_name = "proc_recompilation_exec"


		select @rptline = "    Execution Phase" + space(10) +
			str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
			space(2) +
			str(@tmp_int / convert(real, @NumXacts),12,1) +
			space(2) +
			str(@tmp_int, 10) + space(5) +
			str(100.0 * @tmp_int / @tmp_reco_total,5,1) + @psign


		exec asemon_print @rptline


		select @tmp_int = value
		  from #tempmonitors
		  where group_name = "procmgr" and
			field_name = "proc_recompilation_comp"


		select @rptline = "    Compilation Phase" + space(8) +
			str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
			space(2) +
			str(@tmp_int / convert(real, @NumXacts),12,1) +
			space(2) +
			str(@tmp_int, 10) + space(5) +
			str(100.0 * @tmp_int / @tmp_reco_total,5,1) + @psign


		exec asemon_print @rptline


		select @tmp_int = value
		  from #tempmonitors
		  where group_name = "procmgr" and
			field_name = "proc_recompilation_exec_curs"


		select @rptline = "    Execute Cursor Execution" + space(1) +
			str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
			space(2) +
			str(@tmp_int / convert(real, @NumXacts),12,1) +
			space(2) +
			str(@tmp_int, 10) + space(5) +
			str(100.0 * @tmp_int / @tmp_reco_total,5,1) + @psign


		exec asemon_print @rptline


		select @tmp_int = value
		  from #tempmonitors
		  where group_name = "procmgr" and
			field_name = "proc_recompilation_redef"


		select @rptline = "    Redefinition Phase" + space(7) +
			str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
			space(2) +
			str(@tmp_int / convert(real, @NumXacts),12,1) +
			space(2) +
			str(@tmp_int, 10) + space(5) +
			str(100.0 * @tmp_int / @tmp_reco_total,5,1) + @psign


		exec asemon_print @rptline


		exec asemon_print @blankline


		exec asemon_print "  Recompilation Reasons:"


		select @tmp_int = value
		  from #tempmonitors
		  where group_name = "procmgr" and
			field_name = "proc_recomp_tabmissing"


		select @rptline = "    Table Missing" + space(12) +
			str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
			space(2) +
			str(@tmp_int / convert(real, @NumXacts),12,1) +
			space(2) +
			str(@tmp_int, 10) + space(7) +
			@na_str


		 exec asemon_print @rptline


		select @tmp_int = value
		  from #tempmonitors
		  where group_name = "procmgr" and
			field_name = "proc_recomp_tempmissing"


		select @rptline = "    Temporary Table Missing" + space(2) +
			str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
			space(2) +
			str(@tmp_int / convert(real, @NumXacts),12,1) +
			space(2) +
			str(@tmp_int, 10) + space(7) +
			@na_str


		exec asemon_print @rptline


		select @tmp_int = value
		  from #tempmonitors
		  where group_name = "procmgr" and
			field_name = "proc_recomp_schemacount"


		select @rptline = "    Schema Change" + space(12) +
			str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
			space(2) +
			str(@tmp_int / convert(real, @NumXacts),12,1) +
			space(2) +
			str(@tmp_int, 10) + space(7) +
			@na_str


		exec asemon_print @rptline


		select @tmp_int = value
		  from #tempmonitors
		  where group_name = "procmgr" and
			field_name = "proc_recomp_idxchange"


		select @rptline = "    Index Change" + space(13) +
			str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
			space(2) +
			str(@tmp_int / convert(real, @NumXacts),12,1) +
			space(2) +
			str(@tmp_int, 10) + space(7) +
			@na_str


		exec asemon_print @rptline


		select @tmp_int = value
		  from #tempmonitors
		  where group_name = "procmgr" and
			field_name = "proc_recomp_isolevel"


		select @rptline = "    Isolation Level Change" + space(3) +
			str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
			space(2) +
			str(@tmp_int / convert(real, @NumXacts),12,1) +
			space(2) +
			str(@tmp_int, 10) + space(7) +
			@na_str


		exec asemon_print @rptline


		select @tmp_int = value
		  from #tempmonitors
		  where group_name = "procmgr" and
			field_name = "proc_recomp_permissions"


		select @rptline = "    Permissions Change" + space(7) +
			str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
			space(2) +
			str(@tmp_int / convert(real, @NumXacts),12,1) +
			space(2) +
			str(@tmp_int, 10) + space(7) +
			@na_str


		exec asemon_print @rptline


		select @tmp_int = value
		  from #tempmonitors
		  where group_name = "procmgr" and
			field_name = "proc_recomp_cursor_perm"


		select @rptline = "    Cursor Permissions Change" +
			str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
			space(2) +
			str(@tmp_int / convert(real, @NumXacts),12,1) +
			space(2) +
			str(@tmp_int, 10) + space(7) +
			@na_str


		exec asemon_print @rptline 
	  end
  end


exec asemon_print @blankline


exec asemon_print "  SQL Statement Cache:"


select @tmp_total = value
  from #tempmonitors
  where group_name = "procmgr" and
		field_name = "proc_ssql_procs_available"


select @rptline = "    Statements Cached" + space(8) +
			str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) + 
			space(2) +
			str(@tmp_total / convert(real, @NumXacts),12,1) + 
			space(2) +
			str(@tmp_total, 10) + space(7) +
			@na_str
exec asemon_print @rptline


select @tmp_total = value
  from #tempmonitors
  where group_name = "procmgr" and
		field_name = "proc_ssql_found"


select @rptline = "    Statements Found in Cache" +
			str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) + 
			space(2) +
			str(@tmp_total / convert(real, @NumXacts),12,1) + 
			space(2) +
			str(@tmp_total, 10) + space(7) +
			@na_str
exec asemon_print @rptline


select @tmp_total = value
  from #tempmonitors
  where group_name = "procmgr" and
		field_name = "proc_ssql_not_found"


select @rptline = "    Statements Not Found" + space(5) +
			str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) + 
			space(2) +
			str(@tmp_total / convert(real, @NumXacts),12,1) + 
			space(2) +
			str(@tmp_total, 10) + space(7) +
			@na_str
exec asemon_print @rptline


select @tmp_total = value
  from #tempmonitors
  where group_name = "procmgr" and
		field_name = "proc_ssql_dropped"


select @rptline = "    Statements Dropped" + space(7) +
			str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) + 
			space(2) +
			str(@tmp_total / convert(real, @NumXacts),12,1) + 
			space(2) +
			str(@tmp_total, 10) + space(7) +
			@na_str
exec asemon_print @rptline


select @tmp_total = value
  from #tempmonitors
  where group_name = "procmgr" and
		field_name = "proc_ssql_restored"


select @rptline = "    Statements Restored" + space(6) +
			str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) + 
			space(2) +
			str(@tmp_total / convert(real, @NumXacts),12,1) + 
			space(2) +
			str(@tmp_total, 10) + space(7) +
			@na_str
exec asemon_print @rptline


select @tmp_total = value
  from #tempmonitors
  where group_name = "procmgr" and
		field_name = "proc_ssql_notcached"


select @rptline = "    Statements Not Cached" + space(4) +
			str(@tmp_total / (@NumElapsedMs / 1000.0),12,1) + 
			space(2) +
			str(@tmp_total / convert(real, @NumXacts),12,1) + 
			space(2) +
			str(@tmp_total, 10) + space(7) +
			@na_str
exec asemon_print @rptline


exec asemon_print @blankline
if @Reco = 'Y'
 begin
	select @recotxt = "  Tuning Recommendations for Procedure cache management"
	select @recoline = "  -----------------------------------------------------"
	select @reco_hdr_prn = 0


	/*
	** If % of the number of times a procedure was read from disk is
	** is > 10% consider increasing the procedure cache size
	*/	
	if @reco_phdr_read_from_disk > 10
	begin
                if (@reco_hdr_prn = 0)
                begin
                        exec asemon_print @recotxt
                        exec asemon_print @recoline
                        select @reco_hdr_prn = 1
                end


		exec asemon_print "  - Consider increasing the 'procedure cache size'"
		exec asemon_print "    configuration parameter."
		exec asemon_print @blankline
	end
 end




exec asemon_print @blankline
return

create table #tmpThreadPool (
InstanceID            tinyint not null,
ThreadPoolID          int     not null,
Size                  int     not null,
TargetSize            int     not null,
Tasks                 int     not null,
IdleTimeout           int     not null,
ThreadPoolName        varchar( 30) null,
ThreadPoolDescription varchar(255) null,
Type                  varchar( 30) null,
InstanceName          varchar( 30) null
)
create table #cachemap (                                                                
        cid smallint,                         
        name varchar(255),                    
        group_name varchar(255),              
        cache_status            char(24) null,
        cache_type              char(24) null,
        cache_config_size       char(24) null,
        cache_run_size          char(24) null,
        config_replacement      char(24) null,
        run_replacement         char(24) null)
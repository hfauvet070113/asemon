create table #pool_detail_per_cache (                                      
          name          varchar(80),                                       
          io_size       char(8)
)                                                                    
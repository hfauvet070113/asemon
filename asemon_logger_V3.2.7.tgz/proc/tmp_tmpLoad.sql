create table #tmpLoad (
StatisticID  smallint not null,
EngineNumber smallint not null,
Avg_1min     real     not null,
Avg_5min     real     not null,
Avg_15min    real     not null,
ThreadPoolID int      not null
)
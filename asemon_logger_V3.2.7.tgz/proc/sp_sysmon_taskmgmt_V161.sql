create procedure sp_sysmon_taskmgmt_V161


	@NumEngines smallint,	/* number of engines online */
	@NumElapsedMs int,	/* for "per Elapsed second" calculations */
	@NumXacts int,		/* for per transactions calculations */
	@Reco	char(1),		/* Flag for recommendations */
        @kernelmode  varchar(10)       /* added for asemon_report */
as


/* --------- declare local variables --------- */
declare @NumTaskSwitch bigint,	/* Total Number of Task Context Switches 
				** across all engines */
	@IgnoreTaskSwitch int,	/* Total Number of Task Context Switches 
				** which can be ignored */
	@KnownTaskSwitch int,	/* Count of Number of Task Context Switches 
				** by Known Causes */
	@IgnoreTaskYields int,	/* Total Number of Task Yields which can be
				** ignored */
	@i smallint,		/* loop index to iterate through multi-group 
				** counters (engine, disk, & buffer) */
	@tmp_grp varchar(25),	/* temp var for building group_names 
				** ie. engine_N, disk_N */		
	@tmp_int bigint,	/* temp var for integer storage */
	@tmp_tot bigint,		/* temp var for integer storage */
	@tmp_iopacing int,	/* temp var for storing the value of I/O pacing */
	@sum1line char(80),	/* string to delimit total lines without 
				** percent calc on printout */	
	@sum2line char(67),	/* string to delimit total lines with percent 
				** calc on printout */
	@blankline char(1),	/* to print blank line */
	@psign char(3),		/* hold a percent sign (%) for print out */
	@na_str char(3),	/* holds 'n/a' for 'not applicable' strings */
	@rptline char(80),	/* formatted stats line for print statement */
	@section char(80),	/* string to delimit sections on printout */


/* ------------- threaded mode variables -------------*/
	@EngineId int,		/* Engine Id corresponding to thread */
	@ThreadId int,		/* Thread ID*/
	@TpId int,		/* Thread Pool ID */
	@thr_count int,		/* number of threads */
	@TpName varchar(80),	/* ThreadPool Name */


/* ------------- Variables for Tuning Recommendations ------------*/
	@recotxt char(80),
	@recoline char(80),
	@reco_hdr_prn bit,
	@reco_cache_search_miss real,
	@reco_io_pacing real,
	@reco_lock_contention real,
	@reco_group_commit_sleeps real,
	@reco_device_contention real,
	@reco_network_sent real,
	@reco_network_received real




/* --------- Setup Environment --------- */
set nocount on			/* disable row counts being sent to client */


select @sum1line   = "---------------------------  ------------  ------------  ----------  ----------"
select @sum2line   = "  -------------------------  ------------  ------------  ----------"
select @blankline  = " "
select @psign      = " %%"		/* extra % symbol because '%' is escape char in print statement */
select @na_str     = "n/a"
select @section = "==============================================================================="


/* =========================  Task Management Section ==================== */
print @section
print @blankline
print "Task Management                   per sec      per xact       count  %% of total"
print @sum1line
print @blankline
/*
** ------ Connections Opened (Closed Not Available in counters) ------
*/
select @tmp_int = value
from #tempmonitors
where group_name = "kernel" and
	  field_name = "processes_created"


select @rptline="  Connections Opened" + space(9)
				+ str(@tmp_int/(@NumElapsedMs/1000.0),12,1)
				+ space(2)
				+ str(@tmp_int/convert(real,@NumXacts),12,1)
				+ space(1)
				+ str(@tmp_int, 11) + space(7)
				+ @na_str
print @rptline
print @blankline


select @NumTaskSwitch = SUM(convert(bigint, value))
  from #tempmonitors
  where group_name like "engine_%" and
		field_name = "context_switches"




/*
** Count the number of task switches which can be ignored. For example,
** BCM/CLM daemon may be woken up when ever a request is queued. Once
** the request is serviced, daemons goes back to sleep. Similarly sleeps
** due to garbage collector can also be ignored.
*/
select @IgnoreTaskSwitch = 0


select @tmp_int = value
  from #tempmonitors
  where group_name = "lock" and 
		field_name = "lock_gc_yields"


select @IgnoreTaskSwitch = @IgnoreTaskSwitch + @tmp_int




select @tmp_int = value
  from #tempmonitors
  where group_name = "lock" and 
		field_name = "daemon_context_switches"


select @IgnoreTaskSwitch = @IgnoreTaskSwitch + @tmp_int


select @tmp_int = SUM(convert(bigint, value))
  from #tempmonitors
  where group_name = "bcmt" and 
		field_name in ("bcmt_pri_sleeps", "bcmt_sec_sleeps")


select @IgnoreTaskSwitch = @IgnoreTaskSwitch + @tmp_int 


select @IgnoreTaskYields = value
  from #tempmonitors
  where group_name = "bcmt" and 
		field_name = "bcmt_sec_empty_scans"


print "  Task Context Switches by Engine"


if @NumTaskSwitch <= 0	/* Avoid divide by zero errors - print zero's */
 begin
	select @rptline = "      Total Task Switches             0.0           0.0           0       n/a"
  	print @rptline
 end
else              
  begin
  if(@kernelmode = 'process') 
  begin
	select @i = 0
	while @i < @NumEngines		/* for each engine */
	  begin
		/* build group_name string */
		select @tmp_grp = "engine_" + convert(varchar(4), @i)


		/* If an engine's clock_ticks counter is 0, this means this engine
		** is in offline status. We should skip this engine when priting
		** the statistic information.
		*/
		if (select value
			from #tempmonitors where field_name="clock_ticks"
				and group_name=@tmp_grp) > 0
		begin
			select @tmp_int = value
			  from #tempmonitors
			  where group_name = @tmp_grp and
	  				field_name = "context_switches"


			select @rptline = "    Engine "+convert(char(4),@i)+space(14) +
					str(@tmp_int/(@NumElapsedMs/1000.0),12,1) + 
					space(2) +
					str(@tmp_int/convert(real,@NumXacts),12,1) + 
					space(1) +
					str(@tmp_int, 11) + space(5) +
					str(100.0 * @tmp_int / @NumTaskSwitch,5,1) + 
					@psign
			print @rptline
		end
		select @i = @i + 1
	  end	/* while */
    end /* process mode */
    else
    begin
    	print @blankline
	
    	/* threaded mode */
-- asemon_report : the new temp table is populated by asemon_report
/*
    	select ThreadPoolID, ThreadPoolName, Size, Type 
		into #tmpThreadPool
		from master.dbo.monThreadPool 
		order by ThreadPoolName
*/

	declare epcursor cursor for
		select ThreadPoolID, ThreadPoolName, Size 
		from #tmpThreadPool
		where Type = "Engine (Multiplexed)"
		order by ThreadPoolName	
		
    	declare engcursor cursor for
		select engineid, enginename
		from #muxthreadsinfo
		where tpname = @TpName
		order by engineid


	open epcursor
	fetch epcursor into @TpId, @TpName, @thr_count
	while (@@sqlstatus = 0)
	begin
		select @rptline = "  ThreadPool : "+ @TpName
		print @rptline
	
		select @tmp_tot = 0
		
		open engcursor
		fetch engcursor into @EngineId, @tmp_grp
		while (@@sqlstatus = 0)
		begin
			select @tmp_int = value
				from #tempmonitors
				where group_name = @tmp_grp and
				field_name = "context_switches"
			select @tmp_tot = @tmp_tot + @tmp_int
			
			select @rptline = "    Engine " + convert(char(4),@EngineId) +
				space(14) + 
				str(@tmp_int/(@NumElapsedMs/1000.0),12,1) +
				space(2) +
				str(@tmp_int/convert(real,@NumXacts),12,1) +
				space(1) +
				str(@tmp_int, 11) + space(5) +
				str(100.0 * @tmp_int / (@NumTaskSwitch +
				@IgnoreTaskSwitch + @IgnoreTaskYields),5,1) +
				@psign
			print @rptline
	
			fetch engcursor into @EngineId, @tmp_grp
		end 
		close engcursor
		
		/* Print the Pool Average */
		if @thr_count > 1
		begin
			print @sum2line
			select @rptline = "  Pool Summary" + space(8) 
				+ "Total" + space(2) +
				str(@tmp_tot / (@NumElapsedMs / 1000.0),12,1)
				+ space(2) +
				str(@tmp_tot / convert(real, @NumXacts),12,1)
				+ space(1) +
				str(@tmp_tot, 11) + space(5) 
			print @rptline
			
			select @rptline = space(20) + "Average" + space(2) +
				str((@tmp_tot / @thr_count) / (@NumElapsedMs / 1000.0),12,1)
				+ space(2) +
				str((@tmp_tot / @thr_count)/ convert(real, @NumXacts),12,1)
				+ space(1) +
				str((@tmp_tot / @thr_count), 11) + space(5) 
			print @rptline
		end


		print @blankline
		
		fetch epcursor into @TpId, @TpName, @thr_count
	end /* loop of pools */	
	
	close epcursor
	deallocate cursor epcursor


    end /* threaded mode */
    
    if @NumEngines > 1
    begin
	print @sum2line 
	select @rptline = "    Total Task Switches:" + space(5) +
		str(@NumTaskSwitch / (@NumElapsedMs / 1000.0),12,1) + 
		space(2) +
		str(@NumTaskSwitch / convert(real,@NumXacts),12,1) + 
		space(2) +
		str(@NumTaskSwitch,10)
	print @rptline
     end /* if @NumEngines > 1*/
     
	print @blankline


	select @NumTaskSwitch = @NumTaskSwitch - @IgnoreTaskSwitch - @IgnoreTaskYields


	/* 
	** Break Down All Task Context Switches by Cause 
	*/
	print "  Task Context Switches Due To:"


	/* init count of known context switches */
	select @KnownTaskSwitch = 0		


	/* 
	** Context Switch Due to Task Yields (Voluntary)
	*/
	select @tmp_int = value
	  from #tempmonitors
	  where group_name = "kernel" and
	  		field_name = "yields"


	select @tmp_int = @tmp_int - @IgnoreTaskYields


	select @KnownTaskSwitch = @KnownTaskSwitch + @tmp_int 


	select @rptline = "    Voluntary Yields" + space(9) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(1) +
				str(@tmp_int, 11) + space(5) +
				str(100.0 * @tmp_int / @NumTaskSwitch,5,1) + 
				@psign
	print @rptline


	/*
	**  Context Switch Due to Cache Search Misses resulting in a read
	*/
	select @tmp_int = SUM(convert(bigint, value))
	  from #tempmonitors
	  where group_name like "buffer_%" and
			field_name = "bufread_read_waits"


	select @KnownTaskSwitch = @KnownTaskSwitch + @tmp_int


	select @rptline = "    Cache Search Misses" + space(6) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(1) +
				str(@tmp_int, 11) + space(5) +
				str(100.0 * @tmp_int / @NumTaskSwitch,5,1) +
				@psign


	select @reco_cache_search_miss = convert(int, 
			100.0 * ((1.0* @tmp_int) / @NumTaskSwitch))


	print @rptline


	/*  
	**  Context Switch due to exceeding the 'i/o batch size' config limit.
	**
	**  In other words, we started I/O batch and now we are waiting
	**  for them to complete before starting the next batch.  The server 
	**  works in batches to avoid flooding the I/O subsystem.  The size 
	**  of the batch is tuneable via config parameter 'io batch size'.
	*/
	select @tmp_int = SUM(convert(bigint, value))
	  from #tempmonitors
	  where group_name like "buffer_%" and
			field_name in ("my_start_waits_periobatch")


	select @tmp_iopacing = @tmp_int		
			
	select @KnownTaskSwitch = @KnownTaskSwitch + @tmp_int


	select @rptline = "    Exceeding I/O batch size" + space(1) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(1) +
				str(@tmp_int, 11) + space(5) +
				str(100.0 * @tmp_int / @NumTaskSwitch,5,1) +
				@psign


	select @reco_io_pacing = convert(int, 
			100.0 * ((1.0* @tmp_int)/@NumTaskSwitch))


	print @rptline


	/* 
	** Context Switch Due to Disk Writes 
	*/
	select @tmp_int = SUM(convert(bigint, value))
	  from #tempmonitors
	  where group_name like "buffer_%" and
			field_name in ("write_waits", "hk_write_waits", 
					"restart_io_waits",
					"my_start_waits_log", 
					"my_start_waits_non-log",
					"my_other_waits_non-log") 


	/* 
	** the I/O pacing times will also be record in 
	** restart_io_waits || my_start_waits_log || my_start_waits_non-log.
	** So we should subtract out my_start_waits_periobatch
	*/
	select @tmp_int = @tmp_int - @tmp_iopacing		


	select @KnownTaskSwitch = @KnownTaskSwitch + @tmp_int


	select @rptline = "    System Disk Writes" + space(7) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(1) +
				str(@tmp_int, 11) + space(5) +
				str(100.0 * @tmp_int / @NumTaskSwitch,5,1) + 
				@psign
	print @rptline


	/*
	** Context Switch Due to DB Lock Contention
	*/
	select @tmp_int = SUM(convert(bigint, value))
	  from #tempmonitors
	  where group_name = "lock" and
			field_name like "waited_%" and
			field_name not like "waited_%_ADDR"


	select @KnownTaskSwitch = @KnownTaskSwitch + @tmp_int


	select @rptline = "    Logical Lock Contention  " +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(1) +
				str(@tmp_int, 11) + space(5) +
				str(100.0 * @tmp_int / @NumTaskSwitch,5,1) +
				@psign
	
	select @reco_lock_contention = convert(int, 
			100.0 * ((1.0* @tmp_int)/@NumTaskSwitch))


	print @rptline


	/*  
	** Context Switch Due to Address Lock Contention 
	*/
	select @tmp_int = SUM(convert(bigint, value))
	  from #tempmonitors
	  where group_name = "lock" and
			field_name like "waited_%_ADDR"


	select @KnownTaskSwitch = @KnownTaskSwitch + @tmp_int


	select @rptline = "    Address Lock Contention  " +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(1) +
				str(@tmp_int, 11) + space(5) +
				str(100.0 * @tmp_int / @NumTaskSwitch,5,1) + 
				@psign
	print @rptline


	/* 
	** Context Switch Due to Latch Contention 
	*/
	select @tmp_int = SUM(convert(bigint, value))
	  from #tempmonitors
	  where group_name = "latch" and
			field_name like "waited_%_LATCH"


	select @KnownTaskSwitch = @KnownTaskSwitch + @tmp_int


	select @rptline = "    Latch Contention  " + space(7) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(1) +
				str(@tmp_int, 11) + space(5) +
				str(100.0 * @tmp_int / @NumTaskSwitch,5,1) + 
				@psign


	print @rptline


	/* Context Switch Due to Physical lock transition. */
	select @tmp_int = SUM(convert(bigint, value))
	  from #tempmonitors
	  where group_name = "lock" and
			field_name like "physical_lock_context_switches"


	select @KnownTaskSwitch = @KnownTaskSwitch + @tmp_int


	select @rptline = "    Physical Lock Transition" + space(1) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(1) +
				str(@tmp_int, 11) + space(5) +
				str(100.0 * @tmp_int / @NumTaskSwitch,5,1) + 
				@psign


	print @rptline


	/* Context Switch Due to Logical Lock Transition. */
	select @tmp_int = SUM(convert(bigint, value))
	  from #tempmonitors
	  where group_name = "lock" and
			field_name like "logical_lock_context_switches"


	select @KnownTaskSwitch = @KnownTaskSwitch + @tmp_int


	select @rptline = "    Logical Lock Transition" + space(2) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(1) +
				str(@tmp_int, 11) + space(5) +
				str(100.0 * @tmp_int / @NumTaskSwitch,5,1) + 
				@psign


	print @rptline


	/* Context Switch Due to Object Lock Transition. */
	select @tmp_int = SUM(convert(bigint, value))
	  from #tempmonitors
	  where group_name = "lock" and
			field_name like "ocm_context_switches"


	select @KnownTaskSwitch = @KnownTaskSwitch + @tmp_int


	select @rptline = "    Object Lock Transition " + space(2) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(1) +
				str(@tmp_int, 11) + space(5) +
				str(100.0 * @tmp_int / @NumTaskSwitch,5,1) + 
				@psign


	print @rptline


	/* 
	** Context Switch Due to Blocking on Log Semaphore 
	*/
	select @tmp_int = value
	  from #tempmonitors
	  where group_name = "xls" and
			field_name = "log_lock_waited"

	select @KnownTaskSwitch = @KnownTaskSwitch + @tmp_int

	select @rptline = "    Log Semaphore Contention " +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(1) +
				str(@tmp_int, 11) + space(5) +
				str(100.0 * @tmp_int / @NumTaskSwitch,5,1) + 
				@psign
	print @rptline

	/* 
	** Context Switch Due to Blocking on IMRS Log Semaphore 
	*/
	select @tmp_int = value
	  from #tempmonitors
	  where group_name = "xls" and
			field_name = "imrslog_lock_waited"

	select @KnownTaskSwitch = @KnownTaskSwitch + @tmp_int

	select @rptline = "    IMRSLog Semaphore Contention " + space(1) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),7,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(1) +
				str(@tmp_int, 11) + space(5) +
				str(100.0 * @tmp_int / @NumTaskSwitch,5,1) + 
				@psign
	print @rptline

	/* 
	** Context Switch Due to Blocking on PLCBLOCK flush
	*/
	select @tmp_int = value
	  from #tempmonitors
	  where group_name = "xls" and
			field_name = "plcb_flush_waitforflush"

	select @KnownTaskSwitch = @KnownTaskSwitch + @tmp_int

	select @rptline = "    PLCBLOCK flush " + space(10) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(1) +
				str(@tmp_int, 11) + space(5) +
				str(100.0 * @tmp_int / @NumTaskSwitch,5,1) + 
				@psign
	print @rptline

	/* 
	** Context Switch Due to Blocking on PLC lock
	*/
	select @tmp_int = value
	  from #tempmonitors
	  where group_name = "xls" and
			field_name = "plc_lock_waits"


	select @KnownTaskSwitch = @KnownTaskSwitch + @tmp_int


	select @rptline = "    PLC Lock Contention " + space(5) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(1) +
				str(@tmp_int, 11) + space(5) +
				str(100.0 * @tmp_int / @NumTaskSwitch,5,1) + 
				@psign
	print @rptline


	/* 
	** Context Switch Due to Group Commit Sleeps 
	*/
	select @tmp_int = SUM(convert(bigint, value))
	  from #tempmonitors
	  where group_name like "buffer_%" and
			field_name IN ("my_other_waits_log", 
					"log_lastpage_pending_io_sleeps")


	select @KnownTaskSwitch = @KnownTaskSwitch + @tmp_int


	select @rptline = "    Group Commit Sleeps" + space(6) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(1) +
				str(@tmp_int, 11) + space(5) +
				str(100.0 * @tmp_int / @NumTaskSwitch,5,1) + 
				@psign


	select @reco_group_commit_sleeps = convert(int, 
			100.0 * ((1.0* @tmp_int)/@NumTaskSwitch))


	print @rptline

	/*
        ** Context Switch Due to IMRSLog Group Commit Sleeps
        */
        select @tmp_int = SUM(convert(bigint, value))
          from #tempmonitors
          where group_name like "buffer_%" and
                        field_name IN ("imrslog_gpcmt_waits")

	if (@tmp_int > 0)
	begin
        	select @KnownTaskSwitch = @KnownTaskSwitch + @tmp_int

        	select @rptline = "    IMRSLog Group Commit Sleeps" + 
                                str(@tmp_int / (@NumElapsedMs / 1000.0),10,1) +
                                space(2) +
                                str(@tmp_int / convert(real, @NumXacts),12,1) +
                                space(1) +
                                str(@tmp_int, 11) + space(5) +
                                str(100.0 * @tmp_int / @NumTaskSwitch,5,1) +
                                @psign

        	print @rptline
	end


	/*  
	** Context Switch Due to Last Log Page Writes 
	*/
	select @tmp_int = SUM(convert(bigint, value))
	  from #tempmonitors
	  where group_name like "buffer_%" and
			field_name = "last_log_page_writes"


	select @KnownTaskSwitch = @KnownTaskSwitch + @tmp_int


	select @rptline = "    Last Log Page Writes" + space(5) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(1) +
				str(@tmp_int, 11) + space(5) +
				str(100.0 * @tmp_int / @NumTaskSwitch,5,1) + 
				@psign
	print @rptline


	/* Context Switch Due to Modify Conflicts 
	**
	**  In other words, a task wants to perform an operation on a page 
	**  (i.e. write it), but can't because another task is in the middle 
	**  of modifying it.
	*/
	select @tmp_int = SUM(convert(bigint, value))
	  from #tempmonitors
	  where group_name like "buffer_%" and field_name in 
		  ("changing_state_waits", "bufwrite_changing_waits", 
		   "bufpredirty_write_waits", "bufpredirty_changing_waits", 
		   "bufnewpage_changing_waits", "ind_bufguess_changing_waits",
		   "ind_bufguess_writing_waits")


	select @KnownTaskSwitch = @KnownTaskSwitch + @tmp_int


	select @rptline = "    Modify Conflicts" + space(9) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(1) +
				str(@tmp_int, 11) + space(5) +
				str(100.0 * @tmp_int / @NumTaskSwitch,5,1) + 
				@psign
	print @rptline


	/* 
	** Context Switch Due to Disk Device Contention 
	*/
	select @tmp_int = SUM(convert(bigint, value))
	  from #tempmonitors
	  where group_name like "disk_%" and
			field_name = "p_sleeps"


	select @KnownTaskSwitch = @KnownTaskSwitch + @tmp_int


	select @rptline = "    I/O Device Contention" + space(4) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(1) +
				str(@tmp_int, 11) + space(5) +
				str(100.0 * @tmp_int / @NumTaskSwitch,5,1) + 
				@psign


	select @reco_device_contention = convert(int, 
			100.0 * ((1.0* @tmp_int)/@NumTaskSwitch))


	print @rptline


	/* 
	** Context Switch Due to Network Packets Received
	*/
	select @tmp_int = value
	  from #tempmonitors
	  where group_name = "network" and
			field_name = "network_read_sleeps"


	select @KnownTaskSwitch = @KnownTaskSwitch + @tmp_int


	select @rptline = "    Network Packet Received" + space(2) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(1) +
				str(@tmp_int, 11) + space(5) +
				str(100.0 * @tmp_int / @NumTaskSwitch,5,1) + 
				@psign


	select @reco_network_received = convert(int, 
			100.0 * ((1.0* @tmp_int)/@NumTaskSwitch))


	print @rptline


	/* 
	** Context Switch Due to Network Packets Sent
	*/
	select @tmp_int = SUM(convert(bigint, value))
	  from #tempmonitors
	  where group_name = "network" and
			field_name = "network_send_sleeps"


	select @KnownTaskSwitch = @KnownTaskSwitch + @tmp_int


	select @rptline = "    Network Packet Sent" + space(6) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(1) +
				str(@tmp_int, 11) + space(5) +
				str(100.0 * @tmp_int / @NumTaskSwitch,5,1) + 
				@psign


	select @reco_network_sent = convert(int, 
			100.0 * ((1.0* @tmp_int)/@NumTaskSwitch))


	print @rptline


	/* Context Switch Due to CIPC Thread Sleeps. */
	select @tmp_int = SUM(convert(bigint, value))
	  from #tempmonitors
	  where group_name = "kernel" and
			field_name like "cipc_context_switches"


	select @KnownTaskSwitch = @KnownTaskSwitch + @tmp_int


	select @rptline = "    Interconnect Message Sleeps" + space(1) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),9,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(1) +
				str(@tmp_int, 11) + space(5) +
				str(100.0 * @tmp_int / @NumTaskSwitch,5,1) + 
				@psign


	print @rptline


	/*  
	**  Context Switch Due to Network services
	*/
	select @tmp_int = SUM(convert(bigint, value))
	  from #tempmonitors
	  where group_name like "network%" and
			field_name in ("nserver_sleeps")


	select @KnownTaskSwitch = @KnownTaskSwitch + @tmp_int


	select @rptline = "    Network services" + space(9) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(1) +
				str(@tmp_int, 11) + space(5) +
				str(100.0 * @tmp_int / @NumTaskSwitch,5,1) +
				@psign

	print @rptline

	/*  
	**  Context Switch Due to IMRS GC sleeps
	*/
	select @tmp_int = SUM(convert(bigint, value))
	  from #tempmonitors
	  where group_name like "imrs%" and
			field_name in ("imrs_gc_wakeups")

	if (@tmp_int > 0)
	begin
		select @KnownTaskSwitch = @KnownTaskSwitch + @tmp_int

		select @rptline = "    IMRS GC sleeps" + space(11) +
					str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
					space(2) +
					str(@tmp_int / convert(real, @NumXacts),12,1) +
					space(1) +
					str(@tmp_int, 11) + space(5) +
					str(100.0 * @tmp_int / @NumTaskSwitch,5,1) +
					@psign

		print @rptline
	end	

	/*  
	**  Context Switch Due to IMRS PACK sleeps
	*/
	select @tmp_int = SUM(convert(bigint, value))
	  from #tempmonitors
	  where group_name like "imrs%" and
			field_name in ("imrs_pack_wakeups")

	if (@tmp_int > 0)
	begin
		select @KnownTaskSwitch = @KnownTaskSwitch + @tmp_int

		select @rptline = "    IMRS PACK sleeps" + space(9) +
					str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
					space(2) +
					str(@tmp_int / convert(real, @NumXacts),12,1) +
					space(1) +
					str(@tmp_int, 11) + space(5) +
					str(100.0 * @tmp_int / @NumTaskSwitch,5,1) +
					@psign

		print @rptline
	end

	/*  
	**  Context Switch Due to IMRS LOB GC sleeps
	*/
	select @tmp_int = SUM(convert(bigint, value))
	  from #tempmonitors
	  where group_name like "imrs%" and
			field_name in ("imrs_lobgc_wakeups")

	if (@tmp_int > 0)
	begin
		select @KnownTaskSwitch = @KnownTaskSwitch + @tmp_int

		select @rptline = "    IMRS LOB GC sleeps" + space(7) +
					str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
					space(2) +
					str(@tmp_int / convert(real, @NumXacts),12,1) +
					space(1) +
					str(@tmp_int, 11) + space(5) +
					str(100.0 * @tmp_int / @NumTaskSwitch,5,1) +
					@psign

		print @rptline
	end

	/*  
	**  Context Switch Due to HCB GC sleeps
	*/
	select @tmp_int = SUM(convert(bigint, value))
	  from #tempmonitors
	  where group_name like "btree%" and
			field_name in ("bt_hcb_gc_wakeups")

	if (@tmp_int > 0)
	begin
		select @KnownTaskSwitch = @KnownTaskSwitch + @tmp_int

		select @rptline = "    HCB GC sleeps" + space(12) +
					str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
					space(2) +
					str(@tmp_int / convert(real, @NumXacts),12,1) +
					space(1) +
					str(@tmp_int, 11) + space(5) +
					str(100.0 * @tmp_int / @NumTaskSwitch,5,1) +
					@psign

		print @rptline
	end

	/* 
	** Context Switch Due to Other Causes
	*/
	select @tmp_int = @NumTaskSwitch - @KnownTaskSwitch

	/*
	** Its possible that KnownTaskSwitch exceeds NumTaskSwitch. This happens
	** since in many places in the code we increment counter after 
	** upsleepgeneric call irrespective of whether context switch actually 
	** took place or not. 
	*/
	if (@tmp_int < 0)
	begin
		select @tmp_int = 0
	end

	select @rptline = "    Other Causes" + space(13) +
				str(@tmp_int / (@NumElapsedMs / 1000.0),12,1) +
				space(2) +
				str(@tmp_int / convert(real, @NumXacts),12,1) +
				space(1) +
				str(@tmp_int, 11) + space(5) +
				str(100.0 * @tmp_int / @NumTaskSwitch,5,1) + 
				@psign
	print @rptline


  end		/* else @NumTaskSwitch != 0 */


print @blankline


if @Reco = 'Y'
 begin
        select @recotxt = "  Tuning Recommendations for Task Management" 
        select @recoline = "  ------------------------------------------"
        select @reco_hdr_prn = 0


	/*
	** If the context switches due to cache misses is > 50% 
	** consider tuning your Data Caches
	*/
	if (@reco_cache_search_miss > 50)
	begin
                if (@reco_hdr_prn = 0)
                begin
                        print @recotxt
                        print @recoline
                        select @reco_hdr_prn = 1
                end


		print "  - Consider tuning your Data Caches."
		print "    Look into the Data Cache management section for"
		print "    more details on this."
		print @blankline
		select @reco_hdr_prn = 1
	end


	/*
	** If the context switches due to IO Pacing is > 50% consider tuning 
	** the 'i/o batch size' configuration parameter.
	*/
	if (@reco_io_pacing > 50)
	begin
                if (@reco_hdr_prn = 0)
                begin
                        print @recotxt
                        print @recoline
                        select @reco_hdr_prn = 1
                end


		print "  - Consider tuning the 'i/o batch size' configuration parameter parameter"
		print "	   A value of 100 is generally optimal. Also verify the I/O response times if the 'i/o batch size' tuning does not help"
		print @blankline
		select @reco_hdr_prn = 1
	end


	/*
	** If context switches due to lock contention is > 50% consider using 
	** different lock management strategies such as row level locking
	** for certain objects.
	*/
	if (@reco_lock_contention > 50)
	begin
                if (@reco_hdr_prn = 0)
                begin
                        print @recotxt
                        print @recoline
                        select @reco_hdr_prn = 1
                end


		print "  - Consider identifying objects with high"
		print "    lock contention using the sp_object_stats stored procedure"
		print "    Review the Lock management section for more details."
		print @blankline
		select @reco_hdr_prn = 1
	end
	/*
	** If the context switches due to group commit sleeps is > 50% 
	** consider tuning the log io size
	*/
	if (@reco_group_commit_sleeps > 50)
	begin
                if (@reco_hdr_prn = 0)
                begin
                        print @recotxt
                        print @recoline
                        select @reco_hdr_prn = 1
                end
		print "  - Consider lowering the logio size using sp_logiosize"
		print "    for better transaction commit performance."
		print "    This recommendation is not valid if the logio size is 2K."
		print @blankline
		select @reco_hdr_prn = 1
	end
	/*
	** If the context switches due to device contention is > 50% 
	** consider tuning the disk i/o sub system
	*/
	if (@reco_device_contention > 50)
	begin
                if (@reco_hdr_prn = 0)
                begin
                        print @recotxt
                        print @recoline
                        select @reco_hdr_prn = 1
                end


		print "  - Consider tuning your Disk I/O sub-system."
		print @blankline
		select @reco_hdr_prn = 1
	end
	/*
	** If the context switches due to the network is > 50% 
	** consider tuning the network I/O sub-system
	*/
	if (@reco_network_sent > 50 OR @reco_network_received > 50)
	begin
                if (@reco_hdr_prn = 0)
                begin
                        print @recotxt
                        print @recoline
                        select @reco_hdr_prn = 1
                end


		print "  - Consider tuning your Network I/O sub-system."
		print @blankline
		select @reco_hdr_prn = 1
	end
end
print @blankline


return 0

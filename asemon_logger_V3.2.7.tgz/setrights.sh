#!/bin/sh
# set access rights on all files
chmod -R u+rw *
chmod u+x *.sh
chmod -R g+r *
chmod -R o+r *
chmod o-r passw*
chmod g-r passw*
chmod +x conf
chmod +x dist
chmod +x jConnect-16_0
chmod +x jConnect-16_0/classes
chmod +x jConnect-16_0/sp
chmod +x lib
chmod +x src
chmod +x src/asemon_logger

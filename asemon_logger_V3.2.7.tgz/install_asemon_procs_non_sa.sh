#! /bin/sh


ASE_USER=$1
ASE_PASSWD=$2
ASE_SRV=$3

usage () {
  echo "install_asemon_procs_non_sa.sh sa password server"
}


exitinstall () {

  if [ -f /tmp/asemon_ase_vers_$$.out ]; then rm /tmp/asemon_ase_vers_$$.out; fi
#  if [ -f /tmp/asemon_execscript_${ASE_SRV}_$$.out ]; then rm /tmp/asemon_execscript_${ASE_SRV}_$$.out; fi
  exit $1

}

execscript () {
    echo "Executing script :  $1"
    isql -U$ASE_USER -P$ASE_PASSWD -S$ASE_SRV -Jiso_1 <$1 >/tmp/asemon_execscript_${ASE_SRV}_$$.out 2>&1 
    checkinstallscripterror
    echo "Install OK"
    exitinstall 0
}

checkinstallscripterror () {
  err=`grep -E 'CT-LIBRARY error:|^Msg|NULL' /tmp/asemon_execscript_${ASE_SRV}_$$.out | wc -l `
  if test $err -gt 0
  then
    echo "ERROR installing procedures :"
    grep -E 'CT-LIBRARY error:|^Msg|NULL' /tmp/asemon_execscript_${ASE_SRV}_$$.out
    exitinstall 1
  fi
}


# initial checks
if [ "$#" -lt 3 ]; then
  echo "Missing arguments."
  echo "Usage :"
  usage
  exit 1
fi
if [ $ASE_USER != "sa" ]
then
  echo "You must provide sa login when excuting this script. A user with sa_role is not sufficient !!!"
  exit 1
fi


# Get Srv version
echo "Getting ASE version..."
# Part1 : get version of srv prior to 15.7 (no @@sbssav)
isql -U$ASE_USER -P$ASE_PASSWD -S$ASE_SRV -w 1000 -b -Jiso_1 <<eof >/tmp/asemon_ase_vers_$$.out 2>&1
set nocount on
go
select substring(
   substring(@@version,charindex('ise/',@@version)+4,datalength(@@version)),
             1,                                                                                    
             charindex('/',substring(@@version,charindex('ise/',@@version)+4,datalength(@@version)))-1)
go
eof
err=`grep -E 'CT-LIBRARY error:|^Msg|NULL' /tmp/asemon_ase_vers_$$.out | wc -l `
if test $err -gt 0
then
  echo "ERROR in get ASE version part1 :"
  cat /tmp/asemon_ase_vers_$$.out
  ASEVERSION='NULL'
  exitinstall 1

else
  ASEVERSION=`cat /tmp/asemon_ase_vers_$$.out|sed 's/[[:space:]]//g'`
fi

if [ $ASEVERSION \> "15.7" -o $ASEVERSION = "15.7" ]
then

  # Part2 : get version of srv greater than 15.7 (using @@sbssav)
  isql -U$ASE_USER -P$ASE_PASSWD -S$ASE_SRV -w 1000 -b -Jiso_1 <<eof >/tmp/asemon_ase_vers_$$.out 2>&1
  set nocount on
go
    select @@sbssav
go
eof
  err=`grep -E 'CT-LIBRARY error:|^Msg|NULL' /tmp/asemon_ase_vers_$$.out | wc -l `
  if test $err -gt 0
  then
    echo "ERROR in get ASE version part2:"
    cat /tmp/asemon_ase_vers_$$.out
    ASEVERSION='NULL'
    exitinstall 1
  
  else
    ASEVERSION=`cat /tmp/asemon_ase_vers_$$.out|sed 's/[[:space:]]//g'`
  fi
fi

echo "ASE Version = $ASEVERSION"

if [ $ASEVERSION \> "16" ]
then
  SCRIPT=install_asemon_procs_non_sa_V16.sql
  execscript $SCRIPT
fi 
if [ $ASEVERSION \> "15.7.0.100" -o $ASEVERSION = "15.7.0.100" ]
then
  SCRIPT=install_asemon_procs_non_sa_V15.7SP100.sql
  execscript $SCRIPT
fi 
if [ $ASEVERSION \> "15.7" ]
then
  SCRIPT=install_asemon_procs_non_sa_V15.7.sql
  execscript $SCRIPT
fi 
if [ $ASEVERSION \> "15" ]
then
  SCRIPT=install_asemon_procs_non_sa_V15.sql
  execscript $SCRIPT
fi 
if [ $ASEVERSION = "12.5.0.3" ]
then
  SCRIPT=install_asemon_procs_non_sa_V12503.sql
  execscript $SCRIPT
fi 
if [ $ASEVERSION \> "12.5" ]
then
  SCRIPT=install_asemon_procs_non_sa_V125.sql
  execscript $SCRIPT
fi 

exitinstall 0



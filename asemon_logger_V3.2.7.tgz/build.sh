#!/bin/ksh

export ASEMON_LOGGER_HOME=${ASEMON_LOGGER_HOME:-"`pwd`"}
export JAVA_HOME=${JAVA_HOME:-"$ASEMON_LOGGER_HOME/../jdk1.7.0_71"}
export JCONNECT_HOME=$ASEMON_LOGGER_HOME/jConnect-16_0
export PATH=$JAVA_HOME/bin:$PATH
export CLASSPATH=$ASEMON_LOGGER_HOME/dist/Asemon_logger.jar:$ASEMON_LOGGER_HOME/lib/jdom.jar:$ASEMON_LOGGER_HOME/lib/xerces.jar:$ASEMON_LOGGER_HOME/lib/java-getopt-1.0.9.jar:$JCONNECT_HOME/classes/jconn4.jar:$JCONNECT_HOME/classes/jTDS3.jar 

mkdir build
mkdir build/classes

cd src
javac -g -d ../build/classes asemon_logger/*.java

cd ../build/classes
jar -cvf ../../dist/Asemon_logger_V3.jar asemon_logger/*
cd ../..


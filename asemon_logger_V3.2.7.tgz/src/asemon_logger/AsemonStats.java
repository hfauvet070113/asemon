/**
* <p>AsemonStats</p>
* <p>Asemon_logger :  class for asemon statistics mgmt</p>
* <p>Copyright: Jean-Paul Martin (jpmartin@sybase.com) Copyright (c) 2010</p>
* @version 2.7.18
*/

package asemon_logger;
import java.util.*;
import java.sql.*;

/**
 *
 * @author jpmartin
 */
public class AsemonStats {

    static final int PIPESZ=100;
    String srvName;  // Normalized name of monitored server (limited to 20 chars)


    // inner class to store one row of asemon stats
    class Stats {
        long eventTime;        // asemon_logger time of event
        String eventThread;
        long timeSrv;          // ASE server time of event
        long cWait;
        long cActive;
        long aWait;
        long aActive;
        int archRows;          // Number of rows archived during collection. -1 if error or no collection
        int delay;

        Stats (long dt, String th, long dtsrv, long cw, long ca, long aw, long aa, int ar, int dly){
            eventTime=dt;
            eventThread=th;
            timeSrv=dtsrv;
            cWait=cw;
            cActive=ca;
            aWait=aw;
            aActive=aa;
            archRows = ar;
            delay = dly;
        }

    }

    final Vector<Stats> stats_pipe;

    AsemonStats (String n) {
        srvName = n;
        stats_pipe = new Vector<Stats>(PIPESZ);
    }

    /*
     * add one row of statistics to the pipe
     * (remove the first row of pipe is already full)
     */
    void addStats(long dt, String th, long dtsrv, long cw, long ca, long aw, long aa, int ar, int dly){
        synchronized (stats_pipe) {
            if (stats_pipe.size()==PIPESZ) {
                stats_pipe.removeElementAt(0);
            }
            Stats aStats = new Stats(dt, th, dtsrv, cw, ca, aw, aa, ar, dly);
            stats_pipe.addElement(aStats);
        }
    }



    /*
     * Save statistics into the archive database
     * from the max row already saved to the end of the pipe
     */
    void savStats(Collector aCollector) throws Exception {
        // get an archive connection
        Stats aStats;
        Timestamp tsrv;
        Archive_array archive_array = new Archive_array();
        Archive_array.Archive_row aRow;

        archive_array.addColDef("Timestamp" , java.sql.Types.TIMESTAMP);
        archive_array.addColDef("Thread"    , java.sql.Types.VARCHAR  );
        archive_array.addColDef("cWait"     , java.sql.Types.BIGINT   );
        archive_array.addColDef("cActive"   , java.sql.Types.BIGINT   );
        archive_array.addColDef("aWait"     , java.sql.Types.BIGINT   );
        archive_array.addColDef("aActive"   , java.sql.Types.BIGINT   );
        archive_array.addColDef("archRows"  , java.sql.Types.INTEGER  );
        archive_array.addColDef("delay"     , java.sql.Types.INTEGER  );

     

        // Loop on all rows in pipe not already saved

        synchronized (stats_pipe){
            // Loop of all elements in the pipe and save them, and remove them from the pipe
            while (stats_pipe.size()>0) {
                aStats = stats_pipe.remove(0);
                tsrv = new Timestamp(aStats.timeSrv);
                aRow = archive_array.allocateNewRow();
                aRow.addValue( tsrv );
                aRow.addValue( aStats.eventThread);
                aRow.addValue( aStats.cWait);
                aRow.addValue( aStats.cActive);
                aRow.addValue( aStats.aWait);
                aRow.addValue( aStats.aActive);
                aRow.addValue( aStats.archRows);
                aRow.addValue( aStats.delay);
                archive_array.addRow(aRow);         // save this row in the array
            }
        }
        // Save this array into archive database
        Asemon_logger.archive_class.saveValues (srvName+"_AmStats", archive_array, aCollector);
          
    }

}

/**
* <p>CollectorRSStats</p>
* <p>Asemon_logger : class geting and archiving Replication Server Statistics</p>
* <p>Copyright: Jean-Paul Martin (jpmartin@sybase.com) Copyright (c) 2009</p>
* @version 3.2.6
*/

package asemon_logger;
import java.sql.*;
import java.util.*;

public class CollectorRSStats extends Collector {
  String sql;

  String srvName;
  String structName;

  Timestamp oldTime;
  Timestamp newTime;
  Long interval;

  boolean firstTime;
  //boolean supportMultiCommands = true;
  
  Hashtable<String, StatCounter> statCounters;
  Hashtable<String, KnownInstance> knownInstances;
  Hashtable<String, Counter> knownCounters;
  Hashtable<String, Observer> knownObservers;
  Hashtable<String, Monitor> knownMonitors;
  Vector<Instance> rsStats;
  
  int MAXID = 0;

  int nbRowsToInsert;
  
  int loopGetRSSDtime = 0;

  class StatCounter {
      String name;
      int num;
      String module_name;
      String description;

      
      StatCounter(String n, int c, String mn, String d) {
          name = n;
          num = c;
          module_name = mn;
          description = d;
      }
  }

  class Observer {
     String observer;
     long obs;
     long rate_x_sec;

     Observer (String o, long ob, long r) {
         observer = o;
         obs = ob;
         rate_x_sec = r;
     }
     private Observer duplicate() {
         Observer c = new Observer (this.observer, this.obs,this.rate_x_sec);
         return c;
     }
  }
  
  class Monitor {
     String monitor;
     long obs;
     long last;
     long maxVal;
     long avg_ttl_obs;

     Monitor (String m, long ob, long l, long mv, long ato) {
         monitor = m;
         obs = ob;
         last = l;
         maxVal = mv;
         avg_ttl_obs = ato;
     }
     private Monitor duplicate() {
         Monitor c = new Monitor (this.monitor, this.obs,this.last, this.maxVal, this.avg_ttl_obs);
         return c;
     }

  }

  class Counter {
     String counter;
     long obs;
     long total;
     long last;
     long maxVal;
     long avg_ttl_obs;
     long rate_x_sec;
     
     Counter (String c, long ob, long t, long l, long mv, long ato, long rxs) {
         counter = c;
         obs = ob;
         total = t;
         last = l;
         maxVal = mv;
         avg_ttl_obs = ato;
         rate_x_sec = rxs;
     }
     
     private Counter duplicate() {
         Counter c = new Counter (this.counter, this.obs, this.total, this.last, this.maxVal, this.avg_ttl_obs, this.rate_x_sec);
         return c;
     }
  }

    class Instance {
        int ID;
        String instance;
        int instance_id;
        int instance_val;
        Vector<Observer> Observers;
        Vector<Monitor> Monitors;
        Vector<Counter> Counters;
      
        Instance(String i, int iid, int m) {
            instance = i.trim();
            instance_id = iid;
            instance_val = m;
            Observers = new Vector<Observer>();
            Monitors = new Vector<Monitor>();
            Counters = new Vector<Counter>();
        }

        void addCounter (Counter aCounter) {
            Counters.add(aCounter);
        }

        void addMonitor (Monitor aMonitor) {
            Monitors.add(aMonitor);
        }

        void addObserver (Observer aObserver) {
            Observers.add(aObserver);
        }
      
        private Observer calcDeltaObserver (Observer aObs) {
            // compute key
                        String key = aObs.observer + "|" + instance;
            // Check if this observer was already seen
            Observer previousObs = knownObservers.get(key);
            if (previousObs == null) {
                // Create a copy of the new captured observer
                previousObs = aObs.duplicate();
                // Save this copy in memory for next collect
                knownObservers.put(key, previousObs);
            }
            else {
                // Found this previous observer in memory
                // Compute delta
                long delta = aObs.obs - previousObs.obs;               
                // save new values into knownCounters
                previousObs.obs = aObs.obs;
                if (delta < 0) {
                    // Means stats have been reset !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                    //Asemon_logger.printmess("WARNING - Seems stats have been reset by someone else or queues have been restarted or counters overflow");
                    // Keep new obs
                }
                else {
                    // will return the delta
                    aObs.obs = delta;
                }
            }
            // Compute the rate
            aObs.rate_x_sec = (aObs.obs*1000 / interval); // interval is ms

            return aObs;
        }

        private Counter calcDeltaCounter (Counter aCounter) {
            // compute key
            String key = aCounter.counter + "|" + instance;
            // Check if this counter was already seen
            Counter previousCounter = knownCounters.get(key);
            if (previousCounter == null) {
                // Create a copy of the new captured counter
                previousCounter = aCounter.duplicate();
                // Save this copy in memory for next collect
                knownCounters.put(key, previousCounter);
            }
            else {
                // Found this previous counter in memory
                // Compute delta
                long deltaObs = aCounter.obs - previousCounter.obs;               
                long deltaTotal = aCounter.total - previousCounter.total;               
                // save new values into knownCounters
                previousCounter.obs = aCounter.obs;
                previousCounter.total = aCounter.total;
                previousCounter.last = aCounter.last;
                previousCounter.maxVal = aCounter.last;
                if ( (deltaObs < 0) || (deltaTotal < 0) ) {
                    // Means stats have been reset !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                    //Asemon_logger.printmess("WARNING - Seems stats have been reset by someone else or queues have been restarted or counters overflow");
                    // Keep new obs
                }
                else {
                    // will return the delta
                    aCounter.obs = deltaObs;
                    aCounter.total = deltaTotal;
                    aCounter.maxVal = aCounter.last; // Force MAX to LAST since MAX is since the last reset, not the last sample. Will not get the real MAX if occuring during a sample
                }
            }
            // Compute the rate
            aCounter.rate_x_sec = (aCounter.total*1000 / interval); // interval is ms
            // Compute the avg_ttl_obs
            if (aCounter.obs!=0)
                aCounter.avg_ttl_obs = aCounter.total / aCounter.obs;
            else
                aCounter.avg_ttl_obs = 0;

            if(aCounter.counter.charAt(0)=='*') {
                // This counter must be sampled to reflect correct last and max. Asemon doesn't sample the counters, they are no longer reset after each collect
                aCounter.last = 0;
                aCounter.maxVal = 0;
            }
            return aCounter;
        }

        private Monitor calcDeltaMonitor (Monitor aMon) {
            // compute key
            String key = aMon.monitor + "|" + instance;
            // Check if this monitor was already seen
            Monitor previousMon = knownMonitors.get(key);
            if (previousMon == null) {
                // Create a copy of the new captured monitor
                previousMon = aMon.duplicate();
                // Save this copy in memory for next collect
                knownMonitors.put(key, previousMon);
            }
            else {
                // Found this previous observer in memory
                // Compute delta
                long delta = aMon.obs - previousMon.obs;               
                // save new values into knownCounters
                previousMon.obs = aMon.obs;
                previousMon.last = aMon.last;
                previousMon.maxVal = aMon.last;
                if (delta < 0) {
                    // Means stats have been reset !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                    //Asemon_logger.printmess("WARNING - Seems stats have been reset by someone else or queues have been restarted or counters overflow");
                    // Keep new obs
                }
                else {
                    // will return the delta
                    aMon.obs = delta;
                    aMon.maxVal = aMon.last; // Force MAX to LAST since MAX is since the last reset, not the last sample. Will not get the real MAX if occuring during a sample
                }
            }
            // Compute the avg_ttl_obs
            if (aMon.obs!=0)
                aMon.avg_ttl_obs = aMon.last / aMon.obs;
            else
                aMon.avg_ttl_obs = 0;
            return aMon;
        }

    }

  class KnownInstance {
      String instance;
      String module;
      int ID;
      int instance_id;
      int instance_val;
      KnownInstance(int num, String i, int id, int val){
          if (num==0)
              ID = ++MAXID;  // Generate a new instance ID based on max seen before +1
          else
              ID = num;
          instance = i;
          if (instance.indexOf(',')>-1)
              module = instance.substring(0, instance.indexOf(','));
          else
              module = instance;
          module = module.replace(" ", "");
          if (module.compareTo("dCM")==0)
              module="CM";
          instance_id = id;
          instance_val = val;
          //System.out.println("New instance in memory - ID="+ID+" id="+id+" val="+val+ " name="+i);
      }
  }
    
  public CollectorRSStats (MonitoredSRV ms, MetricDescriptor md) {
      super (ms, md);
      srvName = msrv.srvNormalized;
      structName = metricDescriptor.metricName;
  }

  void initialize () throws Exception {
      super.initialize();

      firstTime = true; // Set to true for first getMetrics call

      Statement stmt;

      // Initialize list of counters, in memory
      statCounters =  new Hashtable<String, StatCounter>();
      knownCounters =  new Hashtable<String, Counter>();
      knownObservers =  new Hashtable<String, Observer>();
      knownMonitors =  new Hashtable<String, Monitor>();

      if ((msrv.needRSSDServer)&& (msrv.RSSDConn == null))
          Asemon_logger.printmess("RSStats ERROR : cannot initialize list of counters from RSSD (cannot connect to RSSD Server)");
      else if (msrv.monSrvConn == null)
          Asemon_logger.printmess("RSStats ERROR : cannot initialize list of counters from RSSD (cannot connect to RS)");
      else {
          try {
            StatCounter aStatCounter;
            if ((msrv.needRSSDServer)&& (msrv.RSSDConn != null))
                stmt = msrv.RSSDConn.createStatement();
            else {
                // Connect to rssd
                stmt = msrv.monSrvConn.createStatement();
                try {
                    Asemon_logger.DEBUG("CollectorRSStats - Line 181, connect to rssd");
                    stmt.executeUpdate("connect to rssd");
                }
                catch (SQLException e) {
                    if (e.getErrorCode()!=15539) throw e; // ignore error  "Gateway connection to 'xxxx.yyy' is created"
                }
            }
            ResultSet rs=stmt.executeQuery("select display_name,counter_id,module_name,description from rs_statcounters");
            while (rs.next()) {
                String name = rs.getString(1);
                String module = rs.getString(3);
                aStatCounter = new StatCounter(name, rs.getInt(2),  module,  rs.getString(4));
                statCounters.put(name+"|"+module, aStatCounter);
                if (name.length()==30 ) {
                    // fix for Sybase bug in admin stats where name of 30 chars long are truncated by one char by "admin stats"
                    statCounters.put(name.substring(0, name.length()-1)+"|"+module, aStatCounter);                    
                }
            }
            if (!msrv.needRSSDServer) {
                try {
                    Asemon_logger.DEBUG("CollectorRSStats - Line 197, disconnect");
                    stmt.executeUpdate("disc");
                }
                catch(SQLException e) {
                    if (e.getErrorCode()!=15540) throw e;   // Ignore message "Gateway connection to 'xxxxx.xxxxx' is dropped."
                }
            }
            stmt.close();
            stmt = null;
          }
          catch (SQLException e){
             Asemon_logger.printmess("RSStats ERROR when initializing list of counters from RSSD. Err="+e.getErrorCode()+" Msg=" +e.getMessage());
          }
          // Save counters in archive database
          try {

              Asemon_logger.archive_class.truncateTable (msrv.srvNormalized+"_Counters", this);

              Archive_array archive_array = new Archive_array();
              Archive_array.Archive_row aRow;

              archive_array.addColDef("counter_id"    , java.sql.Types.INTEGER  );
              archive_array.addColDef("display_name"  , java.sql.Types.VARCHAR  );
              archive_array.addColDef("module_name"   , java.sql.Types.VARCHAR  );
              archive_array.addColDef("description"   , java.sql.Types.VARCHAR  );

              for (Enumeration ec=statCounters.elements(); ec.hasMoreElements();) {
                  StatCounter sc = (StatCounter)ec.nextElement();
                  aRow = archive_array.allocateNewRow();
                  aRow.addValue( sc.num);
                  aRow.addValue( sc.name);
                  aRow.addValue( sc.module_name);
                  aRow.addValue( sc.description);
                  archive_array.addRow(aRow);         // save this row in the array
              }
          // Save this array into archive database
          Asemon_logger.archive_class.saveValues (msrv.srvNormalized+"_Counters", archive_array, this);
          }
          catch (SQLException e) {
               Asemon_logger.printmess("RSStats ERROR "+e.getErrorCode()+" when saving list of counters into archive db : " +e.getMessage());
          }
          catch (Exception e) {
              //e.printStackTrace(System.out);
              throw e;
          }
      }




      // Initialize list of known instances
      knownInstances = new Hashtable<String, KnownInstance>();
      CnxMgr.ArchCnx aArchCnx = null;
      try {
          KnownInstance aKnownInstance;
          // Get an archive connection from the pool
          aArchCnx = CnxMgr.archCnxPool.getArchCnx(false);
          stmt = aArchCnx.archive_conn.createStatement();
          ResultSet rs=stmt.executeQuery("select ID, instance_id, instance_val, instance from "+msrv.srvNormalized+"_Instances order by ID");
          while (rs.next()) {
              int id = rs.getInt(1);
              int iid = rs.getInt(2);
              int ival = rs.getInt(3);
              String name = rs.getString(4);
              aKnownInstance = new KnownInstance(id, name, iid, ival);
              knownInstances.put(name+";"+iid+";"+ival, aKnownInstance);
              MAXID=id;
          }
          stmt.close();
          stmt = null;
//System.out.println("fin init");
      }
      catch (Exception e) {
             Asemon_logger.printmess("RSStats ERROR when initializing list of known instances : " +e.getMessage());
      }
      finally {
          // Return archive connection to the pool
          CnxMgr.archCnxPool.putArchCnx(aArchCnx);
      }
  }
  
  public void getMetrics () throws Exception {
    nbRowsToInsert = 0;  // Used to count number of rows inserted in archive database
    archRows = -1 ; // Real number of rows inserted in archive database. -1 in case of error or missing config params

    ResultSet rs = null;

    // adjust time for this monitored RS every 60 calls to getMetrics
    if (loopGetRSSDtime > 59) {
        CnxMgr.getRSSDtime(msrv);
        loopGetRSSDtime=0;
    }
    else loopGetRSSDtime++;

        
    Statement stmt;
    // Allocate new rsStats object which will hold all results for all instances in this sample
    rsStats = new Vector<CollectorRSStats.Instance>();
    try  {

	// Get values
        String firstColName;
        stmt = msrv.monSrvConn.createStatement();

        
        // Check if connection is not left in rssd
        boolean disconnect = false;
        try {
            stmt.executeQuery("admin version");
        }
        catch (Exception e) {
            disconnect = true;
        }
        if (disconnect) {
            Asemon_logger.DEBUG("CollectorRSStats - Line 312, disconnect");
            stmt.executeUpdate("disc");
        }
        
        
        if (firstTime) {
            oldTime= new Timestamp(System.currentTimeMillis() + msrv.timeAdjust.value());
            // Clear all counters before the first sample
            stmt.executeUpdate("admin stats,'RESET'");
            firstTime= false;
            return;

        }

/*
        if (supportMultiCommands) {
            try {
                rs = stmt.executeQuery( "admin stats,'ALL' admin stats,'RESET'" );
            }
            catch (SQLException sqle) {
                if ((sqle.getErrorCode()==2056) || (sqle.getErrorCode()==56039) ) {
                    // 56039 : Existing command is currently in progress
                    supportMultiCommands = false;
                }
            }
        }


        if (!supportMultiCommands)
*/            
          rs = stmt.executeQuery( "admin stats,'ALL'" );

        newTime= new Timestamp(System.currentTimeMillis() + msrv.timeAdjust.value());
        // Compute the time interval in ms
        if (oldTime != null) {
            long newTsMilli = newTime.getTime();
            long oldTsMilli = oldTime.getTime();
            int newTsNano   = newTime.getNanos();
            int oldTsNano   = oldTime.getNanos();
            // Check if TsMilli has really ms precision (not the case before JDK 1.4)
            if ( (newTsMilli - (newTsMilli/1000)*1000) == newTsNano/1000000)
              // JDK > 1.3.1
              interval = newTsMilli - oldTsMilli ;
            else
              interval = newTsMilli - oldTsMilli + (newTsNano-oldTsNano)/1000000;
        }
        else interval= (long)0;
        
        firstColName = rs.getMetaData().getColumnName(1);
        if (! (firstColName.compareToIgnoreCase("Instance") == 0)){
            Asemon_logger.printmess("RSStats ERROR : first column in result set should be 'Instance'");
            return;
        }
        // Get and save in memory instance definition
        rs.next();
        Instance instance = new Instance(rs.getString(1), rs.getInt(2), rs.getInt(3) );
        rsStats.add(instance); // Save this instance in the result list

        // Get corresponding observer's , monitor's and counter's
        while (stmt.getMoreResults()) {
            // loop until no more resultsSets

            rs=stmt.getResultSet();
            firstColName = rs.getMetaData().getColumnName(1);
            if (firstColName.compareToIgnoreCase("Observer") == 0) {
                while (rs.next() ) {
                    Observer aObserver = new Observer(rs.getString(1), rs.getLong(2), rs.getLong(3));
                    aObserver = instance.calcDeltaObserver (aObserver);
                    instance.addObserver(aObserver);
                }
                continue;
            }

            if (firstColName.compareToIgnoreCase("Monitor") == 0) {
                while (rs.next() ) {
                    Monitor aMonitor = new Monitor(rs.getString(1), rs.getLong(2), rs.getLong(3), rs.getLong(4), rs.getLong(5));
                    aMonitor = instance.calcDeltaMonitor (aMonitor);
                    instance.addMonitor(aMonitor);
                }
                continue;
            }
            if (firstColName.compareToIgnoreCase("Counter") == 0) {
                while (rs.next() ) {
                    Counter aCounter = new Counter(rs.getString(1), rs.getLong(2), rs.getLong(3), rs.getLong(4), rs.getLong(5), rs.getLong(6), rs.getLong(7));
                    aCounter = instance.calcDeltaCounter (aCounter);
                    instance.addCounter(aCounter);
                }
                continue;
            }
            if (firstColName.compareToIgnoreCase("Instance") == 0) {
                // Get and save in memory instance definition
                rs.next();
                instance = new Instance(rs.getString(1), rs.getInt(2), rs.getInt(3) );
                rsStats.add(instance); // Save this instance in the result list
                continue;
            }
            else {
                Asemon_logger.printmess("RSStats ERROR : unknown first column in result set");
                break;
            }

        }
/*
        if (!supportMultiCommands)
          stmt.executeUpdate("admin stats,'RESET'" );
*/
        stmt.close();
        //System.out.println("Oper scanned : "+currentStat.total_operations_scanned);
    }
    catch (Exception e) {
    	throw e;
    }

    saveIntances();
    saveStats();

    oldTime = newTime;
    rsStats = null; // Free current sample results

  }

  void saveIntances()  throws Exception {
      // save all new instances in the archive server
      Instance i;
      KnownInstance aKnownInstance;
      String name;
      int nbNewInstances=0;

      try {

        Archive_array archive_array = new Archive_array();
        Archive_array.Archive_row aRow;

        archive_array.addColDef("Timestamp"     , java.sql.Types.TIMESTAMP);
        archive_array.addColDef("ID"            , java.sql.Types.INTEGER ); 
        archive_array.addColDef("instance_id"   , java.sql.Types.INTEGER);  
        archive_array.addColDef("instance_val"  , java.sql.Types.INTEGER  );
        archive_array.addColDef("instance"      , java.sql.Types.VARCHAR); 
          
        // loop on all captured instances
        for (Iterator ii = rsStats.listIterator(); ii.hasNext();){
            i = (Instance)ii.next();
            // Check if this instance is already a known instance
            name = i.instance;
            if (name.length()==0) continue;                                             // Skip instance name empty
            if (knownInstances.get(name+";"+i.instance_id+";"+ i.instance_val) == null){
                nbNewInstances++;
                // No, keep it in memory for later
                aKnownInstance = new KnownInstance (0, name, i.instance_id, i.instance_val);
                knownInstances.put(name+";"+i.instance_id+";"+i.instance_val, aKnownInstance);
                // Save this new instance
                aRow = archive_array.allocateNewRow();
                aRow.addValue(newTime);
                aRow.addValue(aKnownInstance.ID);
                aRow.addValue(aKnownInstance.instance_id);
                aRow.addValue(aKnownInstance.instance_val);
                aRow.addValue(aKnownInstance.instance);
                archive_array.addRow(aRow);         // save this row in the array
//System.out.println("    New instance insert - ID="+aKnownInstance.ID+" id="+i.instance_id+" val="+i.instance_val+ " name="+name);
              }
          }
          if (nbNewInstances >0)
              // Save this array into archive database
              Asemon_logger.archive_class.saveValues (msrv.srvNormalized+"_Instances", archive_array, this);
      }
      catch (Exception e) {
          Asemon_logger.printmess("RSStats ERROR when saving instances : " +e.getMessage());          
          throw e;
      }
      
  }
  
    void saveStats()  throws Exception {
      // save all statistics for all instances in the archive server
      Instance i;
      KnownInstance aKnownInstance;
      String instance_name;
      int instance_id;
      int instance_val;
      Counter c;
      Observer o;
      Monitor m;
      String counterName;
      int counterID;

      try {
          Archive_array archive_array = new Archive_array();
          Archive_array.Archive_row aRow;

          archive_array.addColDef("Timestamp"     , java.sql.Types.TIMESTAMP);
          archive_array.addColDef("Interval"      , java.sql.Types.BIGINT );
          archive_array.addColDef("ID"            , java.sql.Types.INTEGER);
          archive_array.addColDef("counter_id"    , java.sql.Types.INTEGER  );
          archive_array.addColDef("counter_obs"   , java.sql.Types.BIGINT);
          archive_array.addColDef("counter_total" , java.sql.Types.BIGINT);
          archive_array.addColDef("counter_last"  , java.sql.Types.BIGINT  );
          archive_array.addColDef("counter_max"   , java.sql.Types.BIGINT  );
          archive_array.addColDef("avg_ttl_obs"   , java.sql.Types.BIGINT);
          archive_array.addColDef("rate_x_sec"    , java.sql.Types.BIGINT  );

          // loop on all captured instances
          for (Iterator ii = rsStats.listIterator(); ii.hasNext();){
              i = (Instance)ii.next();
              instance_name = i.instance;
              if (instance_name.length()==0) continue;                          // Skip instance name empty
              instance_id = i.instance_id;
              instance_val = i.instance_val;
              // Retreive corresponding knowninstance
              aKnownInstance = knownInstances.get(instance_name+";"+instance_id+";"+instance_val);
              if (aKnownInstance==null) {
                  Asemon_logger.printmess("ERROR - unknowninstance : "+instance_name+";"+instance_id+";"+instance_val);
                  continue;
              }
              // save counters
              for (Iterator ic = i.Counters.iterator(); ic.hasNext();) {
                  c = (Counter)ic.next();
                  counterName = c.counter;
                  counterID = getCounterID(counterName, aKnownInstance.module);
                  aRow = archive_array.allocateNewRow();
                  aRow.addValue(newTime);
                  aRow.addValue(interval);
                  aRow.addValue(aKnownInstance.ID);
                  aRow.addValue(counterID);
                  aRow.addValue(c.obs);
                  aRow.addValue(c.total);
                  aRow.addValue(c.last);
                  aRow.addValue(c.maxVal);
                  aRow.addValue(c.avg_ttl_obs);
                  aRow.addValue(c.rate_x_sec);
                  archive_array.addRow(aRow);         // save this row in the array
              }
              
              // save observers
              for (Iterator io = i.Observers.iterator(); io.hasNext();) {
                  o = (Observer)io.next();
                  counterName = o.observer;
                  counterID = getCounterID(counterName, aKnownInstance.module);
                  aRow = archive_array.allocateNewRow();
                  aRow.addValue(newTime);
                  aRow.addValue(interval);
                  aRow.addValue(aKnownInstance.ID);
                  aRow.addValue(counterID);
                  aRow.addValue(o.obs);
                  aRow.addValue(null);
                  aRow.addValue(null);
                  aRow.addValue(null);
                  aRow.addValue(null);
                  aRow.addValue(o.rate_x_sec);
                  archive_array.addRow(aRow);         // save this row in the array
              }
              
              
              // save monitors
              for (Iterator im = i.Monitors.iterator(); im.hasNext();) {
                  m = (Monitor)im.next();
                  counterName = m.monitor;
                  counterID = getCounterID(counterName, aKnownInstance.module);
                  aRow = archive_array.allocateNewRow();
                  aRow.addValue(newTime);
                  aRow.addValue(interval);
                  aRow.addValue(aKnownInstance.ID);
                  aRow.addValue(counterID);
                  aRow.addValue(m.obs);
                  aRow.addValue(null);
                  aRow.addValue(m.last);
                  aRow.addValue(m.maxVal);
                  aRow.addValue(m.avg_ttl_obs);
                  aRow.addValue(null);
                  archive_array.addRow(aRow);         // save this row in the array
              }
          }
          // Save this array into archive database
          Asemon_logger.archive_class.saveValues (msrv.srvNormalized+"_RSStats", archive_array, this);
      }
      catch (Exception e) {
          Asemon_logger.printmess("RSStats ERROR when saving stats : " +e.getMessage());          
          throw e;
      }
  }
    
  int getCounterID (String c, String m) {
      StatCounter sc;
      // Remove prefix
      if(c.charAt(0)=='#') c=c.substring(1);
      if(c.charAt(0)=='*') c=c.substring(1);
      // NRM counters have module name PRSNRM in rs_statcounters.
      if (m.equals("PARSER_NRM")) m="PRSNRM";
      String s = c+"|"+m;
      sc = statCounters.get(s);
      if (sc==null) {
          // Not found , try with DSIHQ as module name, since DSIHQ counters are associated to DSIEXEC module
          s = c+"|DSIHQ";
          sc = statCounters.get(s);
          if (sc==null) {
              Asemon_logger.printmess("RSStats ERROR Counter '"+c+"|"+m+"' is not known");
              return -1;
          }
      }
      return sc.num;
  }
  
}
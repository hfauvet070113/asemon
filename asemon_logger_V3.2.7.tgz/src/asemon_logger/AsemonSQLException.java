/*
 * AsemonSQLException.java
 *
 * Created on 24 novembre 2007, 12:12
 *
 * @version 3.0.7
*/

package asemon_logger;
import java.sql.*;

/**
 *
 * @author jp
 */
public class AsemonSQLException extends SQLException 
{
  private String CnxType;
  private String TableName;


  public AsemonSQLException(String message, String SQLState, int vendorCode, String CnxType, String tableName)
  {
    super(message,SQLState,vendorCode);
    this.CnxType = CnxType;  
    this.TableName = tableName;  
  }

  public String getCnxType()
  {
    return CnxType;
  }

  public String getTableName()
  {
    return TableName;
  }
}
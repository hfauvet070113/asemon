/**
* <p>CollectorCachedXML/p>
* <p>Asemon_logger : class for retreiving XML info about SQL and PLAN of cached statements</p>
* <p>Copyright: Jean-Paul Martin (jpmartin@sybase.com) Copyright (c) 2012</p>
* @version 3.2.6b
*/

package asemon_logger;
import static asemon_logger.Asemon_logger.debugSwitchs;
import java.sql.*;
import java.util.*;

public class CollectorCachedXML extends Collector {
  String srvName;
  String structName;
  int min_logical_reads;
  int min_usecount;
  int LEVEL_OF_DETAIL;

  Statement stmt;
  PreparedStatement pstmt;
  PreparedStatement pstmtArch;
  ResultSet rs;


  int nbRowsToInsert;

  int bootcount;            // used to store the bootcount of the monitored server
  Vector <XMLDesc> currentListOfCachedXML;

  Timestamp samplingTime;
  Long interval;
  
  class XMLDesc {
      int ObjectID;
      int PlanID;
      int InstanceID;
      int OwnerUID;
      int DBID;

      XMLDesc (int aObjectID,int aPlanID, int aInstanceID, int aOwnerUID, int aDBID) {
          ObjectID = aObjectID;
          PlanID = aPlanID;
          InstanceID = aInstanceID;
          OwnerUID = aOwnerUID;
          DBID = aDBID;
      }
  

  }



  CollectorCachedXML (MonitoredSRV ms, MetricDescriptor md) {
       super(ms, md);
       srvName = msrv.srvNormalized;
       structName = metricDescriptor.metricName;
  }
  

  void initialize ()  throws Exception {
      super.initialize();
      if (Asemon_logger.skipCollectXML) return;
      int cntgotcachedXML = 0;

      // Retrieve option "min_logical_reads"
      String paramValue = metricDescriptor.parameters.getProperty("min_logical_reads");
      min_logical_reads = 10000;
      try {
          min_logical_reads = Integer.parseInt(paramValue);
      }
      catch (Exception e) {
          Asemon_logger.printmess ("ERROR CachedXML : Bad min_logical_reads. Will use default value instead (10000)");
          min_logical_reads = 10000;
      }
      if (min_logical_reads <0) {
          Asemon_logger.printmess ("ERROR CachedXML : min_logical_reads cannot be <0. Will use default value instead (10000)");
          min_logical_reads = 10000;
      }
      // Retrieve option "min_usecount"
      paramValue = metricDescriptor.parameters.getProperty("min_usecount");
      min_usecount = 10;
      try {
          min_usecount = Integer.parseInt(paramValue);
      }
      catch (Exception e) {
          Asemon_logger.printmess ("ERROR CachedXML : Bad min_usecount. Will use default value instead (10)");
          min_usecount = 10000;
      }
      if (min_usecount <0) {
          Asemon_logger.printmess ("ERROR CachedXML : min_usecount cannot be <0. Will use default value instead (10)");
          min_usecount = 10;
      }

      // Retrieve option "LEVEL_OF_DETAIL"
      paramValue = metricDescriptor.parameters.getProperty("LEVEL_OF_DETAIL");
      LEVEL_OF_DETAIL = 0;
      try {
          LEVEL_OF_DETAIL = Integer.parseInt(paramValue);
      }
      catch (Exception e) {
          Asemon_logger.printmess ("ERROR CachedXML : Bad LEVEL_OF_DETAIL. Will use default value instead (0)");
          LEVEL_OF_DETAIL = 0;
      }
      if ((LEVEL_OF_DETAIL <0)||(LEVEL_OF_DETAIL>6)) {
          Asemon_logger.printmess ("ERROR CachedXML : invalid value for LEVEL_OF_DETAIL must be between 0 and 6. Will use default value instead (0)");
          LEVEL_OF_DETAIL = 0;
      }

      try {
          int minPlanID;
          boolean res;
          // Create temporary table used to store already seen cached XML
          stmt = msrv.monSrvConn.createStatement();
          try {
              res = stmt.execute("select @@bootcount, min(PlanID) from master..monCachedProcedures where ObjectName like '*s%'");
              rs = stmt.getResultSet();
          }
          catch (SQLException ex) {
              int errcode = ex.getErrorCode();
              // Ignore error : Collection of monitoring data for table 'monCachedProcedures' requires that the 'enable monitoring', 'statement statistics active' configuration option(s) be enabled. To set the necessary configuration, contact a user who has the System Administrator (SA) role. 
              // Ignore error : Database 'xxx' is already open and can only have one user at a time.
              // Ignore error : User xx not allowed in database 'xxx' - only the owner of this database can access it.
              if ((errcode!=12036) &&(errcode!=12052) && (errcode!=923) && (errcode!=924)) throw ex; 
              try {
                  stmt.getMoreResults();
              }
              catch (Exception e) {}
              rs = stmt.getResultSet();
          }
          rs.next();
          bootcount = rs.getInt(1);
          minPlanID = rs.getInt(2);

          stmt.executeUpdate("if (select object_id('#gotcachedXML') )!=null drop table #gotcachedXML");
          stmt.executeUpdate("create table #gotcachedXML (ObjectID int not null, PlanID int not null, InstanceID int not null, OwnerUID int not null, DBID int not null)");

          if (minPlanID > 0) {
              // Not necessary to initialize #gotcachedXML if there is no statement in proc cache.
              // All new statements in cache will have a PlanID greater than what was already captured

              // initialization of #gotcachedXML from archive server
              // Get an archive connection from the pool
              CnxMgr.ArchCnx aArchCnx = CnxMgr.archCnxPool.getArchCnx(false);

              try {
                  Statement stmtArch = aArchCnx.archive_conn.createStatement();
                  rs = stmtArch.executeQuery("select distinct ObjectID, PlanID, InstanceID, OwnerUID, DBID "+
                      " from "+srvName+"_CachedXML"+
                      " where bootcount= " + bootcount +" and PlanID >= " +minPlanID);
                  pstmt = msrv.monSrvConn.prepareStatement("insert into  #gotcachedXML (ObjectID, PlanID, InstanceID, OwnerUID, DBID ) values (?,?,?,?,?)");
                  msrv.monSrvConn.setAutoCommit(false);
                  while (rs.next()) {
                      pstmt.setInt(1, rs.getInt((1)));
                      pstmt.setInt(2, rs.getInt((2)));
                      pstmt.setInt(3, rs.getInt((3)));
                      pstmt.setInt(4, rs.getInt((4)));
                      pstmt.setInt(5, rs.getInt((5)));
                      //pstmt.setTimestamp(3, rs.getTimestamp((3)));
                      pstmt.addBatch();
                      cntgotcachedXML++;
                  }
                  pstmt.executeBatch();
              }
              finally {
                  try {
                      if ( (msrv.monSrvConn != null) && (!msrv.monSrvConn.isClosed())) {
                          msrv.monSrvConn.commit();
                          msrv.monSrvConn.setAutoCommit(true);
                      }
                      if (pstmt != null) pstmt.close();
                  }
                  catch (Exception e){
                      Asemon_logger.printmess ("ERROR CollectorCachedXML : error during initialization. "+e.getMessage());
                  }
                  // Return archive connection to the pool
                  CnxMgr.archCnxPool.putArchCnx(aArchCnx);
              }
          }
          stmt.executeUpdate("create unique clustered index iu on #gotcachedXML (ObjectID, PlanID, InstanceID, OwnerUID, DBID  )");
          stmt.close();
      }
      catch (Exception e) {
    	  Asemon_logger.printmess ("ERROR CollectorCachedXML : error during initialization.");
          // message is printed in calling method
          //e.printStackTrace(System.out);
          throw e;
      }
      Asemon_logger.DEBUG(Asemon_logger.DBG101, "End initialization. Row inserted in #gotcachedXML = "+cntgotcachedXML+" Bootcount = "+bootcount);

  }


   public void getMetrics () throws Exception {
       if (Asemon_logger.skipCollectXML) return;
      archRows = -1 ; // in case of error or missing config params, AmStats will show this info

      boolean archiveInIQ = false;
      if (Asemon_logger.archive_type.equalsIgnoreCase("IQ")) archiveInIQ = true;

      // Allocate list for storing results in memory
      if (currentListOfCachedXML == null) 
          currentListOfCachedXML = new Vector<XMLDesc> ();
      else
          currentListOfCachedXML.clear();

      PreparedStatement pstmtArch = null;

      try  {
          stmt = msrv.monSrvConn.createStatement();
          if (debugSwitchs.contains(101)) {
              // Get count of rows in #gotcachedXML
              rs = stmt.executeQuery("select count(*) from #gotcachedXML");
              rs.next();
              Asemon_logger.DEBUG(Asemon_logger.DBG101, "Count in #gotcachedXML = "+rs.getInt(1));
          }
          // Get list of new statements
          String query = "select P.ObjectID,P.PlanID,P.InstanceID,P.OwnerUID,P.DBID,MemUsageKB,CompileDate, xmlinfo=show_cached_plan_in_xml(P.ObjectID, P.PlanID, " + LEVEL_OF_DETAIL + ")"+
               " from master..monCachedProcedures P left outer join #gotcachedXML G on P.ObjectID = G.ObjectID and P.PlanID = G.PlanID and P.InstanceID = G.InstanceID and P.OwnerUID = G.OwnerUID and P.DBID = G.DBID"+
               " where ObjectName like '*s%' and (RequestCnt > "+ String.valueOf(min_usecount)+" or LogicalReads > "+ String.valueOf(min_logical_reads)+" )"+
               " and G.ObjectID is null"+
               " and G.PlanID is null"+
               " and G.InstanceID is null"+
               " and G.OwnerUID is null"+
               " and G.DBID  is null";
          rs = stmt.executeQuery(query);

          samplingTime= new Timestamp(System.currentTimeMillis() + msrv.timeAdjust.value());
          String xmlinfo;
          String planStatus;

          Archive_array archive_array = new Archive_array();
          Archive_array.Archive_row aRow;

          archive_array.addColDef("Timestamp"   , java.sql.Types.TIMESTAMP);
          archive_array.addColDef("ObjectID"    , java.sql.Types.INTEGER );
          archive_array.addColDef("PlanID"      , java.sql.Types.INTEGER);
          archive_array.addColDef("InstanceID"  , java.sql.Types.INTEGER  );
          archive_array.addColDef("OwnerUID"    , java.sql.Types.INTEGER);
          archive_array.addColDef("DBID"        , java.sql.Types.INTEGER);
          archive_array.addColDef("MemUsageKB"  , java.sql.Types.INTEGER  );
          archive_array.addColDef("CompileDate" , java.sql.Types.TIMESTAMP  );
          if (archiveInIQ)
              archive_array.addColDef("xmlinfo"   , java.sql.Types.VARBINARY  );   
          else
              archive_array.addColDef("xmlinfo"     , java.sql.Types.VARCHAR);
          archive_array.addColDef("bootcount"   , java.sql.Types.INTEGER  );
      
          while (true) {

              try {
                  if (rs.next() == false) break;
              }
              catch (SQLException e) {
                  int err = e.getErrorCode();
                  if ( (err==923)||(err==924) ) {
                      // Ignore error : Database 'xxx' is already open and can only have one user at a time.
                      // Ignore error : User xx not allowed in database 'xxx' - only the owner of this database can access it.
                      continue;
                  }
                  else throw e;
              }

                // Check if plan is not in use. If yes, discard this row
                xmlinfo = rs.getString(8);
                if (xmlinfo == null) continue;
                int startStatus = xmlinfo.indexOf("<planStatus>") +12;
                if (startStatus > 0) {
                    // Found startstatus
                    int endStatus = xmlinfo.indexOf("</planStatus>");
                    if (endStatus > 0) {
                        // found endStatus
                        planStatus = (xmlinfo.substring(startStatus, endStatus)).trim().toLowerCase();
                        if ( (planStatus != null) && (planStatus.compareTo("available")!=0) )
                            // skip this row; will take it later when plan is no longer in use
                            continue;
                    }
                }
                // Check if plan contains actual statistics
                if ( !xmlinfo.contains("<act>") ) {
                    // skip this row; will take it later when request is terminated
                    continue;
                }



              // Save id and planid in memory
              XMLDesc aSD = new XMLDesc (rs.getInt(1), rs.getInt(2), rs.getInt(3), rs.getInt(4), rs.getInt(5));
              currentListOfCachedXML.add(aSD);

              aRow = archive_array.allocateNewRow();
              aRow.addValue(samplingTime);
              aRow.addValue(rs.getInt(1));
              aRow.addValue(rs.getInt(2));
              aRow.addValue(rs.getInt(3));
              aRow.addValue(rs.getInt(4));
              aRow.addValue(rs.getInt(5));
              aRow.addValue(rs.getInt(6));
              aRow.addValue(rs.getTimestamp(7));

              if (archiveInIQ) {
                  // When storing in IQ, compress the data because not all customers have the "Unstructured Data Analytics" option
                  aRow.addValue(Gzip.compress (xmlinfo));
              }
              else
                  aRow.addValue(xmlinfo);

              aRow.addValue(bootcount);
              archive_array.addRow(aRow);         // save this row in the array
              nbRowsToInsert++;
          }
          Asemon_logger.DEBUG(Asemon_logger.DBG101, "New cached XML = "+currentListOfCachedXML.size());
          if (currentListOfCachedXML.isEmpty()) {
              // No new cached statement, nothing to do
              stmt.close();
              archRows = 0;
              return;
          }

          // Save this array into archive database
          Asemon_logger.archive_class.saveValues (srvName+"_"+structName, archive_array, this);

          // add list of new cached statement in temporary table
          pstmt= msrv.monSrvConn.prepareStatement("insert into #gotcachedXML values (?,?,?,?,?)");
          msrv.monSrvConn.setAutoCommit(false);
          Iterator itCS = currentListOfCachedXML.iterator();
          int nbinserts = 0;
          while (itCS.hasNext()) {
              XMLDesc aCXML = (XMLDesc)itCS.next();  // Get cached XML
              pstmt.setInt(1, aCXML.ObjectID);
              pstmt.setInt(2, aCXML.PlanID);
              pstmt.setInt(3, aCXML.InstanceID);
              pstmt.setInt(4, aCXML.OwnerUID);
              pstmt.setInt(5, aCXML.DBID);
              pstmt.addBatch();
              nbinserts++;
          }
          pstmt.executeBatch();
          msrv.monSrvConn.commit();
          Asemon_logger.DEBUG(Asemon_logger.DBG101, "Nb inserts in #gotcachedXML = "+nbinserts);

          // clear currentListOfCachedXML
          currentListOfCachedXML.clear();

        
      }
      catch (SQLException sqle) {
          if (sqle.getErrorCode()==12052) {
              // Configuration is not set for statement cache monitoring, don't retreive any data
          }
          
      }
      finally {
          if (msrv.monSrvConn != null) {
              msrv.monSrvConn.commit();
              msrv.monSrvConn.setAutoCommit(true);
          }
          if (pstmt != null) pstmt.close();
          if (stmt != null) stmt.close();
      }


  }

}
/**
* <p>CollectorGeneric</p>
* <p>Asemon_logger : class managing generic metrics (a GENERIC metric can be completely defined 
* <p>in its XML descriptor file.
  <p>This class contains methods for computing relatives values (differences across two samples)</p>
* <p>Copyright: Jean-Paul Martin (jpmartin@sybase.com) Copyright (c) 2004</p>
* @version 3.1.6b
*/

package asemon_logger;
import java.sql.*;
import java.util.*;
import com.sybase.jdbcx.*;

public class CollectorGeneric extends Collector {

  SamplingMetric oldSample=null;         // Contains old raw data
  SamplingMetric newSample=null;         // Contains new raw data
  SamplingMetric diffCnt=null;           // diff between newSample and oldSample data (not filtered)

  String srvName;                        // Monitored server name
  String structName;                     // Name of the metric (ex. : CnxActiv)
  String archiveTabName;                  // Name of archive table (most of the time is srvName_structName; but not for SysMonFld

  Timestamp lastCollectTS=null;            // Timestamp of last collection. Can be referenced in SQL with : ?ASM$LASTCOLLECT?

  boolean dynParamsProcessed;            // reset to false before collect. Set to true when at least one parameter processed
  boolean dynParamsProcessed_no_sa;            // reset to false before collect. Set to true when at least one parameter processed
  
  public CollectorGeneric (MonitoredSRV ms, MetricDescriptor aMetricDescriptor) {
      super (ms, aMetricDescriptor);

      srvName = msrv.srvNormalized;
      structName = metricDescriptor.metricName;

  }

  private void substituteParams () {
      // Check if parameters are defined for this metric
      if (!metricDescriptor.parameters.isEmpty()) {
          StringBuffer sbSQL = new StringBuffer(metricDescriptor.SQL);
          // Loop on all parameters and replace them in the SQL
          for ( Enumeration enumParams=metricDescriptor.parameters.propertyNames();  enumParams.hasMoreElements(); ) {
              String paramName = (String)enumParams.nextElement();
              int paramPosition=sbSQL.indexOf("?"+paramName+"?");
              while (paramPosition > -1) {
                  // substitute parameter
                  sbSQL.replace( paramPosition, paramPosition + ("?"+paramName+"?").length(), metricDescriptor.parameters.getProperty(paramName));
                  // check if another occurence of the same parameter
                  paramPosition = sbSQL.indexOf("?"+paramName+"?");
              }
          }
          // Save this new SQL in the metric descriptor
          metricDescriptor.SQL = sbSQL.toString();

          if (metricDescriptor.SQL_if_no_sa==null) return;
          // Do same processing for SQL_if_no_sa
          sbSQL = new StringBuffer(metricDescriptor.SQL_if_no_sa);
          // Loop on all parameters and replace them in the SQL
          for ( Enumeration enumParams=metricDescriptor.parameters.propertyNames();  enumParams.hasMoreElements(); ) {
              String paramName = (String)enumParams.nextElement();
              int paramPosition=sbSQL.indexOf("?"+paramName+"?");
              while (paramPosition > -1) {
                  // substitute parameter
                  sbSQL.replace( paramPosition, paramPosition + ("?"+paramName+"?").length(), metricDescriptor.parameters.getProperty(paramName));
                  // check if another occurence of the same parameter
                  paramPosition = sbSQL.indexOf("?"+paramName+"?");
              }
          }
          // Save this new SQL in the metric descriptor
          metricDescriptor.SQL_if_no_sa = sbSQL.toString();
      }


      
  }
  
  private void substituteDynParam (String paramName, String value) {
      boolean found=false;
      StringBuffer sbSQL;
      
      if ( (metricDescriptor.SQL_final == null) || (dynParamsProcessed == false) )
             sbSQL = new StringBuffer(metricDescriptor.SQL);
      else
             sbSQL = new StringBuffer(metricDescriptor.SQL_final);

      int paramPosition=sbSQL.indexOf("?"+paramName+"?");
      while (paramPosition > -1) {
          found = true;
          // substitute parameter
          sbSQL.replace( paramPosition, paramPosition + ("?"+paramName+"?").length(), value);
          // check if another occurence of the same parameter
          paramPosition = sbSQL.indexOf("?"+paramName+"?");
      }
      // Save this new SQL in the metric descriptor
      if (found) {
          metricDescriptor.SQL_final = sbSQL.toString();
          dynParamsProcessed = true;
      }
      if (metricDescriptor.SQL_if_no_sa==null)
          return;
      
      // Same processing for SQL_if_no_sa
      found=false;
      if ( (metricDescriptor.SQL_final_if_no_sa == null) || (dynParamsProcessed_no_sa == false) )
          sbSQL = new StringBuffer(metricDescriptor.SQL_if_no_sa);
      else
          sbSQL = new StringBuffer(metricDescriptor.SQL_final_if_no_sa);
          
      paramPosition=sbSQL.indexOf("?"+paramName+"?");
      while (paramPosition > -1) {
          found = true;
          // substitute parameter
          sbSQL.replace( paramPosition, paramPosition + ("?"+paramName+"?").length(), value);
          // check if another occurence of the same parameter
          paramPosition = sbSQL.indexOf("?"+paramName+"?");
      }
      // Save this new SQL in the metric descriptor
      if (found) {
          metricDescriptor.SQL_final_if_no_sa = sbSQL.toString();
          dynParamsProcessed_no_sa = true;
      }
  }

  // Get list of databases asemon can enter in. Needed for some function. Ex. : db_name (id, dbid)
  // If not accessible, this could generate an error
  public static String getAccessibleDBs(MonitoredSRV msrv) throws Exception {
       Connection cnx = msrv.monSrvConn;
       String instanceidPredicate = "";

       // Don't check if database is in "dbo use only" if login has sa_role
       String dbo_use_only_check = "";
       if (msrv.sa_role == 0)
           dbo_use_only_check = "  and status&2048!=2048 /* dbo use only */\n";
       
       if (msrv.instanceid > 0)
           // don't access local temporary db not owned by this instance
           instanceidPredicate = " and (instanceid=@@instanceid or instanceid is null)";
       StringBuffer dblist = new StringBuffer();
       String sep = "(";
       SybStatement stmt = (SybStatement) cnx.createStatement();
       stmt.setSybMessageHandler(new StatementMsgHandler());
       ResultSet rs=stmt.executeQuery(
                "select dbid\n" +
                "from master..sysdatabases\n" +
                "where name != 'sybsecurity' \n" +
                "  and status&32!=32 /* db created for load */\n" +
                "  and status&64!=64 /* recovery started */\n" +
                "  and status&256!=256 /* db suspect */\n" +
                dbo_use_only_check +
                "  and status&4096!=4096 /* single user */\n" +
                "  and status2&16!=16 /* db offline */\n" +
                "  and status2&32!=32 /* db offline until recovery */\n" +
                "  and status2&512!=512  /* db upgrading */\n" +
                "  and status3&8!=8  /* db is being shut down */\n" +
                "  and status3&4096!=4096  /* db has been shut down  */\n" +
                "  and status3&9192!=8192  /* a drop database is in progress  */\n" +
                "  and object_name(1,dbid) is not null" + instanceidPredicate);
       if (rs!=null) {
           while (rs.next()) {
               dblist.append(sep).append( Integer.toString(rs.getInt(1)) );
               sep = ",";
           }
            dblist.append(") ");
       }
       
           
       Asemon_logger.DEBUG("dblist="+dblist.toString());
       return (dblist.toString());
  }

  public void initialize () throws Exception {
      super.initialize();
      oldSample=null;
      // Substitute parameters in the SQL
      substituteParams();

      // Get first table name of create table list
      archiveTabName =  MetricDescriptor.getFirstArchiveTables(metricDescriptor).archiveTabName;
      if (!structName.equalsIgnoreCase("Trends")) {
          // Get last collection Timestamp
          CnxMgr.ArchCnx aArchCnx=null;
          Statement stmt=null;
          try {
              // Get an archive connection from the pool
              aArchCnx = CnxMgr.archCnxPool.getArchCnx(false);
              stmt = aArchCnx.archive_conn.createStatement();
              ResultSet rs= stmt.executeQuery("select max(Timestamp) from "+ archiveTabName);
              rs.next();
              lastCollectTS = rs.getTimestamp(1);
              stmt.close();
          }
          catch (java.sql.SQLException sqle) {
              Asemon_logger.printmess(archiveTabName + " ERROR retreiving last collection date : "+sqle.getErrorCode()+" "+sqle.getMessage());
          }
          catch (Exception e) {
              Asemon_logger.printmess(archiveTabName + " ERROR retreiving last collection date");
              //e.printStackTrace(System.out);
              throw e;
          }
          finally {
              // Return archive connection to the pool
              if (aArchCnx!=null)
                  archCnxActiveTime =  CnxMgr.archCnxPool.putArchCnx(aArchCnx);
          }
      }
      if (lastCollectTS==null)
          lastCollectTS = new Timestamp(0);
  }


  public void getMetrics () throws Exception {
    archRows = -1 ; // in case of error or missing config params, AmStats will show this info
    if (msrv.monSrvConn==null) return;

    newSample = new SamplingMetric();

    if (oldSample != null)
        // Save already got column descriptors
        newSample.columnDescriptors = oldSample.columnDescriptors ;

    // Substitute dynamic parameters in SQL if necessary
    dynParamsProcessed = false;
    Asemon_logger.DEBUG("ASM$LASTCOLLECT="+lastCollectTS.toString());
    substituteDynParam ("ASM$LASTCOLLECT", lastCollectTS.toString());
    substituteDynParam ("ASM$SRVVERSION", msrv.sbssav);
    substituteDynParam ("ASM$VERSION", Asemon_logger.Asemon_logger_version);
    // Check if SQL needs list of acessible databases
    if (metricDescriptor.needAccessibleDBs) {
        String accessibleDBs = getAccessibleDBs(msrv);
        substituteDynParam ("ASM$ACCESSIBLEDBS", accessibleDBs);
    }
        
    //Asemon_logger.DEBUG(metricDescriptor.SQL_final);
    // Collect data from monitored server
    if ( !newSample.getCnt(this) ) {
        // not ok , return
        newSample = null;
        return;
    }

    if (oldSample == null) {
       Asemon_logger.DEBUG("Checking return cols against config cols.");
        
        // First time after initialization of this collection, check if returned cols match those in declared in decriptor
        // except first 2 : Timestamp and interval
        // Get list of archive cols of the archive table
        String archGenericTableName = archiveTabName.substring(archiveTabName.lastIndexOf('_')+1, archiveTabName.length());
        Hashtable confTabColList = (Hashtable)hashArchTableColList.get(archGenericTableName);
        // Loop on retreived cols
        ColumnDescriptor aCd;
        String curColName;
        for (int i =0; i < newSample.nbCols; i++) {
            aCd = (ColumnDescriptor)newSample.columnDescriptors.get(i);
            curColName = aCd.colname;
            // Check if col exists in confTabColList
            if (! confTabColList.containsKey(curColName)) {
                // No,  check if an alias exists for this col
                if (metricDescriptor.colsAlias != null )
                    if (metricDescriptor.colsAlias.containsKey(curColName)) {
                        if ((String) metricDescriptor.colsAlias.get(curColName)=="")
                            aCd.setIgnoreForSave();
                        continue;
                    }
                Asemon_logger.printmess("Col : '"+curColName+"' does not exists in archive table. Will be ignored.");
                aCd.setIgnoreForSave(); // Mark this column as "ignore for save" in archive table
            }
        }
    }


    if (metricDescriptor.colsCalcDiff.length > 0) {
      if (oldSample!=null) {
        // Compute the differences
        diffCnt = oldSample.computeDiffSample(oldSample, newSample);
        if (diffCnt != null) saveValues();
      }
    }
    else {
        diffCnt = newSample;
        if (oldSample != null)
            // Compute interval between 2 samples
            SamplingMetric.calcInterval(oldSample,  newSample, diffCnt);
        if (diffCnt != null) saveValues();
    }
  
    oldSample = null;
    diffCnt = null;
    oldSample = newSample;
    if (archRows==-1) archRows = 0; // No error occured if we are here, and no row saved. Set archRows to 0 to say no error
    lastCollectTS = newSample.samplingTime; // Save last collection Timestamp (server's time)
  }


  private boolean isAnyDiffNotZero (Vector row, Vector columnDescriptors ) {
      int nbcols = diffCnt.nbCols;
      for (int col=1; col <= nbcols; col++) {
      	  // Check if column is not a key and is a computed column
          if ( (col != metricDescriptor.key1) && (col != metricDescriptor.key2) && (col != metricDescriptor.key3) && ( diffCnt.isComputeColumn(col-1) ) ) {
             // Get column type
             ColumnDescriptor fColDesc = (ColumnDescriptor)columnDescriptors.get(col-1);
             
             
             Object colVal = row.get(col-1); // Get value of column
             if (colVal == null) return true;

             if ( fColDesc.isInteger() ){
               if ( ((Integer)(colVal)).intValue()  != 0 ) return true;
             }

            if ( fColDesc.isBigDecimal() ){
               if ( !((java.math.BigDecimal)colVal).equals(new java.math.BigDecimal(0)) ) return true;
            }

            if ( fColDesc.isDouble() ){
               if ( ! ((Double)colVal).equals(new Double(0)) ) return true;
            }

            if ( fColDesc.isLong() ){
               if ( ! ((Long)colVal).equals(new Long(0)) ) return true;
            }

            if ( fColDesc.isFloat() ){
               if ( ! ((Float)colVal).equals(new Float(0)) ) return true;
            }

  	      }
      }
      return false;
  }


  // Prepare a Archive_array used to insert data into the archive database
  private void saveValues () throws Exception {
      Archive_array archive_array = new Archive_array();
      Archive_array.Archive_row aRow;
      int nbRowsToInsert = 0;

      int firstIndex;       // First index of next column
      if (SaveIntervalCol==true) {
          archive_array.addColName("Timestamp");
          archive_array.addColName("Interval");
          firstIndex = 2;
      }
      else {
          String Timestamp_in_result = metricDescriptor.parameters.getProperty("Timestamp_in_result");
          if (Timestamp_in_result==null) {
              archive_array.addColName("Timestamp");
              firstIndex = 1;
          }
          else {
              firstIndex = 0;
          }
      }


      // get the list of column names ( names in diffCnt.columnDescriptors or use alias if one exists)
      String cname;
      for (int col=0; col < diffCnt.nbCols; col++) {
          // Get the column descriptor
          ColumnDescriptor colDesc =
                      ((ColumnDescriptor)(diffCnt.columnDescriptors.get(col)));
          // Check if column is not ignore for save (because it may not exists in archive table)
          if (! colDesc.isIgnoredForSave() ) {
              // Not ignored, get column name of archive table (same name as SQL or use alias)
              cname = colDesc.colname;
              if ( (metricDescriptor.colsAlias!=null)&&(metricDescriptor.colsAlias.containsKey(cname)) )
                  // use alias
                  cname = (String) metricDescriptor.colsAlias.get(cname);
              archive_array.addColName(cname);
          }
      }

      boolean savedTypes = false;   // Set to true when types have been set in archive_array

      for (int rowId=0; rowId < diffCnt.nbRows; rowId++) {
        // Get the row values
        Vector row = (Vector)diffCnt.rows.get(rowId);

        int fColId = metricDescriptor.filterColId;

        
        // Check if the row must be filtered out
        if ( fColId > 0) {

            // Get column descriptor of filter column
            ColumnDescriptor fColDesc =
                ((ColumnDescriptor)(diffCnt.columnDescriptors.get(fColId-1)));

            if ( fColDesc.isInteger() ){
               if ( ((Integer)row.get(fColId - 1)).equals(new Integer(0)) ) continue;
            }

            if ( fColDesc.isBigDecimal() ){
               if ( ((java.math.BigDecimal)row.get(fColId - 1)).equals(new java.math.BigDecimal(0)) ) continue;
            }

            if ( fColDesc.isDouble() ){
               if ( ((Double)row.get(fColId - 1)).equals(new Double(0)) ) continue;
            }

            if ( fColDesc.isLong() ){
               if ( ((Long)row.get(fColId - 1)).equals(new Long(0)) ) continue;
            }

            if ( fColDesc.isFloat() ){
               if ( ((Float)row.get(fColId - 1)).equals(new Float(0)) ) continue;
            }

        }

        // Don't save any row without any change since last sample
        if (metricDescriptor.filterColId == -1) {
          if ( ! isAnyDiffNotZero(row, diffCnt.columnDescriptors) ) continue;
        }

        aRow = archive_array.allocateNewRow();
        int saveIndex = firstIndex;
        if (saveIndex > 0){
            aRow.cols.add(diffCnt.samplingTime);
            if (!savedTypes)
                archive_array.addColType(new Integer(java.sql.Types.TIMESTAMP));
        }
        if (SaveIntervalCol==true){
            aRow.cols.add(diffCnt.interval);
            if (!savedTypes)
                archive_array.addColType(new Integer(java.sql.Types.INTEGER));
        }
        for (int col=0; col < diffCnt.nbCols; col++) {
              // Get the column descriptor
              ColumnDescriptor colDesc =
                      ((ColumnDescriptor)(diffCnt.columnDescriptors.get(col)));
              // Check if column must be ignored
              if (colDesc.isIgnoredForSave()) continue;

              // OK, this col will be saved in table, so increment index used to set param in SQL
              saveIndex++;

              // Get the sql type of the column
              int t = colDesc.getType();

              // check if column is NULL
              Object val = row.get(col);
              if (val == null) {
                  aRow.cols.add(null);
                  if (!savedTypes)
                      archive_array.addColType(t);
                  continue;
              }

              // Check if type is "bit". If Yes change it to char(1) since BULK LOAD does not support bit
              if (t == java.sql.Types.BIT) {
                  boolean valBIT = ((Boolean)val).booleanValue();
                  String valChar;
                  if (valBIT == false) valChar="0";
                  else valChar="1";
                  t=java.sql.Types.VARCHAR;
                  val = valChar;
              }

              // set the column value according to its type
              aRow.cols.add(val);
              if (!savedTypes)
                  archive_array.addColType(t);
          }
          savedTypes = true;
          archive_array.addRow(aRow);     // save this row in the array
          nbRowsToInsert++;
      }
      if (nbRowsToInsert==0) {
          return;
      }

      // Save this array into archive database
      Asemon_logger.archive_class.saveValues (archiveTabName, archive_array, this);
  }
  
  
  static class StatementMsgHandler implements SybMessageHandler
  {
        public SQLException messageHandler(SQLException sqe)
        {
            int code = sqe.getErrorCode();
            if (code == 10351)
            {
                // transform error 10351, Severity  14 Server user id xx is not a valid user in database 'yyy' 
                // into a warning
                sqe = new SQLWarning(sqe.getMessage(), sqe.getSQLState(),
                    sqe.getErrorCode());
            }
            return sqe;
        }
    }

}
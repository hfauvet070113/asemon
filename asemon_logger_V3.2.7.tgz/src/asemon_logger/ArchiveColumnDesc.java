/*
* <p>Archive_IQ</p>
* <p>Copyright: Jean-Paul Martin (jpmartin@sybase.com) Copyright (c) 2015</p>
* Class to manage a column descriptor of a archive column
* Used only during initialization of a collector (during check of existing columns)
* @version 3.0
 */
package asemon_logger;

/**
 *
 * @author jp
 */
public class ArchiveColumnDesc {
    String name;
    int usertype;
    int length;
    int prec;
    int scale;
    int allows_null;
    String typename;
    String fullType;  // Type of column. Ex. : "numeric (10,2)"

    ArchiveColumnDesc (String n, int t, int l, int p, int s, int an, String tn){
        name=n;
        usertype=t;
        length=l;
        prec=p;
        scale=s;
        allows_null = an;
        typename=tn;
    }
    void computeFullType () {
        StringBuffer sb=new StringBuffer(typename);

        // 1-char, 2-varchar, 3-binary, 4-varbinary
        if ((usertype==1)||(usertype==2)||(usertype==3)||(usertype==4)){
            sb.append("("+length+")");
        }
        // 10-numeric, 26-decimal
        if ((usertype==10)||(usertype==26)){
            sb.append("("+prec+","+scale+")");
        }

        // unsigned smallint
        if (usertype==44)
            sb = new StringBuffer ("unsigned smallint");

        // unsigned int
        if (usertype==45)
            sb = new StringBuffer ("unsigned int");

        // unsigned bigint
        if (usertype==46)
            sb = new StringBuffer ("unsigned bigint");

        fullType=sb.toString();
    }

    boolean compareCol(ArchiveColumnDesc aCD) {
        if ( aCD.usertype != usertype)
            return false;
        if ( (aCD.length != length) || (aCD.prec != prec) ||(aCD.scale != scale) )
            return false;

        if ((aCD.allows_null != 0 ) && (aCD.allows_null != allows_null) )
            // Existing column is NOT NULL but should be NULL
            return false;
        return true;
    }
    
}

/**
* <p> CollectorMonSQL : class managing acquisition of long SQL queries and corresponding data (text, plan, objects io)</p>
* <p>Copyright: Jean-Paul Martin (jpmartin@sybase.com) Copyright (c) 2017</p>
* @version 3.2.6c
*/

package asemon_logger;
import static asemon_logger.Asemon_logger.*;
import com.sybase.jdbcx.SybConnection;
import java.sql.*;
import java.util.*;
import java.math.BigDecimal;

public class CollectorMonSQL extends Collector {
    int min_logical_reads;
    int min_elapsed_time_ms;
    String sp_showplan_proc;
    String srvName;
    int currentBootID;                          // BootID (or ASE bootcount+1000000)
    String time_of_last_stmt_seen;
    HashSet<RunningStmt> currentRunningStmts;   // list of currently executing statements captured by select from master..monProcessStatement
    HashSet<RunningStmt> terminatedStmts;       // list of terminated statements
    

    int totalRowsInserted;

    String accessibleDBs;

    Collector sav_collector;
    
    Boolean gotcachedXMLExist;
    
    // Compute haskkey as a long int, and return it as a BigDecimal
    public static BigDecimal hashLong(String string) {
        long h = 0xBB40E64DA205B064L;
        final long hmult = 7664345821815920749L;
        BigDecimal H263_1= new BigDecimal(9223372036854775807L);
        for (int len = string.length(), i = 0; i < len; i++) {
            h = (h * hmult) + string.charAt(i);
        }
        h = h * hmult;
        // Convert to BigDecimal and manage negative values (no unsigned bigint in Java7)
        BigDecimal H = new BigDecimal(h);
        if (h<0)
            H=H.add(H263_1).add(H263_1);
        return (H); 
    }
  
    // Create cache of SQLHashKey's already seen
    final int SQLMAX_ENTRIES = 1000;
    Map<BigDecimal, BigDecimal> SQLHashKey_seen = new LinkedHashMap<BigDecimal, BigDecimal>(SQLMAX_ENTRIES+1, .75F, true) {
        // This method is called just after a new entry has been added
        public boolean removeEldestEntry(Map.Entry eldest) {
            return size() > SQLMAX_ENTRIES;
        }
    };

    // Create cache of PLANHashKey's already seen
    final int PLANMAX_ENTRIES = 1000;
    Map<BigDecimal, BigDecimal> PLANHashKey_seen = new LinkedHashMap<BigDecimal, BigDecimal>(PLANMAX_ENTRIES+1, .75F, true) {
        // This method is called just after a new entry has been added
        public boolean removeEldestEntry(Map.Entry eldest) {
            return size() > PLANMAX_ENTRIES;
        }
    };

    // Class constructor
    CollectorMonSQL (MonitoredSRV ms, MetricDescriptor md) {
        super (ms, md);
        srvName = msrv.srvNormalized;
        sav_collector = this;
    }

    void initialize () throws Exception {
        super.initialize();
        gotcachedXMLExist = false;
        
        if (currentRunningStmts==null) {
            currentRunningStmts = new HashSet<RunningStmt>();
            DEBUG(DBG111, "New currentRunningStmts : " + System.identityHashCode(currentRunningStmts));
        }
        else
            DEBUG(DBG111, "Already existing currentRunningStmts : " + System.identityHashCode(currentRunningStmts));

        // Get date of last captured statement
        CnxMgr.ArchCnx aArchCnx=null;
        try {
            // Get an archive connection from the pool
            aArchCnx = CnxMgr.archCnxPool.getArchCnx(false);
            Statement stmt = aArchCnx.archive_conn.createStatement();
            ResultSet rs;
            
            // no longer get "BootID" from archive database, but use "bootcount" of monitored server + 1000000 (1000000 to avoid reusing an old BootID number)
            //rs=stmt.executeQuery("select isnull( max(BootID)+1 ,0) from "+srvName+"_StmtSQL");
            //rs.next();
            //currentBootID = rs.getInt(1);
            currentBootID= msrv.bootcount + 1000000;
            
            rs=stmt.executeQuery("select case when max(StartTime) is null then '1900/01/01 00:00' else convert (varchar, max(StartTime), 111)+' '+convert (varchar, max(StartTime), 108)+'.'+convert(varchar, datepart(ms,max(StartTime))) end from "+srvName+"_StmtStat");
            rs.next();
            time_of_last_stmt_seen = rs.getString(1);
            Asemon_logger.printmess ("MonSQL BootID = "+currentBootID+ "  time_of_last_stmt_seen = "+time_of_last_stmt_seen);
            
        }
        catch (Exception e) {
            Asemon_logger.printmess ("ERROR CollectorMonSQL : error getting BootID " + e);
            currentBootID = 0;
        }
        finally {
            // Return archive connection to the pool
            CnxMgr.archCnxPool.putArchCnx(aArchCnx);
        }

        // Retrieve option "min_logical_reads"
        String paramValue = metricDescriptor.parameters.getProperty("min_logical_reads");
        min_logical_reads = 10000;
        try {
            min_logical_reads = Integer.parseInt(paramValue);
        }
        catch (Exception e) {
            Asemon_logger.printmess ("ERROR MonSQL : Bad min_logical_reads. Will use default value instead (10000)");
            min_logical_reads = 10000;
        }
        if (min_logical_reads <0) {
            Asemon_logger.printmess ("ERROR MonSQL : min_logical_reads cannot be <0. Will use default value instead (10000)");
            min_logical_reads = 10000;
        }



        // Retrieve option "min_elapsed_time_ms"
        paramValue = metricDescriptor.parameters.getProperty("min_elapsed_time_ms");
        min_elapsed_time_ms = 10000;
        try {
            min_elapsed_time_ms = Integer.parseInt(paramValue);
        }
        catch (Exception e) {
            Asemon_logger.printmess ("ERROR MonSQL : Bad min_elapsed_time. Will use default value instead (10000 ms)");
            min_elapsed_time_ms = 10000;
        }
        if (min_elapsed_time_ms <0) {
            Asemon_logger.printmess ("ERROR MonSQL : min_elapsed_time cannot be <0. Will use default value instead (10000 ms)");
            min_elapsed_time_ms = 10000;
        }



        sp_showplan_proc = metricDescriptor.parameters.getProperty("sp_showplan_proc");
        if (msrv.sa_role==0) {
            // Retrieve option "sp_showplan_proc_non_sa"
            sp_showplan_proc = metricDescriptor.parameters.getProperty("sp_showplan_proc_non_sa");
            if (sp_showplan_proc == null) {
                Exception e =new Exception("ERROR : sp_showplan_proc_non_sa not defined in collector config");
                throw e;
            }
        }
      
    }


    // Utility function
    // Find a running statement already captured
    private RunningStmt findARunningStmt (int aSPID, int aKPID, int aBatchID, int aProcedureID, int aLineNumber) {
        
        RunningStmt aStmt     = null;

        if (!currentRunningStmts.isEmpty()) {
            // Initialize iterator for loop on opened statements
            Iterator<RunningStmt> iterCurStmt = (Iterator<RunningStmt>) currentRunningStmts.iterator();
            DEBUG(DBG111, "Iterator on currentRunningStmts : " + System.identityHashCode(currentRunningStmts));

            /*
               System.out.println("'"+Integer.valueOf(KPID).toString()+"-"
                                     +Integer.valueOf(BatchID).toString()+"-"
                                     +Integer.valueOf(LineNumber).toString()+"'\n");
            */
            while ( iterCurStmt.hasNext() ) {
                aStmt=(RunningStmt)iterCurStmt.next();
                /*
                  System.out.println("'"+Integer.valueOf(aStmt.KPID).toString()+"-"
                                     +Integer.valueOf(aStmt.BatchID).toString()+"-"
                                     +Integer.valueOf(aStmt.LineNumber).toString()+"'\n");
                */                   
                if ( (aSPID==aStmt.SPID) && (aKPID==aStmt.KPID) && 
                       (aBatchID==aStmt.BatchID) &&
                       ( (aProcedureID==aStmt.ProcedureID) || (aProcedureID==-1) ) &&
                       ( (aLineNumber==aStmt.LineNumber) || (aLineNumber==-1) )
                   ) {
                       // System.out.println("found\n");
                       return aStmt;
                }
            }
        }
        return null;
    }


    // Find a terminated statement
    private RunningStmt findATerminatedStmt (int aSPID, int aKPID, int aBatchID, int aProcedureID, int aLineNumber) {
        
        RunningStmt aStmt     = null;

        if (!terminatedStmts.isEmpty()) {
            // Initialize iterator for loop on opened statements
            Iterator<RunningStmt> iterCurStmt = (Iterator<RunningStmt>) terminatedStmts.iterator();
            while ( iterCurStmt.hasNext() ) {
                aStmt=(RunningStmt)iterCurStmt.next();
                if ( (aSPID==aStmt.SPID) && (aKPID==aStmt.KPID) && (aBatchID==aStmt.BatchID) &&
                       ( (aProcedureID==aStmt.ProcedureID) || (aProcedureID==-1) ) &&
                       ( (aLineNumber==aStmt.LineNumber) || (aLineNumber==-1) ) ) {
                    // System.out.println("found\n");
                    return aStmt;
                }
            }
        }
        return null;
    }

    private String choose_ProcName(String ProcName, String ProcName_in_tempdb, String ProcName_in_procs) {
        String NewProcName = ProcName;
        Boolean ProcName_is_integer=false;
        try {
            int i = Integer.parseInt(ProcName);
            ProcName_is_integer=true;
        }
        catch (Exception e) {
        }
        if ( (ProcName==null) || (ProcName_is_integer))
            if (ProcName_in_tempdb != null )
                NewProcName = ProcName_in_tempdb;
            else if (ProcName_in_procs != null )
                NewProcName = ProcName_in_procs;
        return NewProcName;
    }

    
    
    private Boolean similarStatementExists (int aSPID, int aKPID, int aBatchID, Timestamp aTs) {
        RunningStmt aStmt     = null;
        aStmt = findATerminatedStmt (aSPID, aKPID, aBatchID, -1, -1);
        if (aStmt == null)
            // May still be in running list
            aStmt =  findARunningStmt (aSPID, aKPID, aBatchID, -1, -1);
        if (aStmt != null) {
            // Check if starttime are close
            Long t1 = aStmt.StartTime.getTime();
            String t1_s = aStmt.StartTime.toString();
            Long t2 = aTs.getTime();
            String t2_s = aTs.toString();
            Long diff = Math.abs(t1 - t2);
            if (diff < 1000)
                // Diff is less than 1 s
                return true;                    
        }
        return false;
    }


    class RowOfSqlText {

        private Timestamp ts;
        private int LineNumber;
        private int SequenceInLine;
        private String SQLText;
    }

    class BatchOfSQLText {

        private Vector<RowOfSqlText> rows;
        private int SPID, KPID, BatchID;
        private String SQLTextBatch;
        //private BigDecimal SQLoriginalHK;
        private BigDecimal SQLnormalizedHK;
        private boolean attached;
       
        private BatchOfSQLText(int aSPID, int aKPID, int aBatchID) {
            rows = new Vector<RowOfSqlText>();
            SPID=aSPID;
            KPID=aKPID;
            BatchID=aBatchID;
            attached = false;
        }

        private void addRow(RowOfSqlText aRow) {
            rows.add(aRow);
        }

        private void attachToStmt () {
            // check if this batch can be affected to any running or terminated statement
            Iterator<RunningStmt> iter = currentRunningStmts.iterator();
            DEBUG(DBG111, "Iterator attachToStmt currentRunningStmts : " + System.identityHashCode(currentRunningStmts));

            RunningStmt aStmt;
            while (iter.hasNext()) {
                aStmt = iter.next();
                if ( (aStmt.SPID==SPID) && (aStmt.KPID==KPID) && (aStmt.BatchID==BatchID) ) {
                    if (aStmt.batchOfSQLText==null) {
                        aStmt.batchOfSQLText = this;
                        attached = true;
                        // Compute SQLHashKey
                        computeHashKey(aStmt);
                        DEBUG(DBG111, "Stmt : " + System.identityHashCode(aStmt)+" Found in runnningStmts");
                    }
                }              
            }
            iter = terminatedStmts.iterator();
            while (iter.hasNext()) {
                aStmt = iter.next();
                if ( (aStmt.SPID==SPID) && (aStmt.KPID==KPID) && (aStmt.BatchID==BatchID) ) {
                    if ( aStmt.batchOfSQLText == null )  {
                        aStmt.batchOfSQLText = this;
                        attached = true;
                        // Compute SQLHashKey
                        computeHashKey(aStmt);
                        DEBUG(DBG111, "Stmt : " + System.identityHashCode(aStmt)+" Found in terminatedStmts");
                    }
                }              
            }           
        }

        private void computeHashKey(RunningStmt aStmt) {
            //if (SQLHK == null) {
                RowOfSqlText arowOfSQLText;
                // Normalize, parametrize and compute SQLHashKey
                Iterator<RowOfSqlText> itersqltext = rows.iterator();
                StringBuffer SQLTextSB = new StringBuffer();
                //int prevSequenceInLine = 1;
                while (itersqltext.hasNext()) {
                    arowOfSQLText = (RowOfSqlText) itersqltext.next();
                    //DEBUG(DBG111, "Stmt : " + System.identityHashCode(aStmt)+" LineNumber="+arowOfSQLText.LineNumber+" arowOfSQLText="+arowOfSQLText.SQLText);
                    //if (arowOfSQLText.SequenceInLine != prevSequenceInLine) {
                    //    prevSequenceInLine = arowOfSQLText.SequenceInLine;
                    //    SQLTextSB.append("\n");
                    //}
                    SQLTextSB.append(arowOfSQLText.SQLText);
                }
                SQLTextBatch = SQLTextSB.toString();
                //SQLoriginalHK = hashLong(SQLTextBatch);
                //DEBUG(DBG111, "Stmt : " + System.identityHashCode(aStmt)+"  SQLoriginalHK : "+ SQLoriginalHK+" SQL : "+SQLTextBatch);
                SQLTextBatch = ASMUtils.normStr(SQLTextBatch);
                SQLTextBatch = ASMUtils.parameterize(SQLTextBatch, true);
                if (SQLTextBatch.length()!=0)
                    SQLnormalizedHK = hashLong(SQLTextBatch);
                else
                    SQLnormalizedHK = null;
                DEBUG(DBG111, "Stmt : " + System.identityHashCode(aStmt)+"  SQLnormalizedHK : "+ SQLnormalizedHK+" SQL : "+SQLTextBatch.substring(0, (SQLTextBatch.length() < 100)?SQLTextBatch.length():100).replaceAll("\n", " ").replaceAll("\r", " "));
            //}           
        }



       private void clear() {
           rows.clear();
       }
    }


    class RowOfProcessObjects {

        private String DBName;
        private int OwnerUserID;
        private String ObjectName;
        private String ObjectType; 
        private int IndexID; 
        private long LogicalReads; 
        private int PhysicalReads; 
        private int PhysicalAPFReads; 
        private int TableSize;
        private int PartitionSize;
        private int PartitionID;
        private String PartitionName;
        private String IdxName;

    }


    class RunningStmt {
        private BigDecimal StmtID;
        private Timestamp sampleTime; // Idem Endtime for statements captured from master..monSysStatement
        private String Login;
        private String Application;
        private String ClientHost;
        private String ClientIP;
        private String ClientOSPID;
        private String tran_name;
        private String ClientName;
        private String ClientHostName;
        private String ClientApplName;
        private int BootID;
        private int KPID;
        private int SPID;
        private int DBID;
        private int ProcedureID;
        private String ProcName;
        private int PlanID;
        private int BatchID;
        private int ContextID;
        private int LineNumber;
        private int CpuTime;
        private int WaitTime;
        private int MemUsageKB;
        private long PhysicalReads;
        private long LogicalReads;
        private long PagesModified;
        private int PacketsSent;
        private int PacketsReceived;
        private int NetworkPacketSize;
        private int PlansAltered;
        private int RowsAffected;
        private Integer ProcNestLevel;
        private Integer StatementNumber;
        private Timestamp StartTime;
        private String ExactStat="N";
        
        private BatchOfSQLText batchOfSQLText;
        private Vector<RowOfProcessObjects> processObjects;
        private Vector<String> SQLPlan=null;
        private BigDecimal PLANHashKey;
        
        
        private int   SnapCodegenTime       ;
        private int   SnapJITTime           ;
        private int   SnapExecutionTime     ;
        private int   SnapExecutionCount    ;
        private long  QueryOptimizationTime ;
        

        private String     SQLText_From_showplan = "";
        private BigDecimal SQLHashKey_SQLText_From_showplan;
        private String     SQLText_to_save = "";
        private BigDecimal SQLHashKey_to_save;
        
        private boolean    SQLTextSaved=false;
        
        private Timestamp  CompileDate;
        private String xmlinfo;
        private Timestamp xmlInfoTimestamp;
        private int OwnerUID;
        
        void setValues (Timestamp newTime, int aBootID, int aKPID, int aSPID, int aDBID, int aProcedureID, String aProcName, int aPlanID, int aBatchID, int aContextID, int aLineNumber, int aCpuTime, int aWaitTime, int aMemUsageKB,
                  long aPhysicalReads,long aLogicalReads,long aPagesModified,int aPacketsSent,int aPacketsReceived,int aNetworkPacketSize,int aPlansAltered,Timestamp aStartTime, String aExactStat, int aRowsAffected,
                  Integer aProcNestLevel, Integer aStatementNumber,
                  int aSnapCodegenTime, int aSnapJITTime, int aSnapExecutionTime, int aSnapExecutionCount, long aQueryOptimizationTime) 
        {
           sampleTime      = newTime;
           BootID          = aBootID;
           KPID            = aKPID;
           SPID            = aSPID;
           DBID            = aDBID;
           if (ProcedureID == 0)
               ProcedureID     = aProcedureID;
           if ((ProcName == null) || (ProcName.isEmpty()))
               ProcName        = aProcName;
           PlanID          = aPlanID;
           BatchID         = aBatchID;
           ContextID       = aContextID;
           LineNumber      = aLineNumber;
           CpuTime         = aCpuTime;
           WaitTime        = aWaitTime;
           MemUsageKB      = aMemUsageKB;
           PhysicalReads   = aPhysicalReads;
           LogicalReads    = aLogicalReads;
           PagesModified   = aPagesModified;
           PacketsSent     = aPacketsSent;
           PacketsReceived = aPacketsReceived;
           NetworkPacketSize = aNetworkPacketSize;
           PlansAltered    = aPlansAltered;
           StartTime       = aStartTime;
           ExactStat       = aExactStat;
           RowsAffected    = aRowsAffected;
           ProcNestLevel    = aProcNestLevel;
           StatementNumber    = aStatementNumber;
           SnapCodegenTime          = aSnapCodegenTime      ;
           SnapJITTime              = aSnapJITTime          ;
           SnapExecutionTime        = aSnapExecutionTime    ;
           SnapExecutionCount       = aSnapExecutionCount   ;
           QueryOptimizationTime    = aQueryOptimizationTime;
           
        }
        
        private String chooseVal(String oldVal, String newVal) {
            // keep original value captured when the statement was seen the first time
            // If null, take the new value captured at end of the statement in monSysStatement and monProcessLookup
            String val = oldVal;
            if ( ( (oldVal == "") || (oldVal == null) ) && (newVal != "") )
                val = newVal;           
            return val;
        }
        
        void setLookupValues (String aLogin, String aApplication, String aClientHost, String aClientIP, String aClientOSPID, String aClientName, String aClientHostName, String aClientApplName) {
            Login = chooseVal(Login, aLogin);
            Application = chooseVal(Application, aApplication);
            ClientHost = chooseVal(ClientHost, aClientHost);
            ClientIP = chooseVal(ClientIP, aClientIP);
            ClientOSPID = chooseVal(ClientOSPID, aClientOSPID);
            ClientName = chooseVal(ClientName, aClientName);
            ClientHostName = chooseVal(ClientHostName, aClientHostName);
            ClientApplName = chooseVal(ClientApplName, aClientApplName);
        }

        private void retreiveSQLTextandLookup () throws Exception {
            RowOfSqlText SQLLine;
            Statement stmt=null;
            String selClientInfo;

            if (msrv.monSrvConn == null) return;
            try {
                if (stmt == null) stmt = msrv.monSrvConn.createStatement();
                ResultSet rs;
                DEBUG(DBG104, "Stmt : " + System.identityHashCode(this)+ " Retreive SQL for KPID="+KPID+" SPID="+SPID+" BatchID="+BatchID);
                if (!Asemon_logger.skipRetreiveSQLText) {
                    // Get SQL text of current statement
                    // and get process lookup information
                    rs = stmt.executeQuery(
                      "select getdate(),LineNumber,SequenceInLine,SQLText from master..monProcessSQLText where SPID="+SPID+" and KPID="+KPID+" and BatchID="+BatchID );
                    while (rs.next()) {
                        if (batchOfSQLText == null)
                            batchOfSQLText = new BatchOfSQLText(SPID, KPID, BatchID);
                        SQLLine = new RowOfSqlText();
                        SQLLine.ts = rs.getTimestamp(1);
                        SQLLine.LineNumber = rs.getInt(2);
                        SQLLine.SequenceInLine = rs.getInt(3);
                        SQLLine.SQLText = rs.getString(4);
                        batchOfSQLText.addRow(SQLLine);
                    }
                    if (batchOfSQLText != null) {
                        batchOfSQLText.computeHashKey(this);
                        DEBUG(DBG104, "Stmt : " + System.identityHashCode(this)+ " Found SQL. SQLHashKey="+batchOfSQLText.SQLnormalizedHK);
                    }
                }

                if (msrv.version >= 1570)
                    //selClientInfo = ",ClientName, ClientHostName, ClientApplName";
                    selClientInfo = ",ClientName=clientname, ClientHostName=clienthostname, ClientApplName=clientapplname";
                else
                    selClientInfo = "";

                DEBUG(DBG104, "Stmt : " + System.identityHashCode(this)+ " Retreive Lookup values for KPID="+KPID+" SPID="+SPID+" BatchID="+BatchID);
                rs = stmt.executeQuery(
                 // OLD QUERY :" select Login, Application, ClientHost, ClientIP, ClientOSPID" + selClientInfo + " from master..monProcessLookup where SPID="+SPID+" and KPID="+KPID
                 " select Login=suser_name(suid), Application=program_name, ClientHost=hostname, ClientIP=ipaddr, ClientOSPID=hostprocess, tran_name" + selClientInfo + " from master..sysprocesses where spid="+SPID+" and kpid="+KPID
                );
                while (rs.next()) {
                    Login = rs.getString(1);
                    Application = rs.getString(2);
                    ClientHost = rs.getString(3);
                    ClientIP = rs.getString(4);
                    ClientOSPID = rs.getString(5);
                    tran_name = rs.getString(6);
                    if (msrv.version >= 1570) {
                        ClientName = rs.getString(7);
                        ClientHostName = rs.getString(8);
                        ClientApplName = rs.getString(9);
                    }
                    else {
                        ClientName = null;
                        ClientHostName = null;
                        ClientApplName = null;
                    }
                    DEBUG(DBG104, "Stmt : " + System.identityHashCode(this)+ " Lookup values for KPID="+KPID+" SPID="+SPID+" BatchID="+BatchID+ ": Application : "+Application+" ClientHost : "+ClientHost);
                }

                return;
            }
            catch (SQLException e) {
                int err = e.getErrorCode();
                if (err==12036) {
                    // ignore "Collection of monitoring data for table XXXX requires ...'
                    return;
                }
                System.out.println("ERROR CollectorMonSQL.retreiveSQLText : "+err+ " "+e.getMessage());
                if (err != 632) {
                    //e.printStackTrace(System.out);
                    throw e;
                }
            }
            catch (Exception e) {
                //System.out.println("Asemon_logger.retreiveSQLTextandLookup. : "+e);
                //e.printStackTrace(System.out);
                throw e;
            }
        }

        private void retreiveProcessObjects () throws Exception {
            RowOfProcessObjects arowOfProcessObjects;
            Statement stmt=null;
            
            if (msrv.monSrvConn == null) return;
            try {
                if (stmt == null) stmt = msrv.monSrvConn.createStatement();
                
                DEBUG(DBG104, "Stmt : " + System.identityHashCode(this)+ " Retreive obj stats for KPID="+KPID+" SPID="+SPID+" BatchID="+BatchID+" ContextID="+ContextID+" LineNumber="+LineNumber+" Application="+Application+" ClientHost="+ClientHost);
                DEBUG(DBG104, "Stmt : " + System.identityHashCode(this)+ " Accessible db's="+accessibleDBs);
                // Get objects statistics of current statement
                boolean vectorAllocated=false;
                ResultSet rs;
                if (msrv.version < 1252) {
                   // before 1252, TableSize doesn't exists
                    rs = stmt.executeQuery(
                        "select O.DBName,OwnerUserID,ObjectName,ObjectType, IndexID, O.LogicalReads, O.PhysicalReads, O.PhysicalAPFReads, TableSize=0    from master..monProcessObject O, master..monProcessStatement S where O.KPID=S.KPID and O.KPID="+KPID+" and S.BatchID="+BatchID+" and S.ContextID="+ContextID+" and S.LineNumber="+LineNumber
                    );
                } else {
                    if (msrv.version < 1500) {
                        rs = stmt.executeQuery(
                            "select O.DBName,OwnerUserID,ObjectName,ObjectType, IndexID, O.LogicalReads, O.PhysicalReads, O.PhysicalAPFReads, TableSize    from master..monProcessObject O, master..monProcessStatement S where O.KPID=S.KPID and O.KPID="+KPID+" and S.BatchID="+BatchID+" and S.ContextID="+ContextID+" and S.LineNumber="+LineNumber
                        );
                    }
                    else 
                        rs = stmt.executeQuery(
                            // In V15 ObjectName contains name of index rather than name of object
                           "select O.DBName,OwnerUserID, (case when O.DBID in "+accessibleDBs+" then  object_name(ObjectID,O.DBID) else convert(varchar,ObjectID) end),ObjectType, IndexID, O.LogicalReads, O.PhysicalReads, O.PhysicalAPFReads, PartitionSize, PartitionID, PartitionName,ObjectName    from master..monProcessObject O, master..monProcessStatement S where O.KPID=S.KPID and O.KPID="+KPID+" and S.BatchID="+BatchID+" and S.ContextID="+ContextID+" and S.LineNumber="+LineNumber
                        );
                } // if (cnx.version <= 1250) {
                
                while (rs.next()) {
                    arowOfProcessObjects = new RowOfProcessObjects();
                
                    // allocate processObjects structure only if rows are retrieved; Else, previous structure is still there
                    if ( !vectorAllocated ) {
                        processObjects=new Vector<RowOfProcessObjects>();
                        vectorAllocated=true;
                    }
                
                    arowOfProcessObjects.DBName = rs.getString(1);
                    arowOfProcessObjects.OwnerUserID = rs.getInt(2);
                    arowOfProcessObjects.ObjectName = rs.getString(3);
                    arowOfProcessObjects.ObjectType = rs.getString(4);
                    arowOfProcessObjects.IndexID = rs.getInt(5);
                    arowOfProcessObjects.LogicalReads = rs.getLong(6);
                    arowOfProcessObjects.PhysicalReads = rs.getInt(7);
                    arowOfProcessObjects.PhysicalAPFReads = rs.getInt(8);
                    if (msrv.version < 1500) {
                        arowOfProcessObjects.TableSize = rs.getInt(9);
                        arowOfProcessObjects.PartitionID = 0;
                    }
                    else {
                        arowOfProcessObjects.PartitionSize = rs.getInt(9);
                        arowOfProcessObjects.PartitionID = rs.getInt(10);
                        arowOfProcessObjects.PartitionName = rs.getString(11);
                        arowOfProcessObjects.IdxName = rs.getString(12);
                    }
                    
                    
                    processObjects.add(arowOfProcessObjects);
                    DEBUG(DBG104, "Stmt : " + System.identityHashCode(this)+ " Object='"+arowOfProcessObjects.DBName+"."+arowOfProcessObjects.OwnerUserID+"."+arowOfProcessObjects.ObjectName+"' IndexID="+arowOfProcessObjects.IndexID+" LogicalReads="+arowOfProcessObjects.LogicalReads);
                }
                return;
            }
            catch (SQLException e) {
                //System.out.println("Asemon_logger.retreiveProcessObjects. : "+e);
                //e.printStackTrace(System.out);
                switch (e.getErrorCode()) {
                    case 8233 :
                        // An alter table or reorg operation is in progress on the object...
                        // Ignore this error
                        return;
                    default :
                        throw e;
                }
            }
            
            catch (Exception e) {
                //System.out.println("Asemon_logger.retreiveProcessObjects. : "+e);
                //e.printStackTrace(System.out);
                throw e;
            }
        
        
        }
 
        private void retreiveProcInfo () throws Exception {
            if (ProcName == null) return;
            
            // take XML plan of compiled statements only
            if (!ProcName.startsWith("*s"))
                return;

            // Retreive compilation date and memory used by the statement
            String query = "select OwnerUID, CompileDate, MemUsageKB from master..monProcessProcedures where SPID="+SPID+" and KPID="+KPID+" and ObjectID=" +ProcedureID+ "and PlanID="+PlanID;
            Statement stmt = msrv.monSrvConn.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            if (rs!=null) {
                if (rs.next() ) {
                    OwnerUID = rs.getInt(1);
                    CompileDate = rs.getTimestamp(2);
                    MemUsageKB = rs.getInt(3);
                    DEBUG(DBG119,"Got CompileDate, MemUsageKB from monProcessProcedures. ProcID="+ProcedureID+", PlanID="+PlanID);
                }
            }
            stmt.close();
            rs = null;
        }

        private void retreivePlan () throws Exception {
            // System.out.println ("\nEnter retreivePlan\n");
            String msg;
            Statement stmt=null;
            Boolean result;
            int updateCnt;
            StringBuffer plan_as_string = new StringBuffer();
            
            
            if (Asemon_logger.skipRetreivePlan) return;
            if (Asemon_logger.skipSAProcs) return;
            
            if (msrv.monSrvConn == null) return;
            try {
                if (stmt != null) {
                    stmt.close();
                }
                stmt = msrv.monSrvConn.createStatement();
                
                DEBUG(DBG104, "Stmt : " + System.identityHashCode(this)+ " Retreive plan for KPID="+KPID+" SPID="+SPID+" BatchID="+BatchID+" ContextID="+ContextID+" LineNumber="+LineNumber);
                // Get plan of current statement
//                stmt.executeUpdate("sp_showplan "+ Integer.toString(SPID) + ",null, null ,null" );

                result = stmt.execute("set nocount on if exists (select * from master..monProcessStatement" +
                        " where KPID=" +Integer.toString(KPID)+
                        " and BatchID=" +Integer.toString(BatchID)+
                        " and ContextID=" +Integer.toString(ContextID) +
                        " and LineNumber=" +Integer.toString(LineNumber) +
                        ") begin exec " + sp_showplan_proc + " " + Integer.toString(SPID) + ",null, null ,null end set nocount off" );

//                stmt.executeUpdate("sp_showplan "+ Integer.toString(SPID)+ "," + Integer.toString(BatchID)+ "," +  Integer.toString(ContextID) + " ,null" );
//                result = stmt.execute("sp_showplan "+ Integer.toString(SPID)+ ",null, null ,null" );

                if (msrv.version >= 1600) {
                    /* In V16 can retreive SQL text in showplan*/
                    ResultSet rs = stmt.getResultSet();
                    if (rs != null) {
                        rs.next();
                        SQLText_From_showplan = rs.getString(1);
                        DEBUG(DBG104,"Stmt : " + System.identityHashCode(this)+ " SQLTextFrom_showplan ("+SQLText_From_showplan.length()+") :" +SQLText_From_showplan.substring(0, (SQLText_From_showplan.length() < 100)?SQLText_From_showplan.length():100).replaceAll("\n", " ").replaceAll("\r", " "));

                        SQLText_From_showplan = ASMUtils.normStr(SQLText_From_showplan);
                        SQLText_From_showplan = ASMUtils.parameterize(SQLText_From_showplan, true);
                        SQLHashKey_SQLText_From_showplan = hashLong(SQLText_From_showplan);
                        DEBUG(DBG104,"Stmt : " + System.identityHashCode(this)+ " SQLnormalizedHK :"+SQLHashKey_SQLText_From_showplan);

                    }
                }


                do {
                   result = stmt.getMoreResults();
                   updateCnt=stmt.getUpdateCount();
                }  
                while ((!result)&&(updateCnt!=-1));
                SQLWarning sqlw=stmt.getWarnings();
                String qPlanPattern1="QUERY PLAN FOR STATEMENT.*";
                String qPlanPattern2="QUERY PLAN FOR STATEMENT.*(at line "+LineNumber+").*";
                boolean inSearchedPlan=false;
                if (sqlw != null) {
                    
                    while ( true) {
                
                        // Ignore "10233 01ZZZ The specified statement number..." message
                        if (sqlw.getErrorCode()==10233) break;
                        // Ignore "010P4: An output parameter was received and ignored." message
                        if (sqlw.getSQLState().equalsIgnoreCase("010P4") ) break;
                        
                        msg=sqlw.getMessage();
                        //System.out.println(sqlw.getErrorCode()+" " + sqlw.getSQLState()  +" "+msg.substring(0,msg.length()-1));
                        
                        //if (msg.matches("^The query plan for spid.*$"))
                        if (msg.startsWith("The query plan for spid"))
                            break;
                        
                        if (SQLPlan==null) SQLPlan = new Vector<String>();
                        
                        // don't keep last char of message which is a linefeed
                        if (msg.charAt(msg.length()-1)=='\n')
                            msg = msg.substring(0,msg.length()-1);
                        
                        if (msg.matches(qPlanPattern1)) {
                            if (msg.matches(qPlanPattern2))
                                inSearchedPlan = true;
                            else
                                // not yet in searched plan, or leave searched plan
                                inSearchedPlan = false;
                        }
                        
                        if (inSearchedPlan) {
                            SQLPlan.add(msg);
                            plan_as_string.append(msg);
                        }
                        sqlw=sqlw.getNextWarning();
                        if (sqlw==null) break;
                    }
                    if (plan_as_string.length() > 0) {
                      // Compute HashKey
                      PLANHashKey = hashLong(plan_as_string.toString());
                      DEBUG(DBG104, "Stmt : " + System.identityHashCode(this)+ " Found plan. PLANHashKey="+PLANHashKey);
                    }
                }
            }
            catch (Exception e) {
               //System.out.println("Asemon_logger.retreivePlan. : "+e);
               //e.printStackTrace(System.out);
               throw e;
            }
        }

        private void retreiveXMLPlan () throws Exception {
            if (skipCollectXML) return;
            if (msrv.version < 1600)
                return;
            
            if (ProcName == null) return;
            
            // take XML plan of compiled statements only
            if (!ProcName.startsWith("*s"))
                return;

            if (CompileDate==null) return; // Could not get this info before, so cannot save the XML plan in archive database
            
            Statement stmt = msrv.monSrvConn.createStatement();
            ResultSet rs;

            if (!gotcachedXMLExist) {
                // Check if #gotcachedXML exists. Will be necessary during saving of the XML plan
                rs = stmt.executeQuery("if object_id('#gotcachedXML') != null select res='O' else select res='N'");
                if (rs!=null) {
                    if (rs.next() ) {
                        String res = rs.getString(1);
                        if (res.compareTo("N")==0) {
                            rs = null;
                            stmt.close();
                            return;
                        }
                    }
                }
            }
            gotcachedXMLExist = true;

            String query;
            
            int nbRowXMLCaptured = 0;
            // Check if this XML was already captured
            query = "select count(*) from #gotcachedXML where ObjectID=" +ProcedureID+ "and PlanID="+PlanID+" and InstanceID=0 and OwnerUID="+OwnerUID+" and DBID=2";
            rs = stmt.executeQuery(query);
            if (rs!=null) {
                if (rs.next() ) {
                    nbRowXMLCaptured = rs.getInt(1);
                    DEBUG(DBG119,"Nb rows in #gotcachedXML where ProcID="+ProcedureID+"and PlanID="+PlanID+" : "+nbRowXMLCaptured);
                }
            }
            
            if (nbRowXMLCaptured!=0) {
                rs = null;
                stmt.close();
                return;
            }
            
            // Get XML plan
            query = "select getdate(), xmlinfo=show_cached_plan_in_xml("+ProcedureID+", "+PlanID+", 0 )";

            rs = stmt.executeQuery(query);
            if (rs!=null) {
                if (rs.next() ) {
                    xmlInfoTimestamp = rs.getTimestamp(1);
                    xmlinfo = rs.getString(2);
                    DEBUG(DBG119,"Got XML plan in monSQL. ProcID="+ProcedureID+", PlanID="+PlanID);

                    if (xmlinfo != null) {
                        // Check if plan is not in use. If yes, discard this row
                        int startStatus = xmlinfo.indexOf("<planStatus>") +12;
                        if (startStatus > 0) {
                            // Found startstatus
                            int endStatus = xmlinfo.indexOf("</planStatus>");
                            if (endStatus > 0) {
                                // found endStatus
                                String planStatus = (xmlinfo.substring(startStatus, endStatus)).trim().toLowerCase();
                                if ( (planStatus != null) && (planStatus.compareTo("available")!=0) ){
                                    // cannot get this plan
                                    xmlinfo=null;
                                }
                           }
                        }
                        // Check if plan contains actual statistics
                        if (xmlinfo != null) {
                            if ( !xmlinfo.contains("<act>") ) {
                                // don't keep this plan
                                xmlinfo=null;
                            }
                        }
                    }
                    if (xmlinfo!=null)
                        DEBUG(DBG119,"Got XML plan in monSQL. Plan valid");

                }
            }
            rs = null;
            stmt.close();
            
        }

        private void saveXMLPlan(CnxMgr.ArchCnx aArchCnx) throws Exception {
            if (xmlinfo==null) return;
            PreparedStatement pstmtArch_insXMLPlan;
            // Prepare the INSERT statement
            StringBuffer sql = new StringBuffer("insert into "+srvName+"_CachedXML (" +
                "Timestamp , " +
                "ObjectID , " +
                "PlanID , " +
                "InstanceID , " +
                "OwnerUID, " +
                "DBID, " +
                "MemUsageKB , " +
                "CompileDate , " +
                "xmlinfo , " +
                "bootcount ) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)" );
            pstmtArch_insXMLPlan = (aArchCnx.archive_conn).prepareStatement(sql.toString());
            pstmtArch_insXMLPlan.setString(1,xmlInfoTimestamp.toString());
            pstmtArch_insXMLPlan.setInt(2,ProcedureID);
            pstmtArch_insXMLPlan.setInt(3,PlanID);
            pstmtArch_insXMLPlan.setInt(4,0);
            pstmtArch_insXMLPlan.setInt(5,OwnerUID);
            pstmtArch_insXMLPlan.setInt(6,2);             // Force DBID to 2 since compiled statements are in tempdb
            pstmtArch_insXMLPlan.setInt(7,MemUsageKB);
            pstmtArch_insXMLPlan.setString(8,CompileDate.toString());
            pstmtArch_insXMLPlan.setString(9,xmlinfo);
            pstmtArch_insXMLPlan.setInt(10,msrv.bootcount);

            pstmtArch_insXMLPlan.executeUpdate();
            pstmtArch_insXMLPlan.close();
            DEBUG(DBG119,"Plan XML saved in "+srvName+"_CachedXML. ProcID="+ProcedureID+", PlanID="+PlanID+", OwnerUID="+OwnerUID+", CompileDate="+CompileDate);
            
            // insert this captured plan ref into #gotCachedXML . Avoid retreiving this plan by CollectorCachedXML
            PreparedStatement pstmt= msrv.monSrvConn.prepareStatement("insert into #gotcachedXML values (?,?,?,?,?)");
            pstmt.setInt(1, ProcedureID);
            pstmt.setInt(2, PlanID);
            pstmt.setInt(3, 0);
            pstmt.setInt(4, OwnerUID);
            pstmt.setInt(5, 2);                           // Force DBID to 2 since compiled statements are in tempdb

            pstmt.executeUpdate();
            pstmt.close();
        }


        private void saveStmtStat (CnxMgr.ArchCnx aArchCnx) throws Exception {
            // Reset the Bulk Copy mode for this statement.
            // Seems uncompatible with generation of IDENTITY in V16 or with jConnect 16
            aArchCnx.unsetBulkLoad();
            
            String V15cols = "";
            if (msrv.version >= 1500)
                    V15cols = ", ProcNestLevel, StatementNumber";

            String clientInfoCols = "";
            if (msrv.version >= 1570) {
                clientInfoCols = ", ClientName, ClientHostName, ClientApplName ";
            }
            
            String colV16SP03 = "";
            if (msrv.sbssav.compareTo("16.0.03.00") >= 0) {
                colV16SP03 = ", SnapCodegenTime, SnapJITTime, SnapExecutionTime, SnapExecutionCount, QueryOptimizationTime";
            }

            PreparedStatement pstmtArch_insStmtStat;
            // Prepare the INSERT statement
            StringBuffer sql = new StringBuffer("insert into "+srvName+"_StmtStat (" +
                "BootID," +
                "KPID," +
                "SPID," +
                "BatchID," +
                "StartTime," +
                "EndTime," +
                "ExactStat," +
                "\"Login\"," +
                "Application," +
                "ClientHost," +
                "ClientIP," +
                "ClientOSPID," +
                "DBID," +
                "ProcName," +
                "PlanID," +
                "ContextID," +
                "LineNumber," +
                "CpuTime," +
                "WaitTime," +
                "MemUsageKB," +
                "PhysicalReads," +
                "LogicalReads," +
                "PagesModified," +
                "PacketsSent," +
                "PacketsReceived," +
                "NetworkPacketSize," +
                "PlansAltered," +
                "RowsAffected," +
                "SQLHashKey," +
                "PLANHashKey," +
                "tran_name" +
                clientInfoCols +
                colV16SP03 +
                V15cols +
                ") values (");
            sql = sql.append("?");
            sql = sql.append(",?");
            sql = sql.append(",?");
            sql = sql.append(",?");
            sql = sql.append(",?");
            sql = sql.append(",?");
            sql = sql.append(",?");
            sql = sql.append(",?");
            sql = sql.append(",?");
            sql = sql.append(",?");
            sql = sql.append(",?");
            sql = sql.append(",?");
            sql = sql.append(",?");
            sql = sql.append(",?");
            sql = sql.append(",?");
            sql = sql.append(",?");
            sql = sql.append(",?");
            sql = sql.append(",?");
            sql = sql.append(",?");
            sql = sql.append(",?");
            sql = sql.append(",?");
            sql = sql.append(",?");
            sql = sql.append(",?");
            sql = sql.append(",?");
            sql = sql.append(",?");
            sql = sql.append(",?");
            sql = sql.append(",?");
            sql = sql.append(",?");
            sql = sql.append(",?");
            sql = sql.append(",?");
            sql = sql.append(",?");
            if (clientInfoCols.length()>0) {
                sql = sql.append(",?");
                sql = sql.append(",?");
                sql = sql.append(",?");                
            }
            if (colV16SP03.length()>0) {
                sql = sql.append(",?");
                sql = sql.append(",?");
                sql = sql.append(",?");
                sql = sql.append(",?");
                sql = sql.append(",?");
            }
            if (V15cols.length()>0) {
                sql = sql.append(",?");
                sql = sql.append(",?");
            }
            sql = sql.append(")");


            //DEBUG(DBG104, "Stmt : " + System.identityHashCode(this)+ " SQL="+sql.toString().substring(0,(sql.length() < 100)?sql.length():100).replaceAll("\n", " ").replaceAll("\r", " "));

            pstmtArch_insStmtStat = ((SybConnection)aArchCnx.archive_conn).prepareStatement(sql.toString()); //, true); // Dynamic statement cannot return @@identity in some ASE versions. Works with V15.7SP138 and 16SP2PL05

            Statement stmtArch = aArchCnx.archive_conn.createStatement();
            if (archive_type.compareTo("ASE") == 0) {
                stmtArch.executeUpdate("set statement_cache off");
            }

            pstmtArch_insStmtStat.setInt(1,BootID);
            pstmtArch_insStmtStat.setInt(2,KPID);
            pstmtArch_insStmtStat.setInt(3,SPID);
            pstmtArch_insStmtStat.setInt(4,BatchID);
//System.out.println("StartTime="+StartTime.toString()  );
//                pstmtArch_insStmtStat.setTimestamp(5,StartTime);
            pstmtArch_insStmtStat.setString(5,StartTime.toString());
//System.out.println("sampleTime="+sampleTime.toString()  );
//                pstmtArch_insStmtStat.setTimestamp(6,sampleTime);
            pstmtArch_insStmtStat.setString(6,sampleTime.toString());
            pstmtArch_insStmtStat.setString(7,ExactStat);
            pstmtArch_insStmtStat.setString(8,Login);
            pstmtArch_insStmtStat.setString(9,Application);
            pstmtArch_insStmtStat.setString(10,ClientHost);
            pstmtArch_insStmtStat.setString(11,ClientIP);
            pstmtArch_insStmtStat.setString(12,ClientOSPID);
            pstmtArch_insStmtStat.setInt(13,DBID);

            if (ProcName == null) 
                pstmtArch_insStmtStat.setNull(14,java.sql.Types.VARCHAR);
            else {
                if (ProcName.length() <=30)
                    pstmtArch_insStmtStat.setString(14,ProcName);
                else {
                    if (msrv.version < 1500) {
                        pstmtArch_insStmtStat.setString(14,ProcName.substring(0, 30));  
                    }
                    else {
                        if (ProcName.length() <= 255)
                            pstmtArch_insStmtStat.setString(14,ProcName);
                        else
                            pstmtArch_insStmtStat.setString(14,ProcName.substring(0, 255));
                    }
                }
            }

            pstmtArch_insStmtStat.setInt(15,PlanID);
            pstmtArch_insStmtStat.setInt(16,ContextID);
            pstmtArch_insStmtStat.setInt(17,LineNumber);
            pstmtArch_insStmtStat.setInt(18,CpuTime);
            pstmtArch_insStmtStat.setInt(19,WaitTime);
            pstmtArch_insStmtStat.setInt(20,MemUsageKB);
            pstmtArch_insStmtStat.setLong(21,PhysicalReads);
            pstmtArch_insStmtStat.setLong(22,LogicalReads);
            pstmtArch_insStmtStat.setLong(23,PagesModified);
            pstmtArch_insStmtStat.setInt(24,PacketsSent);
            pstmtArch_insStmtStat.setInt(25,PacketsReceived);
            pstmtArch_insStmtStat.setInt(26,NetworkPacketSize);
            pstmtArch_insStmtStat.setInt(27,PlansAltered);
            pstmtArch_insStmtStat.setInt(28,RowsAffected);

            if (SQLHashKey_to_save == null)
                pstmtArch_insStmtStat.setNull(29,java.sql.Types.DECIMAL);
            else
                pstmtArch_insStmtStat.setBigDecimal(29,SQLHashKey_to_save);

            if (PLANHashKey == null)
                pstmtArch_insStmtStat.setNull(30,java.sql.Types.DECIMAL);
            else
                pstmtArch_insStmtStat.setBigDecimal(30,PLANHashKey);

            if (tran_name == null)
                pstmtArch_insStmtStat.setNull(31,java.sql.Types.VARCHAR);
            else
                pstmtArch_insStmtStat.setString(31,tran_name);

            int numcol = 31;
            if (clientInfoCols.length()>0) {
                if(ClientName==null)
                    pstmtArch_insStmtStat.setNull(++numcol,java.sql.Types.VARCHAR);
                else
                    pstmtArch_insStmtStat.setString(++numcol,ClientName);

                if(ClientHostName==null)
                    pstmtArch_insStmtStat.setNull(++numcol,java.sql.Types.VARCHAR);
                else
                    pstmtArch_insStmtStat.setString(++numcol,ClientHostName);

                if(ClientApplName==null)
                    pstmtArch_insStmtStat.setNull(++numcol,java.sql.Types.VARCHAR);
                else
                    pstmtArch_insStmtStat.setString(++numcol,ClientApplName);
            }
            
            if (colV16SP03.length() > 0) {
                pstmtArch_insStmtStat.setInt(++numcol, SnapCodegenTime);
                pstmtArch_insStmtStat.setInt(++numcol, SnapJITTime);
                pstmtArch_insStmtStat.setInt(++numcol, SnapExecutionTime);
                pstmtArch_insStmtStat.setInt(++numcol, SnapExecutionCount);
                pstmtArch_insStmtStat.setLong(++numcol, QueryOptimizationTime);
            }

            if (V15cols.length() > 0) {
                if (ProcNestLevel==null)
                    pstmtArch_insStmtStat.setNull(++numcol,java.sql.Types.INTEGER);
                else
                    pstmtArch_insStmtStat.setInt(++numcol, ProcNestLevel.intValue() );
                if (StatementNumber==null)
                    pstmtArch_insStmtStat.setNull(++numcol,java.sql.Types.INTEGER);
                else
                    pstmtArch_insStmtStat.setInt(++numcol, StatementNumber.intValue() );
            }


            try {
                pstmtArch_insStmtStat.executeUpdate();
                ResultSet rs = stmtArch.executeQuery("select @@identity");
                rs.next();
                StmtID=rs.getBigDecimal(1);
                totalRowsInserted++;
                if (archive_type.compareTo("ASE") == 0) {
                    try {
                        stmtArch.executeUpdate("set statement_cache on");
                    }
                    catch (SQLException sqle){
                        if (sqle.getErrorCode()!=11761)  // Ignore error "SET STATEMENT_CACHE ON can only be executed when the ASE configuration option 'statement cache size' is greater than 0."
                           throw sqle;
                    }
                }
                stmtArch.close();
                pstmtArch_insStmtStat.close();
                // set the BULK COPY mode if activated on this connection
                aArchCnx.setBulkLoad();
                DEBUG(DBG104, "Stmt : " + System.identityHashCode(this)+ " Save stmt stats. StmtID="+StmtID+" KPID="+KPID+" SPID="+SPID+" BatchID="+BatchID+" LineNumber="+LineNumber+" Application="+Application+" ClientHost="+ClientHost+" rows inserted=1");

            }
            catch (SQLException sqle) {
                DEBUG(DBG104,"Stmt : " + System.identityHashCode(this)+ " SaveStmtStat ARCH ERROR : "+sqle.getErrorCode()+" "+sqle.getMessage());
                AsemonSQLException asemonEx = new AsemonSQLException(sqle.getMessage(), sqle.getSQLState(), sqle.getErrorCode(), "ARCH", srvName+"_StmtStat");
                //if (sqle.getErrorCode() == 1622) {
                    // Erreur "type xx is not implemented"
                    aArchCnx.archive_conn.close();
                    //msrv.monSrvConn.close();
                    // Print parameters for this failing INSERT 
                    Asemon_logger.printmess("BootID                : "+BootID);               
                    Asemon_logger.printmess("KPID                  : "+KPID);                 
                    Asemon_logger.printmess("SPID                  : "+SPID);                 
                    Asemon_logger.printmess("BatchID               : "+BatchID);              
                    Asemon_logger.printmess("StartTime             : "+StartTime.toString()); 
                    Asemon_logger.printmess("sampleTime            : "+sampleTime.toString());
                    Asemon_logger.printmess("ExactStat             : "+ExactStat);            
                    Asemon_logger.printmess("Login                 : "+Login);                
                    Asemon_logger.printmess("Application           : "+Application);          
                    Asemon_logger.printmess("ClientHost            : "+ClientHost);           
                    Asemon_logger.printmess("ClientIP              : "+ClientIP);             
                    Asemon_logger.printmess("ClientOSPID           : "+ClientOSPID);          
                    Asemon_logger.printmess("DBID                  : "+DBID);                 
                    Asemon_logger.printmess("ProcName              : "+ProcName);             
                    Asemon_logger.printmess("PlanID                : "+PlanID);               
                    Asemon_logger.printmess("ContextID             : "+ContextID);            
                    Asemon_logger.printmess("LineNumber            : "+LineNumber);           
                    Asemon_logger.printmess("CpuTime               : "+CpuTime);              
                    Asemon_logger.printmess("WaitTime              : "+WaitTime);             
                    Asemon_logger.printmess("MemUsageKB            : "+MemUsageKB);           
                    Asemon_logger.printmess("PhysicalReads         : "+PhysicalReads);        
                    Asemon_logger.printmess("LogicalReads          : "+LogicalReads);         
                    Asemon_logger.printmess("PagesModified         : "+PagesModified);        
                    Asemon_logger.printmess("PacketsSent           : "+PacketsSent);          
                    Asemon_logger.printmess("PacketsReceived       : "+PacketsReceived);      
                    Asemon_logger.printmess("NetworkPacketSize     : "+NetworkPacketSize);    
                    Asemon_logger.printmess("PlansAltered          : "+PlansAltered);         
                    Asemon_logger.printmess("RowsAffected          : "+RowsAffected);         
                    Asemon_logger.printmess("SQLHashKey            : "+SQLHashKey_to_save);           
                    Asemon_logger.printmess("PLANHashKey           : "+PLANHashKey);          
                    Asemon_logger.printmess("tran_name             : "+tran_name);          

                    if (clientInfoCols.length()>0) {
                    Asemon_logger.printmess("ClientName            : "+ClientName);    
                    Asemon_logger.printmess("ClientHostName        : "+ClientHostName);
                    Asemon_logger.printmess("ClientApplName        : "+ClientApplName);
                    }

                    if (colV16SP03.length() > 0) {
                    Asemon_logger.printmess("SnapCodegenTime       : "+SnapCodegenTime);      
                    Asemon_logger.printmess("SnapJITTime           : "+SnapJITTime);          
                    Asemon_logger.printmess("SnapExecutionTime     : "+SnapExecutionTime);    
                    Asemon_logger.printmess("SnapExecutionCount    : "+SnapExecutionCount);   
                    Asemon_logger.printmess("QueryOptimizationTime : "+QueryOptimizationTime);
                    }

                    if (V15cols.length() > 0) {
                    Asemon_logger.printmess("ProcNestLevel         : "+ProcNestLevel );  
                    Asemon_logger.printmess("StatementNumber       : "+StatementNumber );
                    }
                //}
                //else {
                //    aArchCnx.archive_conn.rollback();
                //    aArchCnx.archive_conn.setAutoCommit(true);            
                //}
                throw asemonEx;
            }
        }

        private void saveStmtSQL(CnxMgr.ArchCnx aArchCnx) throws Exception {
            RowOfSqlText arowOfSQLText;
            if ( (batchOfSQLText == null) && (SQLText_to_save == "") ) 
                // No data to save, exit...
                return;

            if (SQLTextSaved)
                // already saved for a previous statement having same SPID, KPID, BatchID
                return;

            Timestamp newTime =  new Timestamp(System.currentTimeMillis() + msrv.timeAdjust.value());
            
            // Save parametrized SQL if required
            if ( Asemon_logger.ArchiveSQLHK) {
                // Check if this HashKey already exist in list of saved SQL 
                if ( ! SQLHashKey_seen.containsKey(SQLHashKey_to_save)) {
                    try {
                        // Commit work already done. It seems duplicate key with BULK LOAD rollback all work, not only statements generating dup key
                        DEBUG(DBG104,"Stmt : " + System.identityHashCode(this)+ " commit before saving StmtSQLHK");
                        aArchCnx.archive_conn.commit();
//                        aArchCnx.unsetBulkLoad();  // seems to work OK with V16

                        int strlen = SQLText_to_save.length();
                        int begindex = 0;
                        int endindex;
                        int sequence = 1;
                        PreparedStatement pstmtArch_insStmtSQLHK = aArchCnx.archive_conn.prepareStatement(
                                "insert into "+srvName+"_StmtSQLHK (Timestamp, SQLHashKey, Sequence, SQLText) values (?, ?, ?, ?)");

                        while (begindex < strlen) {
                            pstmtArch_insStmtSQLHK.setTimestamp(1, newTime);
                            pstmtArch_insStmtSQLHK.setBigDecimal (2, SQLHashKey_to_save);
                            pstmtArch_insStmtSQLHK.setInt ( 3, sequence);
                            endindex=begindex+255;
                            if (endindex>strlen)
                                endindex = strlen;               
                            pstmtArch_insStmtSQLHK.setString(4, SQLText_to_save.substring(begindex, endindex));
                            begindex = endindex;
                            sequence ++;
                            pstmtArch_insStmtSQLHK.addBatch();
                        }
                        try {
                            pstmtArch_insStmtSQLHK.executeBatch();
                            // Push this HashKey in the cache of HashKey already seen
                            SQLHashKey_seen.put(SQLHashKey_to_save, null);
                            totalRowsInserted += sequence-1;
                            DEBUG(DBG104, "Stmt : " + System.identityHashCode(this)+ " Save SQL in StmtSQLHK. SQLHashKey="+SQLHashKey_to_save+" rows inserted="+ (sequence-1));
                        }
                        catch (SQLException sqle) {
                            if ( (sqle.getErrorCode()==2601) || (sqle.getSQLState()=="JZ0BE") ) {
                                // Duplicate key, this HashKey already exists
                                // 2601 for ASE
                                // JZ0BE for IQ
                                // Push this HashKey in the cache of HashKey already seen
                                SQLHashKey_seen.put(SQLHashKey_to_save, null);
                                DEBUG(DBG104, "Stmt : " + System.identityHashCode(this)+ " Save SQL in StmtSQLHK. SQLHashKey="+SQLHashKey_to_save+" already exists in table. Skipping");
                                aArchCnx.archive_conn.rollback();
                            }
                            else 
                                throw sqle;
                        }
                        finally {
//                            aArchCnx.setBulkLoad();
                            pstmtArch_insStmtSQLHK.close();
                        }
                    }
                    catch(SQLException sqle) {
                        DEBUG(DBG104,"Stmt : " + System.identityHashCode(this)+ " BatchOfSQLText ARCH ERROR : "+sqle.getErrorCode()+" "+sqle.getMessage());
                        AsemonSQLException asemonEx = new AsemonSQLException(sqle.getMessage(), sqle.getSQLState(), sqle.getErrorCode(), "ARCH", srvName+"_StmtSQLHK");
                        if (sqle.getErrorCode() == 1622) {
                            // Erreur "type xx is not implemented"
                            aArchCnx.archive_conn.close();
                            msrv.monSrvConn.close();
                        }
                        else {
                            aArchCnx.archive_conn.rollback();
                            aArchCnx.archive_conn.setAutoCommit(true);
                        }
                        throw asemonEx;
                    }
                }
                else {
                    // Next two instructions to make the SQLHashKey_seen list a MRU list
                    SQLHashKey_seen.remove(SQLHashKey_to_save);
                    SQLHashKey_seen.put(SQLHashKey_to_save, null);
                    DEBUG(DBG104, "Stmt : " + System.identityHashCode(this)+ " Save SQL in StmtSQLHK. SQLHashKey="+SQLHashKey_to_save+" already in cache. Skip insert.");
                }

            }
           
            // Save original SQL if required
            if ( ( ! Asemon_logger.skipArchiveSQL) && (batchOfSQLText != null) ) {
                StringBuffer insSql;
                PreparedStatement pstmtArch;

                // Added (for test) before insert into IQ with RLV store
                aArchCnx.archive_conn.commit();   // Added for IQ when archived on IQ

                try {
                    insSql = new StringBuffer("insert into "+srvName+"_StmtSQL (Timestamp, BootID, KPID, SPID, BatchID, LineNumber, SequenceInLine, SQLText, SQLHashKey) values (");
                    insSql = insSql.append("?");
                    insSql = insSql.append(",?");
                    insSql = insSql.append(",?");
                    insSql = insSql.append(",?");
                    insSql = insSql.append(",?");
                    insSql = insSql.append(",?");
                    insSql = insSql.append(",?");
                    insSql = insSql.append(",?");
                    insSql = insSql.append(",?");
                    insSql = insSql.append(")");

                    pstmtArch = aArchCnx.archive_conn.prepareStatement(insSql.toString());

                    Iterator<RowOfSqlText> itersqltext = batchOfSQLText.rows.iterator();
                    while (itersqltext.hasNext()) {
                        arowOfSQLText = (RowOfSqlText) itersqltext.next();
                        pstmtArch.setTimestamp(1,arowOfSQLText.ts);
                        pstmtArch.setInt(2,BootID);
                        pstmtArch.setInt(3,KPID);
                        pstmtArch.setInt(4,SPID);
                        pstmtArch.setInt(5,BatchID);
                        if (arowOfSQLText.LineNumber == -1)
                            pstmtArch.setNull(6, java.sql.Types.INTEGER);
                        else
                            pstmtArch.setInt(6,arowOfSQLText.LineNumber);
                        pstmtArch.setInt(7,arowOfSQLText.SequenceInLine);
                        pstmtArch.setString(8,arowOfSQLText.SQLText);
                        if (SQLHashKey_to_save != null)
                            pstmtArch.setBigDecimal(9,SQLHashKey_to_save);
                        else
                            pstmtArch.setNull(9, java.sql.Types.DECIMAL);
                        pstmtArch.addBatch();
                        DEBUG(DBG104, "Stmt : " + System.identityHashCode(this)+ " Prepare save SQL in StmtSQL. KPID="+KPID+" SPID="+SPID+" BatchID="+BatchID+" LineNumber="+arowOfSQLText.LineNumber+" SequenceInLine="+arowOfSQLText.SequenceInLine+" SQL="+arowOfSQLText.SQLText.substring(0, (arowOfSQLText.SQLText.length() < 100)?arowOfSQLText.SQLText.length():100).replaceAll("\n", " ").replaceAll("\r", " "));
                    }
                    pstmtArch.executeBatch();
                    pstmtArch.close();
                    totalRowsInserted+=batchOfSQLText.rows.size();
                    DEBUG(DBG104, "Stmt : " + System.identityHashCode(this)+ " Save SQL in StmtSQL. KPID="+KPID+" SPID="+SPID+" BatchID="+BatchID+" SQLHashKey="+SQLHashKey_to_save+" rows inserted="+ batchOfSQLText.rows.size());
                    if ( (Asemon_logger.archive_type.equalsIgnoreCase("IQ")) && 
                          ( ((Archive_IQ)(Asemon_logger.archive_class)).isRLVConfigured("StmtSQL", sav_collector)) ) {
                       Statement stmtArch = aArchCnx.archive_conn.createStatement();
                       if (Asemon_logger.forceIQMerge) stmtArch.executeUpdate("sp_iqmergerlvstore 'BLOCKING', '"+srvName+"_StmtSQL'");
                       stmtArch.close();
                    }
                }
                catch (SQLException sqle) {
                    DEBUG(DBG104,"Stmt : " + System.identityHashCode(this)+ " BatchOfSQLText ARCH ERROR : "+sqle.getErrorCode()+" "+sqle.getMessage());
                    AsemonSQLException asemonEx = new AsemonSQLException(sqle.getMessage(), sqle.getSQLState(), sqle.getErrorCode(), "ARCH", srvName+"_StmtSQL");
                    if (sqle.getErrorCode() == 1622) {
                            // Erreur "type xx is not implemented"
                            aArchCnx.archive_conn.close();
                            msrv.monSrvConn.close();
                    }
                    else {
                        aArchCnx.archive_conn.rollback();
                        aArchCnx.archive_conn.setAutoCommit(true);
                    }
                    throw asemonEx;
                }
            }
            SQLTextSaved = true;
           
        }        
        
        private void saveStmtObj (CnxMgr.ArchCnx aArchCnx) throws Exception {
            StringBuffer sql;
            PreparedStatement pstmtArch;
            RowOfProcessObjects aprocessObject;
            if (processObjects != null) {
                sql = new StringBuffer("insert into "+srvName+"_StmtObj (" +
                    "StmtID" +
                    ",DBName" +
                    ",OwnerUserID" +
                    ",ObjectName" +
                    ",ObjectType" +
                    ",IndexID" +
                    ",LogicalReads" +
                    ",PhysicalReads" +
                    ",PhysicalAPFReads");
                if (msrv.version < 1500) {
                    sql.append(",TableSize");
                }
                else {
                    sql.append(",PartitionSize" +
                               ",PartitionID" +
                               ",PartitionName" +
                               ",IdxName");
                }
                sql.append(") values (");
                sql = sql.append("?");
                sql = sql.append(",?");
                sql = sql.append(",?");
                sql = sql.append(",?");
                sql = sql.append(",?");
                sql = sql.append(",?");
                sql = sql.append(",?");
                sql = sql.append(",?");
                sql = sql.append(",?");
                sql = sql.append(",?");
                if (msrv.version >= 1500) {
                    sql = sql.append(",?");
                    sql = sql.append(",?");
                    sql = sql.append(",?");
                }
                sql = sql.append(")");
            
                try {
                    pstmtArch = aArchCnx.archive_conn.prepareStatement(sql.toString());
                    
                    Iterator<RowOfProcessObjects> iterprocessObject = processObjects.iterator();
                    while (iterprocessObject.hasNext()) {
                        aprocessObject = (RowOfProcessObjects) iterprocessObject.next();
                    
                        pstmtArch.setBigDecimal(1,StmtID);
                        pstmtArch.setString(2,aprocessObject.DBName);
                        pstmtArch.setInt(3,aprocessObject.OwnerUserID);
                        pstmtArch.setString(4,aprocessObject.ObjectName);
                        pstmtArch.setString(5,aprocessObject.ObjectType);
                        pstmtArch.setInt(6,aprocessObject.IndexID);
                        pstmtArch.setLong(7,aprocessObject.LogicalReads);
                        pstmtArch.setInt(8,aprocessObject.PhysicalReads);
                        pstmtArch.setInt(9,aprocessObject.PhysicalAPFReads);
                        if (msrv.version < 1500) {
                            pstmtArch.setInt(10,aprocessObject.TableSize);
                        }
                        else {
                            pstmtArch.setInt(10,aprocessObject.PartitionSize);
                            pstmtArch.setInt(11,aprocessObject.PartitionID);
                            pstmtArch.setString(12,aprocessObject.PartitionName);         
                            pstmtArch.setString(13,aprocessObject.IdxName);         
                        }
                        pstmtArch.addBatch();
                    }
                    totalRowsInserted+=processObjects.size();
                    pstmtArch.executeBatch();
                    aArchCnx.archive_conn.commit();   // Added for IQ when archived on IQ
                    pstmtArch.close();
                    DEBUG(DBG104, "Stmt : " + System.identityHashCode(this)+ " Save obj for StmtID="+StmtID+" rows inserted="+processObjects.size());
                    if ( (Asemon_logger.archive_type.equalsIgnoreCase("IQ")) && 
                           ( ((Archive_IQ)(Asemon_logger.archive_class)).isRLVConfigured("StmtObj", sav_collector)) ) {
                       Statement stmtArch = aArchCnx.archive_conn.createStatement();
                       if (Asemon_logger.forceIQMerge) stmtArch.executeUpdate("exec sp_iqmergerlvstore 'BLOCKING', '"+srvName+"_StmtObj'; commit;");
                       stmtArch.close();
                    }
                }
                catch (SQLException sqle) {                  
                    DEBUG(DBG104,"Stmt : " + System.identityHashCode(this)+ " saveStmtObj ARCH ERROR : "+sqle.getErrorCode()+" "+sqle.getMessage());
                    AsemonSQLException asemonEx = new AsemonSQLException(sqle.getMessage(), sqle.getSQLState(), sqle.getErrorCode(), "ARCH", srvName+"_StmtObj");
                    if (sqle.getErrorCode() == 1622) {
                        // Erreur "type xx is not implemented"
                        aArchCnx.archive_conn.close();
                        msrv.monSrvConn.close();
                    }
                    else {
                        aArchCnx.archive_conn.rollback();
                        aArchCnx.archive_conn.setAutoCommit(true);
                    }
                    throw asemonEx;
                }
            
            }
        }

        private void saveStmtPlnHK (CnxMgr.ArchCnx aArchCnx) throws Exception {
            String aPlanLine;
            int sequence=0;         
            Timestamp newTime= new Timestamp(System.currentTimeMillis() + msrv.timeAdjust.value());
            if (SQLPlan != null) {
                if (!PLANHashKey_seen.containsKey(PLANHashKey)) {
                    String sql = "insert into "+srvName+"_StmtPlnHK (Timestamp, PLANHashKey, Sequence, SQLPlan) values (?, ?, ?, ?)";
                    try {
//                        aArchCnx.unsetBulkLoad(); // Seems to work OK with V16

                        PreparedStatement pstmtArch_insStmtPlnHK = aArchCnx.archive_conn.prepareStatement(sql.toString());

                        // Commit work already done. It seems duplicate key with BULK LOAD rollback all work, not only statements generating dup key
                        DEBUG(DBG104,"Stmt : " + System.identityHashCode(this)+ " commit");
                        aArchCnx.archive_conn.commit();

                        Iterator<String> iterplan = SQLPlan.iterator();
                        while (iterplan.hasNext()) {
                            aPlanLine = (String) iterplan.next();
                            //System.out.println(aPlanLine);
                            sequence+=1;
                            pstmtArch_insStmtPlnHK.setTimestamp(1,newTime);
                            pstmtArch_insStmtPlnHK.setBigDecimal(2,PLANHashKey);
                            pstmtArch_insStmtPlnHK.setInt(3,sequence);
                            pstmtArch_insStmtPlnHK.setString(4,aPlanLine);
                            pstmtArch_insStmtPlnHK.addBatch();
                        }
                        try {
                            pstmtArch_insStmtPlnHK.executeBatch();
                            PLANHashKey_seen.put(PLANHashKey, null);
                            totalRowsInserted+=SQLPlan.size();
                            DEBUG(DBG104, "Stmt : " + System.identityHashCode(this)+ " Save stmt plan in StmtPlnHK. PLANHashKey="+PLANHashKey+" rows inserted="+SQLPlan.size());
                        }
                        catch (SQLException sqle) {
                            if ( (sqle.getErrorCode()==2601) || (sqle.getSQLState()=="JZ0BE") ) {
                                // Duplicate key, this HashKey already exists
                                // 2601 for ASE
                                // JZ0BE for IQ
                                // Push this HashKey in the cache of HashKey already seen
                                PLANHashKey_seen.put(PLANHashKey, null);
                                DEBUG(DBG104, "Stmt : " + System.identityHashCode(this)+ " Save stmt plan in StmtPlnHK. PLANHashKey="+PLANHashKey+" already exists in table. Skipping");
                                aArchCnx.archive_conn.rollback();
                            }
                        }
                        finally {
//                            aArchCnx.setBulkLoad();
                            pstmtArch_insStmtPlnHK.close();
                        }


                        if ( (Asemon_logger.archive_type.equalsIgnoreCase("IQ")) && 
                                ( ((Archive_IQ)(Asemon_logger.archive_class)).isRLVConfigured("StmtPlnHK", sav_collector)) ) {
                            Statement stmtArch = aArchCnx.archive_conn.createStatement();
                            if (Asemon_logger.forceIQMerge) stmtArch.executeUpdate("sp_iqmergerlvstore 'BLOCKING', '"+srvName+"_StmtPlnHK'");
                            stmtArch.close();
                        }
                    }
                    catch (SQLException sqle) {
                        DEBUG(DBG104, "Stmt : " + System.identityHashCode(this)+ " saveStmtPlnHK ARCH ERROR : "+sqle.getErrorCode()+" "+sqle.getMessage());
                        AsemonSQLException asemonEx = new AsemonSQLException(sqle.getMessage(), sqle.getSQLState(), sqle.getErrorCode(), "ARCH", srvName+"_StmtPlnHK");
                        if (sqle.getErrorCode() == 1622) {
                            // Erreur "type xx is not implemented"
                            aArchCnx.archive_conn.close();
                            msrv.monSrvConn.close();
                        }
                        else {
                            aArchCnx.archive_conn.rollback();
                            aArchCnx.archive_conn.setAutoCommit(true);
                        }
                        throw asemonEx;
                    }

                }
                else {
                    // Next two instructions to make the PLANHashKey_seen list a MRU list
                    PLANHashKey_seen.remove(PLANHashKey);
                    PLANHashKey_seen.put(PLANHashKey, null);
                    DEBUG(DBG104, "Stmt : " + System.identityHashCode(this)+ " Save stmt plan. PLANHashKey="+PLANHashKey+" already in cache. Skip insert.");
                }
            }
        }
        
        
        
        private void chooseWhich_SQLText_to_save () {
            
            if ( (SQLText_From_showplan != "") &&( Asemon_logger.ArchiveSQLHK) ) {
                SQLText_to_save = SQLText_From_showplan;
                SQLHashKey_to_save = SQLHashKey_SQLText_From_showplan;
                DEBUG(DBG104, "Stmt : " + System.identityHashCode(this)+ " chooseWhich_SQLText_to_save : SQLText_From_showplan. SQLHashKey_to_save : " + SQLHashKey_to_save);
            }
            else {
                if (batchOfSQLText!=null) {
                    SQLText_to_save = batchOfSQLText.SQLTextBatch;
                    SQLHashKey_to_save = batchOfSQLText.SQLnormalizedHK;
                    DEBUG(DBG104, "Stmt : " + System.identityHashCode(this)+ " chooseWhich_SQLText_to_save : batchOfSQLText.SQLTextBatch. SQLHashKey_to_save : " + SQLHashKey_to_save);
                }
                else {
                    SQLText_to_save = "";
                    SQLHashKey_to_save=null;
                    DEBUG(DBG104, "Stmt : " + System.identityHashCode(this)+ " chooseWhich_SQLText_to_save : null. SQLHashKey_to_save : " + SQLHashKey_to_save);
                }
            }
        }


    }




    public void getMetrics () throws Exception {
        DEBUG(DBG104,"Start getMetrics");
        totalRowsInserted = 0;  // Used to count number of rows inserted in archive database
        archRows = -1 ; // Real number of rows inserted in archive database. -1 in case of error or missing config params
        
        int KPID;
        int SPID;
        int DBID;
        int ProcedureID;
        String ProcName, ProcName_in_tempdb, ProcName_in_procs;
        int PlanID;
        int BatchID;
        int ContextID;
        int LineNumber;
        int CpuTime;
        int WaitTime;
        int MemUsageKB;
        long PhysicalReads;
        long LogicalReads;
        long PagesModified;
        int PacketsSent;
        int PacketsReceived;
        int NetworkPacketSize;
        int PlansAltered;
        int RowsAffected;
        Integer ProcNestLevel;
        Integer StatementNumber;
        int   SnapCodegenTime      = 0 ;
        int   SnapJITTime          = 0 ;
        int   SnapExecutionTime    = 0 ;
        int   SnapExecutionCount   = 0 ;
        long  QueryOptimizationTime= 0 ;
        
        
        Timestamp StartTime;
        Timestamp NewTime;
        String Login;
        String Application;
        String ClientHost;
        String ClientIP;
        String ClientOSPID;
        String ClientName;
        String ClientHostName;
        String ClientApplName;
        
        Statement stmt=null;
        
        Vector<RunningStmt> newStmt = null;
        
        archCnxActiveTime = 0;
        archCnxWaitTime = 0;
        
        if (msrv.monSrvConn == null) return;
        //    System.out.println ("\nEnter getMonSQL\n");
        try {
            
            // Get list of accessible databases (needed for object_name function
            accessibleDBs = CollectorGeneric.getAccessibleDBs(msrv);
            
            if (stmt == null) stmt = msrv.monSrvConn.createStatement();
            
            
            // Initialize collection of terminated statements
            terminatedStmts =  (HashSet<CollectorMonSQL.RunningStmt>)currentRunningStmts.clone();
            DEBUG(DBG111, "TerminatedStmts = currentRunningStmts = " + System.identityHashCode(currentRunningStmts));
            
            
            
            // Get info on high logical reads running statements
            ResultSet rs;
            String sql_getProcessStatement;
            // ATTENTION : RowsAffected exists since V12.5.4
            if (msrv.version < 1254) {
                sql_getProcessStatement =
                " select getdate(), KPID, SPID, DBID, ProcedureID, " +
                "ProcName=case when ProcedureID <0 then convert(varchar,ProcedureID) else (case when DBID in "+accessibleDBs+" then  object_name(ProcedureID,DBID) else convert(varchar,ProcedureID) end) end," +
                "ProcName_in_tempdb=object_name(ProcedureID,2), " +
                "ProcName_in_procs=object_name(ProcedureID,db_id('sybsystemprocs')), " +
                "PlanID,BatchID,ContextID,LineNumber, CpuTime,WaitTime,MemUsageKB,PhysicalReads, LogicalReads, PagesModified,PacketsSent, PacketsReceived, NetworkPacketSize, PlansAltered,StartTime from master..monProcessStatement where  DBID!=3 and (LogicalReads >= "+ String.valueOf(min_logical_reads)+") or (datediff(ss, StartTime, getdate()) >= "+ String.valueOf(min_elapsed_time_ms/1000)   +")"
                ;
            }
            else if (msrv.version < 1550) {
                sql_getProcessStatement= 
                "select getdate(), KPID, SPID, DBID, ProcedureID, " +
                "ProcName=case when ProcedureID <0 then convert(varchar,ProcedureID) else (case when DBID in "+accessibleDBs+" then  object_name(ProcedureID,DBID) else convert(varchar,ProcedureID) end) end," +
                "ProcName_in_tempdb=object_name(ProcedureID,2), " +
                "ProcName_in_procs=object_name(ProcedureID,db_id('sybsystemprocs')), " +
                "PlanID,BatchID,ContextID,LineNumber, CpuTime,WaitTime,MemUsageKB,PhysicalReads, LogicalReads, PagesModified,PacketsSent, PacketsReceived, NetworkPacketSize, PlansAltered,StartTime,RowsAffected from master..monProcessStatement where DBID!=3 and  (LogicalReads >= "+ String.valueOf(min_logical_reads)+") or (case when datediff(dd,StartTime,getdate()) > 20 then convert(float,86400000)*datediff(dd,StartTime,getdate()) else datediff(ms,StartTime,getdate())  end >= "+ String.valueOf(min_elapsed_time_ms) + ")"
                ;
            } else { 
                sql_getProcessStatement= 
                "select getdate(), KPID, SPID, DBID, ProcedureID, " +
                "ProcName=case when ProcedureID <0 then convert(varchar,ProcedureID) else (case when DBID in "+accessibleDBs+" then  object_name(ProcedureID,DBID) else convert(varchar,ProcedureID) end) end," +
                "ProcName_in_tempdb=object_name(ProcedureID,2), " +
                "ProcName_in_procs=object_name(ProcedureID,db_id('sybsystemprocs')), " +
                "PlanID,BatchID,ContextID,LineNumber, CpuTime,WaitTime,MemUsageKB,PhysicalReads, LogicalReads=case when CpuTime >0 then case when LogicalReads/CpuTime > 1000 then 0 else LogicalReads end else LogicalReads end, PagesModified,PacketsSent, PacketsReceived, NetworkPacketSize, PlansAltered,StartTime,RowsAffected from master..monProcessStatement where DBID!=3 and (case when CpuTime >0 then case when LogicalReads/CpuTime > 1000 then 0 else LogicalReads end else LogicalReads end >= "+ String.valueOf(min_logical_reads)+") or (datediff(ms, convert(BIGDATETIME,StartTime), convert(BIGDATETIME,getdate()) ) >= "+ String.valueOf(min_elapsed_time_ms) + ")"
                ;
            }             
            if (msrv.sbssav.compareTo("16.0.03.00") >= 0){
                sql_getProcessStatement= 
                "select getdate(), KPID, SPID, DBID, ProcedureID, " +
                "ProcName=case when ProcedureID <0 then convert(varchar,ProcedureID) else (case when DBID in "+accessibleDBs+" then  object_name(ProcedureID,DBID) else convert(varchar,ProcedureID) end) end," +
                "ProcName_in_tempdb=object_name(ProcedureID,2), " +
                "ProcName_in_procs=object_name(ProcedureID,db_id('sybsystemprocs')), " +
                "PlanID,BatchID,ContextID,LineNumber, CpuTime,WaitTime,MemUsageKB,PhysicalReads, LogicalReads=case when CpuTime >0 then case when LogicalReads/CpuTime > 1000 then 0 else LogicalReads end else LogicalReads end, PagesModified,PacketsSent, PacketsReceived, NetworkPacketSize, PlansAltered,StartTime,RowsAffected, " +
                "SnapCodegenTime, SnapJITTime, SnapExecutionTime, SnapExecutionCount, QueryOptimizationTime "     +
                "from master..monProcessStatement where DBID!=3 and (case when CpuTime >0 then case when LogicalReads/CpuTime > 1000 then 0 else LogicalReads end else LogicalReads end >= "+ String.valueOf(min_logical_reads)+") or (datediff(ms, convert(BIGDATETIME,StartTime), convert(BIGDATETIME,getdate()) ) >= "+ String.valueOf(min_elapsed_time_ms) + ")"
                ;
                
            }    
            rs = stmt.executeQuery(sql_getProcessStatement);
                
            // loop on these running statements
            while (rs.next()) {
                NewTime = rs.getTimestamp(1);
                KPID = rs.getInt(2);
                SPID = rs.getInt(3);
                DBID = rs.getInt(4);
                ProcedureID = rs.getInt(5);
                ProcName = rs.getString(6);
                ProcName_in_tempdb = rs.getString(7);
                ProcName_in_procs = rs.getString(8);
                PlanID = rs.getInt(9);
                BatchID = rs.getInt(10);
                ContextID = rs.getInt(11);
                LineNumber = rs.getInt(12);
                CpuTime = rs.getInt(13);
                WaitTime = rs.getInt(14);
                MemUsageKB = rs.getInt(15);
                PhysicalReads = rs.getLong(16);
                LogicalReads = rs.getLong(17);
                PagesModified = rs.getLong(18);
                PacketsSent = rs.getInt(19);
                PacketsReceived = rs.getInt(20);
                NetworkPacketSize = rs.getInt(21);
                PlansAltered = rs.getInt(22);
                StartTime = rs.getTimestamp(23);
                if (msrv.version < 1254)
                    RowsAffected = -1;
                else
                    RowsAffected = rs.getInt(24);
                if (msrv.sbssav.compareTo("16.0.03.00") >= 0){
                    SnapCodegenTime = rs.getInt(25);       
                    SnapJITTime = rs.getInt(26);           
                    SnapExecutionTime = rs.getInt(27);     
                    SnapExecutionCount = rs.getInt(28);    
                    QueryOptimizationTime = rs.getLong(29);
                
                }
                
                // Get good ProcName
                ProcName = choose_ProcName (ProcName, ProcName_in_tempdb, ProcName_in_procs);
                
    //            System.out.println("Open : KPID="+KPID+" BatchID="+BatchID+" ProcName="+ProcName+" LineNumber="+LineNumber+" LogicalReads="+LogicalReads+" SPID="+SPID+"\n");
                
                
                // Check if statement has already be seen
                RunningStmt aStmt = findARunningStmt (SPID, KPID, BatchID, ProcedureID, LineNumber);
                if ( aStmt != null ) {
                    // statement already seen;  remove this statement from list of terminated statement (since not yet terminated)
                    terminatedStmts.remove(aStmt);
                }
                else {
                    // Statement never captured; generate statement object
                    aStmt = new RunningStmt();
                    
                    // save this statement in the list of currently running  statements
                    currentRunningStmts.add( aStmt  );
                    DEBUG(DBG111, "Stmt : " + System.identityHashCode(aStmt)+" Add in currentRunningStmts");
                    
                    // save this statement in the list of new statements
                    if (newStmt == null) newStmt=new Vector<RunningStmt>();
                    newStmt.add(aStmt);
                }
                
                // update values for this statement
                aStmt.setValues(
                    NewTime,
                    currentBootID,
                    KPID,            
                    SPID ,           
                    DBID  , 
                    ProcedureID,         
                    ProcName ,       
                    PlanID  ,        
                    BatchID ,        
                    ContextID,       
                    LineNumber,      
                    CpuTime  ,       
                    WaitTime ,       
                    MemUsageKB,      
                    PhysicalReads,   
                    LogicalReads ,   
                    PagesModified,   
                    PacketsSent,     
                    PacketsReceived, 
                    NetworkPacketSize,
                    PlansAltered,    
                    StartTime,
                    "N",              // exactStat = N in this case     
                    RowsAffected,
                    null,
                    null,
                    SnapCodegenTime,
                    SnapJITTime,
                    SnapExecutionTime,
                    SnapExecutionCount,
                    QueryOptimizationTime
                );
            
            }  // End loop on running statements
            //System.out.println("Nb curr statements : "+currentRunningStmts.size());
            
            RunningStmt aStmt;     // temporary variable used to work on a statement
            
            // Manage new statements
            if (newStmt != null) {
                Iterator iterNewStmt = newStmt.iterator();
                while ( iterNewStmt.hasNext() ) {
                    aStmt = (RunningStmt) iterNewStmt.next();
                    aStmt.retreiveSQLTextandLookup();
                    aStmt.retreivePlan();
                    aStmt.retreiveProcInfo();
                }
            }
            
            // Remove terminated statement from list of running statements
            if (!terminatedStmts.isEmpty() ) {
                Iterator<RunningStmt> iterEndedStmt = (Iterator<RunningStmt>) terminatedStmts.iterator();
                RunningStmt aTerminatedStmt;
                while ( iterEndedStmt.hasNext() ) {
                    aTerminatedStmt=iterEndedStmt.next();
                    // Remove this statement from current list of open statements
                    currentRunningStmts.remove(aTerminatedStmt);
                    DEBUG(DBG111, "Stmt : " + System.identityHashCode(aTerminatedStmt)+" Remove from currentRunningStmts");
                
                }
            }
            
            // Loop on all running statements to retreive objects statistics
            if (!Asemon_logger.skipRetreiveProcessObject) {
                Iterator iterAllCurStmt = currentRunningStmts.iterator();
                while ( iterAllCurStmt.hasNext() ) {
                    aStmt = (RunningStmt) iterAllCurStmt.next();
                    aStmt.retreiveProcessObjects();     
                }
            }
        
            // Get captured statements in "statement PIPE" and associated SQL in "SQL PIPE"
            // Theses statements can be new statements not yet captured by polling monProcessStatement, or already captured by polling and seen finished or not
            
            if (msrv.statementPipeActive && msrv.sqlTextPipeActive) {
                // Remark : this request needs 2 temp tables because we cannot join PIPE tables
                // ATTENTION : RowsAffected exists since V12.5.4
                String RowsAffectedStr;
                if (msrv.version < 1254)
                   RowsAffectedStr = "";
                else
                   RowsAffectedStr = ",RowsAffected";
            
                String selV15cols = "";
                if (msrv.version >= 1500)
                    selV15cols = ", ProcNestLevel, StatementNumber";
            
                String selClientInfo = "";
                if (msrv.version >= 1570)
                    selClientInfo = ",ClientName, ClientHostName, ClientApplName";
            
                String selColV16SP03 = "";
                if (msrv.sbssav.compareTo("16.0.03.00") >= 0)
                    selColV16SP03 = ",SnapCodegenTime, SnapJITTime, SnapExecutionTime, SnapExecutionCount, QueryOptimizationTime";
            
                // just in case temp tables still exists
                stmt.executeUpdate(
                    "if object_id('#stmt') != null exec ('drop table #stmt')" +
                    "if object_id('#sqltext') != null exec ('drop table #sqltext')"
                );
            
                String sQuery;
                sQuery =
                "set nocount on " +
                "select KPID, SPID, BatchID, ProcedureID, LineNumber, StartTime, EndTime, DBID,PlanID,ContextID, CpuTime,WaitTime,MemUsageKB,PhysicalReads, LogicalReads, PagesModified,PacketsSent, PacketsReceived, NetworkPacketSize, PlansAltered" +
                RowsAffectedStr +
                selV15cols +
                selColV16SP03 +
                "\n into #stmt" +
                "\n from master..monSysStatement"+
                "\n where LogicalReads >= " + String.valueOf(min_logical_reads) +
                "\n and  StartTime > '" + time_of_last_stmt_seen +"'" +         // After a restart of the connection, avoid selecting statements already captured by previous connection
                "\n select KPID, SPID, BatchID, SequenceInBatch, SQLText" +
                "\n into #sqltext" +
                "\n from master..monSysSQLText" +
            
                "\n select A.KPID, A.SPID, BatchID, ProcedureID, LineNumber, " +
                "\n ProcName=case when ProcedureID <0 then convert(varchar,ProcedureID) else (case when DBID in "+accessibleDBs+" then  object_name(ProcedureID,DBID) else convert(varchar,ProcedureID) end) end," +
                "\n ProcName_in_tempdb=object_name(ProcedureID,2), " +
                "\n ProcName_in_procs=object_name(ProcedureID,db_id('sybsystemprocs')), " +
                "\n StartTime, EndTime, DBID, PlanID,ContextID, "+
                "\n CpuTime,WaitTime,MemUsageKB,PhysicalReads, LogicalReads, PagesModified,PacketsSent, PacketsReceived, NetworkPacketSize, PlansAltered" +
                "\n ,Login, Application, ClientHost, ClientIP, ClientOSPID" + RowsAffectedStr + selV15cols + selClientInfo + selColV16SP03 +
                "\n from #stmt A left outer join master..monProcessLookup B on A.KPID=B.KPID and A.SPID =B.SPID";
            
                if (msrv.version >= 1500)
                sQuery += "\n plan '( m_join ( sort ( t_scan ( table ( A #stmt ) ) ) ) ( sort ( t_scan ( table ( B [master..monProcessLookup] ) ) ) ) ) '";
            
                sQuery += "\n select getdate(), A.KPID, A.SPID, A.BatchID , SequenceInBatch, SQLText" +
                "\n from #sqltext A  where exists (select 1 from #stmt B where A.KPID = B.KPID and A.SPID = B.SPID and A.BatchID = B.BatchID)" +
                "\n order by A.SPID, A.KPID, A.BatchID, A.SequenceInBatch" +
            
                "\n drop table #stmt" +
                "\n drop table #sqltext" +
                "\n set nocount off" ;

                if (stmt == null) stmt.close(); // For cleaning statement, just in case...
                stmt = msrv.monSrvConn.createStatement();

                boolean ignore_results_from_monSysxxx=false;
                try {
                    rs = stmt.executeQuery(sQuery);
                }
                catch (SQLException sqlEx){
                    int err = sqlEx.getErrorCode();
                    if ((err==12036)||(err==12052)) {
                        // 12036 : Incomplete configuration on instance ID %d. Collection of monitoring data for table '%.*s' requires that the %s configuration option(s) be enabled. To set the necessary configuration, contact a user who has the System Administrator (SA) role.
                        // 12052 : Collection of monitoring data for table '%.*s' requires that the %s configuration option(s) be enabled. To set the necessary configuration, contact a user who has the System Administrator (SA) role.
                        //Asemon_logger.DEBUG("Error="+sqlEx.getErrorCode()+" SQL message="+sqlEx.getMessage());
                        ignore_results_from_monSysxxx = true;
                    }
                    else {
                        ERROR(sqlEx.getMessage());
                        ignore_results_from_monSysxxx = true;
                    }
                }
            
                if (!ignore_results_from_monSysxxx) {
                    // loop on these captured ended statements
                    int colnum;
                    while (rs.next()) {
                        KPID = rs.getInt(1);
                        SPID = rs.getInt(2);
                        BatchID = rs.getInt(3);
                        ProcedureID = rs.getInt(4);
                        LineNumber = rs.getInt(5);
                        ProcName = rs.getString(6);
                        ProcName_in_tempdb = rs.getString(7);
                        ProcName_in_procs = rs.getString(8);
                        StartTime = rs.getTimestamp(9);
                        NewTime = rs.getTimestamp(10);
                        DBID = rs.getInt(11);
                        PlanID = rs.getInt(12);
                        ContextID = rs.getInt(13);
                        CpuTime = rs.getInt(14);
                        WaitTime = rs.getInt(15);
                        MemUsageKB = rs.getInt(16);
                        PhysicalReads = rs.getLong(17);
                        LogicalReads = rs.getLong(18);
                        PagesModified = rs.getLong(19);
                        PacketsSent = rs.getInt(20);
                        PacketsReceived = rs.getInt(21);
                        NetworkPacketSize = rs.getInt(22);
                        PlansAltered = rs.getInt(23);
                        Login = rs.getString(24);
                        Application = rs.getString(25);
                        ClientHost = rs.getString(26);
                        ClientIP= rs.getString(27);
                        ClientOSPID = rs.getString(28);
                        colnum = 28;
                        if (msrv.version < 1254)
                           RowsAffected = -1;
                        else {
                           RowsAffected = rs.getInt(++colnum);
                        }
            
                        if (msrv.version < 1500) {
                           ProcNestLevel = null;
                           StatementNumber = null;
                        }
                        else {
                           ProcNestLevel = new Integer(rs.getInt(++colnum)); 
                           StatementNumber = new Integer(rs.getInt(++colnum)); 
                        }
            
            
            
                        if (msrv.version < 1570) {
                           ClientName = null;
                           ClientHostName = null;
                           ClientApplName = null;
                        }
                        else {
                           ClientName = rs.getString(++colnum);
                           ClientHostName = rs.getString(++colnum);
                           ClientApplName = rs.getString(++colnum);
                        }
                        if (msrv.sbssav.compareTo("16.0.03.00") >= 0) {
                             SnapCodegenTime = rs.getInt(++colnum);       
                             SnapJITTime = rs.getInt(++colnum);           
                             SnapExecutionTime = rs.getInt(++colnum);     
                             SnapExecutionCount = rs.getInt(++colnum);    
                             QueryOptimizationTime = rs.getLong(++colnum);
                        }
            
                        // Get good ProcName
                        ProcName = choose_ProcName (ProcName, ProcName_in_tempdb, ProcName_in_procs);
            
                        DEBUG(DBG111, "Found data in monSysStatement for SPID=" + SPID + " KPID="+KPID+ " BatchID="+BatchID+" LineNumber="+LineNumber);
                        // Check if this statement is in the Terminated Stmt list
                        aStmt = findATerminatedStmt (SPID, KPID, BatchID, ProcedureID, LineNumber);
                        if ( aStmt == null ) {
                            // Not found in terminated stmt
                            // Check if this statement is still in the Running Stmt list
                            aStmt = findARunningStmt (SPID, KPID, BatchID, ProcedureID, LineNumber);
                            if ( aStmt != null ) {
                                // statement already seen; now it is terminated (since in the monSysStatement PIPE)
                                // reinsert this statement in the finished statement list if already removed
                                if ( !terminatedStmts.contains(aStmt) ) {
                                     terminatedStmts.add(aStmt);
                                     // Remove this statement from current list of open statements
                                     currentRunningStmts.remove(aStmt);
                                }
                                DEBUG(DBG111, "Stmt : " + System.identityHashCode(aStmt)+" Already seen, for SPID=" + SPID + " KPID="+KPID+ " BatchID="+BatchID+" LineNumber="+LineNumber);
                            }
                            else {
                                // This statement was never captured, 
                                DEBUG(DBG111, "Stmt new. SPID=" + SPID + " KPID="+KPID+ " BatchID="+BatchID+" LineNumber="+LineNumber);
                                if (similarStatementExists(SPID, KPID, BatchID, StartTime)) {
                                    // A Running or Terminated Statement with same SPID, KPID, BatchID and a very close Startime has been captured
                                    // This situation occurs when a stored proc executes an immediate SQL (execute (...) )
                                    // So this stmt captured in monSysStatement must be ignored to avoid to duplicate statistics for same statement
                                    DEBUG(DBG111, "Stmt ignored (CloseStatementExists) SPID=" + SPID + " KPID="+KPID+ " BatchID="+BatchID);
                                    continue;
                                }
                                else {
                                    // add it to the list of terminated statements
                                    aStmt = new RunningStmt();
                                    terminatedStmts.add(aStmt);
                                    DEBUG(DBG111, "Stmt : " + System.identityHashCode(aStmt)+" Added to terminated stmt, for SPID=" + SPID + " KPID="+KPID+ " BatchID="+BatchID+" LineNumber="+LineNumber);
                                }
                            }
                        }
                        else
                            DEBUG(DBG111, "Stmt : " + System.identityHashCode(aStmt)+" Already seen, for SPID=" + SPID + " KPID="+KPID+ " BatchID="+BatchID+" LineNumber="+LineNumber);

                        // update in memory statistics for this statement
                        aStmt.setValues(
                             NewTime,
                             currentBootID,
                             KPID,            
                             SPID ,           
                             DBID  , 
                             ProcedureID,         
                             ProcName ,       
                             PlanID  ,        
                             BatchID ,        
                             ContextID,       
                             LineNumber,      
                             CpuTime  ,       
                             WaitTime ,       
                             MemUsageKB,      
                             PhysicalReads,   
                             LogicalReads ,   
                             PagesModified,   
                             PacketsSent,     
                             PacketsReceived, 
                             NetworkPacketSize,
                             PlansAltered,    
                             StartTime,
                             "Y",           // exactStat = Y in this case  since from the master..monSysStatement PIPE   
                             RowsAffected,
                             ProcNestLevel,
                             StatementNumber,
                             SnapCodegenTime,
                             SnapJITTime,
                             SnapExecutionTime,
                             SnapExecutionCount,
                             QueryOptimizationTime
                        );
                        aStmt.setLookupValues (Login, Application, ClientHost, ClientIP, ClientOSPID, ClientName,ClientHostName, ClientApplName);
            
                    } // End loop on captured statements from master..monSysStatement
            
                    // step to the SQLText result set                     
                    while (stmt.getMoreResults() || stmt.getUpdateCount()!=-1) {
                        rs = stmt.getResultSet();
                        // Check if SQL Text can be retreived
                        int previousSPID=-1;
                        int previousKPID=-1;
                        int previousBatchID=-1;
                        BatchOfSQLText aBatch=null;
                        RowOfSqlText aRow=null;
                        if (!Asemon_logger.skipRetreiveSQLText) {
                            while (rs.next()) {
                                KPID = rs.getInt(2);
                                SPID = rs.getInt(3);
                                BatchID = rs.getInt(4);
                                if ( (SPID != previousSPID) || (KPID != previousKPID) || (BatchID != previousBatchID) ) {
                                    if (previousSPID != -1) {
                                        // Find if any terminated or running stmt use this batch
                                        DEBUG(DBG111, "Found SQLText from monSysSQLText.  : SPID=" + aBatch.SPID + " KPID="+aBatch.KPID+ " BatchID="+aBatch.BatchID);
                                        aBatch.attachToStmt();
                                        if (! aBatch.attached) {
                                            aBatch.clear();
                                            aBatch = null;
                                        }
                                    }
                                    previousSPID = SPID;
                                    previousKPID = KPID;
                                    previousBatchID = BatchID;
                                    aBatch = new BatchOfSQLText (SPID, KPID, BatchID);

                                }
                                aRow = new RowOfSqlText();
                                aRow.ts = rs.getTimestamp(1);
                                aRow.LineNumber = -1;
                                aRow.SequenceInLine = rs.getInt(5);
                                aRow.SQLText = rs.getString(6);
                                aBatch.addRow(aRow);
                            }
                            if (aBatch != null) {
                                // Manage last batch
                                // Find if any terminated or running stmt use this batch
                                DEBUG(DBG111, "Found SQLText from monSysSQLText.  : SPID=" + aBatch.SPID + " KPID="+aBatch.KPID+ " BatchID="+aBatch.BatchID);
                                aBatch.attachToStmt();
                                if (! aBatch.attached) {
                                    aBatch.clear();
                                    aBatch = null;
                                }
                            }

                        }
                        else {
                           // read the stream to skip
                           while (rs.next()) {}
                        }// End if !Asemon_logger.skipRetreiveSQLText
                    }
                } // End if (!ignore_results_from_monSysxxx)
            } // End if (Asemon_logger.statementPipeActive||Asemon_logger.sqlTextPipeActive)
            
            
            // Manage ended statements
            
            if (!terminatedStmts.isEmpty() ) {
                Iterator<RunningStmt> iterEndedStmt = (Iterator<RunningStmt>) terminatedStmts.iterator();
                RunningStmt aTerminatedStmt;
                
                // Get an archive connection from the pool
                CnxMgr.ArchCnx aArchCnx = CnxMgr.archCnxPool.getArchCnx(false);
                archCnxWaitTime += aArchCnx.waitedFor;
                try {
                    //System.out.println("Nb terminated statements : "+terminatedStmt.size());
                    while ( iterEndedStmt.hasNext() ) {
                       aTerminatedStmt=iterEndedStmt.next();

                        // Check if statement is a compiled statement. If yes get XMLPlan
                        if ( (aTerminatedStmt.ProcedureID != 0) && (aTerminatedStmt.PlanID != 0) )
                            aTerminatedStmt.retreiveXMLPlan();
                

                        //System.out.println("Terminated : KPID="+aTerminatedStmt.KPID+" BatchID="+aTerminatedStmt.BatchID+" LineNumber="+aTerminatedStmt.LineNumber+" LogicalReads="+aTerminatedStmt.LogicalReads+"\n");
                        aArchCnx.archive_conn.setAutoCommit(false);
                        aTerminatedStmt.chooseWhich_SQLText_to_save();
                        aTerminatedStmt.saveStmtStat(aArchCnx);
                        aTerminatedStmt.saveStmtSQL(aArchCnx);
                        aTerminatedStmt.saveStmtObj(aArchCnx);
                        aTerminatedStmt.saveStmtPlnHK(aArchCnx);
                        aTerminatedStmt.saveXMLPlan(aArchCnx);
                        DEBUG(DBG104,"Stmt : " + System.identityHashCode(aTerminatedStmt)+ " commit at end of MonSQL");
                        aArchCnx.archive_conn.commit();
                        aArchCnx.archive_conn.setAutoCommit(true);
                
                        // Remove all plan lines
                        if (aTerminatedStmt.SQLPlan != null) {
                            aTerminatedStmt.SQLPlan.removeAllElements();
                            aTerminatedStmt.SQLPlan=null;
                        }
                        // Remove all obj statistics
                        if (aTerminatedStmt.processObjects != null) {
                            aTerminatedStmt.processObjects.removeAllElements();
                            aTerminatedStmt.processObjects=null;
                        }
                        // Remove all SQL Text
                        if (aTerminatedStmt.batchOfSQLText != null) {
                            aTerminatedStmt.batchOfSQLText.clear();
                            aTerminatedStmt.batchOfSQLText = null;
                            aTerminatedStmt.SQLPlan=null;
                        }

                        // Remove XML Plan
                        if (aTerminatedStmt.xmlinfo != null) {
                            aTerminatedStmt.xmlinfo = null;
                            aTerminatedStmt.xmlInfoTimestamp = null;
                        }

                    }
                }
                catch (Exception e) {
                    throw e;
                }
                finally {
                    // should have been committed before, but, for safe
                    try {
                        aArchCnx.archive_conn.commit();
                        aArchCnx.archive_conn.setAutoCommit(true);
                    }
                    catch(Exception e) {}
                   
                   // Return archive connection to the pool
                   archCnxActiveTime +=  CnxMgr.archCnxPool.putArchCnx(aArchCnx);
                }
            }
        }
        catch (SQLException sqle){
            if (sqle.getErrorCode()==12052)
                // Ignore error "Collection of monitoring data for table 'monProcessStatement' requires that the 'per object ...
                return;
            else throw sqle;
        }
        catch (Exception e) {
             //System.out.println("Asemon_logger.getSQL. : "+e);
             //e.printStackTrace(System.out);
            throw e;
        }
        
        archRows = totalRowsInserted;
        DEBUG(DBG104,"End getMetrics. Nb rows inserted = "+totalRowsInserted);
    } 


}
/*
* <p>Archive_IQ</p>
* <p>Copyright: Jean-Paul Martin (jpmartin@sybase.com) Copyright (c) 2015</p>
* Class to manage interface with a IQ archive database
* @version 3.2.5
 */
package asemon_logger;

import com.sybase.jdbcx.SybConnection;
import java.sql.*;
import java.util.*;

public class Archive_IQ implements Archive_interface {

      public boolean connect_archive_SRV (CnxMgr.ArchCnx aArchServCnx, boolean nowait) {
      aArchServCnx.archive_conn = null; // Force reopen of the connection if not completely cleared last time it was used
      boolean verbose=true;
      boolean displayErrors = true;
      if (Asemon_logger.archive_server!=null) {

          while (aArchServCnx.archive_conn == null)  {
              aArchServCnx.archive_conn = (SybConnection)CnxMgr.connectSRV(Asemon_logger.archive_user, Asemon_logger.archive_server, "", Asemon_logger.archive_charset, "For archive server '"+Asemon_logger.archive_server+"', user '"+Asemon_logger.archive_user+"' - ", verbose, "asemon_arch", Asemon_logger.archive_useKerberos, displayErrors, Asemon_logger.archive_packet_size, Asemon_logger.archive_useSSL, Asemon_logger.archive_address, "IQ", Asemon_logger.archive_aseUserStoreKey);
              if (aArchServCnx.archive_conn==null) {
                  if (nowait) return false;
                  if (displayErrors)
                      Asemon_logger.printmess("Trying to reconnect to archive server every 10 s ...");
                  try {
                    java.lang.Thread.sleep(10000);  // wait 10 s before retrying
                    displayErrors = false;
                    verbose=false;
                  }
                  catch (Exception e) {}
              }
          }

          try {
              Statement stmt = aArchServCnx.archive_conn.createStatement();
              ResultSet rs=stmt.executeQuery("select substring(@@version, 1, charindex('/', @@version)-1)");
              rs.next();
              String product= rs.getString(1);
              String archive_DBMS;
              if ((product.equalsIgnoreCase("SYBASE IQ"))||(product.equalsIgnoreCase("SAP IQ"))) {
                  archive_DBMS = "IQ";
                  rs=stmt.executeQuery(
                        "select substring("+
                           "substring(@@version,charindex ('/',@@version)+1, datalength(@@version)),"+
                           "1, "+
                           "charindex ('/',substring(@@version,charindex ('/',@@version)+1, datalength(@@version)))-1"+
                        ")"
                   );
                  rs.next();
                  Asemon_logger.archive_sbssav = rs.getString(1);
              }
              else
                  archive_DBMS = "ASE";
              stmt.close();
              if (archive_DBMS.compareToIgnoreCase(Asemon_logger.archive_type)!=0) {
                  Asemon_logger.printmess("ERROR : archive DBMS is not what is configured in the config file : '"+Asemon_logger.archive_type+"'");
                  return false;
              }

          }
          catch (Exception e) {
              e.printStackTrace(System.out);
          }

          Asemon_logger.printmess ("Connected to archive server : "+ Asemon_logger.archive_server + " Database : " + Asemon_logger.archive_base  + " IQ Version : " + Asemon_logger.archive_sbssav);

          try {
              Statement stmt = aArchServCnx.archive_conn.createStatement();
              stmt.executeUpdate("SET TEMPORARY OPTION SNAPSHOT_VERSIONING = 'Row-level';");
//              stmt.executeUpdate("SET TEMPORARY OPTION SNAPSHOT_VERSIONING = 'table-level';");
              stmt.executeUpdate("SET TEMPORARY OPTION QUOTED_IDENTIFIER = 'ON';");
              stmt.executeUpdate("SET TEMPORARY OPTION BLOCKING = 'ON';");
              return true;
          }
          catch (Exception e) {
              System.out.println(e.getMessage());
              e.printStackTrace(System.out);
          }

          try {
              Statement stmt = aArchServCnx.archive_conn.createStatement();
              int len = Asemon_logger.config_file.length();
              int start, end;
              if (len > 30) {start=len-30; end=len;}
              else {start=0; end=len-1;}
              stmt.executeUpdate("set clientapplname '"+Asemon_logger.config_file.substring(start, end)+"'");
              stmt.executeUpdate("set quoted_identifier on");
              stmt.close();
          }
          catch (Exception e) {
              e.printStackTrace(System.out);
          }
      }
      return true;
    }

    public boolean connect_archive_SRV_asPurge (MonitoredSRV msrv, boolean printCnxMess, boolean nowait) {
      if (Asemon_logger.archive_server!=null) {
          msrv.purge_conn=null;
          boolean displayErrors=true;
          boolean verbose = printCnxMess;

          while (msrv.purge_conn==null) {
              msrv.purge_conn = CnxMgr.connectSRV(Asemon_logger.archive_user, Asemon_logger.archive_server, Asemon_logger.archive_base, Asemon_logger.archive_charset, "For archive server '"+Asemon_logger.archive_server+"', user '"+Asemon_logger.archive_user+"' - ", verbose, "asemon_purge", Asemon_logger.archive_useKerberos, displayErrors, Asemon_logger.archive_packet_size, Asemon_logger.archive_useSSL, Asemon_logger.archive_address, "IQ", Asemon_logger.archive_aseUserStoreKey);
              if (msrv.purge_conn==null) {
                  if (nowait) return false;
                  if (displayErrors)
                      Asemon_logger.printmess("Trying to reconnect to archive server every 10 s ...");
                  try {
                    java.lang.Thread.sleep(10000);  // wait 10 s before retrying
                    displayErrors = false;
                    verbose=false;
                  }
                  catch (Exception e) {}
              }
          }

          // Set options for blocking statements when an exclusive lock exist on a table
          try {
              Statement stmt = msrv.purge_conn.createStatement();
              stmt.executeUpdate("SET TEMPORARY OPTION SNAPSHOT_VERSIONING = 'Row-level';");
 //             stmt.executeUpdate("SET TEMPORARY OPTION SNAPSHOT_VERSIONING = 'table-level';");
              stmt.executeUpdate("SET TEMPORARY OPTION QUOTED_IDENTIFIER = 'ON';");
              stmt.executeUpdate("SET TEMPORARY OPTION BLOCKING = 'ON';");
              stmt.executeUpdate("set temporary option BLOCKING_TIMEOUT='60000'");
              return true;
          }
          catch (Exception e) {
              Asemon_logger.printmess("ERROR setting options : "+e.getMessage());
              e.printStackTrace(System.out);
          }

          if (printCnxMess)
              Asemon_logger.printmess ("Connected to archive server : "+ Asemon_logger.archive_server );
      }
      return true;
    }

    public boolean checkIfTableExists (String tabname, Statement stmt) throws Exception {
          ResultSet res = null;
          res = stmt.executeQuery("select name from sysobjects where name='"+tabname+"' and type='U'");
          if (!res.next()) return false; // No row returned for this query, so table doesn't exist
          else return true;
    }

    public boolean isRlvEnableInDb(String tabname, Statement stmt) throws Exception {
                  
        ResultSet rs = stmt.executeQuery("select I.is_rlv from systable T join sysiqtab I on T.table_id=I.table_id\n" +
                          "where T.creator=user_id() " +
                          " and T.table_name='"+tabname+"'");
        if (rs.next() == true) {
            String isRlv = rs.getString(1);
            if (isRlv.equalsIgnoreCase("T"))
                return true;
            else
                return false;
        }
        else {
            //Asemon_logger.printmess("ERROR in 'isRlvEnableInDb'. Table '"+tabname+"' does not exists");
            return false;
        }
    }
    
    public boolean isRLVConfigured (String tabname, Collector collector) {
      String prop_use_IQ_RLV = collector.metricDescriptor.parameters.getProperty("use_IQ_RLV");
      if (prop_use_IQ_RLV==null) prop_use_IQ_RLV="";
      if (prop_use_IQ_RLV.equalsIgnoreCase("YES")) prop_use_IQ_RLV="Y";
      if (prop_use_IQ_RLV.equalsIgnoreCase("NO")) prop_use_IQ_RLV="N";
      
      String coll_use_IQ_RLV = MetricDescriptor.useRLVstore(collector.metricDescriptor, tabname);
      if ( (coll_use_IQ_RLV != null)&& (coll_use_IQ_RLV.length()!=0)) 
          coll_use_IQ_RLV=coll_use_IQ_RLV.substring(0, 1).toUpperCase();
      
      // precedence : 
      // 1 : prop_use_IQ_RLV ( attribute in srv descriptor in config file)
      // 2 : MetricDescriptor (attribute in collector descriptor)
      // 3 : archive_use_IQ_RLV (<use_IQ_RLV>  in config file
      
      if (prop_use_IQ_RLV.equalsIgnoreCase("Y")) 
          return true;
      else if (prop_use_IQ_RLV.equalsIgnoreCase("N"))
          return false;
      else if (coll_use_IQ_RLV.equalsIgnoreCase("Y"))
          return true;
      else if (coll_use_IQ_RLV.equalsIgnoreCase("N"))
          return false;
      else if (Asemon_logger.archive_use_IQ_RLV)
          return true;
      else
          return false;
    }

    public void createArchiveTable (StringBuffer ct, Statement stmt) throws Exception {
    
        try {
          stmt.executeUpdate(ct.toString());
          System.out.println(ct);
        }
        catch (SQLWarning sqlw) {
          Asemon_logger.printmess ("initialize - Warning : "  + sqlw);
        }
        catch (SQLException sqlEx) {
          // Check if err is because table already exists
          switch (sqlEx.getErrorCode()) {
              case 12006 :
                  // yes, "ASA Error -110: Item 'WING3IQ_IQStatus' already exists""
                  break;
              default :
                  throw sqlEx;
          }
        }
    }
   
    public void grantRightsOnArchiveTable(String archiveTabName, String granteeList, Statement stmt) {
        try {
            stmt.executeUpdate("grant select on "+archiveTabName+" to " + granteeList);
        }
        catch (SQLException sqlEx) {
          Asemon_logger.printmess("Grant error. Error="+sqlEx.getErrorCode()+" SQL message="+sqlEx.getMessage());
          // not fatal error, continue
        }
    }
    
    
    // Create a table (postfixed with "_tmp") with the config structure, and compare the existing
    // table with this temp table. Automaticaly alter existing table
    // if missing columns
    // If collector has "ignore_dup_key" attribute set, this "_tmp" table is not dropped
    public Hashtable <String, ArchiveColumnDesc> checkAndAlterArchiveTable (StringBuffer ct, String tname, String archive_tname, Statement stmt, Collector collector) throws Exception {
      // This method get and compare structures of configured archive table (conf in config file)
      // and existing archive table. If different, add or modify columns
      Hashtable<String, ArchiveColumnDesc> confTabColList = new Hashtable<String, ArchiveColumnDesc>();
      Hashtable<String, ArchiveColumnDesc> archTabColList = new Hashtable<String, ArchiveColumnDesc>();
      ResultSet rs;

      int start = ct.indexOf("?SERVERNAME?_");
      int end = ct.indexOf("(");
      ct.replace(start , end, archive_tname+"_tmp ");

      try {
          // try dropping temp table if already exists
          stmt.executeUpdate("if object_id('"+archive_tname+"_tmp') is not NULL begin drop table "+archive_tname+ "_tmp end ");
          // create tmp table
          stmt.executeUpdate(ct.toString());
      }
      catch (SQLException sqlEx) {
          Asemon_logger.printmess("ERROR initializeMetric : err creating tmp table");
          throw sqlEx;
      }

      // get list and type of columns of config table
      try {
          rs=stmt.executeQuery("select column_name, C.domain_id, width, width, scale, case when nulls='N' then 0 else 1 end, domain_name " +
                  "from (syscolumn C join systab T on C.table_id=T.table_id) join sysdomain D on C.domain_id=D.domain_id "+
                  "where T.table_name='"+archive_tname+"_tmp' " +
                  "order by C.column_id");
      }
      catch(Exception e) {
          Asemon_logger.printmess("ERROR checkAndAlterArchiveTable : err getting syscolumns");
          throw e;
      }
      ArchiveColumnDesc aColumnDesc;
      while (rs.next()){
          aColumnDesc = new ArchiveColumnDesc(rs.getString(1).trim(), rs.getInt(2), rs.getInt(3), rs.getInt(4), rs.getInt(5), rs.getInt(6), rs.getString(7).trim());
          aColumnDesc.computeFullType();
          confTabColList.put(aColumnDesc.name, aColumnDesc);
      }

      // get list of column of existing archive table
      try {
          rs=stmt.executeQuery("select column_name, C.domain_id, width, width, scale, case when nulls='N' then 0 else 1 end, domain_name " +
                  "from (syscolumn C join systab T on C.table_id=T.table_id) join sysdomain D on C.domain_id=D.domain_id "+
                  "where T.table_name='"+archive_tname+"' " +
                  "order by column_id");
      }
      catch(Exception e) {
          Asemon_logger.printmess("ERROR checkAndAlterArchiveTable : err getting syscolumns");
          throw e;
      }
      while (rs.next()){
          aColumnDesc = new ArchiveColumnDesc(rs.getString(1).trim(), rs.getInt(2), rs.getInt(3), rs.getInt(4), rs.getInt(5), rs.getInt(6), rs.getString(7).trim());
          aColumnDesc.computeFullType();
          archTabColList.put(aColumnDesc.name, aColumnDesc);
      }

      // check if all config columns exist in the archive table
      // if not, alter archive table to add this col (as null)
      // or modify col if type, length or precision are differents
      Enumeration e = confTabColList.elements();
      ArchiveColumnDesc aConfigCol;
      ArchiveColumnDesc aExistingCol;
      String alterSQL=null;
      String newtype;
      while (e.hasMoreElements()){
          aConfigCol = (ArchiveColumnDesc)e.nextElement();
          if ( ! archTabColList.containsKey(aConfigCol.name)) {
              switch (aConfigCol.typename) {
                  case "varchar": 
                      newtype = "varchar ("+aConfigCol.length+")";
                      break;
                  case "integer": 
                      newtype = "integer";
                      break;
                  case "numeric": 
                      newtype = "numeric ("+aConfigCol.prec+","+aConfigCol.scale+")";
                      break;
                  case "smallint": 
                      newtype = "smallint";
                      break;
                  default: 
                      newtype = aConfigCol.fullType;
                      break;
              }
              alterSQL = "alter table " + archive_tname +" add [" + aConfigCol.name + "] " + newtype + " null";
              Asemon_logger.printmess("Modify archive table : " +alterSQL);
              stmt.executeUpdate(alterSQL.toString());
              Asemon_logger.printmess("Archive table modified");
          }
          else {
              aExistingCol = (ArchiveColumnDesc)archTabColList.get(aConfigCol.name);
              if ( ! aExistingCol.compareCol(aConfigCol)) {
                  // Columns are differents, alter existing column
                  // Altering a column is not supported on IQ !!!!!!!
                  /*
                  alterSQL = "alter table " + archive_tname +" modify [" + aConfigCol.name +"] "+ aConfigCol.fullType + " null";
                  Asemon_logger.printmess("Modify archive table : " +alterSQL);
                  stmt.executeUpdate(alterSQL.toString());
                  Asemon_logger.printmess("Archive table modified");
                  */
                  Asemon_logger.printmess("ERROR : cannot alter column '"+aConfigCol.name+"', current type="+aExistingCol.fullType+", new type="+aConfigCol.fullType);
                  Asemon_logger.printmess("This is not supported on IQ");
              }
          }
      }

      try {
          // try dropping tmp table if already exists
          stmt.executeUpdate("if object_id('"+archive_tname+"_tmp') is not NULL begin drop table "+archive_tname+ "_tmp end ");
      }
      catch (SQLException sqlEx) {
          Asemon_logger.printmess("ERROR initializeMetric : err dropping tmp table");
          throw sqlEx;
      }

      // Check if this table have "ignore_dup_key"
      if (MetricDescriptor.hasIgnoreDupKey(collector.metricDescriptor, tname)) {
          // Yes
          if (alterSQL != null) {
              // drop '_temp' table if already exist AND if collector's table was modified
              try {
                  stmt.executeUpdate("if object_id('"+archive_tname+"_temp') is not NULL begin drop table "+archive_tname+ "_temp end ");
              }
              catch (SQLException sqlEx) {
                  Asemon_logger.printmess("ERROR initializeMetric : err droping xxxx_temp table");
                  throw sqlEx;
              }
          }
          else {
              // create '_temp' table if doesn't exist
              try {

                  start = ct.indexOf("_tmp (");
                  end = start+6;
                  ct.replace(start , end, "_temp (");

                  stmt.executeUpdate("if object_id('"+archive_tname+"_temp') is NULL begin " + ct.toString() + " end");
              }
              catch (SQLException sqlEx) {
                  Asemon_logger.printmess("ERROR initializeMetric : err creating xxxx_temp table");
                  throw sqlEx;
              }
          }
      }


      // Check if this table should use RLV_store"
      if ( isRLVConfigured(tname, collector) ) {
          String tab;
          if (MetricDescriptor.hasIgnoreDupKey(collector.metricDescriptor, tname)) {
              // table has ignore_dup_key attribute. Set use_RLV_store on the XXXX_temp table
              tab = archive_tname+"_temp";
          }
          else {
              tab = archive_tname;
          }
          if (!isRlvEnableInDb(tab, stmt)) {
              // Table should be in RLV but RLV status not yet activated in DB
              try {
                  Asemon_logger.printmess("Enable RLV store for '"+tab+"'");
                  stmt.executeUpdate("alter table "+tab+" enable RLV STORE");
              }
              catch (SQLException sqlEx) {
                  Asemon_logger.printmess("ERROR initializeMetric : err setting 'enable RLV STORE' on '"+tab+"'");
                  throw sqlEx;
              }
          }
          else 
              Asemon_logger.printmess("RLV enable already set for '"+tab+"'");

      }
      else {
          if (isRlvEnableInDb(archive_tname, stmt)) {
              // Table should not be in RLV but RLV status is activated in DB
              try {
                  Asemon_logger.printmess("Disable RLV store for '"+archive_tname+"'");
                  stmt.executeUpdate("alter table "+archive_tname+" disable RLV STORE");
              }
              catch (SQLException sqlEx) {
                  int err=sqlEx.getErrorCode();
                  if (err==401) {
                      // Ignore error : Feature 'ALTER TABLE <catalog-store-table> ENABLE/DISABLE RLV STORE' not implemented
                  }
                  else {
                      Asemon_logger.printmess("ERROR initializeMetric : err setting 'disable RLV STORE' on '"+archive_tname+"'");
                      throw sqlEx;
                  }
              }
          }
          else
              Asemon_logger.printmess("RLV disable already set for '"+archive_tname+"'");
      }

      return confTabColList;
  }

    public void createIndex(String ci, Statement stmt) throws Exception {
                  
        // Don't check if the index already exists. If exists, it generates an error and ignore it
        try {
          stmt.executeUpdate(ci);
          System.out.println(ci);
        }
        catch (SQLException sqlEx) {
          // Check if err is because index already exists
          switch (sqlEx.getErrorCode()) {
              case 1921 :
                  // yes, "ASA Error -111: Index name 'idx' not unique"
                  break;
              default :
                  throw sqlEx;
          }
        }
    }
    public void saveValues (String archiveTabName, Archive_array archive_array, Collector collector) throws Exception {
        if (archive_array.nbrows() == 0) {
            collector.archRows = 0;
            return; // no row to insert
        }
        
        try {
            saveValues_exec (archiveTabName, archive_array, collector);
        }
        catch (SQLException sqle){
            // Check if deadlock
            if (sqle.getErrorCode()==1205) {
                  // Yes, deadlock
                  Asemon_logger.DEBUG ("Deadlock on table : '" + archiveTabName+"'");
                  java.lang.Thread.sleep (1000); // Wait 1 s before retry
                  // retry one time
                  saveValues (archiveTabName, archive_array, collector);
            }
            else if (sqle.getErrorCode()==3604) {
                      // Ignore this error
                }
                else {
                    AsemonSQLException asemonEx = new AsemonSQLException(sqle.getMessage(), sqle.getSQLState(), sqle.getErrorCode(), "ARCH", archiveTabName);
                    throw asemonEx;
                }
        }

    }

    public void saveValues_exec (String archiveTabName, Archive_array archive_array, Collector collector) throws Exception {
        // This new version of saveValues batches all insert statements in a same prepared statement
        // If the ENABLE_BULK_LOAD option is set on the connection, the driver then use the bulk insert method (faster than
        // insert by insert method)
        // Furthermore, with this new method, all inserts are in a single transaction (not the case in the older version of the method)

        String targetTable = archiveTabName;
        
        // Get an archive connection from the pool
        CnxMgr.ArchCnx aArchCnx = CnxMgr.archCnxPool.getArchCnx(false);
        collector.archCnxWaitTime = aArchCnx.waitedFor;
        
        // compute tname (without SERVERNAME)
        String tname = archiveTabName.substring(archiveTabName.lastIndexOf('_')+1,archiveTabName.length());
        Boolean hasIgnoreDupKey;
        String[] ignoreDupKeys=null;
        int nbRowsToInsert = 0;
        Statement stmtArch = null;
        PreparedStatement pstmtArch = null;
        

        try {
            stmtArch = aArchCnx.archive_conn.createStatement();
            // check if "ignore_dup_key" is set for this table
            // if YES, do inserts into "xxx_temp" table
            hasIgnoreDupKey = MetricDescriptor.hasIgnoreDupKey(collector.metricDescriptor, tname);
            if (hasIgnoreDupKey) {
                targetTable = archiveTabName+"_temp";

                // New for IQ16.1SP05
                stmtArch.executeUpdate("exec sp_iqmergerlvstore 'BLOCKING', '"+targetTable+"'; commit;");


                // truncate this temp table before inserting
                //stmtArch.execute("truncate table "+targetTable);
                // With IQ16.1 the truncate generates error "Table xxx requires an RLV store merge before table-level modification."
                // Do a DELETE
                stmtArch.execute("delete  "+targetTable+ " where 1=1"); // where 1=1 to avoid warning when deleting all rows
                stmtArch.executeUpdate("exec sp_iqmergerlvstore 'BLOCKING', '"+targetTable+"'; commit;");
                
                ignoreDupKeys = MetricDescriptor.getIgnoreDupKey(collector.metricDescriptor, tname).split(",");
            }

            
            // Prepare the SQL

            StringBuffer sql;
            String sep="";
            sql = new StringBuffer("insert into "+ targetTable + " (");
            // Prepare list of columns names
            for (int i=0; i < archive_array.nbcols(); i++) {
              sql.append(sep);
              sql.append('"'+archive_array.getColName(i)+'"');
              sep = ",";
            }
            sql.append(") values (");

            // Prepare list of question marks
            sep="";
            for (int i=0; i < archive_array.nbcols(); i++) {
              sql.append(sep);
              sql.append("?");
              sep = ",";
            }
            sql.append(")");

            pstmtArch = aArchCnx.archive_conn.prepareStatement(sql.toString());

            // Prepare the batch of statements
            aArchCnx.archive_conn.setAutoCommit(false);

            // Force DYNAMIC_PREPARE to false
            aArchCnx.archive_conn.setClientInfo("DYNAMIC_PREPARE", "FALSE");

            int nbRowsInBatch = 0; // Counter used when disableBulkLoad is set in order to limit number of rows inserted in a single batch
            for (int rowId=0; rowId < archive_array.nbrows(); rowId++) {
                // Get the row values
                Archive_array.Archive_row row = archive_array.getRow(rowId);

                // loop on all columns
                for (int col=0; col < row.cols.size(); col++) {

                  // Get the sql type of the column
                  int t = (Integer)archive_array.getColType(col);

                  // check if column is NULL
                  Object val = row.cols.get(col);
                  if (val == null) {
                      pstmtArch.setNull(col+1, t);
                      continue;
                  }

                  // Check if type is "bit". If Yes change it to char(1) since BULK LOAD does not support bit
                  if (t == java.sql.Types.BIT) {
                      boolean valBIT = ((Boolean)val).booleanValue();
                      String valChar;
                      if (valBIT == false) valChar="0";
                      else valChar="1";
                      t=java.sql.Types.VARCHAR;
                      val = valChar;
                  }

                  // set the column value according to its type
                  pstmtArch.setObject(col+1, val, t);
                }
                pstmtArch.addBatch();
                nbRowsToInsert++;
                nbRowsInBatch++;
                if ((Asemon_logger.disableBulkLoad) && (nbRowsInBatch>=1000)) {
                  pstmtArch.executeBatch();
                  nbRowsInBatch = 0; // reset counter
                }
            }

            // Execute the final batch
            pstmtArch.executeBatch();
            
            if (hasIgnoreDupKey) {
                StringBuffer join_clause = new StringBuffer();
                // prepare join_clause
                for (int i=0; i< ignoreDupKeys.length; i++) {
                    join_clause.append(" and " + archiveTabName + "."+ignoreDupKeys[i].trim()+"=" + targetTable + "."+ignoreDupKeys[i].trim());
                }
                // Delete existing rows
                Asemon_logger.DEBUG("delete " + targetTable + " where exists (select 1 from " + archiveTabName + " where 1=1 " + join_clause.toString() + ")");
                stmtArch.execute("delete " + targetTable + " where exists (select 1 from " + archiveTabName + " where 1=1 " + join_clause.toString() + ")");
                // Count left rows
                ResultSet rs = stmtArch.executeQuery("select count(*) from " + targetTable);
                rs.next();
                nbRowsToInsert = rs.getInt(1);
                // Insert left rows
                stmtArch.execute("insert into "+archiveTabName+ " select * from " + targetTable);

                // New for IQ16.1SP05
                stmtArch.executeUpdate("exec sp_iqmergerlvstore 'BLOCKING', '"+targetTable+"'; commit;");
                // truncate this temp table
                stmtArch.execute("truncate table " + targetTable);
            }
            if ( isRLVConfigured(tname, collector) ) {

                if (Asemon_logger.forceIQMerge) stmtArch.executeUpdate("sp_iqmergerlvstore 'BLOCKING', '"+targetTable+"'");
            }        
            
            collector.archRows = nbRowsToInsert;   // Save number of rows inserted in collector's variable
        }
        catch (Exception e) {
            if ((aArchCnx.archive_conn != null)&&(!aArchCnx.archive_conn.isClosed())) {
                aArchCnx.archive_conn.rollback();
            }
            throw e;
        }
        finally {
            if ((aArchCnx.archive_conn != null)&&(!aArchCnx.archive_conn.isClosed())) {
              aArchCnx.archive_conn.commit();
              aArchCnx.archive_conn.setAutoCommit(true);
              if (stmtArch!=null) stmtArch.close();
              if (pstmtArch!=null) pstmtArch.close();
            }
            
            // Return archive connection to the pool
            collector.archCnxActiveTime =  CnxMgr.archCnxPool.putArchCnx(aArchCnx);
        }
    }
    
    public void truncateTable (String archiveTabName, Collector collector) throws Exception {
        // Get an archive connection from the pool
        CnxMgr.ArchCnx aArchCnx = CnxMgr.archCnxPool.getArchCnx(false);
        collector.archCnxWaitTime = aArchCnx.waitedFor;
        Statement stmtArch = null;
        try {
            stmtArch = aArchCnx.archive_conn.createStatement();
            stmtArch.execute("truncate table "+archiveTabName);
        }
        finally {
            if ((aArchCnx.archive_conn != null)&&(!aArchCnx.archive_conn.isClosed())) {
              aArchCnx.archive_conn.commit();
              if (stmtArch!=null) stmtArch.close();              
            }
            // Return archive connection to the pool
            collector.archCnxActiveTime =  CnxMgr.archCnxPool.putArchCnx(aArchCnx);
        }
    }
    

}

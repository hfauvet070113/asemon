/**
* <p>CollectorCachedSQL</p>
* <p>Asemon_logger : class for retreiving SQL and PLAN of cached statements</p>
* <p>Copyright: Jean-Paul Martin (jpmartin@sybase.com) Copyright (c) 2004</p>
* @version 3.1.6b
*/

package asemon_logger;
import static asemon_logger.Asemon_logger.debugSwitchs;
import java.sql.*;
import java.util.*;

public class CollectorCachedSQL extends Collector {
  String srvName;
  String structName;
  int min_logical_reads;
  int min_usecount;

  Statement stmt;
  PreparedStatement pstmt;
  PreparedStatement pstmtArch;
  ResultSet rs;

  String sp_showplan_proc;

  int nbRowsToInsert;

  int bootcount;            // used to store the bootcount of the monitored server
  Vector <StatementDesc> currentListOfCachedStmt;

  Timestamp newTime;
  Long interval;
  
  class StatementDesc {
      int SSQLID;
      int Hashkey;
      Timestamp LastRecompiledDate;  // This field is ignored for the momemnt. Seems not OK on ASE 15.0.3

      StatementDesc (int aSSQLID,int aHashkey /*,Timestamp aLastRecompiledDate */) {
          SSQLID = aSSQLID;
          Hashkey = aHashkey;
          //LastRecompiledDate = aLastRecompiledDate;
      }
      void getAndSaveSQL (Collector aCollector) throws Exception {
          String aSQLText;
          boolean archiveInIQ = false;
          if (Asemon_logger.archive_type.equalsIgnoreCase("IQ")) archiveInIQ = true;
          rs = stmt.executeQuery("select show_cached_text("+SSQLID+")");
          newTime = new Timestamp(System.currentTimeMillis() + msrv.timeAdjust.value());
          // should retreive only one row
          Archive_array archive_array = new Archive_array();
          Archive_array.Archive_row aRow;

          archive_array.addColDef("Timestamp" , java.sql.Types.TIMESTAMP);  
          archive_array.addColDef("bootcount" , java.sql.Types.INTEGER  );   
          archive_array.addColDef("SSQLID"    , java.sql.Types.INTEGER  );   
          archive_array.addColDef("Hashkey"   , java.sql.Types.INTEGER  );
          if (archiveInIQ)
              archive_array.addColDef("SQLText"   , java.sql.Types.VARBINARY  );   
          else
              archive_array.addColDef("SQLText"   , java.sql.Types.VARCHAR  );

          while (rs.next()) {
              aRow = archive_array.allocateNewRow();
              aRow.addValue(newTime);
              aRow.addValue(bootcount);
              aRow.addValue(SSQLID);
              aRow.addValue(Hashkey);
              aSQLText = rs.getString(1);
              if (aSQLText==null)
                  continue;
              if (archiveInIQ) {
                  // When storing in IQ, compress the data because not all customers have the "Unstructured Data Analytics" option
                  aRow.addValue(Gzip.compress (aSQLText));
              }
              else
                  aRow.addValue(aSQLText);

              archive_array.addRow(aRow);         // save this row in the array
          }
          if (archive_array.nbrows() > 0) {
              // Save this array into archive database
              Asemon_logger.archive_class.saveValues (srvName+"_CachedSQL", archive_array, aCollector);
          }
     }

     void getAndSavePLAN (Collector aCollector) throws Exception {
          try {
              stmt.executeUpdate(sp_showplan_proc + " -1, "+SSQLID);
              newTime = new Timestamp(System.currentTimeMillis() + msrv.timeAdjust.value());
          }
          catch (SQLException sqlEx) {
              switch (sqlEx.getErrorCode()) {
                  case 19612 :
                      // Ignore message "Could not find a plan for the statement id 'xxxxx'."
                      break;
                  default :
                      throw sqlEx;
              }
          }

          SQLWarning sqlw=stmt.getWarnings();
          if (sqlw == null) {
              return;
          }

          Archive_array archive_array = new Archive_array();
          Archive_array.Archive_row aRow;

          archive_array.addColDef("Timestamp"  , java.sql.Types.TIMESTAMP);
          archive_array.addColDef("bootcount"  , java.sql.Types.INTEGER  );
          archive_array.addColDef("SSQLID"     , java.sql.Types.INTEGER  );
          archive_array.addColDef("Hashkey"    , java.sql.Types.INTEGER  );
          archive_array.addColDef("Sequence"   , java.sql.Types.SMALLINT );
          archive_array.addColDef("SQLPlan"    , java.sql.Types.VARCHAR  );
          
          short Sequence = 0;

          String msg;


          while (true) {

              msg=sqlw.getMessage();
              int err=sqlw.getErrorCode();
              String errs=sqlw.getSQLState();
              if ((err==0)&&(errs.equals("010P4"))) break;  // Ignore '010P4: Un parametre de sortie recu a ete ignore.'
              //System.out.println(sqlw.getErrorCode()+" " + sqlw.getSQLState()  +" "+msg.substring(0,msg.length()-1));
              // don't keep last char of message which is a linefeed
              if (msg.charAt(msg.length()-1)=='\n')
                  msg = msg.substring(0,msg.length()-1);

              aRow = archive_array.allocateNewRow();
              aRow.addValue(newTime);
              aRow.addValue(bootcount);
              aRow.addValue(SSQLID);
              aRow.addValue(Hashkey);
              //pstmtArch.setTimestamp(5,LastRecompiledDate);
              aRow.addValue(Sequence);
              aRow.addValue(msg);
              archive_array.addRow(aRow);         // save this row in the array
              Sequence++;


              sqlw=sqlw.getNextWarning();
              if (sqlw==null) break;
          }
          // Save this array into archive database
          Asemon_logger.archive_class.saveValues (srvName+"_CachedPLN", archive_array, aCollector);

      
    }
  }


   CollectorCachedSQL (MonitoredSRV ms, MetricDescriptor md) {
       super(ms, md);
       srvName = msrv.srvNormalized;
       structName = metricDescriptor.metricName;
  }
  

   void initialize ()  throws Exception {
      super.initialize();
      
      int cntgotcachedSQL = 0;
      // Retrieve option "min_logical_reads"
      String paramValue = metricDescriptor.parameters.getProperty("min_logical_reads");
      min_logical_reads = 10000;
      try {
          min_logical_reads = Integer.parseInt(paramValue);
      }
      catch (Exception e) {
          Asemon_logger.printmess ("ERROR CachedSQL : Bad min_logical_reads. Will use default value instead (10000)");
          min_logical_reads = 10000;
      }
      if (min_logical_reads <0) {
          Asemon_logger.printmess ("ERROR CachedSQL : min_logical_reads cannot be <0. Will use default value instead (10000)");
          min_logical_reads = 10000;
      }
      // Retrieve option "min_usecount"
      paramValue = metricDescriptor.parameters.getProperty("min_usecount");
      min_usecount = 10;
      try {
          min_usecount = Integer.parseInt(paramValue);
      }
      catch (Exception e) {
          Asemon_logger.printmess ("ERROR CachedSQL : Bad min_usecount. Will use default value instead (10)");
          min_usecount = 10000;
      }
      if (min_usecount <0) {
          Asemon_logger.printmess ("ERROR CachedSQL : min_usecount cannot be <0. Will use default value instead (10)");
          min_usecount = 10;
      }

      sp_showplan_proc = metricDescriptor.parameters.getProperty("sp_showplan_proc");
      if (msrv.sa_role==0) {
          if (Asemon_logger.skipSAProcs) sp_showplan_proc = null;
          else {
              // Retrieve option "sp_showplan_proc_non_sa"
              sp_showplan_proc = metricDescriptor.parameters.getProperty("sp_showplan_proc_non_sa");
              if (sp_showplan_proc == null) {
                  Exception e =new Exception("ERROR : sp_showplan_proc_non_sa not defined in collector config");
                  throw e;
              }
          }
      }
      try {
          // Create temporary table used to store already seen cached SQL
          stmt = msrv.monSrvConn.createStatement();
          rs = stmt.executeQuery("select @@bootcount");
          rs.next();
          bootcount = rs.getInt(1);

          stmt.executeUpdate("if (select object_id('#gotcachedSQL') )!=null drop table #gotcachedSQL");
          stmt.executeUpdate("create table #gotcachedSQL (SSQLID int,Hashkey int /*,LastRecompiledDate datetime null*/)");

          // initialization of #gotcachedSQL from archive server
          // Get an archive connection from the pool
          CnxMgr.ArchCnx aArchCnx = CnxMgr.archCnxPool.getArchCnx(false);
          try {
              Statement stmtArch = aArchCnx.archive_conn.createStatement();
              rs = stmtArch.executeQuery("select distinct SSQLID ,Hashkey /*,LastRecompiledDate=max(LastRecompiledDate)*/"+
                  " from "+srvName+"_CachedSQL"+
                  //" where bootcount= (select max(bootcount) from "+srvName+"_CachedSQL)");
                  " where bootcount = " + bootcount);
              pstmt = msrv.monSrvConn.prepareStatement("insert into  #gotcachedSQL (SSQLID ,Hashkey ) values (?,?)");
              msrv.monSrvConn.setAutoCommit(false);
              while (rs.next()) {
                  pstmt.setInt(1, rs.getInt((1)));
                  pstmt.setInt(2, rs.getInt((2)));
                  //pstmt.setTimestamp(3, rs.getTimestamp((3)));
                  pstmt.addBatch();
                  cntgotcachedSQL++;
              }
              pstmt.executeBatch();
          }
          finally {
              try {
                  if ( (msrv.monSrvConn != null) && (!msrv.monSrvConn.isClosed())) {
                      msrv.monSrvConn.commit();
                      msrv.monSrvConn.setAutoCommit(true);
                  }
                  if (pstmt != null) pstmt.close();
              }
              catch (Exception e) {
                  Asemon_logger.printmess ("ERROR CollectorCachedSQL : error during initialization. "+e.getMessage());
              }
              // Return archive connection to the pool
              CnxMgr.archCnxPool.putArchCnx(aArchCnx);
          }
          stmt.executeUpdate("create unique clustered index iu on #gotcachedSQL (SSQLID ,Hashkey /*,LastRecompiledDate*/)");
          stmt.close();
      }
      catch (Exception e) {
    	  Asemon_logger.printmess ("ERROR CollectorCachedSQL : error during initialization.");
          // message is printed in calling method
          //e.printStackTrace(System.out);
          throw e;
      }
      Asemon_logger.DEBUG(Asemon_logger.DBG100, "End initialization. Row inserted in #gotcachedSQL = "+cntgotcachedSQL+" Bootcount = "+bootcount);

  }


   public void getMetrics () throws Exception {
      archRows = -1 ; // in case of error or missing config params, AmStats will show this info

      // Allocate list for storing results in memory
      if (currentListOfCachedStmt == null) 
          currentListOfCachedStmt = new Vector<StatementDesc> ();
      else
          currentListOfCachedStmt.clear();

      try  {
          stmt = msrv.monSrvConn.createStatement();
          if (debugSwitchs.contains(100)) {
              // Get count of rows in #gotcachedSQL
              rs = stmt.executeQuery("select count(*) from #gotcachedSQL");
              rs.next();
              Asemon_logger.DEBUG(Asemon_logger.DBG100, "Count in #gotcachedSQL = "+rs.getInt(1));
          }
          // Get list of new statements
          rs = stmt.executeQuery("select S.SSQLID,S.Hashkey"+
               " from master..monCachedStatement S left outer join #gotcachedSQL G on S.SSQLID = G.SSQLID and S.Hashkey = G.Hashkey"+
               " where (UseCount > "+ String.valueOf(min_usecount)+" or MaxLIO > "+ String.valueOf(min_logical_reads)+" )"+
               " and G.SSQLID is null"+
               " and G.Hashkey  is null");
          while (rs.next()) {
              // Loop on all new cached statements and save them in memory
              
              // Get new cached stmt
              StatementDesc aSD = new StatementDesc (rs.getInt(1), rs.getInt(2) /*, rs.getTimestamp(3)*/);
              currentListOfCachedStmt.add(aSD);
          }
          Asemon_logger.DEBUG(Asemon_logger.DBG100, "New cached statements = "+currentListOfCachedStmt.size());
          if (currentListOfCachedStmt.isEmpty()) {
              // No new cached statement, nothing to do
              stmt.close();
              archRows = 0;
              return;
          }


          nbRowsToInsert = 0;

          // For each new cached statement, retreive its SQL and PLAN
          Iterator<StatementDesc> itCS = currentListOfCachedStmt.iterator();
          while (itCS.hasNext()) {
              StatementDesc aCS = itCS.next();  // Get cached statement
              if (! Asemon_logger.skipRetreiveSQLText)
                  aCS.getAndSaveSQL(this);
              if (msrv.version < 1570) {
                  // Retreive plan if version is before V15.7
                  // For 15.7, plan can be retreived with new collector CachedXML.xml
                  if (sp_showplan_proc!=null)
                      aCS.getAndSavePLAN(this);
              }
          }

          // add list of new cached statement in temporary table
          pstmt= msrv.monSrvConn.prepareStatement("insert into #gotcachedSQL values (?,?)");
          msrv.monSrvConn.setAutoCommit(false);
          itCS = currentListOfCachedStmt.iterator();
          int nbinserts = 0;
          while (itCS.hasNext()) {
              StatementDesc aCS = itCS.next();  // Get cached statement
              pstmt.setInt(1, aCS.SSQLID);
              pstmt.setInt(2, aCS.Hashkey);
              //pstmt.setTimestamp(3, aCS.LastRecompiledDate);
              pstmt.addBatch();
              nbinserts++;
          }
          pstmt.executeBatch();
          Asemon_logger.DEBUG(Asemon_logger.DBG100, "Nb inserts in #gotcachedSQL = "+nbinserts);

          // clear currentListOfCachedStmt
          currentListOfCachedStmt.clear();

        
      }
      catch (SQLException sqlex){
          int errcode=sqlex.getErrorCode();
          if (errcode==12052) {
              // Configuration is not set for statement cache monitoring, don't retreive any data
          }
      }
      catch (Exception e) {
          throw e;
      }
      finally {
          msrv.monSrvConn.commit();
          msrv.monSrvConn.setAutoCommit(true);
          pstmt.close();
          stmt.close();
      }

  }

}
/*
* <p>Archive_IQ</p>
* <p>Copyright: Jean-Paul Martin (jpmartin@sybase.com) Copyright (c) 2015</p>
* Class to manage interface with a ASE archive database
* @version 3.2.5
 */
package asemon_logger;

import static asemon_logger.Asemon_logger.debug;
import com.sybase.jdbcx.SybConnection;
import java.sql.*;
import java.util.*;

public class Archive_ASE implements Archive_interface {
    
      public boolean connect_archive_SRV (CnxMgr.ArchCnx aArchServCnx, boolean nowait) {
      aArchServCnx.archive_conn = null; // Force reopen of the connection if not completely cleared last time it was used
      boolean verbose=true;
      boolean displayErrors = true;
      if (Asemon_logger.archive_server!=null) {

          while (aArchServCnx.archive_conn == null)  {
              aArchServCnx.archive_conn = (SybConnection)CnxMgr.connectSRV(Asemon_logger.archive_user, Asemon_logger.archive_server, Asemon_logger.archive_base, Asemon_logger.archive_charset, "For archive server '"+Asemon_logger.archive_server+"', user '"+Asemon_logger.archive_user+"' - ", verbose, "asemon_arch", Asemon_logger.archive_useKerberos, displayErrors, Asemon_logger.archive_packet_size, Asemon_logger.archive_useSSL, Asemon_logger.archive_address, "ASE", Asemon_logger.archive_aseUserStoreKey);
              if (aArchServCnx.archive_conn==null) {
                  if (nowait) return false;
                  if (displayErrors)
                      Asemon_logger.printmess("Trying to reconnect to archive server every 10 s ...");
                  try {
                    java.lang.Thread.sleep(10000);  // wait 10 s before retrying
                    displayErrors = false;
                    verbose=false;
                  }
                  catch (Exception e) {}
              }
          }

          try {
              Statement stmt = aArchServCnx.archive_conn.createStatement();
              ResultSet rs=stmt.executeQuery("select substring(@@version, 1, charindex('/', @@version)-1)");
              rs.next();
              String product= rs.getString(1);
              String archive_DBMS;
              if ((product.equalsIgnoreCase("SYBASE IQ"))||(product.equalsIgnoreCase("SAP IQ")))
                  archive_DBMS = "IQ";
              else {
                  archive_DBMS = "ASE";

                  // Get ASE sbssav (version)
                  rs=stmt.executeQuery(                                                                        
                    "select substring(" +
                           "substring(@@version,charindex('ise/',@@version)+4,datalength(@@version))," +
                           "1," +                                                                                    
                           "charindex('/',substring(@@version,charindex('ise/',@@version)+4,datalength(@@version)))-1" +
                       ")");                                                                                         
                  rs.next();
                  String s = rs.getString(1);
                  Asemon_logger.archive_sbssav = s;
                  s=s.replaceAll("\\.", "");
                  if (s.length()>4)
                      s=s.substring(0,4).trim();
                  int version = Integer.parseInt(s);
                  if (version == 155)
                      // special case for V15.5
                      version= 1550;
                  if (version == 157)
                      // special case for V15.7
                      version= 1570;
                  if (version == 160)
                      // special case for V16
                      version= 1600;
                  if (version == 161)
                      // special case for V161
                      version= 1610;
                  if (version >= 1570) {
                      // Get new @@sbssav variable containing exact version
                      rs=stmt.executeQuery("select @@sbssav");
                      rs.next();
                      Asemon_logger.archive_sbssav = rs.getString(1);
                  }
              }
              stmt.close();
              if (archive_DBMS.compareToIgnoreCase(Asemon_logger.archive_type)!=0) {
                  Asemon_logger.printmess("ERROR : archive DBMS is not what is configured in the config file : '"+Asemon_logger.archive_type+"'");
                  return false;
              }
          }
          catch (Exception e) {
              e.printStackTrace(System.out);
          }

          Asemon_logger.printmess ("Connected to archive server : "+ Asemon_logger.archive_server + " Database : " + Asemon_logger.archive_base + " ASE Version : " + Asemon_logger.archive_sbssav);

          try {
              Statement stmt = aArchServCnx.archive_conn.createStatement();
              int len = Asemon_logger.config_file.length();
              int start, end;
              if (len > 30) {start=len-30; end=len;}
              else {start=0; end=len-1;}
              stmt.executeUpdate("set clientapplname '"+Asemon_logger.config_file.substring(start, end)+"'");
              stmt.executeUpdate("set quoted_identifier on");
              stmt.close();
          }
          catch (Exception e) {
              e.printStackTrace(System.out);
          }
      }
      return true;
    }

    public boolean connect_archive_SRV_asPurge (MonitoredSRV msrv, boolean printCnxMess, boolean nowait) {
      if (Asemon_logger.archive_server!=null) {
          msrv.purge_conn=null;
          boolean displayErrors=true;
          boolean verbose = printCnxMess;

          while (msrv.purge_conn==null) {
              msrv.purge_conn = CnxMgr.connectSRV(Asemon_logger.archive_user, Asemon_logger.archive_server, Asemon_logger.archive_base, Asemon_logger.archive_charset, "For archive server '"+Asemon_logger.archive_server+"', user '"+Asemon_logger.archive_user+"' - ", verbose, "asemon_purge", Asemon_logger.archive_useKerberos, displayErrors, Asemon_logger.archive_packet_size, Asemon_logger.archive_useSSL, Asemon_logger.archive_address, "ASE", Asemon_logger.archive_aseUserStoreKey);
              if (msrv.purge_conn==null) {
                  if (nowait) return false;
                  if (displayErrors)
                      Asemon_logger.printmess("Trying to reconnect to archive server every 10 s ...");
                  try {
                    java.lang.Thread.sleep(10000);  // wait 10 s before retrying
                    displayErrors = false;
                    verbose=false;
                  }
                  catch (Exception e) {}
              }
          }


          if (printCnxMess)
              Asemon_logger.printmess ("Connected to archive server : "+ Asemon_logger.archive_server + " Database : " + Asemon_logger.archive_base + " ASE Version : " + Asemon_logger.archive_sbssav);
          try {
              Statement stmt = msrv.purge_conn.createStatement();
              int len = Asemon_logger.config_file.length();
              int start, end;
              if (len > 30) {start=len-30; end=len;}
              else {start=0; end=len-1;}
              stmt.executeUpdate("set clientapplname '"+Asemon_logger.config_file.substring(start, end)+"'");
              stmt.close();
          }
          catch (Exception e) {
              e.printStackTrace(System.out);
          }
      }
      return true;
    }
    
    public boolean checkIfTableExists (String tabname, Statement stmt) throws Exception {
        ResultSet res = null;
        res = stmt.executeQuery("select name from sysobjects where name='"+tabname+"' and type='U'");
        if (!res.next()) return false; // No row returned for this query, so table doesn't exist
        else return true;
    }

    public void createArchiveTable (StringBuffer ct, Statement stmt) throws Exception {
    
        try {
          stmt.executeUpdate(ct.toString());
          System.out.println(ct);
        }
        catch (SQLWarning sqlw) {
          Asemon_logger.printmess ("initialize - Warning : "  + sqlw);
        }
        catch (SQLException sqlEx) {
          // Check if err is because table already exists
          switch (sqlEx.getErrorCode()) {
              case 2714 :
                  // yes, "ASE error"
                  break;
              default :
                  throw sqlEx;
          }
        }
    }
    
    
    public void grantRightsOnArchiveTable(String archiveTabName, String granteeList, Statement stmt) {
        try {
            stmt.executeUpdate("grant select on "+archiveTabName+" to " + granteeList);
        }
        catch (SQLException sqlEx) {
          Asemon_logger.printmess("Grant error. Error="+sqlEx.getErrorCode()+" SQL message="+sqlEx.getMessage());
          // not fatal error, continue
        }
    }
    
    // Create a temp table with the config structure, and compare the existing
    // table with this temp table. Automaticaly alter existing table
    // if missing columns
    public Hashtable <String, ArchiveColumnDesc> checkAndAlterArchiveTable (StringBuffer ct, String tname, String archive_tname, Statement stmt, Collector collector) throws Exception {
      // This method get and compare structures of configured archive table (conf in config file)
      // and existing archive table. If different, add or modify columns
      Hashtable<String, ArchiveColumnDesc> confTabColList = new Hashtable<String, ArchiveColumnDesc>();
      Hashtable<String, ArchiveColumnDesc> archTabColList = new Hashtable<String, ArchiveColumnDesc>();
      LinkedHashMap<String, ArchiveColumnDesc> linkedConfTabColList = new LinkedHashMap<String, ArchiveColumnDesc>();

      ResultSet rs;
      String tempdbName;
      
      int start = ct.indexOf("?SERVERNAME?_");
      ct.replace(start,start+"?SERVERNAME?_".length(),"#");

      try {
          // try dropping temp table if already exists
          stmt.executeUpdate("if object_id('#"+tname+"') != NULL begin drop table #"+tname+ " end ");
          // create temp table
          stmt.executeUpdate(ct.toString());
      }
      catch (SQLException sqlEx) {
          Asemon_logger.printmess("ERROR initializeMetric : err creating temp table");
          throw sqlEx;
      }


      // get tempdb name
      try {
          rs=stmt.executeQuery("select db_name(@@tempdbid)");
          rs.next();
          tempdbName=rs.getString(1);
      }
      catch (SQLException sqlEx) {
          Asemon_logger.printmess("ERROR initializeMetric : err geting tempdb name");
          throw sqlEx;
      }
      
      // get list and type of columns of config table
      try {
          rs=stmt.executeQuery("select C.name, C.usertype, C.length, C.prec, C.scale , allows_null=C.status&8, T.name from "+
                  tempdbName+"..syscolumns C, "+tempdbName+"..systypes T"+
                  " where id=object_id('"+tempdbName+"..#"+tname+"')"+
                  " and C.usertype=T.usertype order by colid");
      }
      catch(Exception e) {
          Asemon_logger.printmess("ERROR checkAndAlterArchiveTable : err getting syscolumns");
          throw e;
      }
      ArchiveColumnDesc aColumnDesc;
      while (rs.next()){
          aColumnDesc = new ArchiveColumnDesc(rs.getString(1), rs.getInt(2), rs.getInt(3), rs.getInt(4), rs.getInt(5), rs.getInt(6), rs.getString(7));
          aColumnDesc.computeFullType();
          confTabColList.put(aColumnDesc.name, aColumnDesc);
          linkedConfTabColList.put(aColumnDesc.name, aColumnDesc);
          Asemon_logger.DEBUG ("Config Table column : '" + aColumnDesc.name+"'");
      }

      // get list of column of existing archive table
      try {
          rs=stmt.executeQuery("select C.name, C.usertype, C.length, C.prec, C.scale , allows_null=C.status&8, T.name from "+
                  "syscolumns C, systypes T"+
                  " where id=object_id('"+archive_tname+"')"+
                  " and C.usertype=T.usertype order by colid");
      }
      catch(Exception e) {
          Asemon_logger.printmess("ERROR checkAndAlterArchiveTable : err getting syscolumns");
          throw e;
      }
      while (rs.next()){
          aColumnDesc = new ArchiveColumnDesc(rs.getString(1), rs.getInt(2), rs.getInt(3), rs.getInt(4), rs.getInt(5), rs.getInt(6), rs.getString(7));
          aColumnDesc.computeFullType();
          archTabColList.put(aColumnDesc.name, aColumnDesc);
          Asemon_logger.DEBUG ("Archive Table column : '" + aColumnDesc.name+"'");
      }

      // check if all config columns exist in the archive table
      // if not, alter archive table to add this col (as null)
      // or modify col if type, length or precision are differents

      // Get a set of the entries & iterator
      Set set = linkedConfTabColList.entrySet();
      Iterator i = set.iterator();
      
      // Enumeration e = confTabColList.elements();
      ArchiveColumnDesc aConfigCol;
      ArchiveColumnDesc aExistingCol;
      String alterSQL;
      // while (e.hasMoreElements()){
      while (i.hasNext()){
          // aConfigCol = (ArchiveColumnDesc)e.nextElement();
          Map.Entry me = (Map.Entry)i.next();
          aConfigCol = (ArchiveColumnDesc)me.getValue();
          Asemon_logger.DEBUG ("Check if Config Table column exists : '" + aConfigCol.name+"'");
          if ( ! archTabColList.containsKey(aConfigCol.name)) {
              alterSQL = "alter table " + archive_tname +" add [" + aConfigCol.name + "] " + aConfigCol.fullType + " null";
              Asemon_logger.printmess("Modify archive table : " +alterSQL);
              stmt.executeUpdate(alterSQL.toString());
              Asemon_logger.printmess("Archive table modified");
          }
          else {
              aExistingCol = (ArchiveColumnDesc)archTabColList.get(aConfigCol.name);
              if ( ! aExistingCol.compareCol(aConfigCol)) {
                  // Columns are differents, alter existing column
                  alterSQL = "alter table " + archive_tname +" modify [" + aConfigCol.name +"] "+ aConfigCol.fullType + " null";
                  Asemon_logger.printmess("Modify archive table : " +alterSQL);
                  stmt.executeUpdate(alterSQL.toString());
                  Asemon_logger.printmess("Archive table modified");
              }
          }
      }
      // Drop this temp table
      try {
          stmt.executeUpdate("drop table #"+tname);
      }
      catch (SQLException sqlEx) {
          Asemon_logger.printmess("ERROR initializeMetric : err droping temp table");
          throw sqlEx;
      }

      return confTabColList;
  }

    public void createIndex(String ci, Statement stmt) throws Exception {
                  
        // Don't check if the index already exists. If exists, it generates an error and ignore it
        try {
          stmt.executeUpdate(ci);
          System.out.println(ci);
        }
        catch (SQLException sqlEx) {
          // Check if err is because index already exists
          switch (sqlEx.getErrorCode()) {
              case 1913 :
              case 1902 :
                  // yes, "ASE error"
                  break;
              default :
                  throw sqlEx;
          }
        }
    }

    
    public void saveValues (String archiveTabName, Archive_array archive_array, Collector collector) throws Exception {
        if (archive_array.nbrows() == 0) {
            collector.archRows = 0;
            return; // no row to insert
        }
        
        try {
            if ( Asemon_logger.debugSwitchs.contains(Asemon_logger.DBG106))
                archive_array.printRows();
            saveValues_exec (archiveTabName, archive_array, collector);
        }
        catch (SQLException sqle){
            int err = sqle.getErrorCode();
            if (err == 1205) {
                // Deadlock
                Asemon_logger.DEBUG ("Deadlock on table : '" + archiveTabName+"'");
                java.lang.Thread.sleep (1000); // Wait 1 s before retry
                // retry one time
                try {
                    saveValues (archiveTabName, archive_array, collector);
                }
                catch (SQLException sqle2){
                    if (sqle2.getErrorCode()==3604) {
                    // Ignore this error -- 'duplicate key error'
                    }
                    else {
                        AsemonSQLException asemonEx = new AsemonSQLException(sqle2.getMessage(), sqle2.getSQLState(), sqle2.getErrorCode(), "ARCH", archiveTabName);
                        throw asemonEx;
                    }
                }
            }
            else if (err == 3604) {
                    // Ignore this error -- 'duplicate key error'
                }
                else {
                    if ( ( err == 1622) || ( err == 4837) ){
                        // 4837 : SQL message=Bad row data received from the client while bulk copying into
                        // 1622 : "type xx is not implemented"
                        sqle.printStackTrace();
                        collector.msrv.monSrvConn.close();  // Close also the monitored server connection
                        archive_array.printRows();
                    }
                    AsemonSQLException asemonEx = new AsemonSQLException(sqle.getMessage(), sqle.getSQLState(), sqle.getErrorCode(), "ARCH", archiveTabName);
                    throw asemonEx;
                }
        }

    }

    public void saveValues_exec (String archiveTabName, Archive_array archive_array, Collector collector) throws Exception {
        // This new version of saveValues batches all insert statements in a same prepared statement
        // If the ENABLE_BULK_LOAD option is set on the connection, the driver then use the bulk insert method (faster than
        // insert by insert method)
        // Furthermore, with this new method, all inserts are in a single transaction (not the case in the older version of the method)

        // Get an archive connection from the pool
        CnxMgr.ArchCnx aArchCnx = CnxMgr.archCnxPool.getArchCnx(false);
        collector.archCnxWaitTime = aArchCnx.waitedFor;
        
        int nbRowsToInsert = 0;
        PreparedStatement pstmtArch = null;
        

        try {           
            // Prepare the SQL
            StringBuffer sql;
            String sep="";
            sql = new StringBuffer("insert into "+ archiveTabName + " (");
            // Prepare list of columns names
            for (int i=0; i < archive_array.nbcols(); i++) {
              sql.append(sep);
              sql.append(archive_array.getColName(i));
              sep = ",";
            }
            sql.append(") values (");

            // Prepare list of question marks
            sep="";
            for (int i=0; i < archive_array.nbcols(); i++) {
              sql.append(sep);
              sql.append("?");
              sep = ",";
            }
            sql.append(")");

            pstmtArch = aArchCnx.archive_conn.prepareStatement(sql.toString());

            // Prepare the batch of statements
            aArchCnx.archive_conn.setAutoCommit(false);

            // Force DYNAMIC_PREPARE to false
            aArchCnx.archive_conn.setClientInfo("DYNAMIC_PREPARE", "FALSE");

            int nbRowsInBatch = 0; // Counter used when disableBulkLoad is set in order to limit number of rows inserted in a single batch
            for (int rowId=0; rowId < archive_array.nbrows(); rowId++) {
                // Get the row values
                Archive_array.Archive_row row = archive_array.getRow(rowId);

                // loop on all columns
                for (int col=0; col < row.cols.size(); col++) {

                  // Get the sql type of the column
                  int t = (Integer)archive_array.getColType(col);

                  Object val = row.cols.get(col);

                  // check if column is NULL
                  if (val == null) {
                      pstmtArch.setNull(col+1, t);
                      continue;
                  }

                  // Check if type is "bit". If Yes change it to char(1) since BULK LOAD does not support bit
                  if (t == java.sql.Types.BIT) {
                      boolean valBIT = ((Boolean)val).booleanValue();
                      String valChar;
                      if (valBIT == false) valChar="0";
                      else valChar="1";
                      t=java.sql.Types.VARCHAR;
                      val = valChar;
                  }

                  // Check if type is "VARCHAR". If Yes check if last char is binary zero and remove it
                  if ( (t == java.sql.Types.CHAR) || (t == java.sql.Types.VARCHAR) ) {
                      String str = (String)val;
                      int len = str.length();
                      if ( (len >0)  && (str.charAt(str.length()-1)=='\0') ){
                          str = str.substring(0, str.length() - 1);
                      }
                      val = str;
                  }

                  // set the column value according to its type
                  pstmtArch.setObject(col+1, val, t);
                }
                pstmtArch.addBatch();
                nbRowsToInsert++;
                nbRowsInBatch++;
                if ((Asemon_logger.disableBulkLoad) && (nbRowsInBatch>=1000)) {
                  pstmtArch.executeBatch();
                  nbRowsInBatch = 0; // reset counter
                }
            }

            // Execute the final batch
            pstmtArch.executeBatch();
            
            collector.archRows = nbRowsToInsert;   // Save number of rows inserted in collector's variable
        }
        catch (Exception e) {
            if ((aArchCnx.archive_conn != null)&&(!aArchCnx.archive_conn.isClosed())) {
                aArchCnx.archive_conn.rollback();
            }
            throw e;
        }
        finally {
            if ((aArchCnx.archive_conn != null)&&(!aArchCnx.archive_conn.isClosed())) {
                try {
                    aArchCnx.archive_conn.commit();
                    aArchCnx.archive_conn.setAutoCommit(true);
                }
                catch (SQLException sqle) {
                    int err = sqle.getErrorCode();
                    if ( ( err == 1622) || ( err == 4837) ){
                        // 4837 : SQL message=Bad row data received from the client while bulk copying into
                        // 1622 : "type xx is not implemented"
                        sqle.printStackTrace();
                        aArchCnx.archive_conn.close();      // Close archive connection
                        collector.msrv.monSrvConn.close();  // Close also the monitored server connection
                        archive_array.printRows();
                    }
                    AsemonSQLException asemonEx = new AsemonSQLException(sqle.getMessage(), sqle.getSQLState(), sqle.getErrorCode(), "ARCH", archiveTabName);
                    throw asemonEx;

                }
                if (pstmtArch!=null) pstmtArch.close();
            }
            
            // Return archive connection to the pool
            collector.archCnxActiveTime =  CnxMgr.archCnxPool.putArchCnx(aArchCnx);
        }
    }
    
    

    public void truncateTable (String archiveTabName, Collector collector) throws Exception {
        // Get an archive connection from the pool
        CnxMgr.ArchCnx aArchCnx = CnxMgr.archCnxPool.getArchCnx(false);
        collector.archCnxWaitTime = aArchCnx.waitedFor;
        Statement stmtArch = null;
        try {
            stmtArch = aArchCnx.archive_conn.createStatement();
            stmtArch.execute("truncate table "+archiveTabName);
        }
        finally {
            if ((aArchCnx.archive_conn != null)&&(!aArchCnx.archive_conn.isClosed())) {
              aArchCnx.archive_conn.commit();
              if (stmtArch!=null) stmtArch.close();              
            }
            // Return archive connection to the pool
            collector.archCnxActiveTime =  CnxMgr.archCnxPool.putArchCnx(aArchCnx);
        }
    }
    
}

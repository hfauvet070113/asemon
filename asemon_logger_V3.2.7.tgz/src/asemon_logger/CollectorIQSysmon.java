/**
 * <p>CollectorIQSysmon</p> <p>Asemon_logger : class managing Replication Agent
 * counters and for computing differences</p> <p>Copyright: Jean-Paul Martin
 * (jpmartin@sybase.com) Copyright (c) 2004</p>
 *
 * @author fabien
 * @version 3.1.12
 */
package asemon_logger;

import static asemon_logger.Asemon_logger.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.regex.Pattern;
import java.util.Hashtable;

public class CollectorIQSysmon extends Collector {

    String srvName;
    String structName;
    String sql;
    Timestamp oldTime = null;
    Timestamp newTime;
    Long interval;
    String sep1;
    String sep2;
    String sep3;
    StringBuffer sql_insert1_columns;
    StringBuffer sql_insert1_values;
    StringBuffer sql_insert2_columns;
    StringBuffer sql_insert2_values_TOTAL;
    StringBuffer sql_insert2_values_NONE;
    StringBuffer sql_insert2_values_TXTPOS;
    StringBuffer sql_insert2_values_TXTDOC;
    StringBuffer sql_insert2_values_CMPACT;
    StringBuffer sql_insert2_values_BTREEV;
    StringBuffer sql_insert2_values_BTREEF;
    StringBuffer sql_insert2_values_BV;
    StringBuffer sql_insert2_values_VDO;
    StringBuffer sql_insert2_values_DBEXT;
    StringBuffer sql_insert2_values_DBID;
    StringBuffer sql_insert2_values_SORT;
    StringBuffer sql_insert2_values_STORE;
    StringBuffer sql_insert2_values_GARRAY;
    StringBuffer sql_insert2_values_BARRAY;
    StringBuffer sql_insert2_values_BLKMAP;
    StringBuffer sql_insert2_values_HASH;
    StringBuffer sql_insert2_values_CKPT;
    StringBuffer sql_insert2_values_BM;
    StringBuffer sql_insert2_values_TEST;
    StringBuffer sql_insert2_values_CMID;
    StringBuffer sql_insert2_values_RIDCA;
    StringBuffer sql_insert2_values_LOB;
    // V16
    StringBuffer sql_insert2_values_LVCRID;
    StringBuffer sql_insert2_values_FILE;
    StringBuffer sql_insert2_values_RIDMAP;
    StringBuffer sql_insert2_values_RVLOG;


    StringBuffer sql_insert3_columns;
    StringBuffer sql_insert3_values_TOTAL;
    StringBuffer sql_insert3_values_UNKNWN;
    StringBuffer sql_insert3_values_HASH;
    StringBuffer sql_insert3_values_CSORT;
    StringBuffer sql_insert3_values_ROW;
    StringBuffer sql_insert3_values_ROWCOL;
    StringBuffer sql_insert3_values_FP;
    StringBuffer sql_insert3_values_GARRAY;
    StringBuffer sql_insert3_values_LOB;
    StringBuffer sql_insert3_values_BTREE;
    StringBuffer sql_insert3_values_BM;
    StringBuffer sql_insert3_values_BV;
    StringBuffer sql_insert3_values_STORE;
    StringBuffer sql_insert3_values_TEST;
    StringBuffer sql_insert3_values_DBCC;
    StringBuffer sql_insert3_values_BLKMAP;
    StringBuffer sql_insert3_values_IQUTIL;

    
    Pattern numericPattern = Pattern.compile("[^0-9.]+");
    Boolean firstTime=true;  // set to true during first collection
    
    Hashtable<String, String> indicWithDetail2;
    Hashtable<String, String> indicWithDetail3;

    public CollectorIQSysmon(MonitoredSRV ms, MetricDescriptor aMetricDescriptor) {
        super(ms, aMetricDescriptor);
        srvName = msrv.srvNormalized;
        structName = metricDescriptor.metricName;
        sql = metricDescriptor.SQL;
        
        // Initialize list of indicators having detail like : TOTAL  	NONE   	TXTPOS 	TXTDOC 	CMPACT 	BTREEV 	BTREEF 	BV     	VDO    	DBEXT  	DBID   	SORT   	STORE  	GARRAY 	BARRAY 	BLKMAP 	HASH   	CKPT   	BM     	TEST   	CMID   	RIDCA  	LOB 
        // Data inserted in table IQSysmon2
        indicWithDetail2 = new Hashtable();
        indicWithDetail2.put("Finds", "");
        indicWithDetail2.put("Hits", "");
        indicWithDetail2.put("HitPercent", "");
        indicWithDetail2.put("FalseMiss", "");
        indicWithDetail2.put("UnOwnRR", "");
        indicWithDetail2.put("Cloned", "");
        indicWithDetail2.put("Creates", "");
        indicWithDetail2.put("Destroys", "");
        indicWithDetail2.put("Dirties", "");
        indicWithDetail2.put("RealDirties", "");
        indicWithDetail2.put("PrefetchReqs", "");
        indicWithDetail2.put("PrefetchNotInMem", "");
        indicWithDetail2.put("PrefetchInMem", "");
        indicWithDetail2.put("Reads", "");
        indicWithDetail2.put("PReadBlks", "");
        indicWithDetail2.put("PReadKB", "");
        indicWithDetail2.put("ReReads", "");
        indicWithDetail2.put("Writes", "");
        indicWithDetail2.put("PWriteBlks", "");
        indicWithDetail2.put("PWriteKB", "");
        indicWithDetail2.put("GrabbedDirty", "");
        indicWithDetail2.put("MovedToMRU", "");
        indicWithDetail2.put("MovedToWash", "");
        indicWithDetail2.put("RemovedFromLRU", "");
        indicWithDetail2.put("RemovedFromWash", "");
        indicWithDetail2.put("RemovedInScanMode", "");
        indicWithDetail2.put("MovedToPSList", "");
        indicWithDetail2.put("RemovedFromPSList", "");
        indicWithDetail2.put("ReadRemoteRpc","");
        indicWithDetail2.put("ReadRemotePhyIO","");
        indicWithDetail2.put("MainCacheHit","");
        indicWithDetail2.put("MainCacheMiss","");
        indicWithDetail2.put("MainCacheMatch","");
        indicWithDetail2.put("MainCacheMismatch","");
        indicWithDetail2.put("MainCacheReadTotal","");
        indicWithDetail2.put("MainCacheReadInError","");
        indicWithDetail2.put("MainCacheWriteTotal","");
        indicWithDetail2.put("MainCacheWriteInError", "");

        // Initialize list of indicators having detail like : TOTAL  	UNKNWN  HASH  CSORT ROW ROWCOL FP GARRAY LOB BTREE BM BV STORE TEST DBCC BLKMAP IQUTIL
        // Data inserted in table IQSysmon3
        indicWithDetail3 = new Hashtable();
        indicWithDetail3.put("NumClients", "");
        indicWithDetail3.put("PinUserQuota", "");
        indicWithDetail3.put("PrefetchUserQuota", "");
        indicWithDetail3.put("PinUserRegisters", "");
        indicWithDetail3.put("PfUserRegisters", "");
        indicWithDetail3.put("ClientCountOfPinners", "");
        indicWithDetail3.put("Unknown", "");
        indicWithDetail3.put("Hash", "");
        indicWithDetail3.put("Sort", "");
        indicWithDetail3.put("Row", "");
        indicWithDetail3.put("RowColumn", "");
        indicWithDetail3.put("FP", "");
        indicWithDetail3.put("Garray", "");
        indicWithDetail3.put("LOB", "");
        indicWithDetail3.put("BTree", "");
        indicWithDetail3.put("BM", "");
        indicWithDetail3.put("BV", "");
        indicWithDetail3.put("Store", "");
        indicWithDetail3.put("Test", "");
        indicWithDetail3.put("DBCC", "");
        indicWithDetail3.put("Unknown", "");
        indicWithDetail3.put("Run", "");
        indicWithDetail3.put("QCPRun", "");
        indicWithDetail3.put("TextDoc", "");
        indicWithDetail3.put("VDO", "");
        indicWithDetail3.put("Load_Pass_2", "");

    }

    private void appendInsert(String sect, String name, String value, Boolean isString) {
        appendInsert(sect, name, value, 0, isString);
    }

    private void appendInsert(String sect, String name, String value, int offset, Boolean isString) {
        if (!isString) {
            String[] result = numericPattern.split(value);
            // System.out.println(name+"="+value+","+result[offset]);
            if (result.length==0) {
                DEBUG (DBG117, "IQSysmon, appendInsert : section = '"+sect+"' name = '"+name+"' value = '"+value+"' offset = "+offset);
                return;
            }
            value = result[offset];
        }
        name = sect+"_"+name;
        if (sql_insert1_columns.length() > 0) {
            sql_insert1_columns.append(", ");
        }
        sql_insert1_columns.append(name);

        if (sql_insert1_values.length() > 0) {
            sql_insert1_values.append(", ");
        }
        if (isString)
           sql_insert1_values.append("'"+value+"'");
        else
           sql_insert1_values.append(value);
    }

    
    private void appendValue (String sep, StringBuffer sb, String value) {
        String[] result = numericPattern.split(value);
        // System.out.println(name+"="+value+","+result[offset]);
        value = result[0];
        sb.append(sep+value);
    }
    
    private void appendInsert2(String sect, String name, String f1, String f2, String f3, String f4, String f5, String f6, String f7, String f8, String f9, String f10, String f11, String f12, String f13, String f14, String f15, String f16, String f17, String f18, String f19, String f20, String f21, String f22, String f23) 
    {
        name = sect+"_"+name;
        sql_insert2_columns.append(sep2+name);
        
        appendValue (sep2,sql_insert2_values_TOTAL  ,f1);
        appendValue (sep2,sql_insert2_values_NONE   ,f2);
        appendValue (sep2,sql_insert2_values_TXTPOS ,f3);
        appendValue (sep2,sql_insert2_values_TXTDOC ,f4);
        appendValue (sep2,sql_insert2_values_CMPACT ,f5);
        appendValue (sep2,sql_insert2_values_BTREEV ,f6);
        appendValue (sep2,sql_insert2_values_BTREEF ,f7);
        appendValue (sep2,sql_insert2_values_BV     ,f8);
        appendValue (sep2,sql_insert2_values_VDO    ,f9);
        appendValue (sep2,sql_insert2_values_DBEXT  ,f10);
        appendValue (sep2,sql_insert2_values_DBID   ,f11);
        appendValue (sep2,sql_insert2_values_SORT   ,f12);
        appendValue (sep2,sql_insert2_values_STORE  ,f13);
        appendValue (sep2,sql_insert2_values_GARRAY ,f14);
        appendValue (sep2,sql_insert2_values_BARRAY ,f15);
        appendValue (sep2,sql_insert2_values_BLKMAP ,f16);
        appendValue (sep2,sql_insert2_values_HASH   ,f17);
        appendValue (sep2,sql_insert2_values_CKPT   ,f18);
        appendValue (sep2,sql_insert2_values_BM     ,f19);
        appendValue (sep2,sql_insert2_values_TEST   ,f20);
        appendValue (sep2,sql_insert2_values_CMID   ,f21);
        appendValue (sep2,sql_insert2_values_RIDCA  ,f22);
        appendValue (sep2,sql_insert2_values_LOB    ,f23);    
                    
        sep2 = ",";
    }

    private void appendInsert2(String sect, String name, String f1, String f2, String f3, String f4, String f5, String f6, String f7, String f8, String f9, String f10, String f11, String f12, String f13, String f14, String f15, String f16, String f17, String f18, String f19, String f20, String f21, String f22, String f23,
            String f24, String f25, String f26, String f27) {
        name = sect+"_"+name;
        sql_insert2_columns.append(sep2+name);
        
        appendValue (sep2,sql_insert2_values_TOTAL  ,f1);
        appendValue (sep2,sql_insert2_values_NONE   ,f2);
        appendValue (sep2,sql_insert2_values_TXTPOS ,f3);
        appendValue (sep2,sql_insert2_values_TXTDOC ,f4);
        appendValue (sep2,sql_insert2_values_CMPACT ,f5);
        appendValue (sep2,sql_insert2_values_BTREEV ,f6);
        appendValue (sep2,sql_insert2_values_BTREEF ,f7);
        appendValue (sep2,sql_insert2_values_BV     ,f8);
        appendValue (sep2,sql_insert2_values_VDO    ,f9);
        appendValue (sep2,sql_insert2_values_DBEXT  ,f10);
        appendValue (sep2,sql_insert2_values_DBID   ,f11);
        appendValue (sep2,sql_insert2_values_SORT   ,f12);
        appendValue (sep2,sql_insert2_values_STORE  ,f13);
        appendValue (sep2,sql_insert2_values_GARRAY ,f14);
        appendValue (sep2,sql_insert2_values_BARRAY ,f15);
        appendValue (sep2,sql_insert2_values_BLKMAP ,f16);
        appendValue (sep2,sql_insert2_values_HASH   ,f17);
        appendValue (sep2,sql_insert2_values_CKPT   ,f18);
        appendValue (sep2,sql_insert2_values_BM     ,f19);
        appendValue (sep2,sql_insert2_values_TEST   ,f20);
        appendValue (sep2,sql_insert2_values_CMID   ,f21);
        appendValue (sep2,sql_insert2_values_RIDCA  ,f22);
        appendValue (sep2,sql_insert2_values_LOB    ,f23);    
        
        // V16
        appendValue (sep2,sql_insert2_values_LVCRID    ,f24);    
        appendValue (sep2,sql_insert2_values_FILE    ,f25);    
        appendValue (sep2,sql_insert2_values_RIDMAP    ,f26);    
        appendValue (sep2,sql_insert2_values_RVLOG    ,f27);    
            
        sep2 = ",";
    }
    
    
    private void appendInsert3(String sect, String name, String f1, String f2, String f3, String f4, String f5, String f6, String f7, String f8, String f9, String f10, String f11, String f12, String f13, String f14, String f15, String f16, String f17) 
    {
        name = sect+"_"+name;
        sql_insert3_columns.append(sep3+name);
        
        appendValue (sep3, sql_insert3_values_TOTAL  ,f1);    
        appendValue (sep3, sql_insert3_values_UNKNWN   ,f2);  
        appendValue (sep3, sql_insert3_values_HASH ,f3);      
        appendValue (sep3, sql_insert3_values_CSORT ,f4);     
        appendValue (sep3, sql_insert3_values_ROW ,f5);       
        appendValue (sep3, sql_insert3_values_ROWCOL ,f6);    
        appendValue (sep3, sql_insert3_values_FP ,f7);        
        appendValue (sep3, sql_insert3_values_GARRAY     ,f8);
        appendValue (sep3, sql_insert3_values_LOB    ,f9);    
        appendValue (sep3, sql_insert3_values_BTREE  ,f10);   
        appendValue (sep3, sql_insert3_values_BM   ,f11);     
        appendValue (sep3, sql_insert3_values_BV   ,f12);     
        appendValue (sep3, sql_insert3_values_STORE  ,f13);   
        appendValue (sep3, sql_insert3_values_TEST ,f14);     
        appendValue (sep3, sql_insert3_values_DBCC ,f15);     
        appendValue (sep3, sql_insert3_values_BLKMAP ,f16);   
        appendValue (sep3, sql_insert3_values_IQUTIL   ,f17); 
        sep3 = ",";
    }

    @Override
    public void getMetrics() throws Exception {
        boolean hasDetail2;  // True is row should be inserted in IQSysmon2
        boolean hasDetail3;  // True is row should be inserted in IQSysmon3
        
        archRows = -1; // in case of error or missing config params, AmStats will show this info

        // Prepare insert statements
        sql_insert1_columns = new StringBuffer("");
        sql_insert1_values = new StringBuffer("");
        sql_insert2_columns = new StringBuffer("");
        sql_insert2_values_TOTAL  = new StringBuffer("");
        sql_insert2_values_NONE   = new StringBuffer("");
        sql_insert2_values_TXTPOS = new StringBuffer("");
        sql_insert2_values_TXTDOC = new StringBuffer("");
        sql_insert2_values_CMPACT = new StringBuffer("");
        sql_insert2_values_BTREEV = new StringBuffer("");
        sql_insert2_values_BTREEF = new StringBuffer("");
        sql_insert2_values_BV     = new StringBuffer("");
        sql_insert2_values_VDO    = new StringBuffer("");
        sql_insert2_values_DBEXT  = new StringBuffer("");
        sql_insert2_values_DBID   = new StringBuffer("");
        sql_insert2_values_SORT   = new StringBuffer("");
        sql_insert2_values_STORE  = new StringBuffer("");
        sql_insert2_values_GARRAY = new StringBuffer("");
        sql_insert2_values_BARRAY = new StringBuffer("");
        sql_insert2_values_BLKMAP = new StringBuffer("");
        sql_insert2_values_HASH   = new StringBuffer("");
        sql_insert2_values_CKPT   = new StringBuffer("");
        sql_insert2_values_BM     = new StringBuffer("");
        sql_insert2_values_TEST   = new StringBuffer("");
        sql_insert2_values_CMID   = new StringBuffer("");
        sql_insert2_values_RIDCA  = new StringBuffer("");
        sql_insert2_values_LOB    = new StringBuffer("");
        
        // V16
        sql_insert2_values_LVCRID    = new StringBuffer("");
        sql_insert2_values_FILE    = new StringBuffer("");
        sql_insert2_values_RIDMAP    = new StringBuffer("");
        sql_insert2_values_RVLOG    = new StringBuffer("");

        sql_insert3_columns         = new StringBuffer("");
        sql_insert3_values_TOTAL    = new StringBuffer("");
        sql_insert3_values_UNKNWN   = new StringBuffer("");
        sql_insert3_values_HASH     = new StringBuffer("");
        sql_insert3_values_CSORT    = new StringBuffer("");
        sql_insert3_values_ROW      = new StringBuffer("");
        sql_insert3_values_ROWCOL   = new StringBuffer("");
        sql_insert3_values_FP       = new StringBuffer("");
        sql_insert3_values_GARRAY   = new StringBuffer("");
        sql_insert3_values_LOB      = new StringBuffer("");
        sql_insert3_values_BTREE    = new StringBuffer("");
        sql_insert3_values_BM       = new StringBuffer("");
        sql_insert3_values_BV       = new StringBuffer("");
        sql_insert3_values_STORE    = new StringBuffer("");
        sql_insert3_values_TEST     = new StringBuffer("");
        sql_insert3_values_DBCC     = new StringBuffer("");
        sql_insert3_values_BLKMAP   = new StringBuffer("");
        sql_insert3_values_IQUTIL   = new StringBuffer("");

        sep1 = "";
        sep2 = "";
        sep3 = "";

        try {
            // Get values
            Statement stmt = msrv.monSrvConn.createStatement();
            if (oldTime == null) {
                oldTime = new Timestamp(System.currentTimeMillis() + msrv.timeAdjust.value());
                firstTime = true;
            }
            if (firstTime) {
                stmt.executeUpdate(sql);
                firstTime = false;
                return;
            }
            ResultSet rs = stmt.executeQuery(sql);

            Boolean fSectionIsNextLine = false;
            String Section = "";

            while (rs.next()) {
                String Stat = rs.getString(1);
                String f1 = rs.getString(2);

                if (Stat.startsWith("==============================")) {
                    if (fSectionIsNextLine) {
                        fSectionIsNextLine = false;
                    } else {
                        fSectionIsNextLine = true;
                    }
                    continue;
                }

                if (fSectionIsNextLine) {
                    if (Stat.startsWith("Buffer Manager (Main)")) {
                        Section = "BFM";
                    } else if (Stat.startsWith("Buffer Manager (Temporary)")) {
                        Section = "BFT";
                    } else if (Stat.startsWith("Buffer Pool (Main)")) {
                        Section = "BPM";
                    } else if (Stat.startsWith("Buffer Pool (Temporary)")) {
                        Section = "BPT";
                    } else if (Stat.startsWith("Buffer Allocator (Main)")) {
                        Section = "BAM";
                    } else if (Stat.startsWith("Buffer Allocator (Temporary)")) {
                        Section = "BAT";
                    } else if (Stat.startsWith("Prefetch Manager (Main)")) {
                        Section = "PFM";
                    } else if (Stat.startsWith("Prefetch Manager (Temporary)")) {
                        Section = "PFT";
                    } else if (Stat.startsWith("IQ Store (Main) Free List")) {
                        Section = "FLM";
                    } else if (Stat.startsWith("IQ Store (Temporary) Free List")) {
                        Section = "FLT";
                    } else if (Stat.startsWith("Memory Manager")) {
                        Section = "MEM";
                    } else if (Stat.startsWith("Thread Manager")) {
                        Section = "threads";
                    } else if (Stat.startsWith("CPU time statistics")) {
                        Section = "cpu";
                    } else if (Stat.startsWith("Transaction Manager")) {
                        Section = "txn";
                    } else if (Stat.startsWith("Context Server statistics")) {
                        Section = "SRV";
                    } else if (Stat.startsWith("Catalog, DB Log, and Repository  statistics")) {
                        Section = "CLG";
                    } else if (Stat.startsWith("IQ In-Memory Store")) {
                        Section = "ims";
                    } else if (Stat.startsWith("Large Memory Allocator")) {
                        Section = "LMA";
                    }
                    continue;
                }

                if (f1 == null) {
                    continue; // Skip row if Value is null
                }
                if ("".equals(f1)) {
                    continue;
                }
                if (Stat.startsWith("STATS-NAME")) {
                    continue;
                }
                if (Stat.startsWith("Unknown")) {
                    continue;
                }
                // System.out.println(Section+"_"+Stat+" = "+f1);
                

                if (!Section.equals("")) {
                    // BufMan
                    if (Stat.startsWith("Hit%")) {
                        Stat = "HitPercent";
                    } // Prefetch
                    else if (Stat.compareTo("Load Pass 2")==0) {
                        Stat = "Load_Pass_2";
                    }
                  
          


        
        
                    
                    else if (Stat.startsWith("Large Memory Flexible %")) {
                        Stat = "Flexible_Percent";
                    }
                    else if (Stat.startsWith("Large Memory Inflexible %")) {
                        Stat = "Inflexible_Percent";
                    }
                    else if (Stat.startsWith("Large Memory Anti-Starvation %")) {
                        Stat = "Anti_Starvation_Percent";
                    }
                    else if (Stat.startsWith("Large Memory Space")) {
                        Stat = "Space";
                    }
                    else if (Stat.startsWith("Large Memory Max Flexible")) {
                        Stat = "Max_Flexible";
                    }
                    else if (Stat.startsWith("Large Memory Num Flex Allocations")) {
                        Stat = "Num_Flex_Allocations";
                    }
                    else if (Stat.startsWith("Large Memory Flexible used")) {
                        Stat = "Flexible_used";
                    }
                    else if (Stat.startsWith("Large Memory Inflexible used")) {
                        Stat = "Inflexible_used";
                    }
                    else if (Stat.startsWith("Large Memory Num Connections")) {
                        Stat = "Num_Connections";
                    }
                    
                    
                    else if (Stat.startsWith("PFMgrCondVar")) {
                        appendInsert(Section, "PFMgrCondVar_Locks", f1, 1, false);
                        continue;
                    } // Freelist
                    else if (Stat.startsWith("FLIsOutOfSpace")) {
                        Stat = "FLIsOutOfSpace";
                        appendInsert(Section, Stat, f1, true);
                        continue;
                    } // CPU
                    else if (Stat.startsWith("Elapsed Seconds")) {
                        Stat = "ElapsedSec";
                    } else if (Stat.startsWith("CPU User Seconds")) {
                        Stat = "CPUUserSec";
                    } else if (Stat.startsWith("CPU Sys Seconds")) {
                        Stat = "CPUSysSec";
                    } else if (Stat.startsWith("CPU Total Seconds")) {
                        Stat = "CPUTotalSec";
                    } // Catalog
                    else if (Stat.startsWith("CatalogLock")) {
                        appendInsert("CLG", "CatalogLock_RdLocks", f1, 1, false);
                        appendInsert("CLG", "CatalogLock_RdWaits", rs.getString(3), 1, false);
                        appendInsert("CLG", "CatalogLock_RdTryFails", rs.getString(4), 1, false);
                        appendInsert("CLG", "CatalogLock_WrLocks", rs.getString(5), 1, false);
                        appendInsert("CLG", "CatalogLock_WrWaits", rs.getString(6), 1, false);
                        appendInsert("CLG", "CatalogLock_WrTryFails", rs.getString(7), 1, false);
                        continue;
                    } else if (Stat.startsWith("DbLogMLock")) {
                        appendInsert("CLG", "DbLogMLock_Locks", f1, 1, false);
                        appendInsert("CLG", "DbLogMLock_LockWaits", rs.getString(3), 1, false);
                        continue;
                    } else if (Stat.startsWith("DbLogSLock")) {
                        appendInsert("CLG", "DbLogSLock_Locks", f1, 1, false);
                        appendInsert("CLG", "DbLogSLock_LockWaits", rs.getString(3), 1, false);
                        continue;
                    } else if (Stat.startsWith("RepositoryLock")) {
                        appendInsert("CLG", "RepositoryLock_Locks", f1, 1, false);
                        appendInsert("CLG", "RepositoryLock_SpinsWoTO", rs.getString(3), 1, false);
                        appendInsert("CLG", "RepositoryLock_Spins", rs.getString(4), 1, false);
                        appendInsert("CLG", "RepositoryLock_TimeOuts", rs.getString(5), 1, false);
                        continue;
                    } // Txn
                    else if (Stat.startsWith("TxnMgrPCcondvar")) {
                        appendInsert("txn", "PCcondvar_Locks", f1, 1, false);
                        appendInsert("txn", "PCcondvar_LockWaits", rs.getString(3), 1, false);
                        appendInsert("txn", "PCcondvar_Signals", rs.getString(4), 1, false);
                        appendInsert("txn", "PCcondvar_Broadcasts", rs.getString(5), 1, false);
                        appendInsert("txn", "PCcondvar_Waits", rs.getString(5), 1, false);
                        continue;
                    } else if (Stat.startsWith("TxnMgrtxncblock")) {
                        appendInsert("txn", "txncblock_Locks", f1, 1, false);
                        appendInsert("txn", "txncblock_LockWaits", rs.getString(3), 1, false);
                        continue;
                    } else if (Stat.startsWith("TxnMgrVersionLock")) {
                        appendInsert("txn", "VersionLock_Locks", f1, 1, false);
                        appendInsert("txn", "VersionLock_LockWaits", rs.getString(3), 1, false);
                        appendInsert("txn", "VersionLock_Signals", rs.getString(4), 1, false);
                        appendInsert("txn", "VersionLock_Broadcasts", rs.getString(5), 1, false);
                        appendInsert("txn", "VersionLock_Waits", rs.getString(5), 1, false);
                        continue;
                    } else if (Stat.startsWith("TxnMgrNPending")) {
                        Stat = "NPending";
                    } else if (Stat.startsWith("TxnMgrNBlocked")) {
                        Stat = "NBlocked";
                    } else if (Stat.startsWith("TxnMgrNWaiting")) {
                        Stat = "NWaiting";
                    } else if (Stat.startsWith("TxnMgrTxnIDseq")) {
                        Stat = "TxnIDseq";
                    } else if (Stat.startsWith("TxnMgrVersionID")) {
                        Stat = "VersionID";
                    } else if (Stat.startsWith("TxnMgrOAVI")) {
                        Stat = "OAVI";
                    } // Server
                    else if (Stat.startsWith("StCntxLock")) {
                        appendInsert("SRV", "StCntxLock_Locks", f1, 1, false);
                        appendInsert("SRV", "StCntxLock_LockWaits", rs.getString(3), 1, false);
                        continue;
                    } else if (Stat.startsWith("StCntxCondVar")) {
                        appendInsert("SRV", "StCntxCondVar_Locks", f1, 1, false);
                        appendInsert("SRV", "StCntxCondVar_LockWaits", rs.getString(3), 1, false);
                        continue;
                    }

                    // Check if indicator has detail information 
                    Stat = Stat.trim();
                    // Replace blanks by underscore
                    Stat = Stat.replaceAll(" ", "_");

                    hasDetail2 = indicWithDetail2.containsKey(Stat);
                    hasDetail3 = indicWithDetail3.containsKey(Stat);
                    
                    if (hasDetail2) {
                        String f2 = rs.getString(3);
                        String f3 = rs.getString(4);
                        String f4 = rs.getString(5);
                        String f5 = rs.getString(6);
                        String f6 = rs.getString(7);
                        String f7 = rs.getString(8);
                        String f8 = rs.getString(9);
                        String f9 = rs.getString(10);
                        String f10 = rs.getString(11);
                        String f11 = rs.getString(12);
                        String f12 = rs.getString(13);
                        String f13 = rs.getString(14);
                        String f14 = rs.getString(15);
                        String f15 = rs.getString(16);
                        String f16 = rs.getString(17);
                        String f17 = rs.getString(18);
                        String f18 = rs.getString(19);
                        String f19 = rs.getString(20);
                        String f20 = rs.getString(21);
                        String f21 = rs.getString(22);
                        String f22 = rs.getString(23);
                        String f23 = rs.getString(24);
                        
                        if (msrv.versionStr.compareTo("16") >= 0) {
                            //V16
                            String f24 = rs.getString(25);
                            String f25 = rs.getString(26);
                            String f26 = rs.getString(27);
                            String f27 = rs.getString(28);
                            appendInsert2(Section, Stat, f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11, f12, f13, f14, f15, f16, f17, f18, f19, f20, f21, f22, f23, f24, f25, f26, f27);
                        }
                        else
                            // V15
                            appendInsert2(Section, Stat, f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11, f12, f13, f14, f15, f16, f17, f18, f19, f20, f21, f22, f23);
                            
                    }
                    else if (hasDetail3) {
                        String f2 = rs.getString(3);
                        String f3 = rs.getString(4);
                        String f4 = rs.getString(5);
                        String f5 = rs.getString(6);
                        String f6 = rs.getString(7);
                        String f7 = rs.getString(8);
                        String f8 = rs.getString(9);
                        String f9 = rs.getString(10);
                        String f10 = rs.getString(11);
                        String f11 = rs.getString(12);
                        String f12 = rs.getString(13);
                        String f13 = rs.getString(14);
                        String f14 = rs.getString(15);
                        String f15 = rs.getString(16);
                        String f16 = rs.getString(17);
                        String f17 = rs.getString(18);

                        appendInsert3(Section, Stat, f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11, f12, f13, f14, f15, f16, f17);

                    }
                    else
                        // default insert
                        appendInsert(Section, Stat, f1, false);
                }
            }
            stmt.close();

            newTime = new Timestamp(System.currentTimeMillis() + msrv.timeAdjust.value());
            // Compute the time interval in ms
            long newTsMilli = newTime.getTime();
            long oldTsMilli = oldTime.getTime();
            int newTsNano = newTime.getNanos();
            int oldTsNano = oldTime.getNanos();
            // Check if TsMilli has really ms precision (not the case before JDK 1.4)
            if ((newTsMilli - (newTsMilli / 1000) * 1000) == newTsNano / 1000000) // JDK > 1.3.1
            {
                interval = newTsMilli - oldTsMilli;
            } else {
                interval = newTsMilli - oldTsMilli + (newTsNano - oldTsNano) / 1000000;
            }
        } catch (Exception e) {
            throw e;
        }

        StringBuffer sql_insert = new StringBuffer("");
        Statement stmtArch = null;
        
        // Get an archive connection from the pool
        CnxMgr.ArchCnx aArchCnx = CnxMgr.archCnxPool.getArchCnx(false);
        archCnxWaitTime = aArchCnx.waitedFor;
        String tablename = "";
        try {
            if (stmtArch == null) {
                stmtArch = aArchCnx.archive_conn.createStatement();
            }
            aArchCnx.archive_conn.setAutoCommit(false);
            tablename = srvName + "_IQSysmon1";
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon1"
                + "( Timestamp, Interval, " + sql_insert1_columns + " )"
                + " values ( '" + newTime + "', " + interval + ", " + sql_insert1_values + " )");
            stmtArch.executeUpdate(sql_insert.toString());

            tablename = srvName + "_IQSysmon2";
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon2" + "( Timestamp, Interval, indicdetail, " + sql_insert2_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'TOTAL ', " + sql_insert2_values_TOTAL   + " )");
            stmtArch.executeUpdate(sql_insert.toString());
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon2" + "( Timestamp, Interval, indicdetail, " + sql_insert2_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'NONE  ', " + sql_insert2_values_NONE    + " )");
            stmtArch.executeUpdate(sql_insert.toString());
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon2" + "( Timestamp, Interval, indicdetail, " + sql_insert2_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'TXTPOS', " + sql_insert2_values_TXTPOS  + " )");
            stmtArch.executeUpdate(sql_insert.toString());
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon2" + "( Timestamp, Interval, indicdetail, " + sql_insert2_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'TXTDOC', " + sql_insert2_values_TXTDOC  + " )");
            stmtArch.executeUpdate(sql_insert.toString());
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon2" + "( Timestamp, Interval, indicdetail, " + sql_insert2_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'CMPACT', " + sql_insert2_values_CMPACT  + " )");
            stmtArch.executeUpdate(sql_insert.toString());
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon2" + "( Timestamp, Interval, indicdetail, " + sql_insert2_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'BTREEV', " + sql_insert2_values_BTREEV  + " )");
            stmtArch.executeUpdate(sql_insert.toString());
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon2" + "( Timestamp, Interval, indicdetail, " + sql_insert2_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'BTREEF', " + sql_insert2_values_BTREEF  + " )");
            stmtArch.executeUpdate(sql_insert.toString());
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon2" + "( Timestamp, Interval, indicdetail, " + sql_insert2_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'BV    ', " + sql_insert2_values_BV      + " )");
            stmtArch.executeUpdate(sql_insert.toString());
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon2" + "( Timestamp, Interval, indicdetail, " + sql_insert2_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'VDO   ', " + sql_insert2_values_VDO     + " )");
            stmtArch.executeUpdate(sql_insert.toString());
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon2" + "( Timestamp, Interval, indicdetail, " + sql_insert2_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'DBEXT ', " + sql_insert2_values_DBEXT   + " )");
            stmtArch.executeUpdate(sql_insert.toString());
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon2" + "( Timestamp, Interval, indicdetail, " + sql_insert2_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'DBID  ', " + sql_insert2_values_DBID    + " )");
            stmtArch.executeUpdate(sql_insert.toString());
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon2" + "( Timestamp, Interval, indicdetail, " + sql_insert2_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'SORT  ', " + sql_insert2_values_SORT    + " )");
            stmtArch.executeUpdate(sql_insert.toString());
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon2" + "( Timestamp, Interval, indicdetail, " + sql_insert2_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'STORE ', " + sql_insert2_values_STORE   + " )");
            stmtArch.executeUpdate(sql_insert.toString());
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon2" + "( Timestamp, Interval, indicdetail, " + sql_insert2_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'GARRAY', " + sql_insert2_values_GARRAY  + " )");
            stmtArch.executeUpdate(sql_insert.toString());
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon2" + "( Timestamp, Interval, indicdetail, " + sql_insert2_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'BARRAY', " + sql_insert2_values_BARRAY  + " )");
            stmtArch.executeUpdate(sql_insert.toString());
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon2" + "( Timestamp, Interval, indicdetail, " + sql_insert2_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'BLKMAP', " + sql_insert2_values_BLKMAP  + " )");
            stmtArch.executeUpdate(sql_insert.toString());
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon2" + "( Timestamp, Interval, indicdetail, " + sql_insert2_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'HASH  ', " + sql_insert2_values_HASH    + " )");
            stmtArch.executeUpdate(sql_insert.toString());
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon2" + "( Timestamp, Interval, indicdetail, " + sql_insert2_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'CKPT  ', " + sql_insert2_values_CKPT    + " )");
            stmtArch.executeUpdate(sql_insert.toString());
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon2" + "( Timestamp, Interval, indicdetail, " + sql_insert2_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'BM    ', " + sql_insert2_values_BM      + " )");
            stmtArch.executeUpdate(sql_insert.toString());
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon2" + "( Timestamp, Interval, indicdetail, " + sql_insert2_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'TEST  ', " + sql_insert2_values_TEST    + " )");
            stmtArch.executeUpdate(sql_insert.toString());
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon2" + "( Timestamp, Interval, indicdetail, " + sql_insert2_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'CMID  ', " + sql_insert2_values_CMID    + " )");
            stmtArch.executeUpdate(sql_insert.toString());
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon2" + "( Timestamp, Interval, indicdetail, " + sql_insert2_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'RIDCA ', " + sql_insert2_values_RIDCA   + " )");
            stmtArch.executeUpdate(sql_insert.toString());
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon2" + "( Timestamp, Interval, indicdetail, " + sql_insert2_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'LOB   ', " + sql_insert2_values_LOB     + " )");
            stmtArch.executeUpdate(sql_insert.toString());
            
            if (msrv.versionStr.compareTo("16") >= 0) {
                // V16
                sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon2" + "( Timestamp, Interval, indicdetail, " + sql_insert2_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'LVCRID', " + sql_insert2_values_LVCRID     + " )");
                stmtArch.executeUpdate(sql_insert.toString());
                sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon2" + "( Timestamp, Interval, indicdetail, " + sql_insert2_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'FILE  ', " + sql_insert2_values_FILE     + " )");
                stmtArch.executeUpdate(sql_insert.toString());
                sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon2" + "( Timestamp, Interval, indicdetail, " + sql_insert2_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'RIDMAP', " + sql_insert2_values_RIDMAP     + " )");
                stmtArch.executeUpdate(sql_insert.toString());
                sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon2" + "( Timestamp, Interval, indicdetail, " + sql_insert2_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'RVLOG ', " + sql_insert2_values_RVLOG     + " )");
                stmtArch.executeUpdate(sql_insert.toString());
            }

            tablename = srvName + "_IQSysmon3";
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon3" + "( Timestamp, Interval, indicdetail, " + sql_insert3_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'TOTAL ', " + sql_insert3_values_TOTAL     + " )");
            stmtArch.executeUpdate(sql_insert.toString());
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon3" + "( Timestamp, Interval, indicdetail, " + sql_insert3_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'UNKNWN ', " + sql_insert3_values_UNKNWN     + " )");
            stmtArch.executeUpdate(sql_insert.toString());
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon3" + "( Timestamp, Interval, indicdetail, " + sql_insert3_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'HASH ', " + sql_insert3_values_HASH     + " )");
            stmtArch.executeUpdate(sql_insert.toString());
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon3" + "( Timestamp, Interval, indicdetail, " + sql_insert3_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'CSORT', " + sql_insert3_values_CSORT     + " )");
            stmtArch.executeUpdate(sql_insert.toString());
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon3" + "( Timestamp, Interval, indicdetail, " + sql_insert3_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'ROW ', " + sql_insert3_values_ROW     + " )");
            stmtArch.executeUpdate(sql_insert.toString());
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon3" + "( Timestamp, Interval, indicdetail, " + sql_insert3_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'ROWCOL', " + sql_insert3_values_ROWCOL     + " )");
            stmtArch.executeUpdate(sql_insert.toString());
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon3" + "( Timestamp, Interval, indicdetail, " + sql_insert3_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'FP ', " + sql_insert3_values_FP     + " )");
            stmtArch.executeUpdate(sql_insert.toString());
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon3" + "( Timestamp, Interval, indicdetail, " + sql_insert3_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'GARRAY', " + sql_insert3_values_GARRAY     + " )");
            stmtArch.executeUpdate(sql_insert.toString());
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon3" + "( Timestamp, Interval, indicdetail, " + sql_insert3_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'LOB ', " + sql_insert3_values_LOB     + " )");
            stmtArch.executeUpdate(sql_insert.toString());
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon3" + "( Timestamp, Interval, indicdetail, " + sql_insert3_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'BTREE ', " + sql_insert3_values_BTREE     + " )");
            stmtArch.executeUpdate(sql_insert.toString());
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon3" + "( Timestamp, Interval, indicdetail, " + sql_insert3_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'BM ', " + sql_insert3_values_BM     + " )");
            stmtArch.executeUpdate(sql_insert.toString());
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon3" + "( Timestamp, Interval, indicdetail, " + sql_insert3_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'BV ', " + sql_insert3_values_BV     + " )");
            stmtArch.executeUpdate(sql_insert.toString());
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon3" + "( Timestamp, Interval, indicdetail, " + sql_insert3_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'STORE ', " + sql_insert3_values_STORE     + " )");
            stmtArch.executeUpdate(sql_insert.toString());
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon3" + "( Timestamp, Interval, indicdetail, " + sql_insert3_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'TEST ', " + sql_insert3_values_TEST     + " )");
            stmtArch.executeUpdate(sql_insert.toString());
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon3" + "( Timestamp, Interval, indicdetail, " + sql_insert3_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'DBCC ', " + sql_insert3_values_DBCC     + " )");
            stmtArch.executeUpdate(sql_insert.toString());
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon3" + "( Timestamp, Interval, indicdetail, " + sql_insert3_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'BLKMAP ', " + sql_insert3_values_BLKMAP     + " )");
            stmtArch.executeUpdate(sql_insert.toString());
            sql_insert = new StringBuffer("insert into " + srvName + "_IQSysmon3" + "( Timestamp, Interval, indicdetail, " + sql_insert3_columns + " )" + " values ( '" + newTime + "', " + interval + ", 'IQUTIL', " + sql_insert3_values_IQUTIL    + " )");
            stmtArch.executeUpdate(sql_insert.toString());

            
            
            aArchCnx.archive_conn.commit();
        } catch (SQLException sqle) {
            System.err.println("SQL in error: " + sql_insert);
            AsemonSQLException asemonEx = new AsemonSQLException(sqle.getMessage(), sqle.getSQLState(), sqle.getErrorCode(), "ARCH", tablename);
            throw asemonEx;
        } finally {
            aArchCnx.archive_conn.rollback();
            aArchCnx.archive_conn.setAutoCommit(true);
            // Return archive connection to the pool
            archCnxActiveTime = CnxMgr.archCnxPool.putArchCnx(aArchCnx);
        }

        oldTime = newTime;
        archRows = 1;          // One row archived
    }
}

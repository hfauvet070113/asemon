/**
* <p>ASMUtils</p>
* <p>Asemon_logger :  various utility functions</p>
* <p>Copyright: Jean-Paul Martin (jpmartin@sybase.com) Copyright (c) 2017</p>
* @version 3.1.14
*/

package asemon_logger;

import static asemon_logger.Asemon_logger.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.regex.*;





public class ASMUtils {

  private static class Paramdesc {
      String type;
      int start;
      int end;
      Paramdesc(String t, int s, int e) {
          type = t;
          start = s;
          end = e;
      }
  }

  private static class InList {
        int start;
        int end;
        String collapsedParamName;
        InList (int a, int b, String c) {
            start = a;
            end = b;
            collapsedParamName = c;
        }
  }
    
    
  public static int endOfLine (String SQL, int pos) {
      char c;
      char nextc;
      int i;
      for (i=pos; i < SQL.length(); i++) {
          c = SQL.charAt(i);
          if ( (c != '\r') && (c != '\n') )
              continue;
          nextc = ' ';
          if (i < SQL.length()-1) {
              nextc = SQL.charAt(i+1);
              if (nextc == '\n') {
                  i++;
              }
          }
          break;
      }
      return i;
  }

  public static int endOfComment (String SQL, int pos) {
      char c;
      char nextc;
      int i;
      int level=1;
      for (i=pos; i < SQL.length(); i++) {
          c = SQL.charAt(i);
          if ( (c=='/') && (SQL.charAt(i+1)=='*')) {
              // new imbedded comment
              level++;
              i++;
              continue;
          }
          if (c != '*')
              continue;
          nextc = ' ';
          if (i < SQL.length()-1) {
              nextc = SQL.charAt(i+1);
              if (nextc == '/') {
                  i++;
                  if (level==1)
                      break;
                  else
                      level--;
              }
          }
      }
      return i;
  }

  public static boolean nextCharIsNum(String SQL,int pos) {
      char nextc = ' ';
      if (pos < SQL.length()-1) {
          nextc = SQL.charAt(pos+1);
          switch (nextc) {
                  case '0' :
                  case '1' :
                  case '2' :
                  case '3' :
                  case '4' :
                  case '5' :
                  case '6' :
                  case '7' :
                  case '8' :
                  case '9' :
                  case '.' :
                      return true;
                  default :
                      return false;
          }
      }
      return false;
  }

  public static int endOfNum(String SQL,int pos) {
      char c;
      int i;
      boolean prevCharIsE = false;
      for (i=pos; i < SQL.length(); i++) {
          c = SQL.charAt(i);
          switch (c) {
              case '0' :
              case '1' :
              case '2' :
              case '3' :
              case '4' :
              case '5' :
              case '6' :
              case '7' :
              case '8' :
              case '9' :
              case '.' :
                  continue;
              case 'e' :
              case 'E' :
                  prevCharIsE = true;
                  continue;
              case '-' :
              case '+' :
                  if (prevCharIsE) {
                      prevCharIsE = false;
                      continue;
                  }
                  else {
                      return i-1;
                  }
              default :
                  return i-1;
          }
      }
      return i-1;
  }

  public static int endOfHexa(String SQL, int pos) {
      char c;
      int i;
      for (i=pos; i < SQL.length(); i++) {
          c = Character.toUpperCase(SQL.charAt(i));
          switch (c) {
              case '0' :
              case '1' :
              case '2' :
              case '3' :
              case '4' :
              case '5' :
              case '6' :
              case '7' :
              case '8' :
              case '9' :
              case 'A' :
              case 'B' :
              case 'C' :
              case 'D' :
              case 'E' :
              case 'F' :
                  continue;
              default :
                  return i-1;
          }
      }
      return i-1;
  }
  
  public static int endOfAlphanum(String SQL, int pos, char delim) {
      char c;
      char nextc;
      int i;
      for (i=pos; i < SQL.length(); i++) {
          c = SQL.charAt(i);
          if (c != delim)
              continue;
          else {
              nextc = ' ';
              if (i < SQL.length()-1) {
                  nextc = SQL.charAt(i+1);
                  if (nextc == delim) {
                      // embedded quote, skip
                      i++;
                      continue;
                  }
                  break; // found end of string
              }
              break;  // found end of string
          }
      }
      return i;
  }

  public static String parameterize (String SQL, Boolean ignoreDoubleQuotes) {
      DEBUG(DBG115, "SQL before parametrization = \n"+SQL);
      StringBuffer newSQLnoParamNumber = new StringBuffer();
      StringBuffer newSQLnoParamNumberCollapsedInList = new StringBuffer();
      StringBuffer newSQLwithParamNumber = new StringBuffer();
      ArrayList<Paramdesc> params = new ArrayList();
      boolean prevCharIsSep = false;
      char c;
      char nextc;
      int startparam;
      Paramdesc aParam;
      
      boolean gotStringIndexOutOfBoundsException = false;
      
    try {
          
      for (int i=0; i< SQL.length(); i++) {
          c = SQL.charAt(i);
          switch (c) {
              case '-' :
              // Find comment introduced by --
                  nextc = ' ';
                  if (i < SQL.length()-1) {
                      nextc = SQL.charAt(i+1);
                      if (nextc == '-') {
                          // This is a comment introduced by '--'
                          // Find end of line
                          i = endOfLine(SQL,i+2);
                          prevCharIsSep = true;
                      }
                      else {
                          if (prevCharIsSep && nextCharIsNum(SQL, i)) {
                              // This is a num param
                              startparam = i;
                              i = endOfNum (SQL,i+2);
                              aParam = new Paramdesc ("num", startparam, i);
                              params.add(aParam);
                              prevCharIsSep = false;
                          }
                          else
                              prevCharIsSep = true;
                      }
                  }
                  break;
              case '/' :
                  // Find comment introduced by /*
                  nextc = ' ';
                  if (i < SQL.length()-1) {
                      nextc = SQL.charAt(i+1);
                      if (nextc == '*') {
                          // This is a comment introduced by '/*'
                          i = endOfComment(SQL,i+2);
                      }
                  }
                  prevCharIsSep = true;
                  break;
              case '+':
                  if (prevCharIsSep && nextCharIsNum(SQL, i)) {
                      startparam = i;
                      i = endOfNum (SQL,i+2);
                      aParam = new Paramdesc ("num", startparam, i);
                      params.add(aParam);
                      prevCharIsSep = false;
                  }
                  else
                      prevCharIsSep = true;
                  break;

              case '0':
              case '1':
              case '2':
              case '3':
              case '4':
              case '5':
              case '6':
              case '7':
              case '8':
              case '9':
                  if (c == '0') {
                      // Find hexa introduced by 0x
                      nextc = ' ';
                      if (i < SQL.length()-1) {
                          nextc = SQL.charAt(i+1);
                          if ( (nextc == 'x') || (nextc == 'X') ){
                              // This is a hexa param introduced by '0x'
                              startparam = i;
                              i = endOfHexa(SQL,i+2);
                              aParam = new Paramdesc ("hexa", startparam, i);
                              params.add(aParam);
                              continue;
                          }
                      }
                  }
                  if (prevCharIsSep) {
                      startparam = i;
                      i = endOfNum (SQL,i+1);
                      aParam = new Paramdesc ("num", startparam, i);
                      params.add(aParam);
                  }
                  prevCharIsSep = false;
                  break;
              case ' ':
              case ',':
              case '\t':
              case '\n':
              case '\r':
              case '(':
              case ')':
              case '*':
              case '=':
              case '<':
              case '>':
                  prevCharIsSep = true;
                  break;
              case '\'' :
                  // alphanum param between simple quotes
                  startparam = i;
                  i = endOfAlphanum (SQL,i+1, '\'');
                  aParam = new Paramdesc ("alpha", startparam, i);
                  params.add(aParam);
                  prevCharIsSep = true;
                  break;
              case '"' :
                  if (ignoreDoubleQuotes)
                      break;
                  // alphanum param between double quotes
                  startparam = i;
                  i = endOfAlphanum (SQL,i+1, '"');
                  aParam = new Paramdesc ("alpha", startparam, i);
                  params.add(aParam);
                  prevCharIsSep = true;
                  break;
              default :
                  prevCharIsSep = false;
                  break;
          }
      }
      
      if (!params.isEmpty()) {
          Iterator iter = params.iterator();
          int startSQL = 0;
          int endSQL;
          while(iter.hasNext()) {
              aParam = (Paramdesc)iter.next();
              endSQL = aParam.start;
              newSQLnoParamNumber.append(SQL.substring(startSQL, endSQL));
              newSQLnoParamNumber.append("@@@V");
              startSQL = aParam.end + 1;
          }
          int sqllen = SQL.length();
          if (startSQL < sqllen )
              newSQLnoParamNumber.append(SQL.substring(startSQL, sqllen));
      }
      else
          newSQLnoParamNumber.append(SQL);


      // Collapse IN-LISTs
      Pattern pattern;
      Matcher matcher;
      int len, pos, startPos=0, endPos=0, level, numInList=0;
      String wd[]; 
      if (!skipCollapseInLists) {
          // search IN-LISTs
          String temp_inlist;
          LinkedList<InList> INLISTs = new java.util.LinkedList<InList>();
          pattern = Pattern.compile("[ \n]+in[ \n]*[(]", Pattern.CASE_INSENSITIVE);
          matcher = pattern.matcher(newSQLnoParamNumber);
          len = newSQLnoParamNumber.length();
          while (true) {
              if (!matcher.find()) break;
              startPos = matcher.end();

              // Check if this IN-list is defined by a SELECT
              if (startPos+10 < len) {
                  wd = newSQLnoParamNumber.substring(startPos, startPos+10).replaceAll("\\n", " ").trim().split(" ");
                  if (wd[0].compareToIgnoreCase("SELECT") == 0)
                      continue;
              }
              
              
              // find the rigth parenthesis of the IN-LIST (IN-LIST can include expressions with parenthesis
              pos = startPos;
              level = 0;
              boolean found=false;
              while (pos < len-1) {
                  pos++;
                  c=newSQLnoParamNumber.charAt(pos);
                  switch (c) {
                      case ')' :
                          endPos=pos;
                          if (level==0) found=true;
                          else level--;
                          break;
                      case '(' :
                          level ++;
                          break;
                      case '-' :
                          if ((pos+1 < len-1) && (newSQLnoParamNumber.charAt(pos+1) == '-') ) {
                              // ignore this comment in in-list
                              pos = newSQLnoParamNumber.indexOf("\n", pos);
                          }
                  }
                  if (found) break;
              }
              if (!found) {
                  // Not found because the SQL may be truncated (because of 'max SQL text monitored')
                  endPos = pos;
                  DEBUG(DBG115,"in list truncated = "+newSQLnoParamNumber.substring(startPos-1, endPos+1));
                  numInList++;
                  INLISTs.add(new InList(startPos-1, endPos+1, "( @@@CollapsedInList"+numInList+" )"));
              }
              else {
                  
                  DEBUG(DBG115,"in list = "+newSQLnoParamNumber.substring(startPos-1, endPos+1));
                  // Found begin / end of in list. 
                  temp_inlist=newSQLnoParamNumber.substring(startPos, endPos).replaceAll("(@@@V)|[,\n ]*", "");
                  temp_inlist=temp_inlist.replaceAll("[?,]", "");   // Consider in-lists for prepared statements like : (?,?,?,?)
                  if (temp_inlist.length()==0) {
                      // This in-list doesn't contain expression or SELECT, this is pure list of values         
                      // Save this in list in HashMap
                      numInList++;
                      INLISTs.add(new InList(startPos-1, endPos+1, "( @@@CollapsedInList"+numInList+" )"));
                  }
              }
              // Look for next INLIST
              startPos = endPos;
          }
          if (INLISTs.size()!=0) { 
              DEBUG(DBG115, "SQL before collapse inlist = \n"+newSQLnoParamNumber);
              // Substitute collapsed in-list in SQL
              Iterator iter = INLISTs.iterator();
              int startSQL = 0;
              int endSQL;
              int sqllen;
              InList aInList;
              while(iter.hasNext()) {
                  aInList = (InList)iter.next();
                  endSQL = aInList.start;
                  newSQLnoParamNumberCollapsedInList.append(newSQLnoParamNumber.substring(startSQL, endSQL));
                  newSQLnoParamNumberCollapsedInList.append(aInList.collapsedParamName);
                  startSQL = aInList.end;
              }
              sqllen = newSQLnoParamNumber.length();
              if (startSQL < sqllen )
                  newSQLnoParamNumberCollapsedInList.append(newSQLnoParamNumber.substring(startSQL, sqllen));
          }
          else
              newSQLnoParamNumberCollapsedInList=newSQLnoParamNumber;
      }
      else
          newSQLnoParamNumberCollapsedInList=newSQLnoParamNumber;
      
      DEBUG(DBG115, "SQL before param numbering = \n"+newSQLnoParamNumberCollapsedInList);
      
      // Number parameters starting with @@@V
      pattern = Pattern.compile("@@@V");
      matcher = pattern.matcher(newSQLnoParamNumberCollapsedInList);
      int numparam=0;
      int startSQL =0;
      int sqllen = newSQLnoParamNumberCollapsedInList.length();
      endPos=0;
      while (true) {
          if (!matcher.find()) break;
          endPos = matcher.end();
          newSQLwithParamNumber.append(newSQLnoParamNumberCollapsedInList.substring(startSQL, endPos));
          newSQLwithParamNumber.append(numparam);
          startSQL=endPos;
          numparam++;
      }
      if (endPos < sqllen )
          newSQLwithParamNumber.append(newSQLnoParamNumberCollapsedInList.substring(endPos, sqllen));
      
      //DEBUG(DBG115, "\nSQL after parametrization (length="+newSQLwithParamNumber.length()+") =\n"+newSQLwithParamNumber.toString().replaceAll("\r","R").replaceAll("\n","N").replaceAll(" ","B"));
      DEBUG(DBG115, "SQL after parametrization (length="+newSQLwithParamNumber.length()+") =\n"+newSQLwithParamNumber);

    }

      
    catch (StringIndexOutOfBoundsException e)       {
          gotStringIndexOutOfBoundsException = true;
          ERROR(e.getMessage()+"\nSQL :\n"+SQL);
          e.printStackTrace();
    }
      
    if (gotStringIndexOutOfBoundsException)
        return SQL;
    else
        return newSQLwithParamNumber.toString();
  }

  
  public static String normStr (String SQL) {
    // Replace \r by \n    
    SQL = SQL.replaceAll("[\r]+", "\n");

    DEBUG(DBG116, "normStr : SQL = " + SQL);
//for (StackTraceElement ste : Thread.currentThread().getStackTrace()) {
//    System.out.println(ste);
//}
    // FOR TEST !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    //SQL = SQL.replaceAll("\n", "\\$");
    
    try {
        // Remove comments defined between /* and */
        int startsb=0;
        Pattern pattern;
        Matcher matcher;
        pattern = Pattern.compile("\\/\\*");
        StringBuffer sb = new StringBuffer();    
        matcher = pattern.matcher(SQL);
        int len = SQL.length();
        while (1==1) {
            if (startsb >= len)
                // Found end of comment at end of SQL, or comment is truncated due to SQL truncated, don't copy to sb
                break;
            // Start search at at biginning of string or at the end of last search
            if ( (startsb<len) && (!matcher.find(startsb)) ) {
                sb.append(SQL.substring(startsb));
                break;
            }
            else {
                sb.append(SQL.substring(startsb,matcher.start()));
                // New position to copy to sb after that
                startsb = endOfComment (SQL, matcher.end())+1;
            }
        }

        SQL = sb.toString();

    /*    
        // Remove LF except for rows with comment starting with --
        Boolean foundComment=false;
        for (int i=0; i<sb.length(); i++)     {
            switch (sb.charAt(i)) {
                case '-' :
                    if (i+1 < sb.length()) {
                       if (sb.charAt(i+1) == '-') {
                        foundComment=true;
                        i++;
                       }
                    }
                    break;
                case '\n' :
                    if (foundComment) {
                        // skip this LF
                        foundComment=false;
                    }
                    else
                        // replace LF by space
                        sb.setCharAt(i, ' ');
                    break;
            }
        }
    */
        startsb=0;
        pattern = Pattern.compile("--");
        sb = new StringBuffer();    
        matcher = pattern.matcher(SQL);
        while (1==1) {
            // Start search at at biginning of string or at the end of last search
            if ((startsb < SQL.length() ) && (!matcher.find(startsb)) ) {
                sb.append(SQL.substring(startsb));
                break;
            }
            else {
                sb.append(SQL.substring(startsb,matcher.start()));
                // New position to copy to sb after that
                startsb = SQL.indexOf("\n", matcher.start());
                if (startsb == -1)
                    // end of SQL and no LF at end
                    break;
            }
        }
        SQL = sb.toString();
    }
    catch (Exception e) {
        ERROR("normStr : could not remove comment. Use debug flag 118 to see SQL");
        if ( debug || (debugSwitchs.contains(DBG118)) ) {
            System.out.println("normStr : "+e.getMessage());
            e.printStackTrace(System.out);
            System.out.println("normStr : SQL = " + SQL);            
        }
    }

    // Keep only one \n
    SQL = SQL.replaceAll("[\n]+", "\n");
    // Keep one space in place of TAB and muti spaces
    SQL = SQL.replaceAll("[\t ]+", " ").trim();
    // remove space before \n
    SQL = SQL.replaceAll(" \n+", "\n");

    // Transform @@@Vx_Vtype into @@@V (these variables come from SQLTextFrom_showplan when 'enable literal autoparam is activated'
    /*
    SQL = SQL.replaceAll("@@@V[0-9]+_[A-Z]+[0-9]*[,]{1}", "@@@V,");
    SQL = SQL.replaceAll("@@@V[0-9]+_[A-Z]+[0-9]*[\n]{1}", "@@@V\n");
    SQL = SQL.replaceAll("@@@V[0-9]+_[A-Z]+[0-9]*[ ]{1}", "@@@V ");
    SQL = SQL.replaceAll("@@@V[0-9]+_[A-Z]+[0-9]*[)]{1}", "@@@V)");
    */
    SQL = SQL.replaceAll("@@@V[0-9]+_[A-Z]+[0-9]*", "@@@V");
    
    
    
    if (SQL.matches("^.*DYNAMIC_SQL dyn.*")) {
        int pos = SQL.indexOf(" as ");
        if (pos != -1) {
            SQL = SQL.substring(pos+4);
        }
        else {
            pos = SQL.indexOf(":");
            if (pos != -1) {
                SQL = SQL.substring(pos+1).trim();
            }
        }
    }
    DEBUG(DBG115, "\n\n#################################################################################################\nSQL after normalization = \n"+SQL+"\n\n");
    return SQL;
  }
}

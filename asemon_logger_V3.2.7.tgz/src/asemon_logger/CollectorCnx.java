/**
* <p>CollectorCnx</p>
* <p>Asemon_logger : class managing acquisition of ASE connections info </p>
* <p>Copyright: Jean-Paul Martin (jpmartin@sybase.com) Copyright (c) 2004</p>
* @version 2.7.17
*/

package asemon_logger;
import java.sql.*;

public class CollectorCnx extends Collector {
  String sql;

  String srvName;
  String structName;

  Timestamp oldTimes;
  Timestamp newTimes;

  Timestamp oldloggedindatetime;

  public CollectorCnx (MonitoredSRV ms, MetricDescriptor md) {
      super (ms, md);
      srvName = msrv.srvNormalized;
      structName = metricDescriptor.metricName;
  }

  void initialize () throws Exception {
      super.initialize();

      oldloggedindatetime=new Timestamp(0);
  }

  public void getMetrics ()  throws Exception {
    archRows = -1 ; // in case of error or missing config params, AmStats will show this info

    if (msrv.monSrvConn == null) return;

    Statement stmt;
    try {

      stmt = msrv.monSrvConn.createStatement();
      
      String pname_clause = "program_name=convert(varchar(30), str_replace(program_name+' ',char(0), ' ' )), ";
      if (msrv.maxcharlen > 1)
          pname_clause = "program_name, ";
      
      ResultSet rs = stmt.executeQuery(
" select "+
"   loggedindatetime,"+
"   kpid,"+
"   spid,"+
"   UserName=suser_name(suid),"+
//"   program_name=convert(varchar(30), case when program_name like '<astc>%' then '<astc>' else program_name end ), "+
//"   program_name=convert(varchar(30), case when program_name like '%>%' then left (program_name, charindex('>', program_name)) else program_name end ), "+
    pname_clause +
"   DBName=db_name(dbid),"+
"   execlass,"+
"   ipaddr,"+
//"   hostname,"+
//"   hostprocess=convert(char(8), case when substring(hostprocess,1,1)=char(0) then '' else hostprocess end),"+
"   hostname=convert(varchar(30), str_replace(hostname, char(0), ' ')), "+
"   hostprocess=convert(varchar(30), ltrim(rtrim(str_replace(hostprocess, char(0), ' '))) ),"+
"   clientname,"+
"   clienthostname,"+
"   clientapplname,"+
"   tempdbid=tempdb_id(spid)," +
"   tempdbname=db_name(tempdb_id(spid))" +
" from master.dbo.sysprocesses "+
" where loggedindatetime > '" + oldloggedindatetime.toString() + "'"
      );
      
      Archive_array archive_array = new Archive_array();
      Archive_array.Archive_row aRow;

      archive_array.addColDef("Loggedindatetime", java.sql.Types.TIMESTAMP);
      archive_array.addColDef("Kpid"            , java.sql.Types.INTEGER  );
      archive_array.addColDef("Spid"            , java.sql.Types.INTEGER  );
      archive_array.addColDef("UserName"        , java.sql.Types.VARCHAR  );
      archive_array.addColDef("program_name"    , java.sql.Types.VARCHAR  );
      archive_array.addColDef("DBName"          , java.sql.Types.VARCHAR  );
      archive_array.addColDef("execlass"        , java.sql.Types.VARCHAR  );
      archive_array.addColDef("ipaddr"          , java.sql.Types.VARCHAR  );
      archive_array.addColDef("hostname"        , java.sql.Types.VARCHAR  );
      archive_array.addColDef("hostprocess"     , java.sql.Types.VARCHAR  );
      archive_array.addColDef("clientname"      , java.sql.Types.VARCHAR  );
      archive_array.addColDef("clienthostname"  , java.sql.Types.VARCHAR  );
      archive_array.addColDef("clientapplname"  , java.sql.Types.VARCHAR  );
      archive_array.addColDef("tempdbid"        , java.sql.Types.INTEGER  );
      archive_array.addColDef("tempdbname"      , java.sql.Types.VARCHAR  );

     
      while (rs.next()) {
          oldloggedindatetime=rs.getTimestamp(1);
          aRow = archive_array.allocateNewRow();
          aRow.addValue(oldloggedindatetime);  // Loggedindatetime
          aRow.addValue(rs.getInt(2)    );    // Kpid             
          aRow.addValue(rs.getInt(3)    );    // Spid             
          aRow.addValue(rs.getString(4) );    // UserName         
          aRow.addValue(rs.getString(5) );    // program_name     
          aRow.addValue(rs.getString(6) );    // DBName           
          aRow.addValue(rs.getString(7) );    // execlass         
          aRow.addValue(rs.getString(8) );    // ipaddr           
          aRow.addValue(rs.getString(9) );    // hostname         
          aRow.addValue(rs.getString(10));    // hostprocess      
          aRow.addValue(rs.getString(11));    // clientname       
          aRow.addValue(rs.getString(12));    // clienthostname   
          aRow.addValue(rs.getString(13));    // clientapplname   
          aRow.addValue(rs.getInt(14)   );    // tempdbid         
          aRow.addValue(rs.getString(15));    // tempdbname       
          archive_array.addRow(aRow);         // save this row in the array
      }
      // Save this array into archive database
      Asemon_logger.archive_class.saveValues (srvName+"_"+structName, archive_array, this);




    }
    catch (Exception e) {
    	//System.out.println("Asemon_logger.getCnx. : "+e);
        //e.printStackTrace(System.out);
        throw e;
    }


  } // end getCnx





}
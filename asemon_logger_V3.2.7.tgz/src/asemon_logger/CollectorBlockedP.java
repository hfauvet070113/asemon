/**
* <p>CollectorBlockedP</p>
* <p>Asemon_logger : class managing acquisition of blocked process and associated blocking process and locks</p>
* <p>Copyright: Jean-Paul Martin (jpmartin@sybase.com) Copyright (c) 2004</p>
* @version 3.0
*/

package asemon_logger;
import java.sql.*;

public class CollectorBlockedP extends Collector {

    String sql;

    String srvName;
    String structName;

    Timestamp oldTimes;
    Timestamp newTimes;

    String accessibleDBs;

    public CollectorBlockedP (MonitoredSRV ms, MetricDescriptor aMetricDescriptor) {
        super(ms, aMetricDescriptor);
        srvName = msrv.srvNormalized;
        structName = metricDescriptor.metricName;
    }

    public void getMetrics ()  throws Exception {
        archRows = -1 ; // in case of error or missing config params, AmStats will show this info

        if (msrv.monSrvConn == null) return;

        // Get list of accessible databases (needed for object_name function
        accessibleDBs = CollectorGeneric.getAccessibleDBs(msrv);

        Statement stmt;

        stmt = msrv.monSrvConn.createStatement();

        ResultSet rs = null;
        try {
            rs = stmt.executeQuery(
" set forceplan on"+
" select "+
"     Timestamp=getdate(),"+
"     time_blocked=BlockedSysP.time_blocked,"+
"     blockedSpid=BlockedSysP.spid,   "+
"     blockedUsr=substring(suser_name(BlockedSysP.suid),1,30),"+
"     blockedTran=substring(BlockedSysP.tran_name,1,30),"+
"     blockedProg=substring(BlockedSysP.program_name,1,30),"+
"     blockedProc=substring( (case when BlockedSysP.dbid in "+accessibleDBs+" then  object_name(BlockedSysP.id,BlockedSysP.dbid) else convert(varchar,BlockedSysP.id) end) ,1,30),"+
"     blockedLine=BlockedSysP.linenum,"+

"     blockingSpid=BlockingSysP.spid,"+
"     blockingUsr=substring(suser_name(BlockingSysP.suid),1,30),"+
"     blockingTran=substring(BlockingSysP.tran_name,1,30),"+
"     blockingProg=substring(BlockingSysP.program_name,1,30), "+
"     blockingProc=substring( (case when BlockingSysP.dbid in "+accessibleDBs+" then  object_name(BlockingSysP.id,BlockingSysP.dbid) else convert(varchar,BlockingSysP.id) end) ,1,30),"+
"     blockingLine=BlockingSysP.linenum,"+

"     lckBase=substring(db_name(L.DBID),1,30),"+
"     lckObjet=substring( (case when L.DBID in "+accessibleDBs+" then  object_name(L.ObjectID,L.DBID) else convert(varchar,L.ObjectID) end) ,1,30),"+
"     lckPage=L.PageNumber,"+
"     lckRow=L.RowNumber,"+
"     lckName=L.LockType"+

" from master.dbo.monLocks L,"+
"      master.dbo.sysprocesses BlockedSysP,"+
"      master.dbo.sysprocesses BlockingSysP"+
" where L.LockState='Requested'"+
" and   L.SPID=BlockedSysP.spid"+
" and   BlockedSysP.blocked = BlockingSysP.spid"+
" set forceplan off"
           );
        }
        catch (SQLException e) {
            int errcode = e.getErrorCode();
            if ( (errcode==12052)||(errcode==12036))
                // ignore 12052 error : Collection of monitoring data for table 'xxx' requires that the 'enable monitoring' configuration option(s) be enabled.
                // ignore 12036 error : Collection of monitoring data for table 'xxx' requires that the 'enable monitoring' configuration option(s) be enabled.
                return;
            else throw e;
        }

        try {
            Archive_array archive_array = new Archive_array();
            Archive_array.Archive_row aRow;

            archive_array.addColDef("Timestamp"   , java.sql.Types.TIMESTAMP);
            archive_array.addColDef("time_blocked", java.sql.Types.INTEGER  );
            archive_array.addColDef("blockedSpid" , java.sql.Types.INTEGER  );
            archive_array.addColDef("blockedUsr"  , java.sql.Types.VARCHAR  );
            archive_array.addColDef("blockedTran" , java.sql.Types.VARCHAR  );
            archive_array.addColDef("blockedProg" , java.sql.Types.VARCHAR  );
            archive_array.addColDef("blockedProc" , java.sql.Types.VARCHAR  );
            archive_array.addColDef("blockedLine" , java.sql.Types.INTEGER  );
            archive_array.addColDef("blockingSpid", java.sql.Types.INTEGER  );
            archive_array.addColDef("blockingUsr" , java.sql.Types.VARCHAR  );
            archive_array.addColDef("blockingTran", java.sql.Types.VARCHAR  );
            archive_array.addColDef("blockingProg", java.sql.Types.VARCHAR  );
            archive_array.addColDef("blockingProc", java.sql.Types.VARCHAR  );
            archive_array.addColDef("blockingLine", java.sql.Types.INTEGER  );
            archive_array.addColDef("lckBase"     , java.sql.Types.VARCHAR  );
            archive_array.addColDef("lckObjet"    , java.sql.Types.VARCHAR  );
            archive_array.addColDef("lckPage"     , java.sql.Types.INTEGER  );
            archive_array.addColDef("lckRow"      , java.sql.Types.INTEGER  );
            archive_array.addColDef("lckName"     , java.sql.Types.VARCHAR  );

            while (rs.next()) {
                // Prepare insert values into database
                aRow = archive_array.allocateNewRow();
                aRow.addValue(rs.getTimestamp(1));              
                aRow.addValue(rs.getInt(2));     // time_blocked
                aRow.addValue(rs.getInt(3));     // blockedSpid 
                aRow.addValue(rs.getString(4));  // blockedUsr  
                aRow.addValue(rs.getString(5));  // blockedTran 
                aRow.addValue(rs.getString(6));  // blockedProg 
                aRow.addValue(rs.getString(7));  // blockedProc 
                aRow.addValue(rs.getInt(8));     // blockedLine 
                aRow.addValue(rs.getInt(9));     // blockingSpid
                aRow.addValue(rs.getString(10)); // blockingUsr 
                aRow.addValue(rs.getString(11)); // blockingTran
                aRow.addValue(rs.getString(12)); // blockingProg
                aRow.addValue(rs.getString(13)); // blockingProc
                aRow.addValue(rs.getInt(14));    // blockingLine
                aRow.addValue(rs.getString(15)); // lckBase     
                aRow.addValue(rs.getString(16)); // lckObjet    
                aRow.addValue(rs.getInt(17));    // lckPage     
                aRow.addValue(rs.getInt(18));    // lckRow      
                aRow.addValue(rs.getString(19)); // lckName     
                archive_array.addRow(aRow);      // save this row in the array
          }

          // Save this array into archive database
          Asemon_logger.archive_class.saveValues (srvName+"_"+structName, archive_array, this);
      }
      catch (SQLException e) {
            int errcode = e.getErrorCode();
            if ( (errcode==12052)||(errcode==12036))
                // ignore 12052 error : Collection of monitoring data for table 'xxx' requires that the 'enable monitoring' configuration option(s) be enabled.
                // ignore 12036 error : Collection of monitoring data for table 'xxx' requires that the 'enable monitoring' configuration option(s) be enabled.
                return;
            else throw e;
      }
  }

}
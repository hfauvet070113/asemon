/*
 * MetricDescriptor.java
 *
 * Created on 10 septembre 2007, 17:50
 *
 * <p>MetricDescriptor</p>
 * <p>class managing metrics descriptors</p>
 * <p>Copyright: Jean-Paul Martin (jpmartin@sybase.com) Copyright (c) 2007</p>
 * @version 3.1.0

 */

package asemon_logger;

import static asemon_logger.Asemon_logger.*;
import java.io.*;
import java.math.BigDecimal;
import java.util.*;
import org.jdom.*;
import org.jdom.input.SAXBuilder;


public class MetricDescriptor {
    
    /*
     * Class used to associate a descriptor file with a version
     */
    static class DescriptorVersion {
        int    id;      // ID in the list
        String version; // this field is used as this : if monitored server version is lower than this field then use the file in this DescriptorVersion
        String file;        
        
        DescriptorVersion(int i, String ver, String f) {
            id = i;
            version = ver;
            file = f;
        }
    }
    

    /*
     * Class used to keep the description of the purge of one table
     */
    static class PurgeDescriptor implements Cloneable {
        String tableName;                         // raw table name including ?SERVERNAME?
        String trueTableName;                     // table name where ?SERVERNAME? has been translated
        String SQL;
        String srvNormalized;                     // Server name "normalized" (truncated to 20 chars)
                                                  // This info is set when the purge desc is just added to the active set of purge desc
        int daysToKeep;                           // Number of days to keep when purging
        int deleteSleep;                          // Number of seconds to sleep between two delete statements when purging
        int batchsize;                            // Number of rows to delete per transaction
        
        
        PurgeDescriptor (String t, String S) {
            tableName=t;
            SQL=S;
        }
        public Object clone() throws CloneNotSupportedException{
            return super.clone();
        } 
    }  
    
    static class FilterHighValue {
        String colname;
        int highvaluerate;
        int defaultvalue;
        
        Object filter (Object val, long interval) {
            // interval : number of millisecond between 2 samples
            Object retval = val;
            String cls = val.getClass().getName();
            if (cls.equals("java.lang.Integer"))  {
                   long i = ((Integer)val).intValue();
                   if ( Math.abs((i / interval) * 1000) > highvaluerate )
                       retval = new Integer(defaultvalue);
            }
            else if (cls.equals("java.lang.Long")) {
                   long i = ((Long)val).longValue();
                   //i=9223372036854775785L;
                   if ( Math.abs((i / interval) * 1000) > highvaluerate )
                       retval = new Long(defaultvalue);
            }

            else if (cls.equals("java.math.BigDecimal")) {
                   BigDecimal bd = (BigDecimal)val;
                   /*
                   BigDecimal a;
                   a = bd.divideToIntegralValue(new BigDecimal(30000));
                   a = a.multiply(new BigDecimal(1000));
                   a = a.abs();
                   */
                   
                   if ( bd.divideToIntegralValue(new BigDecimal(interval)).multiply(new BigDecimal(1000)).abs().compareTo(new BigDecimal(highvaluerate)) > 0 )
                      retval = new Long(defaultvalue);
                   
            }



            return retval;
        }
    }

    String metricName;           // Used for archive table named : {name_of_monitored_server}_{metricName}
    String metricType;           // Type of metric : generic or specific
    
    public Vector<DescriptorVersion> descriptorVersions = null;    // set of all version descriptors. NULL if this descriptor is not a version selector

    String SQL;                  // Original SQL used to get the metrics (includes dynamic variable tags)
    Boolean use_rssd = false;    // True if a "connect to rssd" must be executed before sending SQL
    String SQL_if_no_sa;         // Original SQL used to get the metrics (includes dynamic variable tags) if user don't have sa_role
    String SQL_final=null;       // Final SQL with dynamic variables substituted. Null if no dynamic variables
    String SQL_final_if_no_sa=null;       // Final SQL with dynamic variables substituted. Null if no dynamic variables
//    String[] primaryKey;         // List of columns of the primary key (currently limited to 3 columns)

    String colKey1="";           // name of first key ("" if not used as a key)
    String colKey2="";           // name of first key ("" if not used as a key)
    String colKey3="";           // name of first key ("" if not used as a key)
    String filterCol;            // Name of numeric column used for filtering data, or "#filter_if_no_change#" for filtering rows whitout any change between 2 samples
    
    // These 4 variables are computed by SampleMetric at the first call
    int key1=0;                  // number of first key (0 if not used as a key)
    int key2=0;                  // number of second key (0 if not used as a key)
    int key3=0;                  // number of third key (0 if not used as a key)
    int filterColId;             // ID (start at 1)  of numeric column used for filtering data, or -1 for filtering rows whitout any change between 2 samples



    String[] colsCalcDiff;        // list of numeric columns where difference must be computed between two sampls  ex : {"IOs", "IOTime"};
    int delay;                    // delay between two samples
    String[] mandatoryConfigs;    // list of all mandatory configuration options (ex. "per object statistics active")"
    Hashtable<String, String> colsAlias;          // list of alias to cols : key=nameInSQL value=nameInTable
    Hashtable<String, FilterHighValue> colsFilters;         // list of cols with filters: key=colname value=FilterHighValue
    Properties parameters;        // parameters of the metric
    
    Vector<PurgeDescriptor> purgeDescriptors = null; // set of all purge descriptors

    boolean needAccessibleDBs;      // true if the SQL contains ASE$ACESSIBLEDBS variable

    /* Metadata for archive database */
    static class Archive_table {
        String configTabName;         // name of the table (without "?SERVERNAME?_")
        String archiveTabName;        // name of the archive table (with "?SERVERNAME?_")
        StringBuffer createTable;     // create table statement
        String ignore_dup_key;        // ignore_dup_key strings. Null if no ignore_dup_key config. 
                                      // (For archive databse not supporting  CREATE INDEX ... WITH IGNORE_DUP_KEY)
        String use_RLV_store;         // Y if RLV store can be used for this table, N if forced to not use. Blanc if not defined
    }
    
    static class Archive_mda {
        Hashtable<String,Archive_table> archive_tables;  // Hashtable of all structures describing create tables
        StringBuffer[] createIndexes; // array of all create index statements
    }
 
    Hashtable<String,Archive_mda> archive_mdas = null;           // List of metadata per archive type : ASE, IQ
    Archive_mda a_archive_mda = null;         // For temporary use
    static Hashtable<String,Archive_table> getArchiveTables (MetricDescriptor md) {
        Archive_mda a_archive_mda = md.archive_mdas.get(Asemon_logger.archive_type);
        return a_archive_mda.archive_tables;
    }
    static Archive_table getFirstArchiveTables (MetricDescriptor md) {
        Hashtable<String,Archive_table> ats = getArchiveTables(md);
        return ats.get(ats.keys().nextElement());
    }

    static Boolean hasIgnoreDupKey (MetricDescriptor md, String tabname) {
        Archive_mda a_archive_mda = md.archive_mdas.get(Asemon_logger.archive_type);
        if (a_archive_mda.archive_tables.get(tabname).ignore_dup_key != null)
            return true;
        else
            return false;
    }
    static String useRLVstore (MetricDescriptor md, String tabname) {
        Archive_mda a_archive_mda = md.archive_mdas.get(Asemon_logger.archive_type);
        return a_archive_mda.archive_tables.get(tabname).use_RLV_store;
    }

    static String getIgnoreDupKey (MetricDescriptor md, String tabname) {
        Archive_mda a_archive_mda = md.archive_mdas.get(Asemon_logger.archive_type);
        return a_archive_mda.archive_tables.get(tabname).ignore_dup_key;
    }

    static StringBuffer[] getCreateIndexes (MetricDescriptor md) {
        Archive_mda a_archive_mda = md.archive_mdas.get(Asemon_logger.archive_type);
        return a_archive_mda.createIndexes;
    }

    
    /** Creates a new instance of Metrics */
    public MetricDescriptor() {
    }


  /*
  ** Build a parser, set parsing option and parse the XML document
  ** If error, returns a null document
  */
  static Document parseXml(InputStream input, String fname) throws Exception
  {
    //File mydoc = new File(ficname);
    Document doc=null;

    // Create a SAXBuiler and activate validation
    SAXBuilder builder = new SAXBuilder(
        "org.apache.xerces.parsers.SAXParser");

    // turn on schema validation support
    //builder.setValidation(true);
    //builder.setFeature(
    //    "http://apache.org/xml/features/validation/schema", true);


    try {
      // If there are no well-formedness errors,
      // then no exception is thrown
      doc = builder.build(input);
    }
    // indicates a well-formedness error
    catch (JDOMException e) {
      System.out.println("parseXml : Doc '" +fname+ "' is not well-formed or valid.");
      System.out.println(e.getMessage());
    }

    return doc;
  }

  // Parse metadata (create table's, create index's) for an archive DB type (ex. ASE, IQ, ...)
  static Archive_mda parseArchiveMDA (Element cts, Element cis) {
      if ((cts == null)&&(cis == null) ) return null;
      Archive_mda a_archive_mda = new Archive_mda();
      StringBuffer ct;
      String tablename;
      if (cts != null) {    
          a_archive_mda.archive_tables = new Hashtable<String,Archive_table>();
          List ctsl = cts.getChildren("T");
          int i=0;
          Archive_table aArchive_table;
          for (Iterator itCtsl = ctsl.iterator(); itCtsl.hasNext();) {
              Element t = (Element)itCtsl.next();
              aArchive_table = new Archive_table();     //  Allocate structure for this archive table
              ct = new StringBuffer(t.getTextTrim());
              aArchive_table.createTable = ct;
              // extract config table name
              DEBUG(DBG105, "parseArchiveMDA. ct = "+aArchive_table.createTable);
              tablename = ct.substring(ct.indexOf("?SERVERNAME?_")+"?SERVERNAME?_".length(), ct.indexOf("(")).trim();
              aArchive_table.configTabName = tablename;
              // check ignore_dup_key attibute
              String idk = t.getAttributeValue("ignore_dup_key");
              if (idk!=null)
                  aArchive_table.ignore_dup_key = idk.toString().trim();
              else aArchive_table.ignore_dup_key = null;
              // Check use_RLV_store attribute
              String rlv = t.getAttributeValue("use_RLV_store");
              if (rlv!=null) {
                  aArchive_table.use_RLV_store = rlv;
              }
              else aArchive_table.use_RLV_store = "";
              
              a_archive_mda.archive_tables.put(tablename, aArchive_table);
              i++;
          }
      }

      if (cis != null) {
          List cisl = cis.getChildren("I");
          a_archive_mda.createIndexes = new StringBuffer[cisl.size()];
          int i=0;
          for (Iterator itCisl = cisl.iterator(); itCisl.hasNext();) {
              Element ind = (Element)itCisl.next();
              a_archive_mda.createIndexes[i] = new StringBuffer(ind.getTextTrim()); 
              i++;
          }
      }
      return a_archive_mda;
  }
  
  
  /*
  ** Parse a Metric XML descriptor file. Save values in a MetricDescriptor
  ** Input argument : a input file name
  **                  parameters defined at Server Descriptor level
  ** If error, returns a null Metricdescriptor
  */
  static MetricDescriptor parseMetricFile(String fname, Properties SDLevelParameters) throws Exception
  {
      DEBUG(DBG105, "parseMetricFile. fname = "+fname);
      
      MetricDescriptor md=null;
      InputStream input = new FileInputStream(fname);
      // Parse the document and check validity
      Document doc = parseXml(input, fname);
      if (doc == null) return null;

      md = new MetricDescriptor();
      
      // Retreive Metric's elements
      Element root = doc.getRootElement();
      if ( ! (root.getName().equals("MetricDescriptor")) ) return null; 
      md.metricName = root.getChild("metricName").getText().trim();
      md.metricType = root.getChild("metricType").getText().trim();
      
      
      Element swtch = root.getChild("versionSwitch");
      if (swtch != null) {
          // Special case of the version selector descriptor used to describe which desc file should be used depending on monitored server version
          List versions = swtch.getChildren("version");
          md.descriptorVersions = new Vector<DescriptorVersion>();
          int id=0;
          String lowerthan;
          String file;
          Element el;
          DescriptorVersion des;
          for (Iterator itVers = versions.iterator(); itVers.hasNext();) {
              el = (Element)itVers.next();
              lowerthan = el.getAttributeValue("lowerthan");
              file = el.getTextTrim();
              des = new DescriptorVersion(id, lowerthan, file);
              md.descriptorVersions.add(des);                  // save this in the list
              id++;
          }
          
          return md;
      }

      if (root.getChild("SQL") != null) {
          Element sql = root.getChild("SQL");
          md.SQL = sql.getText();
          // Check if SQL contains ?ASM$NEEDACCESSIBLEDBS? variable
          if (md.SQL.indexOf("?ASM$ACCESSIBLEDBS?") > -1) 
              md.needAccessibleDBs = true;
          else
              md.needAccessibleDBs = false;

          String use_rssd = sql.getAttributeValue("use_rssd");
          if (use_rssd != null) {
              md.use_rssd = true;
          }
      }
      if (root.getChild("SQL_if_no_sa") != null)
          md.SQL_if_no_sa = root.getChild("SQL_if_no_sa").getText();
      if (root.getChild("key1") != null)
          md.colKey1 = root.getChild("key1").getTextTrim(); 
      if (root.getChild("key2") != null)
          md.colKey2 = root.getChild("key2").getTextTrim(); 
      if (root.getChild("key3") != null)
          md.colKey3 = root.getChild("key3").getTextTrim();
      if (root.getChild("filterCol") != null) {
          md.filterCol = root.getChild("filterCol").getTextTrim();
          if (md.filterCol.equals("#filter_if_no_change#")) md.filterColId = -1;
      }

      md.delay = Integer.parseInt( root.getChild("delay").getText().trim() );
      
      Element ccd = root.getChild("colsCalcDiff");
      if (ccd != null) {
          List mdl = ccd.getChildren("COL");
          md.colsCalcDiff = new String[mdl.size()];
          int i=0;
          for (Iterator itMdl = mdl.iterator(); itMdl.hasNext();) {
             md.colsCalcDiff[i] = ((Element)itMdl.next()).getTextTrim(); 
             i++;
          }
      }
      

      // Get the mandatory config options
      Element mc = root.getChild("mandatoryConfigs");
      if (mc != null) {
          List mcl = mc.getChildren("config");
          md.mandatoryConfigs = new String[mcl.size()];
          int i=0;
          for (Iterator itMcl = mcl.iterator(); itMcl.hasNext();) {
             md.mandatoryConfigs[i] = ((Element)itMcl.next()).getTextTrim(); 
             i++;
          }
      }

      // Get col aliases if any
      Element colsAliasXML = root.getChild("colsAlias");
      if (colsAliasXML != null) {
          md.colsAlias = new Hashtable<String, String>();
          String nameInSQL;
          String nameInTable;
          List cal = colsAliasXML.getChildren("col");
          for (Iterator itCal = cal.iterator(); itCal.hasNext();) {
              Element alias = (Element)itCal.next();
              nameInSQL = alias.getAttributeValue("nameInSQL");
              nameInTable = alias.getAttributeValue("nameInTable");
              md.colsAlias.put(nameInSQL, nameInTable);
          }
      }

      // Get col filter if any
      Element colsFilterXML = root.getChild("filterHighValues");
      if (colsFilterXML != null) {
          md.colsFilters = new Hashtable<String, FilterHighValue>();
          List colxml = colsFilterXML.getChildren("col");
          for (Iterator itCol = colxml.iterator(); itCol.hasNext();) {
              Element col = (Element)itCol.next();
              FilterHighValue aFilterHighValue = new FilterHighValue();
              aFilterHighValue.colname = col.getValue().trim();
              String attr=col.getAttributeValue("highvaluerate");
              aFilterHighValue.highvaluerate = Integer.parseInt(attr);
              attr=col.getAttributeValue("defaultvalue");
              aFilterHighValue.defaultvalue = Integer.parseInt(attr);
              md.colsFilters.put(aFilterHighValue.colname, aFilterHighValue);
          }
      }

      md.archive_mdas = new Hashtable<String,Archive_mda>();
      
      // Get the "create table's"  OLD syntaxe, for compatibility with previous XML descriptors config files
      Element cts = root.getChild("createTables");
      // Get the "create indexes"
      Element cis = root.getChild("createIndexes");
      // parse this section
      md.a_archive_mda = parseArchiveMDA (cts, cis);
      if (md.a_archive_mda!=null) {
          // Add this metadata descriptor to the list as the default ASE config
          md.archive_mdas.put("ASE", md.a_archive_mda);
      }

      
      Element archive_mda_elem = root.getChild("ARCHIVE_MDA");
      if (archive_mda_elem != null) {
          // metadata for archive db is defined
          md.a_archive_mda = null;
          List aml = archive_mda_elem.getChildren("ARCHIVE");
          for (Iterator itAml = aml.iterator(); itAml.hasNext();) {
              // Get metadata for a archive server type
              Element mda = (Element)itAml.next();
              String aType = mda.getChildTextTrim("TYPE");
              Element cretabelm = mda.getChild("createTables");
              Element creidxelm = mda.getChild("createIndexes");
              md.a_archive_mda = parseArchiveMDA (cretabelm,creidxelm);
              if (md.a_archive_mda != null)
                  md.archive_mdas.put(aType, md.a_archive_mda);
          }
      }
      
      
      
      // Get parameters
      md.parameters = new Properties();
      Element paramsXml = root.getChild("parameters");
      Element optXml;
      if (paramsXml != null) {
          List param_lst = paramsXml.getChildren("param");
          if (param_lst != null) {
              for (Iterator itOpts = param_lst.iterator(); itOpts.hasNext();) {
                  // Retreive an option
                  optXml = (Element)itOpts.next();
                  String optName = optXml.getAttributeValue("name");
                  String optValue = optXml.getTextTrim();
                  md.parameters.put(optName, optValue);
             }
          }
      }
      // Insert parameter already found at the config file level (parameter at server file level override parameter at MD file level)
      if (SDLevelParameters != null) {
          // Loop on all server level parameter
          for (Enumeration enumSDLParams = SDLevelParameters.propertyNames(); enumSDLParams.hasMoreElements();) {
              String paramName = (String)enumSDLParams.nextElement();
              md.parameters.put(paramName, SDLevelParameters.getProperty(paramName));
          }
          
      }
      

      
      
      // Get purge descriptors, and save them in the metric descriptor
      Element purgeXml = root.getChild("purge");
      Element purgeTableXml;
      if (purgeXml != null) {
          List purgeTableList = purgeXml.getChildren("P");
          if (purgeTableList != null) {
              for (Iterator itPurgeTables = purgeTableList.iterator(); itPurgeTables.hasNext();) {
                  // Retreive a purge descriptor
                  if (md.purgeDescriptors == null) md.purgeDescriptors = new Vector<PurgeDescriptor>();
                  purgeTableXml = (Element)itPurgeTables.next();
                  String tableName = purgeTableXml.getAttributeValue("table");
                  if (tableName != null) {
                      String SQL = purgeTableXml.getTextTrim();
                      PurgeDescriptor aPurgeDesc = new PurgeDescriptor(tableName, SQL );
                      
                      md.purgeDescriptors.add(aPurgeDesc);
                  }
             }
          }
      }

      
      return md;
  }
    
  /*
  ** Load a Metric XML descriptor file. Save values in a MetricDescriptor
  ** Input arguments : 
  **                      a input file name (with relative path)
  **                      Server Descriptor level parameter for this MetricDescriptor
  ** If error, returns a null Metricdescriptor
  */
  static MetricDescriptor loadMetricFile(String fname, Properties SDLevelParameters)
  {
    MetricDescriptor md=null;
    try {
         Asemon_logger.DEBUG("Loading descriptor : "+fname);
         md = parseMetricFile(fname, SDLevelParameters);
      }
      catch (Exception e){
         Asemon_logger.printmess ("parseMetricFile : (" +fname+ ") " + e);
         e.printStackTrace(System.out);
         return null;
      }
    return md;
  }
  
  /*
   * getParam method
   *
   * returns the value of a given parameter, null if param is not set
   *
   */
  
  String getParam (String paramName) {
      return parameters.getProperty(paramName);
  }
  
  
}

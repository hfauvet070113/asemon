/**
* <p>Asemon_logger</p>
* <p>Asemon_logger :  Gzip class</p>
* <p>Copyright: Jean-Paul Martin (jpmartin@sybase.com) Copyright (c) 2016</p>
* @version 3.0
*/
package asemon_logger;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.zip.*;

public class Gzip {
    public static byte[] compress(String data) throws IOException {
        byte[] compressed = null;
        byte[] byteData = data.getBytes();
        ByteArrayOutputStream bos = new ByteArrayOutputStream(byteData.length);
        Deflater compressor = new Deflater();
        compressor.setLevel(Deflater.BEST_COMPRESSION);
        compressor.setInput(byteData, 0, byteData.length);
        compressor.finish();

        // Compress the data
        final byte[] buf = new byte[1024];
        while (!compressor.finished()) {
            int count = compressor.deflate(buf);
            bos.write(buf, 0, count);
        }
        compressor.end();
        compressed = bos.toByteArray();
        bos.close();
        Asemon_logger.DEBUG(Asemon_logger.DBG102, "compress. Size before=" + data.length() + " After=" + compressed.length);
        return compressed;
    }
}
/*
* <p>Archive_array</p>
* <p>Copyright: Jean-Paul Martin (jpmartin@sybase.com) Copyright (c) 2015</p>
* Define object passed to save data into archive database
* @version 3.0.8b
 */
package asemon_logger;
import java.util.Vector;
import static asemon_logger.Asemon_logger.*;

public class Archive_array {
    
    class Archive_row {
        Vector<Object> cols;
        private Archive_row () {
            cols = new Vector<Object>();
        }
        public void addValue(Object o) {
            cols.add(o);
        }
    }
    
    private Vector<String> colnames;
    private Vector<Integer> coltypes;
    private Vector<Archive_row> rows;

    public Archive_array() {
        colnames = new Vector<String>();
        coltypes = new Vector<Integer>();
        rows = new Vector<Archive_row>();
    }
    
    public Archive_row allocateNewRow() {
        return new Archive_row ();
    }
    
    public void addColName(String name) {
        colnames.add(name);
    }

    public void addColType(int type) {
        coltypes.add(new Integer(type));
    }

    public void addColDef(String name, int type) {
        colnames.add(name);
        coltypes.add(new Integer(type));
    }

    public void addRow(Archive_row arow) {
        rows.add(arow);
    }
    
    public int nbcols() {
        return colnames.size();
    }

    public int nbrows() {
        return rows.size();
    }
    
    public String getColName(int i) {
        return colnames.get(i);
    }

    public int getColType(int i) {
        return coltypes.get(i).intValue();
    }

    public Archive_row getRow(int i) {
        return rows.get(i);
    }

    public void printRows() {
        String stringvalue;
        // loop on all rows
        for (int rowId=0; rowId < rows.size(); rowId++) {
            DEBUG(DBG109, "Row : "+rowId);
            // Get the row values
            Archive_array.Archive_row row = getRow(rowId);
            // loop on all columns
            for (int col=0; col < row.cols.size(); col++) {

              // Get the sql type of the column
              int t = (Integer)getColType(col);

              Object val = row.cols.get(col);

              // check if column is NULL
              if (val == null) {
                  stringvalue = "null";
              }
              else {

                  // Check if type is "bit". If Yes change it to char(1) since BULK LOAD does not support bit
                  if (t == java.sql.Types.BIT) {
                      boolean valBIT = ((Boolean)val).booleanValue();
                      if (valBIT == false) stringvalue="0";
                      else stringvalue="1";
                  }
                  else
                      stringvalue = val.toString();
              }
              
              DEBUG(DBG109, "    "+getColName(col)+" : "+stringvalue);
            }
        }
    }

}

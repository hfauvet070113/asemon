/*
* <p>Archive_IQ</p>
* <p>Copyright: Jean-Paul Martin (jpmartin@sybase.com) Copyright (c) 2015</p>
* Define interface to a archive database
* @version 3.0
 */
package asemon_logger;

import java.sql.Statement;
import java.util.Hashtable;

public interface Archive_interface {

      boolean connect_archive_SRV (CnxMgr.ArchCnx aArchServCnx, boolean nowait);

      boolean connect_archive_SRV_asPurge (MonitoredSRV msrv, boolean printCnxMess, boolean nowait);
      
      public boolean checkIfTableExists (String tabname, Statement stmt) throws Exception;

      public void createArchiveTable (StringBuffer ct, Statement stmt) throws Exception;
      
      public void grantRightsOnArchiveTable(String archiveTabName, String granteeList, Statement stmt);
      
      public Hashtable <String, ArchiveColumnDesc> checkAndAlterArchiveTable (StringBuffer ct,String tname, String archive_tname,  Statement stmt, Collector collector) throws Exception ;

      public void createIndex(String ci, Statement stmt) throws Exception;
      
      public void saveValues (String archiveTabName, Archive_array archive_array, Collector collector) throws Exception;

      public void truncateTable (String archiveTabName, Collector collector) throws Exception;

}

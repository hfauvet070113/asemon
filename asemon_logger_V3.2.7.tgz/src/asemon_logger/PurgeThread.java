/**
* <p>Asemon_logger</p>
* <p>Asemon_logger :  purge thread</p>
* <p>Copyright: Jean-Paul Martin (jpmartin@sybase.com) Copyright (c) 2007</p>
* @version 3.1.5
*/

package asemon_logger;
import static asemon_logger.Asemon_logger.*;
import java.util.*;
import java.sql.*;
import java.util.Calendar;
import java.text.SimpleDateFormat;


public class PurgeThread extends Thread {
    MonitoredSRV msrv;
           
    public PurgeThread(MonitoredSRV ms)
    {
        super("Purge " + ms.name);
        msrv = ms;
    }

    private StringBuffer substituteParam (StringBuffer sb, String paramName, String value) {
      int start;
      // Replace all instances of ?SERVERNAME? by servername
      while (true) {
          start = sb.indexOf("?"+paramName+"?");
          if (start != -1) 
              sb.replace(start, start+("?"+paramName+"?").length(), value);
          else break;
      }
      return sb;
    }
  
  
    void archiveIndic (Statement stmt, int TrendID, String grpname, String description, String aggtable, String aggidx, String aggrestrict,String agg_expr_lvl0, String agg_grpby_lvl0, String agg_expr, String aggfunction, String granularity, String SQL)   
          throws Exception {
        StringBuffer archivestmt = new StringBuffer();
        DEBUG(DBG112, "archiveIndic "+TrendID+ " From table : "+msrv.srvNormalized+"_"+aggtable);
        if (aggtable != null) {
            // Check if table exists
            if (Asemon_logger.archive_class.checkIfTableExists(msrv.srvNormalized+"_"+aggtable, stmt) == false) {
                DEBUG(DBG112, "archiveIndic "+TrendID+ " table doesn't exist");
                return;
            } 
            archivestmt = archivestmt.append("declare @startts datetime");
            archivestmt = archivestmt.append(" select @startts=isnull(dateadd(dd, 1, (select convert(varchar, max(dt),102) from "+msrv.srvNormalized+"_Trends where TrendID="+TrendID+") ),'1900/01/01')");
            if ( (SQL != null) && (SQL.length()>0) ) {
                SQL = substituteParam (new StringBuffer(SQL), "SERVERNAME", msrv.srvNormalized).toString();
                archivestmt = archivestmt.append(" " +SQL);
            }
            archivestmt = archivestmt.append(" insert into "+msrv.srvNormalized+"_Trends");
            archivestmt = archivestmt.append(" select "+TrendID+", dt=dateadd(hh,datepart(hh, Timestamp), convert(datetime,convert(varchar,Timestamp,102)) ),");
            archivestmt = archivestmt.append(" Value="+agg_expr);
            archivestmt = archivestmt.append(" from");
            if ((agg_expr_lvl0 != null) && (agg_grpby_lvl0!=null)) {
                archivestmt = archivestmt.append("   (select Timestamp, "+agg_expr_lvl0);
                archivestmt = archivestmt.append("    from "+msrv.srvNormalized+"_"+aggtable);
                archivestmt = archivestmt.append("     where Timestamp >= @startts");
                archivestmt = archivestmt.append("     and Timestamp < convert(varchar,getdate(), 102)");
                if (aggrestrict != null)
                    archivestmt = archivestmt.append("     "+aggrestrict);
                archivestmt = archivestmt.append("   group by "+agg_grpby_lvl0+") lvl0tbl");
            }
            else {
                archivestmt = archivestmt.append(" "+msrv.srvNormalized+"_"+aggtable);
                if (aggidx != null)
                    archivestmt = archivestmt.append(" (index "+aggidx+")");
                archivestmt = archivestmt.append("     where Timestamp >= @startts");
                archivestmt = archivestmt.append("     and Timestamp < convert(varchar,getdate(), 102)");
                if (aggrestrict != null)
                    archivestmt = archivestmt.append("     "+aggrestrict);
            }
            archivestmt = archivestmt.append(" group by dateadd(hh,datepart(hh, Timestamp), convert(datetime,convert(varchar,Timestamp,102)) )");

            //System.out.println(archivestmt.toString());
            DEBUG(DBG112,archivestmt.toString());
            int cnt=stmt.executeUpdate(archivestmt.toString());
            if (cnt==0) {
                // no row inserted. Check if any row exists for this date
                ResultSet res=stmt.executeQuery("select count(*) from "+msrv.srvNormalized+"_Trends where dt=dateadd(dd,-1,convert(varchar,getdate(),102)) and TrendID="+TrendID);
                res.next();
                cnt = res.getInt(1);
                if (cnt==0) {
                    // insert a NULL for this date
                    stmt.executeUpdate("insert into "+msrv.srvNormalized+"_Trends values ("+TrendID+", dateadd(dd,-1,convert(varchar,getdate(),102)), null)");
                }
            }
        }
        else {
            // table is not defined but SQL should be
            if (SQL == null) return;
            stmt.executeUpdate(SQL);
        }

    }

    void reorgUpdstatsArchTables () throws Exception {
        Statement stmt1 = msrv.purge_conn.createStatement();
        Statement stmt2 = msrv.purge_conn.createStatement();
        ResultSet rs;
        Vector<String> tableList = new Vector<>();
        // Get list of tables
        try {
            rs = stmt1.executeQuery("select name from sysobjects where reverse(substring(reverse(name),charindex('_',reverse(name))+1, datalength(name))) = '"+msrv.srvNormalized+"' and type='U' and sysstat2&8192!=8192 order by 1"); // don't take ALLPAGE locking tables
            while (rs.next())
                tableList.add ( rs.getString(1));
        }
        catch (SQLException sqle) {
            Asemon_logger.printmess("Purge Thread - reorgUpdstatsArchTables - Error when retreiving table list. "+sqle);
            throw sqle;
        }
        
        // loop on all tables
        String tabname;
        String idxname;
        boolean updatestats;
        Long leafcnt;
        Long emptypgcnt;
        double emptypgcnt_pct;
        double datachanged_pct;
        double ipcr;
        int fill_factor;
        Enumeration tablesEnum = tableList.elements();
        while (tablesEnum.hasMoreElements()) {
            
            tabname = (String)tablesEnum.nextElement();
            idxname = "";
            updatestats = false;
            leafcnt=(long)0;
            emptypgcnt=(long)0;
            emptypgcnt_pct=0;
            datachanged_pct=0;
            fill_factor=0;
            ipcr=0;
            // Check if reorg index and update statistics must be done
            DEBUG(DBG114, "Get stats for : " + tabname);
            try {
                rs = stmt1.executeQuery( 
                    "select I.name,S.leafcnt,S.emptypgcnt,emptypgcnt_pct=1.0e2*S.emptypgcnt/S.leafcnt, \n" +
                    "datachanged_pct=datachange('"+tabname+"', null, null), \n" +
                    "ipcr=derived_stat('"+tabname+"', I.indid, 'ipcr'), \n" +
                    "fill_factor \n" +
                    "from sysindexes I, systabstats S\n" +
                    "where I.id=object_id('"+tabname+"')\n" +
                    "and I.indid between 1 and 254\n" +
                    "and I.id=S.id\n" +
                    "and I.indid=S.indid\n" +
                    "and S.leafcnt >100");
                while (rs.next()) {
                    idxname = rs.getString(1);
                    leafcnt = rs.getLong(2);
                    emptypgcnt = rs.getLong(3);
                    emptypgcnt_pct = rs.getDouble(4);
                    datachanged_pct = rs.getDouble(5);
                    ipcr = rs.getDouble(6);
                    fill_factor= rs.getInt(7);
                    DEBUG(DBG114, "  Index : " + idxname + " leafcnt="+leafcnt+" emptypgcnt="+emptypgcnt+ " emptypgcnt_pct="+emptypgcnt_pct+" datachanged_pct="+datachanged_pct+" ipcr="+ipcr+" fill_factor="+fill_factor);
                    if ( (ipcr < 0.7) && ( (fill_factor > 75) || (fill_factor == 0)) ) {
                        // Force fillfactor to 75 for this index to avoid future fragmentation
                        DEBUG(DBG114, "    sp_chgattribute '"+tabname+"."+idxname+"', 'fillfactor', 75");
                        stmt2.execute("sp_chgattribute '"+tabname+"."+idxname+"', 'fillfactor', 75");
                        
                    }
                    if ((emptypgcnt_pct > 10.) || ( (ipcr < 0.7) && (leafcnt > 1000) ) ) {
                        // Reorganize index which have more than 10 % emty pages 
                        // OR index has more than 1000 pages and ipcr < 0.7 
                        DEBUG(DBG114, "    reorg rebuild "+tabname+" "+idxname);
                        stmt2.execute("reorg rebuild "+tabname+" "+idxname);
                        updatestats = true;
                    }
                }
                if ( ( (updatestats) || (datachanged_pct > 10.) ) && (msrv.sbssav.compareTo("15.7.0.100") > 0 ) ) {
                    // Do update stats only with hashing with ASE > 15.7 SP100
                    DEBUG(DBG114, "    update index statistics " + tabname + " with hashing");
                    stmt2.execute("update index statistics "+tabname+" with hashing"); 
                }
            }
            catch (SQLException sqle) {
                int errcode = sqle.getErrorCode();
                // Ignore error 14216 Function 'datachange' not found. (for ASE version not supporting this function)
                if (errcode!=14216) {
                    Asemon_logger.printmess("Purge Thread - reorgUpdstatsArchTables - Table : '"+tabname+"' Error : "+errcode+" "+sqle.getMessage());
                    throw sqle;
                }
            }
            
        }             
    }

                  
                  
  public void run() {
      Calendar aCalendar = Calendar.getInstance();  // used to compute the purge date
      java.util.Date curdate;                       // current date
      java.util.Date purgedate;                     // purge date
      SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss" );                         // used to convert purgeDate
      String purgedateStr;                          // purge date formated
      String purgeSQLStr;                           // purge SQL statement
      
      Statement stmt = null;                        // Used to execute SQL
      int rowcnt;                                   // Return row processed count
      boolean printCnxMess = true;                  // Used to avoid printing a message each time purge reconnects to archive server
      

      try {
          // startpurgeDelay contains the number of minutes to wait before starting purging (default is 30)
          java.lang.Thread.sleep(msrv.startDelay*60*1000);
      }
      catch (Exception e) {}

      if (msrv.activePurgeDescs == null)
          // No purge descriptors (bad config or no daysToKeep param in conf)
          return;      

      Asemon_logger.printmess ("Start thread.");

      //loop infinitely, wait one hour between execution
      while (true) {
          DEBUG(DBG113, "Begin archive/purge session");                  

          try {
              // Check connection to archive server
              if ((msrv.purge_conn==null)||(msrv.purge_conn.isClosed() )) {
                  Asemon_logger.archive_class.connect_archive_SRV_asPurge(msrv, printCnxMess, false);
                  msrv.purge_conn.setAutoCommit(true);
                  stmt = null; /* force reallocation of a new stmt after connexion is open*/
              }
              if (stmt == null) stmt = msrv.purge_conn.createStatement();
              
              // Archive indicators
             
              try {
                  // check if Trends and TrendsCfg tables exist
                  String tabname = msrv.srvNormalized+"_Trends";
                  if (Asemon_logger.archive_class.checkIfTableExists(tabname, stmt) == true) {
                      tabname = msrv.srvNormalized+"_TrendsCfg";
                      if (Asemon_logger.archive_class.checkIfTableExists(tabname, stmt) == true) {
                          // loop on configured trends
                          ResultSet resTrendsCfg = stmt.executeQuery("select TrendID, grpname, description, aggtable, aggidx, aggrestrict, agg_expr_lvl0, agg_grpby_lvl0, agg_expr, aggfunction, granularity, SQL from "+tabname+" order by TrendID");
                          stmt.setCursorName("TrendsCfgCursor");
                          Statement trendstmt = msrv.purge_conn.createStatement();
                          while (resTrendsCfg.next()) {
                              archiveIndic (trendstmt,
                                      resTrendsCfg.getInt(1),    // TrendID
                                      resTrendsCfg.getString(2), // grpname
                                      resTrendsCfg.getString(3), // description
                                      resTrendsCfg.getString(4), // aggtable
                                      resTrendsCfg.getString(5), // aggidx
                                      resTrendsCfg.getString(6), // aggrestrict
                                      resTrendsCfg.getString(7), // agg_expr_lvl0
                                      resTrendsCfg.getString(8), // agg_grpby_lvl0
                                      resTrendsCfg.getString(9), // agg_expr        
                                      resTrendsCfg.getString(10), // aggfunction
                                      resTrendsCfg.getString(11), // granularity
                                      resTrendsCfg.getString(12) // SQL
                              );

                          }
                          stmt.close();
                      }
                  }
              }
              catch (Exception e) {
                  Asemon_logger.printmess("Purge Thread : archive, error in loop. "+e);
                  e.printStackTrace(System.out);
                  Asemon_logger.printmess("Purge Thread - archive,Closing connection");
                  try {
                      if (msrv.purge_conn!=null) msrv.purge_conn.close();
                      msrv.purge_conn=null;
                  } catch (Exception ee){}
              }
              finally {
                  DEBUG(DBG113, "Purge Thread : End archive session");                  
              }
              
              
              
              stmt = msrv.purge_conn.createStatement();
              MetricDescriptor.PurgeDescriptor purgeDesc;
              // loop on all purge descriptors
              Enumeration purgedescElems = msrv.activePurgeDescs.elements();
              while (purgedescElems.hasMoreElements()) {
                  purgeDesc = (MetricDescriptor.PurgeDescriptor)purgedescElems.nextElement();
                  
                  // Force purge operations to be limiteed to 'batchsize' rows
                  // WARNING : rowcount on delete does not work on IQ
                  stmt.executeUpdate("set rowcount "+String.valueOf(purgeDesc.batchsize));

                  // Compute table name
                  String purgeTableName = purgeDesc.trueTableName;
                  DEBUG(DBG113, "Purge Thread - Start purge table : " + purgeTableName);                  

                  
                  // Check if table exists
                  if (Asemon_logger.archive_class.checkIfTableExists(purgeTableName, stmt) == false) 
                      continue; // table doesn't exist

                  
                  if ( Asemon_logger.archive_type.equalsIgnoreCase("IQ") ) {
                      // Check if table is RLV enabled in DB
                      ResultSet rs = stmt.executeQuery( "select isRlv from  sp_iqtable ('"+purgeTableName+"')");
                      rs.next();
                      String isRlv = rs.getString(1);
                      if ( isRlv.equalsIgnoreCase("T") ) {
                          if (Asemon_logger.forceIQMerge) stmt.executeUpdate("sp_iqmergerlvstore 'BLOCKING', '"+purgeTableName+"'");
                      }
                      rs.close();
                  }
                  
                  
                  // Compute the purge date
                  curdate= new java.util.Date();
                  aCalendar.setTime(curdate);
                  // Substract the number of kept days
                  aCalendar.add(Calendar.DAY_OF_MONTH, - purgeDesc.daysToKeep);
                  purgedate = aCalendar.getTime();
                  purgedateStr = sdf.format(purgedate);

                  // Prepare the purge statement
                  StringBuffer purgeSQL = new StringBuffer(purgeDesc.SQL);
                  // Replace all instances of ?SERVERNAME? by servername
                  purgeSQL = substituteParam (purgeSQL, "SERVERNAME", purgeDesc.srvNormalized);
                  // Replace all instances of ?DATE? by purge date
                  purgeSQL = substituteParam (purgeSQL, "DATE", "'"+purgedateStr+"'");
                  purgeSQL = substituteParam (purgeSQL, "ASM$SRVVERSION", msrv.sbssav);
                  purgeSQL = substituteParam (purgeSQL, "ASM$VERSION", Asemon_logger.Asemon_logger_version);
                  
                  
                  purgeSQLStr = purgeSQL.toString();
                  DEBUG(DBG113, "Purge Thread - Table : '"+purgeTableName+"' SQL : " + purgeSQLStr);                  
                                    
                  // Begin purge
                  try {
                      while (true) {
                          // remember, rowcount is set to purgeDesc.batchsize
                          rowcnt = stmt.executeUpdate(purgeSQLStr);
                          // Sleep "deleteSleep" seconds
                          DEBUG(DBG113, "Purge Thread - Table : '"+purgeTableName+"' rowcount : " + rowcnt);                  
                          DEBUG(DBG113, "Purge Thread - Table : '"+purgeTableName+"' Sleep " + purgeDesc.deleteSleep + " ms");
                          sleep(purgeDesc.deleteSleep);
                          if (rowcnt < purgeDesc.batchsize ) break;
                      }
                  }
                  catch (SQLException sqle) {
                      Asemon_logger.printmess("Purge Thread - Table : '"+purgeTableName+"' : error in purge loop. "+sqle);
                      Asemon_logger.printmess("Purge Thread - Closing connection");
                      if (msrv.purge_conn!=null) msrv.purge_conn.close();
                      msrv.purge_conn=null;
                  }
                  
                  
              }

              if ( (!skipReorgUpdstatsArchTables) && (Asemon_logger.archive_type.equalsIgnoreCase("ASE") ) ) 
                  reorgUpdstatsArchTables ();
          
          
          }
          catch (Exception e) {
              Asemon_logger.printmess("Purge Thread : error in loop. "+e);
              e.printStackTrace(System.out);
              Asemon_logger.printmess("Purge Thread - Closing connection");
              try {
                  if (msrv.purge_conn!=null) msrv.purge_conn.close();
                  msrv.purge_conn=null;
              } catch (Exception ee){}
          }
          finally {
             DEBUG(DBG113, "Purge Thread : End purge session");                  
          }


      try {
          // Close connection after this purge session
          if (msrv.purge_conn != null) msrv.purge_conn.close();
          msrv.purge_conn = null;
          printCnxMess = false;                           // Don't print message every hours
          // Wait one hour before next purge session
          java.lang.Thread.sleep(3600*1000);
      }
      catch (Exception e) {}

      }  // End loop on tempo

  }

}
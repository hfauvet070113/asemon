<?php
  // retreive all posted params and affect them to variables
  foreach ($_POST as $key => $value)
    @$$key=$value;

  include ("connectArchiveServer.php");

  if ( !isset($pid) || $pid==0 ) {
    if ($error == '')
      $error="Cannot open connection";  
    $data = array(        
        'status' => 'error',
        'message' => $error,
        'query' => ''   
        );
    echo json_encode($data);
    return;
  }


  $query = $querydblist;
  $version = "";
  $archive_sbssav = "";
  
  $total_rows=0;
  if ($ArchSrvType=="Adaptive Server Enterprise") {
    // Get ASE version
    $result = asemon_query("select version=substring(
                            substring(@@version,charindex('ise/',@@version)+4,datalength(@@version)),
                            1,
                            charindex('/',substring(@@version,charindex('ise/',@@version)+4,datalength(@@version)))-1
                           )", $pid);
    $row=asemon_fetch_assoc($result);
    $version=$row["version"];
    $archive_sbssav = $version;
    $version = str_replace ( '.', '', $version);
    if ($version == 155)
      $version=1550;
    if ($version == 157)
      $version=1570;
    if ($version == 160)
      $version=1600;
    if ($version == 161)
      $version=1610;
    if ($version >= 1570) {
        // Get new @@sbssav variable containing exact version
        $result = asemon_query("select sbssav=@@sbssav", $pid);
        $row=asemon_fetch_assoc($result);
        $archive_sbssav = $row["sbssav"];
    }

    // Get databaselist
    $result = asemon_query($query, $pid);
    while (($row=asemon_fetch_assoc($result))) {
  
      $myrow = array();
      foreach ($row as $key => $value) {
        $myrow[$key] = $value;
      }
      $rows[] = $myrow;
      $total_rows++;
    }
  }
  else {
    // IQ
    
  }


  if ($total_rows==0) $rows=array();
  
  if ($error == "")
    $data = array(
      'status' => 'success',
      'TotalRows' => $total_rows,
      'Rows' => $rows,
      'ArchSrvType' => $ArchSrvType,
      'ArchSrvVersion' => $version,
      'ArchSrvsbssav' => $archive_sbssav,
      'ArchiveServer' => $ArchiveServer
      );
  
  else
    $data = array(
      'status' => 'error',
      'message' => $error,
      );

  echo json_encode($data);


?>
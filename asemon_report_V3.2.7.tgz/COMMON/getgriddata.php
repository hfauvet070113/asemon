<?php
  // retreive all posted params and affect them to variables
  foreach ($_POST as $key => $value)
    @$$key=$value;

//  $debugfile = fopen('/tmp/getgriddata.txt', 'a+');

  include ("connectArchiveServer.php");	
  if ( ( !isset($pid) ) || ($queryfile == '') ){
    $data = array(
        'status' => 'noconnect'
        );
    echo json_encode($data);
    return;
  }

    if (!isset($filter_clause) ) $filter_clause = "";
    if (!isset($sort_clause) )   $sort_clause = "";

  // List of fields whose name must be renamed when used in where clause
  $datafieldsMapping = [];
  if ( isset($datafieldsMappingJSON) )
    $datafieldsMapping = json_decode($datafieldsMappingJSON, true); 

  // List of fields of type timestamp which must be converted when returned
  $datafieldsTS = [];
  if (isset($datafieldsTSJSON))
    $datafieldsTS = json_decode($datafieldsTSJSON, true);

  $sort_clause="";
  if ( isset($default_order_by) ) $sort_clause = " order by ".$default_order_by;
  if ( isset($sortdatafield) && ($sortdatafield!="")) {
    /*
    // field name translation must be done only for filter clause, not sort clause. Sort clause must use alias column name
    if (isset($datafieldsMapping[$sortdatafield]))
          $sortdatafield = $datafieldsMapping[$sortdatafield];
    */
    $sort_clause = " order by ".$sortdatafield." ".$sortorder;
  }

  $SQLTextIsCompressed = false;

  // filter data.
  if (isset($_POST['filterscount'])) {
    $filterscount = $_POST['filterscount'];
    if ($filterscount > 0) {
      $filter_clause = " AND (";
      $tmpdatafield = "";
      $tmpfilteroperator = "";
      $values = [];
      for ($i = 0; $i < $filterscount; $i++) {
        // get the filter's value.
        $filtervalue = $_POST["filtervalue" . $i];
        // get the filter's condition.
        $filtercondition = $_POST["filtercondition" . $i];
        // get the filter's column.
        $filterdatafield = $_POST["filterdatafield" . $i];  
//fputs( $debugfile, "filterdatafield: ".$filterdatafield."\n");
        if (isset($datafieldsMapping[$filterdatafield]))
          $filterdatafield = $datafieldsMapping[$filterdatafield];
        // get the filter's operator.
        $filteroperator = $_POST["filteroperator" . $i];
//fputs( $debugfile, "filteroperator: ".$filteroperator."\n");
        if ($tmpdatafield == "") {
            $tmpdatafield = $filterdatafield;
          }
          else if ($tmpdatafield <> $filterdatafield) {
            $filter_clause.= ")AND(";
          }
          else if ($tmpdatafield == $filterdatafield) {
            if ($tmpfilteroperator == 0) {
              $filter_clause.= " AND ";
            }
            else $filter_clause.= " OR ";
          }
        // build the "WHERE" clause depending on the filter's condition, value and datafield.
//fputs( $debugfile, "filtercondition: ".$filtercondition."   filtervalue: ".$filtervalue.    "\n");

        // Very special case for SQLHashKey (BigInt in database, but must be String in jqxGrid to display all digits
        if ( $filterdatafield=="stat.SQLHashKey")  {
//fputs( $debugfile, "Special case for : ".$filterdatafield.    "\n");
          $condition = " = ";
          $value = $filtervalue;
        }
        else {
          switch ($filtercondition) {
          case "CONTAINS":
            $condition = " LIKE ";
            $value = "'{$filtervalue}'";
            break;
          case "DOES_NOT_CONTAIN":
            $condition = " NOT LIKE ";
            $value = "'{$filtervalue}'";
            break;
          case "EQUAL":
          case "NOT_EMPTY":
          case "EMPTY":
            $condition = " = ";
            $value = $filtervalue;
            break;
          case "NOT_EQUAL":
            $condition = " <> ";
            $value = $filtervalue;
            break;
          case "GREATER_THAN":
            $condition = " > ";
            $value = $filtervalue;
            break;
          case "LESS_THAN":
            $condition = " < ";
            $value = $filtervalue;
            break;
          case "GREATER_THAN_OR_EQUAL":
            $condition = " >= ";
            $value = $filtervalue;
            break;
          case "LESS_THAN_OR_EQUAL":
            $condition = " <= ";
            $value = $filtervalue;
            break;
          case "STARTS_WITH":
            $condition = " LIKE ";
            $value = "'{$filtervalue}%'";
            break;
          case "ENDS_WITH":
            $condition = " LIKE ";
            $value = "'%{$filtervalue}'";
            break;
          case "NULL":
            $condition = " IS NULL ";
            $value = "";
            break;
          case "NOT_NULL":
            $condition = " IS NOT NULL ";
            $value = "";
            break;
          }
        }
        $filter_clause.= " " . $filterdatafield . $condition . $value;
//fputs( $debugfile, "   generated filter_clause: ".$filter_clause.    "\n");
        if ($i == $filterscount - 1) {
          $filter_clause.= ")";
        }
        $tmpfilteroperator = $filteroperator;
        $tmpdatafield = $filterdatafield;
      }
    }
  }


// get data and store in a json array
  // Special case for very long numerics. Must be converted to char before sending to client
  $datafieldsHK = array("SQLHashKey","PLANHashKey");
  
  $total_rows=0;
  if ( isset($queryfile) && ($queryfile != '') ) {
    include ($queryfile);
  
    $result = asemon_query($query, $pid);
    if ($result) {
      while (($row=asemon_fetch_assoc($result))) {
        $myrow = array();
        foreach ($row as $key => $value) {
          if ( in_array($key, $datafieldsTS) ) {
            $dt = date_create($value);
            if ($dt)
              $myrow[$key] = date_format($dt,'Y/m/d H:i:s.u');
            else
              $myrow[$key] = '';
          }
          else if ( in_array($key, $datafieldsHK) ) {
             $myrow[$key] = (string)$value;
          }
          else if (($key == 'SQLText') && ($SQLTextIsCompressed) )
             $myrow[$key] = gzuncompress(pack("H*",$value));
               else
                 $myrow[$key] = $value;
        }
        $rows[] = $myrow;
        $total_rows++;
      }
    }
  }

  if ($total_rows==0) $rows=array();

  if ($error == "")
    $data = array(
      'status' => 'success',
      'TotalRows' => $total_rows,
      'Rows' => $rows,
      'query' => $query,
      'filter_clause' => $filter_clause,
      'sort_clause' => $sort_clause
      );

  else
    $data = array(
      'status' => 'error',
      'message' => $error,
      'query' => $query,
      'filter_clause' => $filter_clause,
      'sort_clause' => $sort_clause
      );

  echo json_encode($data);

//fclose($debugfile);
?>
<?php
  require_once("config.php");

  // Get PHP version
  list($PHP_main_version) = explode(".",phpversion());
  $PHP_main_version = (int)$PHP_main_version;

  $archive_password_is_encrypted = 0;
  if (isset($default_archive_password) && $default_archive_password != "") {
    // encrypt password

    if ($password_encryption_type == 'normal')
      $pubKey = file_get_contents($rootDir.'/COMMON/keys/public.der');
    
    if ($password_encryption_type == 'default')
      $pubKey = file_get_contents($rootDir.'/COMMON/keys/default_public.der');
    
    if (isset($pubKey)) {
        //Encrypt
        define('CRYPT_RSA_PKCS15_COMPAT', true);
        if ($PHP_main_version==5) {
            $rsa2 = new Crypt_RSA();
            $rsa2->setEncryptionMode(CRYPT_RSA_ENCRYPTION_PKCS1);
            $rsa2->loadKey($pubKey); // public key
            $default_archive_password = base64_encode ($rsa2->encrypt($default_archive_password));
        }
        else {
            $public = \phpseclib3\Crypt\RSA::loadPublicKey($pubKey);
            $encrypter = $public->withPadding(\phpseclib3\Crypt\RSA::ENCRYPTION_PKCS1);
            $encryptedData = $encrypter->encrypt($default_archive_password);
            $default_archive_password = base64_encode ($encryptedData);
        }
        $archive_password_is_encrypted = 1;
    }
  }

?>


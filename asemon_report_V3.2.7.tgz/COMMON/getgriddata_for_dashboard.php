<?php
  // Retreive data for grid
  $result = asemon_query($query, $pid);
  if ($result) {
    while (($row=asemon_fetch_assoc($result))) {
      $myrow = array();
      foreach ($row as $key => $value) {
        if ( in_array($key, $datafieldsTS) ) {
          $dt = date_create($value);
          if ($dt)
            $myrow[$key] = date_format($dt,'Y/m/d H:i:s.u');
          else
            $myrow[$key] = '';
        }
        else if ( in_array($key, $datafieldsHK) ) {
           $myrow[$key] = (string)$value;
        }
        else if (($key == 'SQLText') && ($SQLTextIsCompressed) )
           $myrow[$key] = gzuncompress(pack("H*",$value));
             else
               $myrow[$key] = $value;
      }
      $rows[] = $myrow;
      $total_rows++;
    }
  }
  if ($total_rows==0) $rows=array();
  if ($error == "")
    $data = array(
      'status' => 'success',
      'TotalRows' => $total_rows,
      'Rows' => $rows,
      'query' => $query,
      'filter_clause' => $filter_clause,
      'sort_clause' => $sort_clause
      );
  else
    $data = array(
      'status' => 'error',
      'message' => $error,
      'query' => $query,
      'filter_clause' => $filter_clause,
      'sort_clause' => $sort_clause
      );

?>
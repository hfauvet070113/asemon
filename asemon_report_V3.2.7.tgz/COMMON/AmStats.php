<div class="AmStats nondisplay">
  <center>
  <div class="maingrid">
    <div ID="AmStats_statistics" class="asemongrid singlegrid" ></div>
    <div ID="AmStats_statistics_mess" class="nondisplay" >  </div>
  </div>
  </center>
</div>

<script type="text/javascript">
  var height =    $('#page-content').innerHeight() - 55;




  if (typeof detail_type != 'undefined')
    $('.AmStats').removeClass('nondisplay');

  $('#AmStats_statistics').asemonGrid({
    'title' : 'Asemon Logger Statistics',
    'width' : '100%',
    'height' : height,
    'rowcount': 200,
    'filterable': true,
    'showaggregates': true,
    'querydata': {'queryfile' : '', 'default_order_by' : 'Thread'},
    'beforeRefresh': function() {refresh_AmStats_statistics (this[0]);},
    'datafieldsMapping': {},
    'datafields': [
           { name: 'Thread',        type: 'string'},
           { name: 'nbCollect',     type: 'number'},
           { name: 'avgcWait_ms',   type: 'number'},
           { name: 'avgcActive_ms', type: 'number'},
           { name: 'avgaWait_ms',   type: 'number'},
           { name: 'avgaActive_ms', type: 'number'},
           { name: 'archRows',      type: 'number'},
           { name: 'avgdelay',      type: 'number'}
    ],
    'columns': [
           { text: 'Thread     ',    datafield: 'Thread',        width: 120,  filterable: true},
           { text: 'nbCollect  ',    datafield: 'nbCollect',     width: 100,  filterable: false, cellsformat: 'd',   cellsalign: 'right' ,aggregates: ['sum']},
           { text: 'avgcWait_ms   ', datafield: 'avgcWait_ms',   width: 100,  filterable: false, cellsformat: 'd2',  cellsalign: 'right'},
           { text: 'avgcActive_ms ', datafield: 'avgcActive_ms', width: 100,  filterable: false, cellsformat: 'd2',  cellsalign: 'right'},
           { text: 'avgaWait_ms   ', datafield: 'avgaWait_ms',   width: 100,  filterable: false, cellsformat: 'd2',  cellsalign: 'right'},
           { text: 'avgaActive_ms ', datafield: 'avgaActive_ms', width: 100,  filterable: false, cellsformat: 'd2',  cellsalign: 'right'},
           { text: 'avgArchRows',    datafield: 'archRows',      width: 100,  filterable: false, cellsformat: 'd0',  cellsalign: 'right'},
           { text: 'avgdelay',       datafield: 'avgdelay',      width: 100,  filterable: false, cellsformat: 'd0',  cellsalign: 'right'},
           { text: '', width: 25,  filterable: false}
    ]
  });

  function refresh_AmStats_statistics (grid) {
    var asemondata = jQuery.data(grid, 'asemondata');
    var AmStatsExists = 0;
    var delayExists = 0;


    if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_AmStats') )  )
      AmStatsExists = 1;

    if ( (ARContext.ServerName!="") && ( existColumn(ARContext.ServerName+'_AmStats', 'delay') )  ) {
      delayExists = 1;
    }

    if ( AmStatsExists == 0) {
      $('#AmStats_statistics').hide();
      $('#AmStats_statistics_mess').show();
      $('#AmStats_statistics_mess').html('<p>Asemon_logger statistics (stats on asemon_logger threads) is not available. The AmStats collector has not been activated for server '+ARContext.ServerName+'.</P><P> (Add AmStats.xml in the asemon_logger config file)</p>');
      $.extend(asemondata, {'querydata' : {'queryfile' : '', 'query': ''}});
      return;
    }
    else {
      $('#AmStats_statistics').show();
      $('#AmStats_statistics_mess').hide();
    }


    $(grid).asemonGrid({'querydata': {'queryfile' : 'sql_AmStats_statistics.php', 'delayExists': delayExists}});
   
  }

  onArchCnxOpened = function(){
    $('.AmStats').removeClass('nondisplay');
    $('#AmStats_statistics').asemonGrid('refresh');
  }

</script>
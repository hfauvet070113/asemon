<?php
  // Get PHP version
  list($PHP_main_version) = explode(".",phpversion());
  $PHP_main_version = (int)$PHP_main_version;

  if ($PHP_main_version==5) {
      set_include_path(get_include_path() . PATH_SEPARATOR . $rootDir.'/COMMON/phpseclib');
      include('Crypt/RSA.php');
  }
  else
      require_once $rootDir.'/autoloader.php';


  function decrypt($strBase64CipherText)
  {
    global $error, $rootDir, $password_encryption_type, $PHP_main_version;

    if ($strBase64CipherText=="") return(""); // Case when password not defined by user , when it uses aseuserstore for example

    if ($password_encryption_type == 'normal')
      $privKey = file_get_contents($rootDir.'/COMMON/keys/private.pem');
    
    if ($password_encryption_type == 'default')
      $privKey = file_get_contents($rootDir.'/COMMON/keys/default_private.pem');
    
    if ($password_encryption_type == 'none')
      return ($strBase64CipherText);
  

    //Decrypt
    $decrypted_text = "";
    if ($PHP_main_version==5) {
        $rsa = new Crypt_RSA();
        $rsa->setEncryptionMode(CRYPT_RSA_ENCRYPTION_PKCS1);
        $rsa->loadKey($privKey); // private key
    
        define('CRYPT_RSA_PKCS15_COMPAT', true);
        $decrypted_text = $rsa->decrypt(base64_decode($strBase64CipherText));
    }
    else {
        $private = \phpseclib3\Crypt\RSA::loadPrivateKey($privKey);

        //define('CRYPT_RSA_PKCS15_COMPAT', true);

        $private = $private->withPadding(\phpseclib3\Crypt\RSA::ENCRYPTION_PKCS1);

        $decrypted_text = $private->decrypt(base64_decode($strBase64CipherText));
    }
    return ($decrypted_text);
  }

?>
<?php
// Get PHP version
list($PHP_main_version) = explode(".",phpversion());
$PHP_main_version = (int)$PHP_main_version;

if ($PHP_main_version==5) {
    set_include_path(get_include_path() . PATH_SEPARATOR . 'COMMON/phpseclib');
    include('Crypt/RSA.php');
}
else
    require_once $rootDir.'/autoloader.php';

$genkeysOutputmess="";
//set_include_path(get_include_path() . PATH_SEPARATOR . 'COMMON/phpseclib');


$privatekey = file_get_contents($rootDir.'/COMMON/keys/private.pem');
$publickey = file_get_contents($rootDir.'/COMMON/keys/public.der');
$publickey = base64_encode($publickey);
if ($privatekey) {
  //$genkeysOutputmess = $genkeysOutputmess.  "
  //<script type='text/javascript'>
  //  $('#mainmessageDIV').empty();
  //</script>
  //Genkey :  private key exists"."<br />\n";

  //$genkeysOutputmess = $genkeysOutputmess.  "privatekey : ".$privatekey."<br />\n";
  //$genkeysOutputmess = $genkeysOutputmess.  "publickey : ".$publickey."<br />\n";
  $privatekey  = "";
  $password_encryption_type = "normal";
}
else {
  $genkeysOutputmess = $genkeysOutputmess. "Genkey :  generating new SSL keys. Please wait ... <br />\n";   

  // Create the private and public key

  if ($PHP_main_version==5) {
      $rsa = new Crypt_RSA(); 
      extract($rsa->createKey(1024));
      //$genkeysOutputmess = $genkeysOutputmess.  "privatekey : ".$privatekey."<br />\n";  
  }
  else {
      $privatekey = \phpseclib3\Crypt\RSA::createKey(1024);
      $publickey = $privatekey->getPublicKey();
      $genkeysOutputmess = $genkeysOutputmess.  "privatekey : ".$privatekey."<br />\n";
  }

  if (!$privatekey) {
    $genkeysOutputmess = $genkeysOutputmess.  "Genkey :  errors during generation of SSL keys"."<br />\n";

    $genkeysOutputmess = $genkeysOutputmess.  "Genkey :  try opening default keys...<br />\n";
    $privatekey = file_get_contents($rootDir.'/COMMON/keys/default_private.pem');
    $publickey  = file_get_contents($rootDir.'/COMMON/keys/default_public.der');
    if ((!$privatekey)||(!$publickey)) {
      $genkeysOutputmess = $genkeysOutputmess.  "Err. opening default keys. Password will not be encrypted"."<br />\n";
      $genkeysOutputmess = $genkeysOutputmess.  "<br />You can connect to the server<br />\n";
      $password_encryption_type = "none";
    }
    else {
      $genkeysOutputmess = $genkeysOutputmess.  "Asemon_report will use default keys to encrypt password"."<br />\n";
      $genkeysOutputmess = $genkeysOutputmess.  "<br />You can connect to the server<br />\n";
      $password_encryption_type = "default"; 
      $publickey = base64_encode($publickey);
    }
  }
  else {
    //$genkeysOutputmess = $genkeysOutputmess.  "privatekey : ".$privatekey."<br />\n";
    //$genkeysOutputmess = $genkeysOutputmess.  "publickey : ".$publickey."<br />\n";

    //$genkeysOutputmess = $genkeysOutputmess.  "rootDir = ".$rootDir."<br />\n";
    file_put_contents($rootDir.'/COMMON/keys/private.pem', $privatekey);
    file_put_contents($rootDir.'/COMMON/keys/public.der', $publickey);
    $publickey = base64_encode($publickey);
    $password_encryption_type = "normal";

    $genkeysOutputmess = $genkeysOutputmess.  "Genkey :  SSL keys generated"."<br />\n";
    $genkeysOutputmess = $genkeysOutputmess.  "<br />You can connect to the server<br />\n";

  }


}

?>
<?php
  // retreive all posted params and affect them to variables
  foreach ($_POST as $key => $value)
    @$$key=$value;

  include ("connectArchiveServer.php");	

 $queries = json_decode($queriesJSON, true);

 $ResultSets = [];
  foreach ($queries as $queryname => $query) {  
    $result = asemon_query($query, $pid);
    if ($result == false) {
      $error = "Error in query named : ".$queryname;
      break;
    }
    $rows = [];
    while (($row=asemon_fetch_assoc($result))) {
      $myrow = array();
      foreach ($row as $key => $value) {
        $myrow[$key] = $value;
      }
      $rows[] = $myrow;
    }  
    if ( $error != "")
      break;
    $ResultSets [$queryname] = $rows;

  }


  if ($error == "")
    $data = array(
      'status' => 'success',
      'ResultSets' => $ResultSets
      );

  else
    $data = array(
      'status' => 'error',
      'message' => $error,
      'query' => $query
      );

  echo json_encode($data);


?>
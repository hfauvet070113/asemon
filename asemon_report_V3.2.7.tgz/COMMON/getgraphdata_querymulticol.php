<?php
  // Retrieve series of data. Each data has a timestamp
  // First column must be datetime converted in format 109
  // max 10 other columns in order to generate 10 series

  include_once ("aggregate_data.php");

  $maxvalues = 1000;
  $delaymultiplier = 4;


  if (!isset($InReport) ||!$InReport) {
    // script called in interactive mode, not from a report

    // retreive all posted params and affect them to variables
    foreach ($_POST as $key => $value)
      @$$key=$value;
    
    include ("connectArchiveServer.php");	
  }

  date_default_timezone_set("UTC");

//  $debugfile = fopen('/tmp/getgraphdata_querymulticol'.$graphname.'.txt', 'a+');


  if ( !isset($delay) ) $delay = 1000000000;  // delay : wait between two collects. Unit : second. If not set, considere delay is infinite  
  else $delay = intval($delay);


  if (!isset($InReport) || !$InReport) {
    if (isset($queryfile))
      include ($queryfile);

    if ($query !="") $result = asemon_query($query, $pid);
    //else $error= "No data";
  }

  if ($error == "") {
    $total_rows=0;
    $previousTime = 0;
    $series = array();
    $serie0 = [];
    $serie1 = [];
    $serie2 = [];
    $serie3 = [];
    $serie4 = [];
    $serie5 = [];
    $serie6 = [];
    $serie7 = [];
    $serie8 = [];
    $serie9 = [];
    $serie10 = [];
    //$timeswithnull = [];

    $firstrow = true;
    while (($row=asemon_fetch_assoc($result))) {  
      if ($firstrow) {
        // retreive col names
        foreach ($row as $key => $value) {
          if ( $key == 'Ts') continue;
          $colnames [] = $key;
        }
        $firstrow = false;
      }
      $Ts_value = date_create($row['Ts']);
      $time = intval(date_format($Ts_value,'U'));       // number of s since 1/1/1970
      $msec = intval(date_format($Ts_value,'u')) / 1000;// ms part of the value
      $Ts = $time*1000 + $msec;
      
      // Check if there is a hole in data collect
      if (($previousTime > 0 ) && ( ($time - $previousTime) > $delaymultiplier*$delay) ) {
        // yes we have a hole
        // add a null point 1s after the last seen point
        $nullpointtime = ($previousTime+1)*1000;
        $serie0[] = [$nullpointtime, null];
        if (count($serie1) > 0) $serie1[] = [$nullpointtime, null];
        if (count($serie2) > 0) $serie2[] = [$nullpointtime, null];
        if (count($serie3) > 0) $serie3[] = [$nullpointtime, null];
        if (count($serie4) > 0) $serie4[] = [$nullpointtime, null];
        if (count($serie5 ) > 0) $serie5 [] = [$nullpointtime, null];
        if (count($serie6 ) > 0) $serie6 [] = [$nullpointtime, null];
        if (count($serie7 ) > 0) $serie7 [] = [$nullpointtime, null];
        if (count($serie8 ) > 0) $serie8 [] = [$nullpointtime, null];
        if (count($serie9 ) > 0) $serie9 [] = [$nullpointtime, null];
        if (count($serie10) > 0) $serie10[] = [$nullpointtime, null];
        $total_rows++;
        //$timeswithnull[] = [$previousTime, $time, $time - $previousTime, $delaymultiplier*$delay, $nullpointtime];
        // add a null point 1s before the new point
        $nullpointtime = ($time-1)*1000;
        $serie0[] = [$nullpointtime, null];
        if (count($serie1) > 0) $serie1[] = [$nullpointtime, null];
        if (count($serie2) > 0) $serie2[] = [$nullpointtime, null];
        if (count($serie3) > 0) $serie3[] = [$nullpointtime, null];
        if (count($serie4) > 0) $serie4[] = [$nullpointtime, null];
        if (count($serie5 ) > 0) $serie5 [] = [$nullpointtime, null];
        if (count($serie6 ) > 0) $serie6 [] = [$nullpointtime, null];
        if (count($serie7 ) > 0) $serie7 [] = [$nullpointtime, null];
        if (count($serie8 ) > 0) $serie8 [] = [$nullpointtime, null];
        if (count($serie9 ) > 0) $serie9 [] = [$nullpointtime, null];
        if (count($serie10) > 0) $serie10[] = [$nullpointtime, null];
        $total_rows++;
        //$timeswithnull[] = [$previousTime, $time, $time - $previousTime, $delaymultiplier*$delay, $nullpointtime];
      }
    
      $serie_num = 0;
      foreach ($row as $key => $value) {
        if ( $key == 'Ts') continue;
        if ( $serie_num == 0)
          $serie0[] = [$Ts, floatval($value)];
        else if ( $serie_num == 1)
          $serie1[] = [$Ts, floatval($value)];
        else if ( $serie_num == 2)
          $serie2[] = [$Ts, floatval($value)];
        else if ( $serie_num == 3)
          $serie3[] = [$Ts, floatval($value)];
        else if ( $serie_num == 4)
          $serie4[] = [$Ts, floatval($value)];
        else if ( $serie_num == 5)
          $serie5[] = [$Ts, floatval($value)];
        else if ( $serie_num == 6)
          $serie6[] = [$Ts, floatval($value)];
        else if ( $serie_num == 7)
          $serie7[] = [$Ts, floatval($value)];
        else if ( $serie_num == 8)
          $serie8[] = [$Ts, floatval($value)];
        else if ( $serie_num == 9)
          $serie9[] = [$Ts, floatval($value)];
        else if ( $serie_num == 10)
          $serie10[] = [$Ts, floatval($value)];
        $serie_num++;
      }
      $total_rows++;
      $previousTime = $time;
    }
    
    $cnt = count($serie0);
    if ($cnt > $maxvalues)
      $series[] = aggregate_data($serie0, $cnt);
    else
      $series[] = $serie0;
    
    $cnt = count($serie1);
    if ($cnt > 0) {
      if ($cnt > $maxvalues)
        $series[] = aggregate_data($serie1, $cnt);
      else
        $series[] = $serie1;
    }
    
    $cnt = count($serie2);
    if ($cnt > 0) {
      if ($cnt > $maxvalues)
        $series[] = aggregate_data($serie2, $cnt);
      else
        $series[] = $serie2;
    }
    
    $cnt = count($serie3);
    if ($cnt > 0) {
      if ($cnt > $maxvalues)
        $series[] = aggregate_data($serie3, $cnt);
      else
        $series[] = $serie3;
    }
    
    $cnt = count($serie4);
    if ($cnt > 0) {
      if ($cnt > $maxvalues)
        $series[] = aggregate_data($serie4, $cnt);
      else
        $series[] = $serie4;
    }
    
    $cnt = count($serie5);
    if ($cnt > 0) {
      if ($cnt > $maxvalues)
        $series[] = aggregate_data($serie5, $cnt);
      else
        $series[] = $serie5;
    }
    
    $cnt = count($serie6);
    if ($cnt > 0) {
      if ($cnt > $maxvalues)
        $series[] = aggregate_data($serie6, $cnt);
      else
        $series[] = $serie6;
    }
    
    $cnt = count($serie7);
    if ($cnt > 0) {
      if ($cnt > $maxvalues)
        $series[] = aggregate_data($serie7, $cnt);
      else
        $series[] = $serie7;
    }
    
    $cnt = count($serie8);
    if ($cnt > 0) {
      if ($cnt > $maxvalues)
        $series[] = aggregate_data($serie8, $cnt);
      else
        $series[] = $serie8;
    }
    
    $cnt = count($serie9);
    if ($cnt > 0) {
      if ($cnt > $maxvalues)
        $series[] = aggregate_data($serie9, $cnt);
      else
        $series[] = $serie9;
    }
    
    $cnt = count($serie10);
    if ($cnt > 0) {
      if ($cnt > $maxvalues)
        $series[] = aggregate_data($serie10, $cnt);
      else
        $series[] = $serie10;
    }
  }

  if ($error == "") {
    if ($firstrow)
      // no data
      $data = array(
      'status' => 'success',
      'TotalRows' => 0,
      'series' => null,
      'colnames' => null,
      'query' => $query
      );
    else
      $data = array(
      'status' => 'success',
      'TotalRows' => count($series[0]),
      'series' => $series,
      'colnames' => $colnames,
      'query' => $query 
      );
  }
  else
    $data = array(
      'status' => 'error',
      'message' => $error,
      'query' => $query
      );

  if (!isset($InReport) || !$InReport) {
    echo json_encode($data);
  }

//  fclose($debugfile);
?>
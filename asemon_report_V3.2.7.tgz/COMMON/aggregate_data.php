<?php
  function aggregate_data ($serie, $cnt) {
    global $maxvalues, $error, $debugfile, $delay;
    $totalTimeRange = $serie[$cnt-1][0] - $serie[0][0];
    $avgInterval_ms = $totalTimeRange / $maxvalues;
    if ($avgInterval_ms < $delay*1000)
      $avgInterval_ms = $delay*1000;
//    fputs( $debugfile, "Entr�e dans aggregate_data. Cnt = ".$cnt." totalTimeRange = ".$totalTimeRange." avgInterval_ms = ".$avgInterval_ms."\n");
    // Aggregate x points , where x = $cnt / 1000
    // keep null points
    $aggcnt = ($cnt / $maxvalues) - 1;
//    fputs( $debugfile, "Aggcnt = ".$aggcnt."\n");
    if ($aggcnt < 1) return $serie;
    $currentsum = 0;
    $currentcnt = 0;
    $lastTS = null;
    $lastIsNull = false;
    $lastInsertedTS = null;
    
    for ($i=0; $i < $cnt; $i++) {
      if (is_null($serie[$i][1]) ) {
        // found null point
//        fputs( $debugfile, "found null point. currentcnt= ".$currentcnt."\n");
        if ($currentcnt > 0) {
          // add current avg value
//          fputs( $debugfile, "add last avg. Ts= ".$lastTS." val=".$currentsum / $currentcnt."\n");
          $newserie[] = [$lastTS, $currentsum / $currentcnt];
          $lastInsertedTS = $lastTS;
          $currentsum = 0;
          $currentcnt = 0;
        }
        if ($lastIsNull) {
          if ( ($serie[$i][0] - $lastInsertedTS) < $avgInterval_ms) {
            // ignore this intermediate null
//            fputs( $debugfile, "ignore intermediate null. Ts= ".$serie[$i][0]."\n");
          }
          else {
            // save this null point
            $lastInsertedTS = $serie[$i][0];
//            fputs( $debugfile, "save null point. Ts= ".$lastInsertedTS."\n");
            $newserie[] = $serie[$i];
            $lastIsNull = true;
          }
        }
        else {
          // save this null point
          $lastInsertedTS = $serie[$i][0];
//          fputs( $debugfile, "save null point. Ts= ".$lastInsertedTS."\n");
          $newserie[] = $serie[$i];
          $lastIsNull = true;
        }
      }
      else {
        if ($lastIsNull) {
//          fputs( $debugfile, "save null point. Ts= ".$lastTS."\n");
          $newserie[] = [$lastTS, null];
          $lastIsNull = false;
          $lastInsertedTS = $lastTS;
        }
        if ($currentcnt > $aggcnt) {
          // add current avg value
//          fputs( $debugfile, "add current avg. Ts= ".$lastTS." val=".$currentsum / $currentcnt."\n");
          $newserie[] = [$lastTS, $currentsum / $currentcnt];
          $lastInsertedTS = $lastTS;
          $currentsum = 0;
          $currentcnt = 0;
        }
        else {
          $currentsum += $serie[$i][1];
          $currentcnt++;
        }
      }
      $lastTS = $serie[$i][0];
    }
    // save last avg if exist
    if ($currentcnt > 0) {
//      fputs( $debugfile, "add last avg. Ts= ".$lastTS." val=".$currentsum / $currentcnt."\n");
      $newserie[] = [$lastTS, $currentsum / $currentcnt];
    }
    // save last NULL if exist
    if ($lastIsNull) {
//      fputs( $debugfile, "save last null point. Ts= ".$lastTS."\n");
      $newserie[] = [$lastTS, null];
    }

//    fputs( $debugfile, "Sortie de aggregate_data. Newcnt = ".count($newserie)."\n");
    return $newserie;
  }
?>
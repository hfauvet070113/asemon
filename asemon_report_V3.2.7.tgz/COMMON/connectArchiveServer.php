<?php
//error_reporting(E_ALL);
  // For Kerberos support : retreive credential cache used by Apache
  if ( isset ($_SERVER['KRB5CCNAME']) && ($_SERVER['KRB5CCNAME'] != "") )
    putenv("KRB5CCNAME={$_SERVER['KRB5CCNAME']}");

  // Retreive ARContext
  if ( !isset($ARContextJSON) ) {
    $error="ARContext is not defined";  
    $data = array(        
        'status' => 'error',
        'message' => $error,
        'query' => ''   
        );
    echo json_encode($data);
    return;
  }

  $ARContext = json_decode($ARContextJSON, true);

  if (isset($ARContext['rootDir']                 )) $rootDir                  = $ARContext['rootDir'];
  if (isset($ARContext['version_asemon_report']   )) $version_asemon_report    = $ARContext['version_asemon_report'];
  if (isset($ARContext['ArchiveServer']           )) $ArchiveServer            = $ARContext['ArchiveServer'];
  if (isset($ARContext['ArchiveUser']             )) $ArchiveUser              = $ARContext['ArchiveUser'];
  if (isset($ARContext['ArchiveDatabase']         )) $ArchiveDatabase          = $ARContext['ArchiveDatabase'];
  if (isset($ARContext['ArchiveCharset']          )) $ArchiveCharset           = $ARContext['ArchiveCharset'];
  if (isset($ARContext['ArchSrvVersion']          )) $ArchSrvVersion           = $ARContext['ArchSrvVersion'];
  if (isset($ARContext['ArchSrvsbssav']           )) $ArchSrvsbssav            = $ARContext['ArchSrvsbssav'];
  if (isset($ARContext['DFormat']                 )) $DFormat                  = $ARContext['DFormat'];
  if (isset($ARContext['ArchSrvType']             )) $ArchSrvType              = $ARContext['ArchSrvType'];
  if (isset($ARContext['StartTimestamp']          )) $StartTimestamp           = $ARContext['StartTimestamp'];
  if (isset($ARContext['EndTimestamp']            )) $EndTimestamp             = $ARContext['EndTimestamp'];
  if (isset($ARContext['ArchivePassword']         )) $ArchivePassword          = $ARContext['ArchivePassword'];
  if (isset($ARContext['ServerName']              )) $ServerName               = $ARContext['ServerName'];
  if (isset($ARContext['ServerType']              )) $ServerType               = $ARContext['ServerType'];
  if (isset($ARContext['password_encryption_type'])) $password_encryption_type = $ARContext['password_encryption_type'];

  if ( !isset($ArchiveServer) ) return;

  require_once($rootDir."/config.php");

  require_once("decryptPHP.php");
  $ArchivePassword = decrypt($ArchivePassword);
  if ($error) return;

  // Get PHP version
  list($PHP_main_version) = explode(".",phpversion());
  // $error= "PHP_main_version=".$PHP_main_version."<BR/>";
  $PHP_main_version = (int)$PHP_main_version;

  // Only pass a charset value if the user has specified one.
  // Don't pass the empty string, instead pass in NULL.
  // If NULL, force to utf8 : this is needed for json_encode
  $Charset = strlen($ArchiveCharset) > 0 ? $ArchiveCharset : 'utf8';


  if ( ($PHP_main_version==5) && (!function_exists("msg_handler_GET")) ) {
       function msg_handler_GET($msgnumber, $severity, $state, $line, $msgtext) {
           global $error, $ArchivePassword;
           if ($msgnumber==911) return; // Database does not exists. Return, and get the list of databases.
           if ($msgnumber==5701) return;
           if ($msgnumber==5703) return; // Charset
           if ($msgnumber==5704) return; // Charset
           if ($msgnumber==3701) return; // ASE - Cannot drop the table 'xxx', because it doesn't exist in the system catalogs. 
           if ($msgnumber==2706) return; // IQ - SQL Anywhere Error -141: Table 'XXXX' not found 
           if ($msgnumber==2411) return; // ASE - No conversion will be done
           if ($msgnumber==2401) return; // ASE - Character set conversion is not available between client character set 'utf8' and server character set 'iso_1'.

           $error="Sybase error in msg_handler_GET :  ".$msgnumber." severity : ".$severity." state : ".$state." line : ".$line." Msg : ".str_replace("\n","",$msgtext);
           //var_dump( $msgnumber, $severity, $state, $line, $msgtext);

       }

       function msg_handler_POST($msgnumber, $severity, $state, $line, $msgtext) {
           if ($msgnumber==911) return; // Database does not exists. Return, and get the list of databases.
           if ($msgnumber==5701) return;
           if ($msgnumber==5703) return; // Charset
           if ($msgnumber==5704) return; // Charset
           if ($msgnumber==3701) return; // ASE - Cannot drop the table 'xxx', because it doesn't exist in the system catalogs. 
           if ($msgnumber==2706) return; // IQ - SQL Anywhere Error -141: Table 'XXXX' not found 
           if ($msgnumber==2411) return; // ASE - No conversion will be done
           if ($msgnumber==2401) return; // ASE - Character set conversion is not available between client character set 'utf8' and server character set 'iso_1'.
           $error="Sybase error in msg_handler_POST :  ".$msgnumber." severity : ".$severity." state : ".$state." line : ".$line." Msg : ".str_replace("\n","",$msgtext);
       }

     function timeout() {
       $status = connection_status();
       if ($status >0) {
         $error= "Script aborted, connection_status = $status";
       }
     }

     if ((!isset($ARContextJSON_mode)) || ($ARContextJSON_mode == "GET") )
         // When passed by POST, means PHP is called thru AJAX, so don't implement this error handler
         sybase_set_message_handler('msg_handler_GET');
     else
         sybase_set_message_handler('msg_handler_POST');
     register_shutdown_function ("timeout");
  }

  if ( !isset($pid) || $pid==0 ) {

    // Try to connect even if ArchiveServer is not defined, may use aseuserstore (in that case ArchiveUser is considered the key in aseuserstore) Works with sybase_ct not PDO
    // Try to connect even if user is not defined (will try to use Kerberos) Works with sybase_ct. With PDO define security at odbc DSN level

    $ApplicationName="asemon_report_".$version_asemon_report;
    
    $pid=asemon_connect($ArchiveServer, $ArchiveUser, $ArchivePassword, $Charset, $ApplicationName, $ArchiveDatabase);        
    if (!$pid) {
         $error = "Cannot connect to archive server";
         return;
    }
    
    
    $result=asemon_query("select res=substring(@@version,1,charindex('/',@@version)-1), srvn=@@servername", $pid);
    if ($result==FALSE) {
       // Error, retry opening the connection   
         $pid=asemon_connect($ArchiveServer, $ArchiveUser, $ArchivePassword, $Charset, $ApplicationName, $ArchiveDatabase);
       if (!$pid) {
            
            return;
       }
       $result=asemon_query("select res=substring(@@version,1,charindex('/',@@version)-1), srvn=@@servername", $pid);
    }


    $row=asemon_fetch_assoc($result);
 
    $ArchSrvType= $row["res"];
    $ArchiveServer= $row["srvn"];
    $ARContext['ArchSrvType']=$ArchSrvType;
    $ARContext['ArchiveServer']=$ArchiveServer;
    if ($ArchSrvType=="SAP IQ") $ArchSrvType="Sybase IQ"; // Restore old name for compatibility
    if ($ArchSrvType=="Adaptive Server Enterprise") {
      if ((isset($ArchiveDatabase)) && ( $ArchiveDatabase != "") ) {
        //echo "ArchiveDatabase=".$ArchiveDatabase."<BR>";
        asemon_query("use ".$ArchiveDatabase, $pid); 
      }
      else {
          $result=asemon_query("select dbname from master..syslogins where name=suser_name()", $pid);
          $row=asemon_fetch_assoc($result);
          $ArchiveDatabase = $row["dbname"];
      }
      asemon_query("set textsize 262144", $pid);
    }
    else {
       // if connection comes from the pool, need to do a commit to see last data
       asemon_query("commit",$pid);
       asemon_query("set temporary option chained='off'",$pid);
       asemon_query("SET TEMPORARY OPTION SNAPSHOT_VERSIONING = 'Row-level' ",$pid);
       // asemon_query("SET TEMPORARY OPTION QUOTED_IDENTIFIER = 'ON' ",$pid);
       asemon_query("SET TEMPORARY OPTION BLOCKING = 'ON' ",$pid);
       asemon_query("set temporary option BLOCKING_TIMEOUT='60' ",$pid);
    }
    asemon_query("set dateformat ".$DFormat, $pid);

    // Force language to us_english (for date convertions)
    $result = asemon_query("set language us_english", $pid);
  
    set_time_limit(3600);
    

  }



  function asemon_connect($ArchiveServer, $ArchiveUser, $ArchivePassword,$Charset, $ApplicationName, $ArchiveDatabase) {
      global $PHP_main_version;
      global $odbc_module;
      if ($PHP_main_version==5)
          // Connect using old interface (sybase_ct)
          $pid=sybase_pconnect($ArchiveServer, $ArchiveUser, $ArchivePassword,$Charset, $ApplicationName);
      else {
          // Connect using PDO interface and odbc
          if ($odbc_module=="PHP-DBO_ODBC") {
            try {
//            $pid = new PDO("odbc:Driver={Adaptive Server Enterprise};Server=xxxxx;Port=yyyy;Database=".$ArchiveDatabase.";ApplicationName=".$ApplicationName.";CharSet=".$Charset.";", 
              $pid = new PDO("odbc:".$ArchiveServer, 
                           $ArchiveUser, 
                           $ArchivePassword,
                           array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION) 
                          );
            } catch (PDOException $exception) {      
                $error="PHP-DBO_ODBC - Cannot connect to archive server using odbc. Error = ".$exception->getMessage()."
                DSN=".$ArchiveServer;  
                $data = array(        
                  'status' => 'error',
                  'message' => $error,
                  'query' => ''   
                );
                echo json_encode($data);
                exit;
            }
          } 



          else if ($odbc_module=="PHP-ODBC") {
            //$pid = odbc_connect($ArchiveServer, 
            if ( $ArchivePassword=="") {
                $conn_property = "Driver=Adaptive Server Enterprise;SecStoreKey=".$ArchiveUser;
                $pid = odbc_connect($conn_property ); 
            }
            else {
                $conn_property = "DSN=".$ArchiveServer.";ApplicationName=AsemonReport;EncryptPassword=1";
                $pid = odbc_connect($conn_property, $ArchiveUser, $ArchivePassword ); 
            }
            if ($pid==false) { 
                $odbc_errormsg= mb_convert_encoding(odbc_errormsg(), "UTF-8", "UTF-8");
                $error="PHP-ODBC - Cannot connect to archive server using odbc. Error = ".odbc_error()." ".$odbc_errormsg."\nCxn props : ".$conn_property;  
                $data = array(        
                  'status' => 'error',
                  'message' => $error,
                  'query' => ''   
                );
                echo json_encode($data);
                exit;
            }
          }
          else {
                $error="Invalid option in config file : odbc_module = ".$odbc_module;
                $data = array(        
                  'status' => 'error',
                  'message' => $error,
                  'query' => ''   
                );
                echo json_encode($data);
                exit;
          }

      }
      return $pid;
  }



  function asemon_query($query, $pid) {
    global $PHP_main_version;
    global $odbc_module;
    global $error;
    if ($PHP_main_version==5) {
      $result = sybase_query($query, $pid);
    }
    else {
      if ($odbc_module=="PHP-DBO_ODBC")
        $result = $pid->query($query);
      if ($odbc_module=="PHP-ODBC")
        $result = odbc_exec($pid, $query);
    }
    return $result;
  }
  

  function asemon_fetch_assoc($result) {
    global $PHP_main_version;
    global $odbc_module;
    global $error;
    if ($PHP_main_version==5) {
      $row=sybase_fetch_assoc($result);
    }
    else {
      if ($odbc_module=="PHP-DBO_ODBC")
        $row = $result->fetch( PDO::FETCH_ASSOC );
      if ($odbc_module=="PHP-ODBC")
        $row = odbc_fetch_array($result );
    }
    return $row;
  }


?>

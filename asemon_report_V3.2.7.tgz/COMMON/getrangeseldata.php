<?php

  $maxvalues = 1000;
  $delaymultiplier = 4;
  // Retrieve series of data. Each data has a timestamp
  // retreive all posted params and affect them to variables
  foreach ($_POST as $key => $value)
    @$$key=$value;

  include ("connectArchiveServer.php");	
  include ("aggregate_data.php");	

//  $debugfile = fopen('/tmp/getrangeseldata.txt', 'a+');

  if ( !isset($delay) ) $delay = 1000000000;  // delay : wait between two collects. Unit : second. If not set, considere delay is infinite  
  else $delay = intval($delay);

//    $data = array(
//      'status' => 'error',
//      'message' => $error,
//      'query' => $query
//      );
//
//  echo json_encode($data);
//  return;

  if ($queryrangesel == '') {
    if ($ServerType == 'ASE') {
      $query0="select cnt=count(*) from ".$ServerName."_Trends 
      where TrendID=1 and dt > 
       (select min(Timestamp) from ".$ServerName."_Engines where ContextSwitches>0
         and Timestamp >='".$StartRangesel."'
         and Timestamp <'".$EndRangesel."')
       and dt <= '".$EndRangesel."'";
  
      $query1="select Ts=convert(varchar,dt,109),Value from ".$ServerName."_Trends 
      where TrendID=1 and dt >= 
       (select min(Timestamp) from ".$ServerName."_Engines where ContextSwitches>0
         and Timestamp >='".$StartRangesel."'
         and Timestamp <'".$EndRangesel."')
       and dt <= '".$EndRangesel."'
      order by dt";
      $delay1=86400;
  
      $query2="select 
         Ts=convert(varchar,Timestamp,109)
        ,avgCpu=avg(convert(float,UserCPUTime*1000)/Interval*100)
       from ".$ServerName."_Engines
       where ContextSwitches>0
       and Timestamp >='".$StartRangesel."'
       and Timestamp <'".$EndRangesel."' 
       group by Timestamp
       order by Timestamp";
       $delay2=60;
    }
    if ($ServerType == 'IQ') {
      $query0="select cnt=1";

      $query2="select Ts=convert(varchar,Timestamp,109),
         TotCpu=(case when d_ProcessCPUUser   <0 then 0 else d_ProcessCPUUser   end) + (case when d_ProcessCPUSystem <0 then 0 else d_ProcessCPUSystem end)
       from ".$ServerName."_IQAsaStat
       where Timestamp >='".$StartRangesel."'
       and Timestamp <='".$EndRangesel."'
       order by Timestamp";
       $delay2=30;
    }

    if ($ServerType == 'RS') {
      $query0="select cnt=count(*) from ".$ServerName."_Trends 
      where TrendID=13 and dt > 
       (select min(Timestamp) from ".$ServerName."_RSStats where counter_id in (6057, 62000)
         and Timestamp >='".$StartRangesel."'
         and Timestamp <'".$EndRangesel."')
       and dt <= '".$EndRangesel."'";
  
      $query1="select Ts=convert(varchar,dt,109),Value=sum(Value) from ".$ServerName."_Trends 
      where TrendID in (13, 20) and dt >= 
       (select min(Timestamp) from ".$ServerName."_RSStats where counter_id in (6057, 62000)
         and Timestamp >='".$StartRangesel."'
         and Timestamp <'".$EndRangesel."')
       and dt <= '".$EndRangesel."'
      group by TrendID
      order by dt";
      $delay1=86400;
  
      $query2="select 
         Ts=convert(varchar,Timestamp,109),
         Value=sum(counter_obs)
       from ".$ServerName."_RSStats
       where counter_id in (6057, 62000)
       and Timestamp >='".$StartRangesel."'
       and Timestamp <'".$EndRangesel."' 
       group by Timestamp
       order by Timestamp";
       $delay2=60;
    }
    if ($ServerType == 'RAO') {
      $query0="select cnt=1";

      $query2="select Ts=convert(varchar,Timestamp,109),opers_scanned
       from ".$ServerName."_RAOSTATS
       where Timestamp >='".$StartRangesel."'
       and Timestamp <='".$EndRangesel."'
       order by Timestamp";
       $delay2=60;
    }

    $result = asemon_query($query0, $pid);
    $cnt = 0;
    if ((isset($result))&&($result!=null) ){
      $row=asemon_fetch_assoc($result);
      $cnt = $row['cnt'];
    }
    $error=""; // ignore errors on first query
    if ($cnt > 200) {
      // do the search on Trends
      $query=$query1;
      $delay=$delay1;
    }
    else {
      // do the search on real table
      $query=$query2;
      $delay=$delay2;
    }
  }
  else
    $query = $queryrangesel;

//fputs( $debugfile, "delay : ". $delay ."\n");
//fputs( $debugfile, "Query : ". $query ."\n");
  $result = asemon_query($query, $pid);
  $total_rows=0;
  $previousTime = 0;
  $series = array();
  $serie = [];

  date_default_timezone_set("UTC");

  while (($row=asemon_fetch_assoc($result))) {
//    fputs( $debugfile, "New value. Ts = ".$row['Ts']."\n");
    $Ts_value = date_create($row['Ts']);
    $time = intval(date_format($Ts_value,'U'));       // number of s since 1/1/1970
    $msec = intval(date_format($Ts_value,'u')) / 1000;// ms part of the value
    $Ts = $time*1000 + $msec;
    
    // Check if there is a hole in data collect
    if (($previousTime > 0 ) && ( ($time - $previousTime) > $delaymultiplier*$delay) ) {
      // yes we have a hole
      // add a null point 1s after the last seen point
      $nullpointtime = ($previousTime+1)*1000;
      $serie[] = [$nullpointtime, null];
      $total_rows++;
      
      // Since datetime type axis does not work for rangeselector, add null points for this interval
      $numberNullPoints = ( ($time-1) -  ($previousTime+1) ) / $delay;
//      fputs( $debugfile, "Prev time + 1 = ". ($previousTime+1) ." Time - 1 = ". ($time-1) ." -- Nb null points = ". $numberNullPoints ."\n");
      $delaycorrected = $delay;
      if ( $numberNullPoints > 10000) {
        $delaycorrected = $delay * 100;
        $numberNullPoints = $numberNullPoints / 100;
      }
      else
        if ( $numberNullPoints > 1000) {
          $delaycorrected = $delay * 10;
          $numberNullPoints = $numberNullPoints / 10;
        }
      for ($i=1; $i <= $numberNullPoints; $i++) {
        $serie[] = [ (($previousTime+1) + $delaycorrected*$i ) *1000, null];
        $total_rows++;
//        fputs( $debugfile, "  Add point : ". ( (($previousTime+1) + $delaycorrected*$i ) *1000 ) ."\n");
      }

      //$timeswithnull[] = [$previousTime, $time, $time - $previousTime, $delaymultiplier*$delay, $nullpointtime];
      // add a null point 1s before the new point
      $nullpointtime = ($time-1)*1000;
      $serie[] = [$nullpointtime, null];
      $total_rows++;
      //$timeswithnull[] = [$previousTime, $time, $time - $previousTime, $delaymultiplier*$delay, $nullpointtime];
    }

    foreach ($row as $key => $value) {
      if ( $key == 'Ts') continue;
      $serie[] = [$Ts, floatval($value)];
    }
    $total_rows++;
    $previousTime = $time;
  }

//$error="hgfh";


//  fputs( $debugfile, "  Before aggregation : total_rows=".$total_rows ."\n");
  $serie_agg = aggregate_data($serie,$total_rows);
  $total_rows = count($serie_agg);
//  fputs( $debugfile, "  After aggregation : total_rows=".$total_rows ."\n");

  if ($error == "")
    $data = array(
      'status' => 'success',
      'TotalRows' => $total_rows,
      'serie' => $serie_agg,
      'query' => $query 
      );

  else
    $data = array(
      'status' => 'error',
      'message' => $error,
      'query' => $query
      );

  echo json_encode($data);

//  fclose($debugfile);
?>
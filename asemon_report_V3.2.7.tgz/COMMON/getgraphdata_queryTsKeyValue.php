<?php
  include ("aggregate_data.php");	

  $maxvalues = 1500;


  // Retrieve series of data. Each data has a timestamp
  // retreive all posted params and affect them to variables
  foreach ($_POST as $key => $value)
    @$$key=$value;

  include ("connectArchiveServer.php");	

  date_default_timezone_set("UTC");


  //$debugfile = fopen('/tmp/getgraphdata_queryTsKeyValue'.$graphname.'.txt', 'a+');



  if ( !isset($delay) ) $delay = 1000000000;  // delay : wait between two collects. Unit : second. If not set, considere delay is infinite  
  else $delay = intval($delay);

//    $data = array(
//      'status' => 'error',
//      'message' => $error,
//      'query' => $query
//      );
//
//  echo json_encode($data);
//  return;




// get data and store in a json array
// First column (named "Ts") must be datetime converted in format 109
// Second column (named "Key") contains names of series
// Third column (named "Value") contains values 

  if (isset($queryfile))
    include ($queryfile);

  $result = asemon_query($query, $pid);
  $total_rows=0;

  $TsCrossKeys = array();
  $KeysList = array();
  $previousTs = 0;
  while (($row=asemon_fetch_assoc($result)))
  {
    $Ts_value = date_create($row['Ts']);
    $time = intval(date_format($Ts_value,'U'));       // number of s since 1/1/1970
    $msec = intval(date_format($Ts_value,'u')) / 1000;// ms part of the value
    $Ts = $time*1000 + $msec;
    $Key = $row["Key"];
    $Value = floatval($row["Value"]);
    
    if ($Ts <> $previousTs ) {
      // save previous structure
      $previousTs = $Ts;
      if (isset($KeyData))
        $TsCrossKeys[] = array ("Ts" => $Ts, "KD" => $KeyData);
      // allocate new structure
      $KeyData = array();
    }
    $KeyData[$Key] = $Value;

    // KeyList contains sum of values for each key
    if (isset($KeysList[$Key]))
      $KeysList[$Key] += $Value;
    else
      $KeysList[$Key] = $Value;
  }
  // Save last structure
  if (isset($KeyData))
    $TsCrossKeys[] = array ("Ts" => $Ts, "KD" => $KeyData);

  // Sort the keylist by number of values desc
  arsort($KeysList);
  // Keep first 10 keys
  $i=0;
  foreach ($KeysList as $Key => $val){
    if ($i > 9 ) break;
    $FilteredKeyList[$Key] = $val;
    $i++;
  }

  // Now, generate arrays of (Ts, Value) for each different Key
  $series = array();
  foreach($FilteredKeyList as $Key => $val1) 
  {
    $serie = [];
    foreach($TsCrossKeys as $TsKeyData)
    {
      $Ts = $TsKeyData["Ts"];
      $KeyData = $TsKeyData["KD"];
      $serie[] = array($Ts, (isset($KeyData[$Key]) ? $KeyData[$Key] : 0));
    }
    $cnt = count($serie);
    $series[] = aggregate_data($serie, $cnt);
  }
  // Generate colnames
  $colnames = [];
  foreach ($KeysList as $Key => $val)
    $colnames[] = $Key;

  if ($error == "")
    $data = array(
      'status' => 'success',
      'TotalRows' => count($series[0]),
      'series' => $series,
      'colnames' => $colnames,
      'query' => $query ,
      'TsCrossKeys' => $TsCrossKeys
      );

  else
    $data = array(
      'status' => 'error',
      'message' => $error,
      'query' => $query
      );

  echo json_encode($data);

//  fclose($debugfile);
?>
<?php
  $total_rows=0;
  $series = array();
  $serie0 = [];
  $serie1 = [];
  $serie2 = [];
  $serie3 = [];
  $serie4 = [];
  //$timeswithnull = [];
  date_default_timezone_set("UTC");
  while (($row=asemon_fetch_assoc($result))) {
    $serie_num = 0;
    foreach ($row as $key => $value) {
      if ( $serie_num == 0)
        $serie0[] = $value;
      else if ( $serie_num == 1)
        $serie1[] = floatval($value);
      else if ( $serie_num == 2)
        $serie2[] = floatval($value);
      else if ( $serie_num == 3)
        $serie3[] = floatval($value);
      else if ( $serie_num == 4)
        $serie4[] = floatval($value);
      $serie_num++;
    }
    $total_rows++;
  }
  $series[] = $serie0;
  if (count($serie1) > 0) $series[] = $serie1;
  if (count($serie2) > 0) $series[] = $serie2;
  if (count($serie3) > 0) $series[] = $serie3;
  if (count($serie4) > 0) $series[] = $serie4;
  if ($error == "")
    $data = array(
      'status' => 'success',
      'TotalRows' => $total_rows,
      'series' => $series,
      'query' => $query/*,
      'timeswithnull' => $timeswithnull*/ 
      );
  else
    $data = array(
      'status' => 'error',
      'message' => $error,
      'query' => $query
      );
?>
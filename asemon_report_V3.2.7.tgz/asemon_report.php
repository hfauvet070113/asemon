    <?php
      $version_asemon_report = "V3.2.7 (261022)";

      $rootDir = getcwd();
      //echo "rootDir=".$rootDir."<br />\n";
      require_once("COMMON/genkeys.php");
      //$password_encryption_type="none";
      require_once("COMMON/encrypt_pwd_config.php");
    ?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Asemon_report</title>
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="icon" href="favicon.ico" type="image/x-icon">
    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">
    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- Custom CSS -->
    <link href="css/asemon_report.css" rel="stylesheet">
    <link href="css/stylecalend.css" rel="stylesheet" >

    <!-- add the jQWidgets base styles and one of the theme stylesheets -->
    <link rel="stylesheet" href="jqwidgets/styles/jqx.base.css" type="text/css" />
<!--    <link rel="stylesheet" href="jqwidgets/styles/jqx.darkblue.css" type="text/css" />-->
    <link rel="stylesheet" href="jqwidgets/styles/jqx.asemon.css" type="text/css" />


    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>
    <script src="js/jsDate.js"></script>
    <script src="js/parsedate.js"> </script>
    <script src="js/calendrier.js"> </script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/md5.min.js"></script>

    <script type="text/javascript">
        var rootDir                                = '<?php echo addslashes($rootDir)       ?>';
        var version_asemon_report                  = '<?php echo $version_asemon_report     ?>';
        var default_archive_server                 = '<?php echo $default_archive_server    ?>';
        var default_archive_user                   = '<?php echo $default_archive_user      ?>';
        var default_archive_password               = '<?php echo $default_archive_password  ?>';
        var archive_password_is_encrypted          = '<?php echo $archive_password_is_encrypted  ?>';
        var default_archive_db                     = '<?php echo $default_archive_db        ?>';
        var default_archive_charset                = '<?php echo $default_archive_charset   ?>';
        var databaselist_filter                    = '<?php echo $databaselist_filter       ?>';
        var allow_change_archive_user              = '<?php echo $allow_change_archive_user ?>';
        var allow_change_archive_user              = '<?php echo $allow_change_archive_user ?>';
        var AR_EditableGrid                        = '<?php echo $editable_grids ?>';
        var AR_refresh_StatServers_delay           = '<?php echo $refresh_StatServers_delay ?>';
    </script>
    <script src="js/asemon_report.js"></script>
    <script src="js/asemon_report_common.js"></script>
    <script type="text/javascript" src="jqwidgets/jqx-all.js"></script>
    <script type="text/javascript" src="jqwidgets/globalization/globalize.js"></script>
    <script type="text/javascript" src="js/highstock.js"></script>



    <script type="text/javascript" src="js/asemon.widgets-min.js"></script>
    <script type="text/javascript" src="js/no-data-to-display.js"></script>


<script language="JavaScript" type="text/javascript" src="js/jsbn.js"></script>
<script language="JavaScript" type="text/javascript" src="js/rsa.js"></script>
<script language="JavaScript" type="text/javascript" src="js/sha1.js"></script>

<script language="JavaScript" type="text/javascript" src="js/columnTooltips.js"></script>

<script language="JavaScript" type="text/javascript" src="js/jsencrypt.min.js"></script>

<!--
<script language="JavaScript" type="text/javascript" src="js/jsencrypt.js"></script>
-->
<body>

<div>


    <div class="banner">
      <div class="logo" > 
        <div class="nav-btn">
          <a id="nav-btn" class="nav-btn" >
            <i class="fa fa-bars fa-lg white"></i> MENU
          </a>
        </div> 
    <div id="divVersion" >Asemon Report <?php echo $version_asemon_report ?></div>
    <div id="copyrighttext"><b>&copy;</b> By : JP Martin - 2004..2026</div>
      </div>
      <div class="rightbanner"> 
        <div class="topinput">
          
          <div class="topinput-row1">
            <div class="form-group form-group-sm" style="margin-bottom: 5px;" title="Choose server type">
                  <label for="selecttype">Type : </label>
                  <select id="selecttype" name="SrvType" class="form-control" ONCHANGE="javascript:changeServerType()">
                    <option>ASE</option>
                    <option>RS</option>
                    <option>IQ</option>
                    <option>RAO</option>
                  </select>
            </div>
            
            <div class="form-group form-group-sm" style="margin-bottom: 5px;" title="Choose monitored server">
                  <label for="selectsrv" >Server : </label>
                  <select id="selectsrv" name="ServerName" class="form-control" style="width: 250px"  ONCHANGE="javascript:changeServer()">
                  </select>
            </div>
            
            <div class="form-group form-group-sm" style="margin-bottom: 5px;" title="Choose start datetime of analyzed interval">
              <label for="StartTimestamp" >StartTime : </label>
              <div class="input-group" style="width: 160px">
                <input id="StartTimestamp" class="form-control" type="text" onchange="javascript:saveinterval_and_setrangeselector()" />
                <span class="input-group-addon"><i class="fa fa-calendar fa-lg white" onclick="dispcalend('StartTimestamp');" ></i></span>
              </div>
            </div>

            <!-- <div id="StartTimestampBTN" class="hide" ></div> -->

            <div class="form-group form-group-sm" style="margin-bottom: 5px;" title="Choose end datetime of analyzed interval">
              <label for="EndTimestamp" >EndTime : </label>
              <div class="input-group" style="width: 160px">
                <input id="EndTimestamp" class="form-control" type="text" onchange="javascript:saveinterval_and_setrangeselector()" />
                <span class="input-group-addon"><i class="fa fa-calendar fa-lg white" onclick="dispcalend('EndTimestamp');" ></i></span> 
              </div>
            </div>
            <!-- <div id="EndTimestampBTN" class="hide" ></div> -->

            <div class="form-group form-group-sm" style="margin-bottom: 5px;">
              <label for="RefreshBtn" >&nbsp;</label>
              <button type="button" id="RefreshBtn" class="form-control btn btn-primary"  onclick="mainRefresh()"><i class="fa fa-refresh fa-fw white"></i> REFRESH </button>
            </div>
          </div>


          <div class="topinput-row2">

            <div style="width: 342px; height: 30px; display: flex;  flex-direction: row;   justify-content: left;align-items: center;padding-left: 20px">
               <div class="checkbox">
                 <label>
                   <input id="DispRangeSel" type="checkbox" value="DispRangeSel" checked="checked" onchange="javascript:changeDispRangeSel();"/> Display Range Selector
                 </label>
               </div>
            </div>
            <div class="topinput-row2-datemenu">




                  <div>
                    <select ID="DFormat" name="DFormat" class="form-control" style="height: 30px" title="Choose dateformat : mdy='Month Day Year', dmy='Day Month Year'" onchange="javascript:changeDFormat();">
                      <option <?php if (strtolower ($default_date_order) == "mdy") echo " SELECTED";  ?> >mdy</option>
                      <option <?php if (strtolower ($default_date_order) == "dmy") echo " SELECTED";  ?> >dmy</option>
                    </select>
                  </div>


                  <div class="IncDateInBanner">
                    <div ID="datemenu">
                      <ul>
                        <li style="width:54px" ><a ONCLICK="javascript:setminusoneday()">-1D</a>
                          <ul>
                            <li style="width:54px" ><a ONCLICK="javascript:addXhours(-1)">-1h</a> </li>
                            <li style="width:54px" ><a ONCLICK="javascript:addXhours(-2)">-2h</a> </li>
                          </ul>
                        </li>
                      </ul>
                      </div>
                  </div>


                  <div class="SelectDateInBanner">
                    <div ID="datemenu">
                      <ul>
                        <li style="width:106px" ><a ONCLICK="javascript:settoday()">Today</a>
                          <ul>
                            <li style="width:106px" ><a ONCLICK="javascript:setlasthour()">LastHour</a> </li>
                            <li style="width:106px" ><a ONCLICK="javascript:setyesterday()">Yesterday</a> </li>
                            <li style="width:106px" ><a ONCLICK="javascript:setlastweek()">LastWeek</a> </li>
                            <li style="width:106px" ><a ONCLICK="javascript:setlastweekworkdays()">LastWeekWorkD</a> </li>
                            <li style="width:106px" ><a ONCLICK="javascript:setlastmonth()">LastMonth</a> </li>
                          </ul>
                        </li>
                      </ul>
                    </div>
                  </div>


                  <div class="IncDateInBanner">
                    <div ID="datemenu">
                      <ul>
                        <li style="width:54px" ><a ONCLICK="javascript:setplusoneday()">+1D</a>
                          <ul>
                            <li style="width:54px" ><a ONCLICK="javascript:addXhours(1)">+1h</a> </li>
                            <li style="width:54px" ><a ONCLICK="javascript:addXhours(2)">+2h</a> </li>
                          </ul>
                        </li>
                      </ul>
                    </div>
                  </div>    






            </div>
          </div>

        </div>
      </div>
    </div>


    <div id="rangeselectorpanel" class="nav-expanded nondisplay" > 
      <div style="display: flex;  flex-direction: row;   justify-content: center;align-items: center;height:30px" >
        <div style="margin-left: 20px; margin-right: 50px"> Range Selector </div>
        <div style="margin-right: 15px">
          <button type="button" id="zoomin" class="btn btn-primary btn-xs"  onclick="zoomin()" title="Zoom on selected range"> Zoom <i class="fa fa-plus-circle white"></i></button>
        </div>
        <div style="margin-right: 15px">
          <button type="button" id="zoomout" class="btn btn-primary btn-xs"  onclick="zoomout()" title="Zoom out" disabled> Zoom <i class="fa fa-minus-circle white"></i></button>
        </div>
      </div>
      <div id="rangeselector" ></div>
      <div id="rangeselector_loading" class="nondisplay" >Loading...</div>

    </div>



    <div id="page-content" class="nav-expanded" >



      <nav>
<!--        <ul class="list-unstyled main-menu">-->
        <ul class="left-menu-archbox">
       
          <!--Include your navigation here-->
          <li class="text-right"><a href="#" id="nav-close"  title="Hide menu"><i class="fa fa-angle-double-left fa-2x"></i></a></li>
          <li class="loginarchive"> 
          <div class="archboxtitle">Archive server :</div>
          <div class="archboxpanel">
      
            <div class="">
              <label for="ArchiveServer" class="">Server : </label>
              <?php
              if ( (isset($default_archive_server_list)) && (count($default_archive_server_list) > 0) ) {
              ?>
                <select id="ArchiveServer" onchange="javascript:changeArchiveServer()" title="Select servername containing archive database or use a DSN name if ODBC is used to access to the database" <?php if (count($default_archive_server_list) == 1) { echo "DISABLED"; } ?> >                
                  <?php 
                    for ($i=0; $i<count($default_archive_server_list); $i++) {
                      echo "<option ";
                      if ($default_archive_server_list[$i] == $default_archive_server) {echo "SELECTED";  }
                      echo ">$default_archive_server_list[$i]</option>";
                    }
                  ?>
                </select>
              <?php 
              }     
              else {
              ?>    
                  <input type="text" id="ArchiveServer" value="<?php if ( isset($default_archive_server) ){ echo $default_archive_server ; } ?>" onchange="javascript:changeArchiveServer()" title="Select servername containing archive database" >
              <?php
              } 
              ?>
            </div>
      
      
            <div>
             <label for="ArchiveUser" class="">User : </label>
              <input type="text" id="ArchiveUser" value="<?php if ( isset($default_archive_user) ){ echo $default_archive_user ; } ?>" title="Input username to connect to the archive database" <?php if (!$allow_change_archive_user) { echo " disabled "; }  ?> >
            </div>
      
            <div>
             <label for="ArchivePassword" class="">Pwd : </label>
              <input type="password" id="ArchivePassword" onChange="javascript:changePassword();" title="Input password to connect to the archive database" <?php if (!$allow_change_archive_user) { echo " disabled "; }  ?> >
            </div>
      
      
            <div>
             <label for="ArchiveCharset" class="">Char : </label>
              <input type="text" id="ArchiveCharset" value="<?php if ( isset($default_archive_charset) ){ echo $default_archive_charset ; } else echo ""; ?>" title="(Optional) Input charset of the archive server" <?php if (isset($ArchiveCharset) && (isset($default_archive_server_list)) && (count($default_archive_server_list) == 1) ) echo " disabled "; ?> />
            </div>
      
            <div>
                <button type="button" id="loginBtn" class="btn btn-primary btn-xs" style="margin-top:3px; margin-bottom:6px" onClick="javascript:connectServer();" title="Connect to the archive server"><i class="fa fa-sign-in fa-fw white"></i> CONNECT </button>
            </div>
      
      
            <div>
             <label for="ArchiveDatabase" class="">Db : </label>
              <select id="ArchiveDatabase" onchange=javascript:changeArchiveDB(); title="select database containing archive tables">
              </select>
            </div>
      
      
            <!-- Display the gauge -->
            <div id="gaugediv" style="margin-top:8px;width: 150px;height:40px">
                        Data space used (<span id="spaceusedFld"></span> %)&nbsp;:
                <div class="progress">
                  <div class="progress-bar progress-bar-info""></div>
                </div>
            <!--<span style="float:left">0</span> <span style="float:right">100</span>-->
            </div>
      
          </div> <!-- End archboxpanel -->
          </li>
        </ul>


        <div class="left-menu-checkbox menu-chkbox nondisplay" title="When checked, open following items in a new window or tab">
            <label style="padding: 0px;">Open in new window : 
              <input id="OpenInNewWindow" type="checkbox"  value="OpenInNewWindow" />
            </label>
        </div>

        <div class="left-menu-items">
          <ul class="left-menu menu-ASE nondisplay">
            <li title="Display summary statistics and CPU, I/O, proc cache usage... graphs"             ID="ASE-Summary"           > <a href="#" > Summary                   </a></li>
            <li title="Display statistics per objects (tables and indexes)"                             ID="ASE-Objects_Stats"     > <a href="#" > Objects Stats             </a></li>
            <li title="Display size of cached objects"                                                  ID="ASE-Objects_Cached"    > <a href="#" > Objects Cached            </a></li>
            <li title="Display statistics on ASE connections"                                           ID="ASE-Process"           > <a href="#" > Process                   </a></li>
            <li title="Display blocking locks"                                                          ID="ASE-Locks"             > <a href="#" > Locks                     </a></li>
            <li title="Display deadlocks"                                                               ID="ASE-Deadlocks"         > <a href="#" > Deadlocks                 </a></li>
            <li title="Display blocking time per object (works with ASE 12.5 or 15.0.3 ESD#4 and upper" ID="ASE-LockWaits"         > <a href="#" > LockWaits                 </a></li>
            <li title="Display procedure's statistics derived from captured statements"                 ID="ASE-Procs"             > <a href="#" > Procs from statements     </a></li>
            <li title="Display object's statistics in procedure cache"                                  ID="ASE-ProcCache"         > <a href="#" > ProcCache                 </a></li>
            <li title="Display statistics about objects (table and index) fragmentation"                ID="ASE-Fragmentation"     > <a href="#" > Fragmentation             </a></li>
            <li title="(near)Equivalent of sp_sysmon"                                                   ID="ASE-Sysmon"            > <a href="#" > Sysmon                    </a></li>
            <li title="Display spinlocks usage"                                                         ID="ASE-Spinlocks"         > <a href="#" > Spinlocks                 </a></li>
            <li title="Display ASE KPI's trends"                                                        ID="ASE-Trends"            > <a href="#" > Trends                    </a></li>
            <li title="Display Syslogshold captured data"                                               ID="ASE-LogsHold"          > <a href="#" > LogsHold                  </a></li>
            <li title="Display captured statements"                                                     ID="ASE-Statements"        > <a href="#" > Statements                </a></li>
            <li title="Display captured statements in statement cache"                                  ID="ASE-StmtCache"         > <a href="#" > StmtCache (V15)           </a></li>
            <li title="Display captured data from QP Metrics"                                           ID="ASE-QPMetrics"         > <a href="#" > QPMetrics (V15)           </a></li>
            <li title="Display missing statistics"                                                      ID="ASE-MissStats"         > <a href="#" > MissStats (V15)           </a></li>
            <li title="Display devices statistics"                                                      ID="ASE-Devices"           > <a href="#" > Devices                   </a></li>
            <li title="Display system waits"                                                            ID="ASE-SysWaits"          > <a href="#" > SysWaits                  </a></li>
            <li title="Display databases space usage"                                                   ID="ASE-SpaceUsed"         > <a href="#" > SpaceUsed                 </a></li>
            <li title="Display asemon_logger's statistics"                                              ID="AmStats"               > <a href="#" > AmStats                   </a></li>
            <li title="Display table compression statistics (V15.7)"                                    ID="ASE-Compression"       > <a href="#" > Compression (V15.7)       </a></li>
            <li title="Display memory usage (V15.7)"                                                    ID="ASE-MemUsage"          > <a href="#" > MemUsage (V15.7)          </a></li>
            <li title="Display sysExecutiontime statistics (V15.7SP100)"                                ID="ASE-SysExec"           > <a href="#" > SysExec (V15.7SP100)      </a></li>
            <li title="Display configuration changes (V16)"                                             ID="ASE-ChEvents"          > <a href="#" > Config changes(V16)       </a></li>
            <li title="Graph all log's contention"                                                      ID="ASE-LogsCont"          > <a href="#" > Logs Contention           </a></li>
            <li title="Display cursor's locks"                                                          ID="ASE-CursLocks"         > <a href="#" > Open cursor's locks       </a></li>
          </ul>
          
          <ul class="left-menu menu-RS nondisplay">
            <li title="Display RS summary statistics"                                                   ID="RS-Summary"            > <a href="#" > Summary                   </a></li>
            <li title="Display stable devices usage"                                                    ID="RS-Devices"            > <a href="#" > Devices                   </a></li>
            <li title="Display stable queues statistics"                                                ID="RS-Queues"             > <a href="#" > Queues                    </a></li>
            <li title="Display replication of objects statistics"                                       ID="RS-objects"            > <a href="#" > objects                   </a></li>
            <li title="Display all RS counters"                                                         ID="RS-AllCounters"        > <a href="#" > Counters                  </a></li>
            <li title="Display RepAgent's statistics"                                                   ID="RS-RepAgents"          > <a href="#" > RepAgents                 </a></li>
            <li title="Display Distributor's statistics"                                                ID="RS-DIST"               > <a href="#" > DIST                      </a></li>
            <li title="Display SQT's statistics"                                                        ID="RS-SQT"                > <a href="#" > SQT                       </a></li>
            <li title="Display SQM's statistics"                                                        ID="RS-SQM"                > <a href="#" > SQM                       </a></li>
            <li title="Display SQMR's statistics"                                                       ID="RS-SQMR"               > <a href="#" > SQMR                      </a></li>
            <li title="Display DSI's statistics"                                                        ID="RS-DSI"                > <a href="#" > DSI                       </a></li>
            <li title="Display STS's statistics"                                                        ID="RS-STS"                > <a href="#" > STS                       </a></li>
            <li title="Display RSI's statistics (output to another RS)"                                 ID="RS-RSI"                > <a href="#" > RSI                       </a></li>
            <li title="Display RSIUSER's statistics (input from another RS)"                            ID="RS-RSIUSER"            > <a href="#" > RSIUSER                   </a></li>
            <li title="Display RS KPIS's trends"                                                        ID="RS-Trends"             > <a href="#" > Trends                    </a></li>
            <li title="Display asemon_logger's statistics"                                              ID="AmStats"               > <a href="#" > AmStats                   </a></li>
          </ul>                                                                                                      
                                                                                                                     
          <ul class="left-menu menu-IQ nondisplay">                                                                             
            <li title="Display IQ summary statistics"                                                   ID="IQ-Summary"            > <a href="#" > Summary                   </a></li>
            <li title="Display Multiplex statistics"                                                    ID="IQ-Multiplex"          > <a href="#" > Multiplex                 </a></li>
            <li title="Display IQ connections statistics"                                               ID="IQ-Connections"        > <a href="#" > Connections               </a></li>
            <li title="Display IQ statements"                                                           ID="IQ-Statements"         > <a href="#" > Statements                </a></li>
            <li title="Display IQ transactions statistics"                                              ID="IQ-Transactions"       > <a href="#" > Transactions              </a></li>
            <li title="Display IQ versionning statistics"                                               ID="IQ-Versioning"         > <a href="#" > Versioning                </a></li>
            <li title="Equivalent of sp_iqsysmon"                                                       ID="IQ-IQSysmon"           > <a href="#" > IQSysmon                  </a></li>
            <li title="Display object's size"                                                           ID="IQ-IQTblSize"          > <a href="#" > IQTblSize                 </a></li>
            <li title="Display table usage statistics"                                                  ID="IQ-IQTableUse"         > <a href="#" > IQTableUse                </a></li>
            <li title="Display index usage statistics"                                                  ID="IQ-IQIndexUse"         > <a href="#" > IQIndexUse                </a></li>
            <li title="Display asemon_logger's statistics"                                              ID="AmStats"               > <a href="#" > AmStats                   </a></li>
          </ul>                                                                                                      
                                                                                                                     
          <ul class="left-menu menu-RAO nondisplay">                                                                            
            <li title="Display RAO Statistics"                                                          ID="RAO-Summary"           > <a href="#" > Summary                   </a></li>
          </ul>

          <ul class="left-menu menu-COMMON nondisplay">                                                                            
            <li title="Display server's status"                                                         ID="COMMON-StatServers"           > <a href="#" > StatServers        </a></li>
            <li title="Display all databases info"                                                      ID="COMMON-AllDBs"                > <a href="#" > AllDBs             </a></li>
            <li title="Display all ASE Parameters"                                                      ID="COMMON-AllAseParams"          > <a href="#" > AllAseParams       </a></li>
          </ul>
        </div>
      </nav>

      <?php require_once ("ASE/Summary.php"); ?>
      <?php require_once ("ASE/Object_statistics.php"); ?>
      <?php require_once ("ASE/CachedObj_statistics.php"); ?>
      <?php require_once ("ASE/Process_statistics.php"); ?>
      <?php require_once ("ASE/Device_statistics.php"); ?>
      <?php require_once ("ASE/Locks_list.php"); ?>
      <?php require_once ("ASE/Deadlocks_list.php"); ?>
      <?php require_once ("ASE/LockWaits_list.php"); ?>
      <?php require_once ("ASE/ProcMDA_statistics.php"); ?>
      <?php require_once ("ASE/ProcCache_statistics.php"); ?>
      <?php require_once ("ASE/Fragmentation_statistics.php"); ?>
      <?php require_once ("ASE/Sysmon.php"); ?>
      <?php require_once ("ASE/Spinlocks_statistics.php"); ?>
      <?php require_once ("ASE/Syslogshold_statistics.php"); ?>
      <?php require_once ("ASE/Statements_statistics.php"); ?>
      <?php require_once ("ASE/CachedStatements_statistics.php"); ?>
      <?php require_once ("ASE/QPMetrics_statistics.php"); ?>
      <?php require_once ("ASE/Missing_statistics.php"); ?>
      <?php require_once ("ASE/SysWaits_statistics.php"); ?>
      <?php require_once ("ASE/AseDbSpce.php"); ?>
      <?php require_once ("ASE/Compress_statistics.php"); ?>
      <?php require_once ("ASE/MemUsage_statistics.php"); ?>
      <?php require_once ("ASE/Sysexec.php"); ?>
      <?php require_once ("ASE/ChEvents_statistics.php"); ?>
      <?php require_once ("ASE/LogsContention.php"); ?>
      <?php require_once ("ASE/CursLocks_statistics.php"); ?>
      <?php require_once ("IQ/Summary.php"); ?>
      <?php require_once ("IQ/Multiplex.php"); ?>
      <?php require_once ("IQ/IQCnx_statistics.php"); ?>
      <?php require_once ("IQ/IQStatements.php"); ?>
      <?php require_once ("IQ/IQTrans_statistics.php"); ?>
      <?php require_once ("IQ/IQVersions_statistics.php"); ?>
      <?php require_once ("IQ/IQSysmon.php"); ?>
      <?php require_once ("IQ/IQTblSize.php"); ?>
      <?php require_once ("IQ/IQTableUse.php"); ?>
      <?php require_once ("IQ/IQIndexUse.php"); ?>
      <?php require_once ("RS/Summary.php"); ?>
      <?php require_once ("RS/devices_statistics.php"); ?>
      <?php require_once ("RS/queues_statistics.php"); ?>
      <?php require_once ("RS/objects_statistics.php"); ?>
      <?php require_once ("RS/RA_statistics.php"); ?>
      <?php require_once ("RS/DIST_statistics.php"); ?>
      <?php require_once ("RS/SQT_statistics.php"); ?>
      <?php require_once ("RS/SQM_statistics.php"); ?>
      <?php require_once ("RS/SQMR_statistics.php"); ?>
      <?php require_once ("RS/DSI_statistics.php"); ?>
      <?php require_once ("RS/RSI_statistics.php"); ?>
      <?php require_once ("RS/RSIUSER_statistics.php"); ?>
      <?php require_once ("RAO/RAOStats.php"); ?>

      <?php require_once ("COMMON/StatServers.php"); ?>
      <?php require_once ("COMMON/AmStats.php"); ?>
      <?php require_once ("ASE/AllDatabases_list.php"); ?>
      <?php require_once ("ASE/AllAseParams_list.php"); ?>

      <div ID="mainmessageDIV">
      <?php
        //echo "rootDir=".$rootDir."<br />\n";
        echo $genkeysOutputmess;
      ?>
      </div>

    </div>


</div>

<script type="text/javascript">
    var pubKey                         = '<?php echo $publickey    ?>';
    ARContext.password_encryption_type = '<?php echo $password_encryption_type ?>';
    ARContext.ArchivePassword = default_archive_password;
    $('#ArchivePassword').val('xxxxxxxx');


  // Execute login in case user hit RETURN when placed in ArchiveUser field
  $('#ArchiveUser, #ArchivePassword').keyup( function(event) {
    // Cancel the default action, if needed
    event.preventDefault();
    // Number 13 is the "Enter" key on the keyboard
    if (event.keyCode === 13) {
      // Trigger the button element with a click
      $('#loginBtn').click();
    }
  });


  function refresh_screen() {
    if (current_selector == 'StatServers') {
      mainRefresh();
    }
  }
  
  if (AR_refresh_StatServers_delay > 0) {
    // Refresh every x ms
    jQuery(document).ready(function(){
       setInterval(refresh_screen, AR_refresh_StatServers_delay);
    });
  }
</script>


</body>

</html>

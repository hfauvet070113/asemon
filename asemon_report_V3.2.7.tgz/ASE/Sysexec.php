<div class="ASE-SysExec nondisplay">
  <center>
  <div class="maingrid">
    <div id="sysexec_Execution" class="ASE-SysExec mainchart" > </div>
    <div id="sysexec_Compilation" class="ASE-SysExec mainchart" > </div>
    <div id="sysexec_Sorting" class="ASE-SysExec mainchart" > </div>
    <div id="sysexec_Unknown" class="ASE-SysExec mainchart" > </div>
    <div ID="sysexec_mess" class="nodisplay" >  </div>
  </div>
  </center>
</div>

<script type="text/javascript">

  function refresh_sysexec () {
    var SysExecExists = 0;
    var graph;


    if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_SysExec') )  )
      SysExecExists = 1;
    
    if ( SysExecExists == 0) {
      $('#sysexec_Execution').hide();
      $('#sysexec_Compilation').hide();
      $('#sysexec_Sorting').hide();
      $('#sysexec_Unknown').hide();
      $('#sysexec_mess').show();
      $('#sysexec_mess').html('<p>SysExec info is not available. The SysExec collector (for ASE V15.7 SP100 or higher) has not been activated for server '+ARContext.ServerName+'.</P><P> (Add SysExec.xml in the asemon_logger config file)</p>');
      return;
    }
    else {
      $('#sysexec_Execution').show();
      $('#sysexec_Compilation').show();
      $('#sysexec_Sorting').show();
      $('#sysexec_Unknown').show();
      $('#sysexec_mess').hide();
    }
    
    graph = $('#sysexec_Execution').highcharts();
    if (typeof graph == 'undefined')
      $('#sysexec_Execution').asemonChart({
      title: {
        text: 'SysExecutionTime for : "Execution"'
      },
      queryFile : '../ASE/sql/graphSysexec.php',
      tableName : 'SysExec',
      chart: {
          type: 'line'
      },
      yAxis: [{
        max: 100
      }] ,
      series: [
        {
          name: 'ExecutionTime (pct of 1 core)',
          color: 'blue'
        },
        {
          name: 'ExecutionCnt/s',
          color: 'green',
          yAxis: 1
        }
      ],
      data: {
        name: 'Execution'
      }
      
      });
    $('#sysexec_Execution').asemonChart('refresh',threadDelays);
   
    graph = $('#sysexec_Compilation').highcharts();
    if (typeof graph == 'undefined')
      $('#sysexec_Compilation').asemonChart({
      title: {
        text: 'SysExecutionTime for : "Compilation"'
      },
      queryFile : '../ASE/sql/graphSysexec.php',
      tableName : 'SysExec',
      chart: {
          type: 'line'
      },
      yAxis: [{
        max: 100
      }] ,
      series: [
        {
          name: 'ExecutionTime (pct of 1 core)',
          color: 'blue'
        },
        {
          name: 'ExecutionCnt/s',
          color: 'green',
          yAxis: 1
        }
      ],
      data: {
        name: 'Compilation'
      }
      
      });
    $('#sysexec_Compilation').asemonChart('refresh',threadDelays);
   
    graph = $('#sysexec_Sorting').highcharts();
    if (typeof graph == 'undefined')
      $('#sysexec_Sorting').asemonChart({
      title: {
        text: 'SysExecutionTime for : "Sorting"'
      },
      queryFile : '../ASE/sql/graphSysexec.php',
      tableName : 'SysExec',
      chart: {
          type: 'line'
      },
      yAxis: [{
        max: 100
      }] ,
      series: [
        {
          name: 'ExecutionTime (pct of 1 core)',
          color: 'blue'
        },
        {
          name: 'ExecutionCnt/s',
          color: 'green',
          yAxis: 1
        }
      ],
      data: {
        name: 'Sorting'
      }
      
      });
    $('#sysexec_Sorting').asemonChart('refresh',threadDelays);
   
    graph = $('#sysexec_Unknown').highcharts();
    if (typeof graph == 'undefined')
      $('#sysexec_Unknown').asemonChart({
      title: {
        text: 'SysExecutionTime for : "Unknown"'
      },
      queryFile : '../ASE/sql/graphSysexec.php',
      tableName : 'SysExec',
      chart: {
          type: 'line'
      },
      yAxis: [{
        max: 100
      }] ,
      series: [
        {
          name: 'ExecutionTime (pct of 1 core)',
          color: 'blue'
        },
        {
          name: 'ExecutionCnt/s',
          color: 'green',
          yAxis: 1
        }
      ],
      data: {
        name: 'Unknown'
      }
      
      });
    $('#sysexec_Unknown').asemonChart('refresh',threadDelays);
   
  }

  onArchCnxOpened = function(){
    $('.ASE-SysExec').removeClass('nondisplay');
    refresh_sysexec();
  }

</script>
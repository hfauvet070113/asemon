<center>
<div class="">
<!--  <h1 id="headertitle"> Same statements (with SQLHashKey = <?php echo $SQLHashKey ?> )</h1> -->

  <div class="maingrid">
    <div id="Statements_hashkey_statistics" class="singlegrid" > </div>
  </div>

</div>
</center>

<script type="text/javascript">

var SQLHashKey = "<?php echo $SQLHashKey ?>"; 


onArchCnxOpened = function(){
  var height =    $('#page-content').innerHeight() - $('#headertitle').height() - 65;
  var support157 = 0;
  var StmtSQLHKExists = 0;
  var StmtPlnHKExists = 0;
  var colV16SP03Exists = 0;
  var V16SP03optfields  = [];
  var V16SP03optcols    = [];
  var V16SP03snapfields = [];
  var V16SP03snapcols   = [];
  var supportFieldsAnja = 0;
  var fieldsAnja = [];
  var colsAnja = [];

  if ( existColumn(ARContext.ServerName+'_StmtStat', 'ClientName') ) {
    support157 = 1;
  }
  if ( (ARContext.ServerName!="") && ( existColumn(ARContext.ServerName+'_StmtStat', 'StatementNumber') ) && ( existColumn(ARContext.ServerName+'_StmtStat', 'ProcNestLevel') ) ) {
    supportFieldsAnja = 1;
  }

  fieldsAnja = [ 
         { name: 'StatementNumber', type: 'number'},
         { name: 'ProcNestLevel', type: 'number'}
  ];
  colsAnja= [
         { text: 'StatementNumber', datafield: 'StatementNumber', width: 90, filterable: true, cellsalign: 'right'},
         { text: 'ProcNestLevel', datafield: 'ProcNestLevel', width: 90, filterable: true, cellsalign: 'right'}
  ];



  if ( (ARContext.ServerName!="") &&( existColumn(ARContext.ServerName+'_StmtStat', 'QueryOptimizationTime') )  ){
    colV16SP03Exists = 1;
    V16SP03optfields = [
    { name: 'QueryOptimizationTime', type: 'number' }
    ];
    V16SP03optcols   = [
    { text: 'QueryOptimizationTime', datafield: 'QueryOptimizationTime', width: 100, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']}
    ];
    V16SP03snapfields = [
    { name: 'SnapCodegenTime',       type: 'number' },
    { name: 'SnapJITTime',           type: 'number' },
    { name: 'SnapExecutionTime',     type: 'number' },
    { name: 'SnapExecutionCount',    type: 'number' }
    ];
    V16SP03snapcols   = [
    { text: 'SnapCodegenTime',       datafield: 'SnapCodegenTime',       width: 100, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']},
    { text: 'SnapJITTime',           datafield: 'SnapJITTime',           width: 100, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']},
    { text: 'SnapExecutionTime',     datafield: 'SnapExecutionTime',     width: 100, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']},
    { text: 'SnapExecutionCount',    datafield: 'SnapExecutionCount',    width: 100, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']}
    ];
  }

  fields = [
         { name: 'stat_StmtID',   type: 'number'},
         { name: 'Debut',         type: 'string'},
         { name: 'Elapsed_s',     type: 'number'},
         { name: 'SPID',          type: 'number'},
         { name: 'DBID',          type: 'number'},
         { name: 'Application',   type: 'string'},
         { name: 'ClientHost',    type: 'string'},
         { name: 'ProcName',      type: 'string'},
         { name: 'LineNumber',    type: 'number'},
         { name: 'CpuTime',       type: 'number'}]
         .concat(V16SP03optfields)
         .concat([
         { name: 'WaitTime',      type: 'number'},
         { name: 'MemUsageKB',    type: 'number'},
         { name: 'PhysicalReads', type: 'number'},
         { name: 'LogicalReads',  type: 'number'},
         { name: 'PagesModified', type: 'number'},
         { name: 'PacketsSent',   type: 'number'},
         { name: 'planOK',        type: 'string'},
         { name: 'PlanID',        type: 'number'},
         { name: 'BatchID',       type: 'number'},
         { name: 'ContextID',     type: 'number'}])
         .concat(V16SP03snapfields);
  cols = [
         { text: 'StmtID',      datafield: 'stat_StmtID',   width: 70,  filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number'},
         { text: 'StartTime',   datafield: 'Debut',         width: 170, filterable: false},
         { text: 'Elapsed_s',   datafield: 'Elapsed_s',     width: 70, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number'},
         { text: 'SPID',        datafield: 'SPID',          width: 50, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number'},
         { text: 'DBID',        datafield: 'DBID',          width: 50, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number'},
         { text: 'Application', datafield: 'Application',   width: 90, filterable: true},
         { text: 'ClientHost',  datafield: 'ClientHost',    width: 150, filterable: true},
         { text: 'Proc',        datafield: 'ProcName',      width: 150, filterable: true},
         { text: 'Line',        datafield: 'LineNumber',    width: 70, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number'},
         { text: 'CpuTime_ms',  datafield: 'CpuTime',       width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']}]
         .concat(V16SP03optcols)
         .concat([
         { text: 'WaitTime_ms', datafield: 'WaitTime',      width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']},
         { text: 'MemUsageKB',  datafield: 'MemUsageKB',    width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['max']},
         { text: 'PReads',      datafield: 'PhysicalReads', width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']},
         { text: 'LReads',      datafield: 'LogicalReads',  width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']},
         { text: 'PgsModified', datafield: 'PagesModified', width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']},
         { text: 'PktsSent',    datafield: 'PacketsSent',   width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']},
         { text: 'Plan',        datafield: 'planOK',        width: 50, filterable: false},
         { text: 'PlanID',      datafield: 'PlanID',        width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number'},
         { text: 'BatchID',     datafield: 'BatchID',       width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number'},
         { text: 'ContextID',   datafield: 'ContextID',     width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number'}])
         .concat(V16SP03snapcols);
  fields157 = [
         { name: 'ClientName',     type: 'string'},
         { name: 'ClientHostName', type: 'string'},
         { name: 'ClientApplName', type: 'string'}
  ];
  cols157= [
         { text: 'ClientName',     datafield: 'ClientName',     width: 90, filterable: true},
         { text: 'ClientHostName', datafield: 'ClientHostName', width: 90, filterable: true},
         { text: 'ClientApplName', datafield: 'ClientApplName', width: 90, filterable: true}
  ];
  
  
  if (support157 == 1) {
    fields = fields.concat(fields157);
    cols = cols.concat(cols157);
  }

  if (supportFieldsAnja == 1) {
    fields = fields.concat(fieldsAnja);
    cols = cols.concat(colsAnja);
  }

  if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_StmtSQLHK') )  ) {
    StmtSQLHKExists = 1;
  }

  if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_StmtPlnHK') )  ) {
    StmtPlnHKExists = 1;
  }


  var grid = $('#Statements_hashkey_statistics').data('jqxWidget');
  if (typeof grid != 'undefined') {
    $("#Statements_hashkey_statistics").asemonGrid('refresh');
  }
  else {

    $("#Statements_hashkey_statistics").asemonGrid({
    'title' : 'Statements statistics with SQLHashKey = '+SQLHashKey,
    'columnTooltipsKey' : 'Statements_statistics',
    'width' : '100%',
    'height' : height,
    'rowcount': 200,
    'editable': false,
    'filterable': true,
    'cursor' : 'pointer',
    'querydata': {'queryfile' : '../ASE/sql/sql_stmt_statistics.php',
                  'default_order_by' : 'stat_StmtID',
                  'support157': support157,
                  'StmtSQLHKExists' : StmtSQLHKExists,
                  'StmtPlnHKExists' : StmtPlnHKExists,
                  'colV16SP03Exists' : colV16SP03Exists,
                  'SQLHashKey': SQLHashKey,
                  'supportFieldsAnja': supportFieldsAnja},
    'datafieldsMapping': {'Debut': 'StartTime', 'stat_StmtID': 'stat.StmtID'},
    'datafields': fields,
    'columns': cols 
    });
    
    $("#Statements_hashkey_statistics").on('rowselect', function (event) {
      var rowindex = event.args.rowindex;
      //alert ("row "+rowindex+" selected");
      
      rowdata = $('#Statements_hashkey_statistics').jqxGrid('getrowdatabyid', rowindex);
      if (typeof rowdata == 'undefined') return 0;
      var StmtID = rowdata.stat_StmtID;
    
      openWindowFromGrid ("#Statements_hashkey_statistics", "detail_page.php", {ARContextJSON: ARContext, 'displaylevel' : 2, 'detail_type': 'STMT', 'StmtID': StmtID});
    });
  }

};

  
</script>


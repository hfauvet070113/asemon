
<center>
<div id="allinfo">
  <h1> Active connections Graphs </h1>
  <div style="display: flex;flex-direction: row;justify-content: space-around;flex-wrap: wrap;align-items: center;">
    <div id="graphActiv-UserName"      class="mainchart" style="min-width:700px;width:1200px" > </div>
    <div id="graphActiv-program_name"  class="mainchart" style="min-width:700px;width:1200px" > </div>
    <div id="graphActiv-hostname"      class="mainchart" style="min-width:700px;width:1200px" > </div>
  </div>
</div>
</center>


<script type="text/javascript">

var filter_clause = "<?php echo $filter_clause; ?>";


onArchCnxOpened = function(){
  var graph;
  var metric_minimum = 5;
  var metric_name = 'UserName';

  graph = $('#graphActiv-UserName').highcharts();
  if (typeof graph == 'undefined')
    //graph.destroy();
    $('#graphActiv-UserName').asemonChart({
    title: {
      text: "Active Connections by "+metric_name
    },
    querytype : 'TSKEYVALUE',
    queryFile : '../ASE/sql/graphActiveCnx_TOP.php',
    tableName : 'CnxActiv',
    data: {
      metric_name: metric_name,
      metric_minimum: metric_minimum,
      filter_clause: filter_clause
    },
    chart: {
              type: 'column'
    },
    plotOptions: {
      series: {stacking: 'normal'}
    },
    series: [
      { name: '0'      },
      { name: '1'      },
      { name: '2'      },
      { name: '3'      },
      { name: '4'      },
      { name: '5'      },
      { name: '6'      },
      { name: '7'      },
      { name: '8'      },
      { name: '9'      }
    ],
    legend: {
       enabled: true
    },
    yAxis: {
      minRange: 0.5,
      min : 0  ,
      reversedStacks: false,
      title: {text: 'Nb. CnxActives'}
      }

    });
  $('#graphActiv-UserName').asemonChart('refresh',threadDelays);

  metric_name = 'program_name';

  graph = $('#graphActiv-program_name').highcharts();
  if (typeof graph == 'undefined')
    //graph.destroy();
    $('#graphActiv-program_name').asemonChart({
    title: {
      text: "Active Connections by "+metric_name
    },
    querytype : 'TSKEYVALUE',
    queryFile : '../ASE/sql/graphActiveCnx_TOP.php',
    tableName : 'CnxActiv',
    data: {
      metric_name: metric_name,
      metric_minimum: metric_minimum,
      filter_clause: filter_clause
    },
    chart: {
              type: 'column'
    },
    plotOptions: {
      series: {stacking: 'normal'}
    },
    series: [
      { name: '0'      },
      { name: '1'      },
      { name: '2'      },
      { name: '3'      },
      { name: '4'      },
      { name: '5'      },
      { name: '6'      },
      { name: '7'      },
      { name: '8'      },
      { name: '9'      }
    ],
    legend: {
       enabled: true
    },
    yAxis: {
      minRange: 0.5,
      min : 0  ,
      reversedStacks: false,
      title: {text: 'Nb. CnxActives'}
      }

    });
  $('#graphActiv-program_name').asemonChart('refresh',threadDelays);




  metric_name = 'hostname';

  graph = $('#graphActiv-hostname').highcharts();
  if (typeof graph == 'undefined')
    //graph.destroy();
    $('#graphActiv-hostname').asemonChart({
    title: {
      text: "Active Connections by "+metric_name
    },
    querytype : 'TSKEYVALUE',
    queryFile : '../ASE/sql/graphActiveCnx_TOP.php',
    tableName : 'CnxActiv',
    data: {
      metric_name: metric_name,
      metric_minimum: metric_minimum,
      filter_clause: filter_clause
    },
    chart: {
              type: 'column'
    },
    plotOptions: {
      series: {stacking: 'normal'}
    },
    series: [
      { name: '0'      },
      { name: '1'      },
      { name: '2'      },
      { name: '3'      },
      { name: '4'      },
      { name: '5'      },
      { name: '6'      },
      { name: '7'      },
      { name: '8'      },
      { name: '9'      }
    ],
    legend: {
       enabled: true
    },
    yAxis: {
      minRange: 0.5,
      min : 0  ,
      reversedStacks: false,
      title: {text: 'Nb. CnxActives'}
      }

    });
  $('#graphActiv-hostname').asemonChart('refresh',threadDelays);


}
</script>


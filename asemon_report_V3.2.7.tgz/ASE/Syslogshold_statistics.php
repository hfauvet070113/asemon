<div class="ASE-LogsHold nondisplay">
  <center>
  <div class="maingrid">
    <div ID="LogsHold" class="asemongrid singlegrid" ></div>
    <div ID="LogsHold_mess" class="nodisplay" >  </div>
  </div>
  </center>
</div>

<script type="text/javascript">
  var height =    $('#page-content').innerHeight() - 55;

  if (typeof detail_type != 'undefined')
    $('.ASE-LogsHold').removeClass('nondisplay');

  $('#LogsHold').asemonGrid({
    'title' : 'Long transactions (Syslogshold)',
    'width' : '100%',
    'height' : height,
    'rowcount': 200,
    'editable': false,
    'filterable': true,
    'cursor' : 'pointer',
    'querydata': {'queryfile' : '../ASE/sql/sql_SysLogsHold.php', 'default_order_by' : 'elapsed desc'},
//    'beforeRefresh': function() {refresh_LogsHold (this[0]);},
    'datafieldsMapping': {'starttm': 'starttime'},
    'datafields': [
     { name: 'starttm',  type: 'string'},
     { name: 'elapsed',  type: 'number'},
     { name: 'dbname',   type: 'string'},
     { name: 'dbid',     type: 'number'},
     { name: 'spid',     type: 'number'},
     { name: 'page',     type: 'number'},
     { name: 'name',     type: 'string'},
     { name: 'xloid',    type: 'number'},
     { name: 'endtime',  type: 'string'},
     { name: 'Loggedindatetime',  type: 'string'}

      ],
    'columns': [
     { text: 'StartTime  ', datafield: 'starttm', width: 170, filterable: false},
     { text: 'Elapsed_s  ', datafield: 'elapsed', width: 90,  filterable: false , cellsformat: 'd', cellsalign: 'right'},
     { text: 'DBName     ', datafield: 'dbname',  width: 110, filterable: true},
     { text: 'DBID       ', datafield: 'dbid',    width: 90,  filterable: true, cellsformat: 'd', cellsalign: 'right' },
     { text: 'SPID       ', datafield: 'spid',    width: 90,  filterable: true, cellsformat: 'd', cellsalign: 'right' },
     { text: 'Page       ', datafield: 'page',    width: 90,  filterable: true, cellsformat: 'd', cellsalign: 'right' },
     { text: 'Trans. Name', datafield: 'name',    width: 150, filterable: true},
     { text: 'xloid      ', datafield: 'xloid',   width: 90,  filterable: true, cellsformat: 'd', cellsalign: 'right' },
     { text: '', width: 25,  filterable: false}
      ],
    'datafieldsTS' : []
  });

  $("#LogsHold").on('rowselect', function (event) {
    var rowindex = event.args.rowindex;

    var rowdata = $('#LogsHold').jqxGrid('getrowdatabyid', rowindex);
    if (typeof rowdata == 'undefined') return 0;
    if (rowdata.spid == 0) return 0;
    
    

    openWindowFromGrid ("#LogsHold", "detail_page.php", {ARContextJSON: ARContext, 'displaylevel' : 1, 'detail_type': 'PROCESS', 'Spid': rowdata.spid, 'starttm': rowdata.starttm, 'Loggedindatetime': rowdata.Loggedindatetime});

  });

  onArchCnxOpened = function(){
    $('.ASE-LogsHold').removeClass('nondisplay');
    $('#LogsHold').asemonGrid('refresh');
  }

</script>
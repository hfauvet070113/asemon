
<center>
<div id="allinfo">
  <H1> Wait graphs </H1>
  <div id="waits_DIV" style="display: flex;flex-direction: row;justify-content: space-around;flex-wrap: wrap;align-items: center;">
  </div>
</div>
</center>


<script type="text/javascript">

var ASM_XHR_getsyswaits_list;

function refresh_graph (WaitEventID, ClassDesc, EventDesc) {

  var graph;

  graph = $('#graph_SysWaits_'+WaitEventID).highcharts();
  if (typeof graph == 'undefined') {
    $('#waits_DIV').append('<div id="graph_SysWaits_'+WaitEventID+'"    class="mainchart" style="min-width:700px;width:1200px" > </div>');
    $('#graph_SysWaits_'+WaitEventID).asemonChart({
    title: {
      text: EventDesc+" : Total time (left axis) Avg wait time (right axis)"
    },
    queryFile : '../ASE/sql/graphSysWaits.php',
    tableName : 'SysWaits',
    data: {
      WaitEventID: WaitEventID
    },
    chart: {
       type: 'line'
    },
    series: [
      { name: 'TotWaitTime_s'      },
      { 
        name: 'AvgWaitTime_ms',
        yAxis: 1
      }
    ],
    legend: {
       enabled: true
    }
  
    });
  }
  graph = $('#graph_SysWaits_'+WaitEventID).highcharts();
  $('#graph_SysWaits_'+WaitEventID).asemonChart('refresh',threadDelays);   


}

onArchCnxOpened = function(){

  var WaitEventID;
  var ClassDesc;
  var EventDesc;
  var query = 
    "select W.WaitEventID, ClassDesc=C.Description, EventDesc=I.Description, SumWaitTime=sum(1.*WaitTime)"
  + " from "+ARContext.ServerName+"_SysWaits W, "+ARContext.ServerName+"_WEvInf I, "+ARContext.ServerName+"_WClassInf C"
  + " where W.Timestamp >='"+ARContext.StartTimestamp+"'"
  + " and W.Timestamp <'"+ARContext.EndTimestamp+"'"
  + " and convert(smallint,W.WaitEventID) = I.WaitEventID"
  + " and I.WaitClassID=C.WaitClassID"
  + " group by W.WaitEventID, C.Description, I.Description"
  + " order by 4 desc";

  var data = {ARContextJSON: JSON.stringify(ARContext), query: query};

  if (ASM_XHR_getsyswaits_list != null) {
    ASM_XHR_getsyswaits_list.abort();
    ASM_XHR_getsyswaits_list = null;
  }
  incXHRcnt();
  ASM_XHR_getsyswaits_list = $.post( 'COMMON/simplequery.php', data ).done(function(res) {
    var result = JSON.parse(res);
    if ( checkSQLError(result, 'refresh_trends') ) return;
    for (var i=0; i < result.TotalRows; i++) {
      WaitEventID = result.Rows[i].WaitEventID;
      ClassDesc = result.Rows[i].ClassDesc;
      EventDesc = result.Rows[i].EventDesc;

      refresh_graph(WaitEventID, ClassDesc, EventDesc);
    }

  })
  .fail(function(data) {
    if (data.statusText == 'abort')
      return;
    alert( "error retreiving syswaits" );
  })
  .always(function() {
    decXHRcnt();
  });

}
</script>


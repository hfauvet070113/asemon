<script type="text/javascript" src="js/shCore.js"></script>
<script type="text/javascript" src="js/shBrushSql.js"></script>


<center>
<div class="">
  <h1 id="headertitle"> Trends for statement with hashkey = <?php echo $SQLHashKey ?> </h1>

  <div id="message_TrendStmt"> </div>
  
  <div id="stmtSQLDIV" class="boxinmain detailbox">
    <div class="statTitle" ><strong>Batch SQL</strong></div>
    <div class="statLowerTitle" ><div style="margin-left: 10px;" align="left" ><input id="FormatSQLBTN" value="FormatSQL" type="button" class="btn btn-primary btn-xs" /></div></div>
    <div id="stmtSQL" class="boxcontent">
      <div> Loading...</div>
    </div>
  </div>

  
  <div id="Executions" class="trendchart" > </div>
  <div id="AvgLogicalReads" class="trendchart" > </div>
  <div id="AvgPhysicalReads" class="trendchart" > </div>
  <div id="AvgCpuTime" class="trendchart" > </div>
  <div id="AvgWaitTime" class="trendchart" > </div>
  <div id="AvgMemUsageKB" class="trendchart" > </div>
  <div id="AvgPagesModified" class="trendchart" > </div>
  <div id="AvgPacketsSent" class="trendchart" > </div>
  <div id="AvgPacketsReceived" class="trendchart" > </div>
  <div id="AvgRowsAffected" class="trendchart" > </div>

</div>
</center>

<script type="text/javascript">

var SQLHashKey = "<?php echo $SQLHashKey ?>"; 

var support157 = 0;
var StmtObjExists = 0;
var StmtSQLHKExists = 0;
var StmtPlnHKExists = 0;
var SQLHashKeyExists = 0;
var PLANHashKeyExists = 0;
var StmtObjVersion = 'old';
var CachedXMLExists = 0;
var colV16SP03Exists = 0;
var supportFieldsAnja = 0;
var ASM_result_stmtSQL;

var ASM_XHR_refresh_stmtSQL;


var queryrangesel = "select Ts=convert(varchar,convert(datetime,convert(varchar,day,3),3),109),"
                  + " Value=AVG(case when Executions <0 then 0 else Executions end)  /* Ignore negatives values */" 
                  + " from "+ARContext.ServerName+"_TrendStmt" 
                  + " where SQLHashKey="+SQLHashKey
                  + " group by convert(datetime,convert(varchar,day,3),3)"
                  + " order by convert(datetime,convert(varchar,day,3),3)";
var delayRangeSel = 86400;
var setTimestampToRSExtremes=1;


function refresh_stmtSQL () {


  var data = {ARContextJSON: JSON.stringify(ARContext),
              'StmtSQLHKExists' : StmtSQLHKExists,
               'SQLHashKey' : SQLHashKey,
               'BootID': 0,
               'KPID': 0,
               'SPID': 0,
               'BatchID': 0,
               'Strttm': '1/1/1900',
               'Elapsed_ms': 0};
  $('#stmtSQL').html('<div> Loading...</div>');
  $('#stmtSQL').removeClass('detailboxcontent_nodata');
  $('#stmtSQL').addClass('detailboxcontent_loading');

  if (ASM_XHR_refresh_stmtSQL != null) {
    ASM_XHR_refresh_stmtSQL.abort();
    ASM_XHR_refresh_stmtSQL = null;
  }
  incXHRcnt();
  ASM_XHR_refresh_stmtSQL = $.post( 'ASE/sql/sql_stmt_SQL.php', data ).done(function(res) {
    var result_stmtSQL = JSON.parse(res);
    if ( checkSQLError(result_stmtSQL, 'refresh_stmtSQL') ) return;
    $('#stmtSQL').removeClass('detailboxcontent_loading');
    if (result_stmtSQL.TotalRows == 0) {
      $('#stmtSQL').html('<div> No data to display</div>');
      $('#stmtSQL').addClass('detailboxcontent_nodata');
    }
    else {
      result_stmtSQL.FormattedSQL = result_stmtSQL.FormattedSQL.replace('<', '&lt;');
      ASM_result_stmtSQL = result_stmtSQL; // Save this result in global var
      render_stmtSQL();
    }
  })
  .fail(function(data) {
    if (data.statusText == 'abort')
      return;
    alert( "error in refresh_stmtSQL()" );
    $('#stmtSQL').html('<div> Error when loading data </div>');
  })
  .always(function() {
    decXHRcnt();
  });
}



function render_stmtSQL() {

  var sql = "";
  var sqltext;
  var sep = "\n";
  var previousLineNumber = 1;
  var currentLineNumber;
  for (var i=0; i< ASM_result_stmtSQL.TotalRows; i++) {
    sqltext = ASM_result_stmtSQL.Rows[i].SQLText.replace('<', '&lt;');
    currentLineNumber = ASM_result_stmtSQL.Rows[i].LineNumber
    if (currentLineNumber == null) currentLineNumber = 1;
    if (currentLineNumber != previousLineNumber) {
      sql = sql + sep.repeat(currentLineNumber - previousLineNumber)  + sqltext;
      previousLineNumber = currentLineNumber;
    }
    else
      sql = sql + sqltext;
    
  }
  $('#stmtSQL').html('<pre class="brush: sql">'+sql+'</pre>');
  SyntaxHighlighter.highlight();

}

function render_formattedSQL () {
  $('#stmtSQL').html('<pre class="brush: sql">'+ASM_result_stmtSQL.FormattedSQL+'</pre>');
  SyntaxHighlighter.highlight();
}

onArchCnxOpened = function(){
  var height =    $('#page-content').innerHeight() - $('#headertitle').height() - 65;
  var graph;

  if ( existColumn(ARContext.ServerName+'_StmtStat', 'ClientName') ) {
    support157 = 1;
  }

  if ( existTable(ARContext.ServerName+'_StmtObj' ) ) {
    StmtObjExists = 1;
  }
  if ( existColumn(ARContext.ServerName+'_StmtObj', 'PartitionID') ) {
    StmtObjVersion = 'new';
  }

  if ( existTable(ARContext.ServerName+'_CachedXML' ) ) {
    CachedXMLExists = 1;
  }

  if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_StmtSQLHK') )  ) {
    StmtSQLHKExists = 1;
  }

  if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_StmtPlnHK') )  ) {
    StmtPlnHKExists = 1;
  }

  if ( (ARContext.ServerName!="") && ( existColumn(ARContext.ServerName+'_StmtStat', 'SQLHashKey') )  ) {
    SQLHashKeyExists = 1;
  }

  if ( (ARContext.ServerName!="") && ( existColumn(ARContext.ServerName+'_StmtStat', 'PLANHashKey') )  ) {
    PLANHashKeyExists = 1;
  }

  if ( (ARContext.ServerName!="") && ( existColumn(ARContext.ServerName+'_StmtStat', 'QueryOptimizationTime') )  ) {
    colV16SP03Exists = 1;
  }

  if ( (ARContext.ServerName!="") && ( existColumn(ARContext.ServerName+'_StmtStat', 'StatementNumber') ) && ( existColumn(ARContext.ServerName+'_StmtStat', 'ProcNestLevel') ) ) {
    supportFieldsAnja = 1;
  }

  if ( (ARContext.ServerName!="") && ( existColumn(ARContext.ServerName+'_StmtStat', 'tran_name') ) ) {
    col_tran_name_Exists = 1;
  }


  refresh_stmtSQL();


  if ( ! existTable(ARContext.ServerName+'_TrendStmt') || ! existTable(ARContext.ServerName+'_TrendsCfg') ) {
    $('#message_TrendStmt').append('TrendStmt data is not available. The indicators aggregation has not been activated for server "'+ARContext.ServerName+'".<P> (Add Trends.xml in the asemon_logger config file)');
  }
  else {

    // Display trends up to now  MARCHE PAS POUR L'INSTANT (modifier asemonChart !!!!!!!!!)
    ARContext.EndTimestamp = '01/01/2100';

    graph = $('#Executions').highcharts();
    if (typeof graph == 'undefined')
      //graph.destroy();
      $('#Executions').asemonChart({
      title: {
        text: 'Executions (number per day)'
      },
      queryFile : '../ASE/sql/graphTrendStmt.php',
      data: {
        indic: 'Executions',
        SQLHashKey: SQLHashKey
      },
      tableName : 'TrendStmt',
      chart: {
               marginTop: 50,
               marginBottom: 60,
          type: 'area'
      },
      series: [
        {
          name: 'Value'
        }
      ],
      legend: {
         enabled: false
        },
      xAxis: {
        labels : {
          format: '{value:%Y-%m-%d}',
        }
      },
      tooltip: {
            xDateFormat: '%Y-%m-%d'
        }
    
      });
    $('#Executions').asemonChart('refresh');
    
        
    
    graph = $('#AvgLogicalReads').highcharts();
    if (typeof graph == 'undefined')
      //graph.destroy();
      $('#AvgLogicalReads').asemonChart({
      title: {
        text: 'AvgLogicalReads (avg per execution of proc)'
      },
      queryFile : '../ASE/sql/graphTrendStmt.php',
      data: {
        indic: 'AvgLogicalReads',
        SQLHashKey: SQLHashKey
      },
      tableName : 'TrendStmt',
      chart: {
               marginTop: 50,
               marginBottom: 60,
          type: 'area'
      },
      series: [
        {
          name: 'Value'
        }
      ],
      legend: {
         enabled: false
        },
      xAxis: {
        labels : {
          format: '{value:%Y-%m-%d}',
        }
      },
      tooltip: {
            xDateFormat: '%Y-%m-%d'
        }
    
      });
    $('#AvgLogicalReads').asemonChart('refresh');
    
    
    graph = $('#AvgPhysicalReads').highcharts();
    if (typeof graph == 'undefined')
      //graph.destroy();
      $('#AvgPhysicalReads').asemonChart({
      title: {
        text: 'AvgPhysicalReads (avg per execution of proc)'
      },
      queryFile : '../ASE/sql/graphTrendStmt.php',
      data: {
        indic: 'AvgPhysicalReads',
        SQLHashKey: SQLHashKey
      },
      tableName : 'TrendStmt',
      chart: {
               marginTop: 50,
               marginBottom: 60,
          type: 'area'
      },
      series: [
        {
          name: 'Value'
        }
      ],
      legend: {
         enabled: false
        },
      xAxis: {
        labels : {
          format: '{value:%Y-%m-%d}',
        }
      },
      tooltip: {
            xDateFormat: '%Y-%m-%d'
        }
    
      });
    $('#AvgPhysicalReads').asemonChart('refresh');
    
    
    graph = $('#AvgCpuTime').highcharts();
    if (typeof graph == 'undefined')
      //graph.destroy();
      $('#AvgCpuTime').asemonChart({
      title: {
        text: 'AvgCpuTime (avg per execution of proc)'
      },
      queryFile : '../ASE/sql/graphTrendStmt.php',
      data: {
        indic: 'AvgCpuTime',
        SQLHashKey: SQLHashKey
      },
      tableName : 'TrendStmt',
      chart: {
               marginTop: 50,
               marginBottom: 60,
          type: 'area'
      },
      series: [
        {
          name: 'Value'
        }
      ],
      legend: {
         enabled: false
        },
      xAxis: {
        labels : {
          format: '{value:%Y-%m-%d}',
        }
      },
      tooltip: {
            xDateFormat: '%Y-%m-%d'
        }
    
      });
    $('#AvgCpuTime').asemonChart('refresh');
    
    
    graph = $('#AvgWaitTime').highcharts();
    if (typeof graph == 'undefined')
      //graph.destroy();
      $('#AvgWaitTime').asemonChart({
      title: {
        text: 'AvgWaitTime (avg per execution of proc)'
      },
      queryFile : '../ASE/sql/graphTrendStmt.php',
      data: {
        indic: 'AvgWaitTime',
        SQLHashKey: SQLHashKey
      },
      tableName : 'TrendStmt',
      chart: {
               marginTop: 50,
               marginBottom: 60,
          type: 'area'
      },
      series: [
        {
          name: 'Value'
        }
      ],
      legend: {
         enabled: false
        },
      xAxis: {
        labels : {
          format: '{value:%Y-%m-%d}',
        }
      },
      tooltip: {
            xDateFormat: '%Y-%m-%d'
        }
    
      });
    $('#AvgWaitTime').asemonChart('refresh');
    
    
    graph = $('#AvgMemUsageKB').highcharts();
    if (typeof graph == 'undefined')
      //graph.destroy();
      $('#AvgMemUsageKB').asemonChart({
      title: {
        text: 'AvgMemUsageKB (avg per execution of proc)'
      },
      queryFile : '../ASE/sql/graphTrendStmt.php',
      data: {
        indic: 'AvgMemUsageKB',
        SQLHashKey: SQLHashKey
      },
      tableName : 'TrendStmt',
      chart: {
               marginTop: 50,
               marginBottom: 60,
          type: 'area'
      },
      series: [
        {
          name: 'Value'
        }
      ],
      legend: {
         enabled: false
        },
      xAxis: {
        labels : {
          format: '{value:%Y-%m-%d}',
        }
      },
      tooltip: {
            xDateFormat: '%Y-%m-%d'
        }
    
      });
    $('#AvgMemUsageKB').asemonChart('refresh');
    

  }


  $('#FormatSQLBTN').click(function() {
    if (this.value == 'FormatSQL') {
      render_formattedSQL ();
      this.value = 'OriginalSQL';
    }
    else {
      render_stmtSQL ();
      this.value = 'FormatSQL';
    }
  });

};

  
</script>


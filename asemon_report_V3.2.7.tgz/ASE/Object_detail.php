
<center>
<div class="">
  <?php
    if (($OwnerName == '') && ($OwnerUserID != 0) )
      if ($OwnerUserID == 1)
        $OwnerName = 'dbo';
      else
        $OwnerName = $OwnerUserID;
  ?>

  <h1> Detail for Object '<?php echo $ObjectDbName ?>.<?php echo $OwnerName ?>.<?php echo $ObjectName ?>'   </h1>

<div id="allinfo">
  <h2> Usage Statistics </h2>

  <div id="graph_Object_LReads" class="mainchart" > </div>
  <div id="graph_Object_DML" class="mainchart" > </div>
  <div id="graph_Object_IO" class="mainchart" > </div>
  <div id="index_stats"> </div>
  <div id="caches_info"> </div>
  
  
  <div ID="Statements_statisticsDIV" class="detailbox">
    <h2> Captured Statements using this table </h2>
    <div ID="Statements_statistics"></div>
  </div>

</div>
<div id="messageDIV" style="display:none;">
  No data for this time range
</div>
</div>
</center>


<script type="text/javascript">

var ObjectDbName = "<?php echo $ObjectDbName ?>"; 
var ObjectName = "<?php echo $ObjectName ?>";
var ObjectID = "<?php echo $ObjectID ?>";
var OwnerUserID = "<?php echo $OwnerUserID ?>";
var OwnerName = "<?php echo $OwnerName ?>";
var ObjectID_clause = "";

var CachedObjExists = 0;
var StmtStatExists = 0;
var support157 = 0;

var ASM_XHR_refresh_index_stats;
var ASM_XHR_refresh_cached_objects;

var StmtPlnHKExists = 0;
var colV16SP03Exists = 0;
var supportFieldsAnja = 0;


function refresh_index_stats () {


  var query = 
     "select distinct IndexID=IndID, indname from  "+ARContext.ServerName+"_OpObjAct"
   + " where Timestamp >='"+ARContext.StartTimestamp+"'"
   + " and Timestamp <='"+ARContext.EndTimestamp+"'"
   + " and dbname='"+ObjectDbName+"' and objname='"+ObjectName+"' and IndID >0 order by 1";

  var IndexID;
  var indname;
  var graph;
  $('#index_stats').empty(); 
  var data = {ARContextJSON: JSON.stringify(ARContext), 'query' : query};

  if (ASM_XHR_refresh_index_stats != null) {
    ASM_XHR_refresh_index_stats.abort();
    ASM_XHR_refresh_index_stats = null;
  }
  incXHRcnt();
  ASM_XHR_refresh_index_stats = $.post( 'COMMON/simplequery.php', data ).done(function(res) {
    var result = JSON.parse(res);
    if ( checkSQLError(result, 'refresh_index_stats') ) return;
    
    if (result.TotalRows > 0) {
      $('#index_stats').append('<h2> Index Statistics </h2>');
      for (var i = 0; i < result.TotalRows; i++) {
        IndexID = result.Rows[i].IndexID;
        indname = result.Rows[i].indname;
        $('#index_stats').append('<div ID="index_stats_'+IndexID+'" class="mainchart" > </div>'); 

        graph = $('#index_stats_'+IndexID).highcharts();
        if (typeof graph == 'undefined')
          $('#index_stats_'+IndexID).asemonChart({
          title: {
            text: 'INDEX : \''+indname+'\' (id='+IndexID+') Physical IO / s (cumulated)'
          },
          queryFile : '../ASE/sql/graph_Object_IO.php',
          data: {
            ObjectDbName: ObjectDbName,
            ObjectName: ObjectName,
            ObjectID_clause: ObjectID_clause,
            IndexID: IndexID
          },
          tableName : 'OpObjAct',
          chart: {
              type: 'area'
          },
          series: [
            {
              name: 'PhysicalReads / s'
            },
            {
              name: 'APFReads / s'
            },
            {
              name: 'PhysicalWrites / s'
            }
          ],
          legend: {
             enabled: true
            },
          yAxis: {
                  minRange: 0.5,
                  min : 0
            }
        
          });
        $('#index_stats_'+IndexID).asemonChart('refresh', threadDelays);

      }
    }
  })
  .fail(function(data) {
    if (data.statusText == 'abort')
      return;
    alert( "error in refresh_index_stats()" );
  })
  .always(function() {
    decXHRcnt();
  });
}



function refresh_cached_objects () {

var IndexID;
var CacheName;
var graph;
var Iname;

  var query = 
     "select"
   + " distinct IndexID, CacheName"
   + " from "+ARContext.ServerName+"_CachedObj"
   + " where Timestamp >='"+ARContext.StartTimestamp+"'"
   + " and Timestamp <='"+ARContext.EndTimestamp+"'"
   + " and DBName='"+ObjectDbName+"'"
   + " and ObjectName='"+ObjectName+"'"
   + ObjectID_clause
   + " order by 1";

  $('#caches_info').empty();

  var data = {ARContextJSON: JSON.stringify(ARContext), 'query' : query};

  if (ASM_XHR_refresh_cached_objects != null) {
    ASM_XHR_refresh_cached_objects.abort();
    ASM_XHR_refresh_cached_objects = null;
  }
  incXHRcnt();
  ASM_XHR_refresh_cached_objects = $.post( 'COMMON/simplequery.php', data ).done(function(res) {
    var result = JSON.parse(res);
    if ( checkSQLError(result, 'refresh_cached_objects') ) return;
    
    if (result.TotalRows > 0) {
      $('#caches_info').append('<h2> Caches Info </h2>');
      for (var i = 0; i < result.TotalRows; i++) {
        IndexID = result.Rows[i].IndexID;
        CacheName = result.Rows[i].CacheName;

        if (IndexID==0) Iname="DATA";
        else Iname="INDEX "+IndexID;

        $('#caches_info').append('<div ID="caches_info_'+IndexID+'" class="mainchart" > </div>'); 

        graph = $('#caches_info_'+IndexID).highcharts();
        if (typeof graph == 'undefined')
          $('#caches_info_'+IndexID).asemonChart({
          title: {
            text: Iname+' cached KB in "'+CacheName+'"'
          },
          queryFile : '../ASE/sql/graphCachedObj.php',
          data: {
            ObjectDbName: ObjectDbName,
            ObjectName: ObjectName,
            ObjectID: ObjectID,
            IndexID: IndexID
          },
          tableName : 'CachedObj',
          chart: {
              type: 'area'
          },
          series: [
            {
              name: 'CachedKB'
            }
          ],
          legend: {
             enabled: true
            },
          yAxis: {
                  minRange: 0.5,
                  min : 0
            }
        
          });
        $('#caches_info_'+IndexID).asemonChart('refresh', threadDelays);
      }
    }
    else {
      $('#caches_info').hide();
    }
  })
  .fail(function(data) {
    if (data.statusText == 'abort')
      return;
    alert( "error in refresh_cached_objects()" );
      $('#caches_info').hide();
  })
  .always(function() {
    decXHRcnt();
  });
}




  function render_Statements_statistics () {
    var cols = [];
    var fields = [];
    var cols157 = [];
    var fields157 = [];

    fields = [
           { name: 'stat_StmtID',   type: 'number'},
           { name: 'Debut',         type: 'string'},
           { name: 'Elapsed_s',     type: 'number'},
           { name: 'SPID',          type: 'number'},
           { name: 'DBID',          type: 'number'},
           { name: 'Application',   type: 'string'},
           { name: 'ClientHost',    type: 'string'},
           { name: 'ProcName',      type: 'string'},
           { name: 'LineNumber',    type: 'number'},
           { name: 'CpuTime',       type: 'number'},
           { name: 'WaitTime',      type: 'number'},
           { name: 'MemUsageKB',    type: 'number'},
           { name: 'PhysicalReads', type: 'number'},
           { name: 'LogicalReads',  type: 'number'},
           { name: 'PagesModified', type: 'number'},
           { name: 'PacketsSent',   type: 'number'},
           { name: 'planOK',        type: 'string'},
           { name: 'PlanID',        type: 'number'},
           { name: 'BatchID',       type: 'number'},
           { name: 'ContextID',     type: 'number'}
    ];
    cols = [
           { text: 'StmtID',      datafield: 'stat_StmtID',   width: 70,  filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number'},
           { text: 'StartTime',   datafield: 'Debut',         width: 170, filterable: false},
           { text: 'Elapsed_s',   datafield: 'Elapsed_s',     width: 70, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number'},
           { text: 'SPID',        datafield: 'SPID',          width: 50, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number'},
           { text: 'DBID',        datafield: 'DBID',          width: 50, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number'},
           { text: 'Application', datafield: 'Application',   width: 90, filterable: true},
           { text: 'ClientHost',  datafield: 'ClientHost',    width: 150, filterable: true},
           { text: 'Proc',        datafield: 'ProcName',      width: 150, filterable: true},
           { text: 'Line',        datafield: 'LineNumber',    width: 70, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number'},
           { text: 'CpuTime_ms',  datafield: 'CpuTime',       width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']},
           { text: 'WaitTime_ms', datafield: 'WaitTime',      width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']},
           { text: 'MemUsageKB',  datafield: 'MemUsageKB',    width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['max']},
           { text: 'PReads',      datafield: 'PhysicalReads', width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']},
           { text: 'LReads',      datafield: 'LogicalReads',  width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']},
           { text: 'PgsModified', datafield: 'PagesModified', width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']},
           { text: 'PktsSent',    datafield: 'PacketsSent',   width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']},
           { text: 'Plan',        datafield: 'planOK',        width: 50, filterable: false},
           { text: 'PlanID',      datafield: 'PlanID',        width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number'},
           { text: 'BatchID',     datafield: 'BatchID',       width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number'},
           { text: 'ContextID',   datafield: 'ContextID',     width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number'}
    ];
    fields157 = [
           { name: 'ClientName',     type: 'string'},
           { name: 'ClientHostName', type: 'string'},
           { name: 'ClientApplName', type: 'string'}
    ];
    cols157= [
           { text: 'ClientName',     datafield: 'ClientName',     width: 90, filterable: true},
           { text: 'ClientHostName', datafield: 'ClientHostName', width: 90, filterable: true},
           { text: 'ClientApplName', datafield: 'ClientApplName', width: 90, filterable: true}
    ];


    if (support157 == 1) {
      fields = fields.concat(fields157);
      cols = cols.concat(cols157);
    }

    grid = $('#Statements_statistics').data('jqxWidget');
    if (typeof grid == 'undefined')
      $('#Statements_statistics').asemonGrid({
        'title' : 'Statements statistics',
        'width' : '100%',
        'height' : 350,
        'rowcount': 200,
        'editable': false,
        'filterable': true,
        'cursor' : 'pointer',
        'showaggregates': false,
        'querydata': {'queryfile' : '../ASE/sql/sql_stmt_statistics.php', 'default_order_by' : 'stat.StmtID',
                       'support157': support157,
                       'ObjectDbName': ObjectDbName,
                       'OwnerUserID': OwnerUserID,
                       'StmtPlnHKExists': StmtPlnHKExists,
                       'colV16SP03Exists': colV16SP03Exists,
                       'supportFieldsAnja': supportFieldsAnja,
                       'ObjectName': ObjectName},
        'datafieldsMapping': {'Debut': 'StartTime', 'stat_StmtID': 'stat.StmtID'},
        'datafields':fields,
        'columns': cols,
        'datafieldsTS' : []
      
      });
    else
      $('#Statements_statistics').asemonGrid('refresh');

  
    $("#Statements_statistics").on('rowselect', function (event) {
      var rowindex = event.args.rowindex;
      //alert ("row "+rowindex+" selected");
      
      rowdata = $('#Statements_statistics').jqxGrid('getrowdatabyid', rowindex);
      if (typeof rowdata == 'undefined') return 0;
      var StmtID = rowdata.stat_StmtID;
        
        openWindowFromGrid ("#Statements_statistics", "detail_page.php", {ARContextJSON: ARContext, 'displaylevel' : 2, 'detail_type': 'STMT', 'StmtID': StmtID});
    });
  }






onArchCnxOpened = function(){

  var graph;
  var hasObjectID = 0;
  if ( existColumn(ARContext.ServerName+'_OpObjAct', 'ObjectID') )
    hasObjectID = 1;

  if ( (ObjectID != 0) && (hasObjectID) )
     ObjectID_clause = " and ObjectID = " + ObjectID;

  if ( existTable(ARContext.ServerName+'_StmtStat' ) ) {
    StmtStatExists = 1;
  }
  if ( existColumn(ARContext.ServerName+'_StmtStat', 'ClientName') )
    support157 = 1;


  if ( existTable(ARContext.ServerName+'_CachedObj' ) ) {
    CachedObjExists = 1;
    refresh_cached_objects();
  }

  if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_StmtPlnHK') )  ) {
    StmtPlnHKExists = 1;
  }
  if ( (ARContext.ServerName!="") &&( existColumn(ARContext.ServerName+'_StmtStat', 'QueryOptimizationTime') )  ){
    colV16SP03Exists = 1;
  }

  if ( (ARContext.ServerName!="") && ( existColumn(ARContext.ServerName+'_StmtStat', 'StatementNumber') ) && ( existColumn(ARContext.ServerName+'_StmtStat', 'ProcNestLevel') ) ) {
    supportFieldsAnja = 1;
  }


  graph = $('#graph_Object_LReads').highcharts();
  if (typeof graph == 'undefined')
    $('#graph_Object_LReads').asemonChart({
    title: {
      text: 'DATA + INDEX Logical IO / s (cumulated)'
    },
    queryFile : '../ASE/sql/graph_Object_LReads.php',
    data: {
      ObjectDbName: ObjectDbName,
      ObjectName: ObjectName,
      ObjectID_clause: ObjectID_clause
    },
    tableName : 'OpObjAct',
    chart: {
        type: 'area'
    },
    series: [
      {
        name: 'DATA_LReads / s'
      },
      {
        name: 'INDEX_LReads / s'
      }
    ],
    legend: {
       enabled: true
      },
    yAxis: {
            minRange: 1,
            min : 0
      }
  
    });
  $('#graph_Object_LReads').asemonChart('refresh', threadDelays);

  graph = $('#graph_Object_DML').highcharts();
  if (typeof graph == 'undefined')
    $('#graph_Object_DML').asemonChart({
    title: {
      text: 'DML operations / s (cumulated)'
    },
    queryFile : '../ASE/sql/graph_Object_DML.php',
    data: {
      ObjectDbName: ObjectDbName,
      ObjectName: ObjectName,
      ObjectID_clause: ObjectID_clause,
      IndexID: '0'
    },
    tableName : 'OpObjAct',
    chart: {
        type: 'area'
    },
    series: [
      {
        name: 'RowsInserted / s'
      },
      {
        name: 'RowsUpdated / s'
      },
      {
        name: 'RowsDeleted / s'
      }
    ],
    legend: {
       enabled: true
      },
    yAxis: {
            minRange: 1,
            min : 0
      }
  
    });
  $('#graph_Object_DML').asemonChart('refresh', threadDelays);


  graph = $('#graph_Object_IO').highcharts();
  if (typeof graph == 'undefined')
    $('#graph_Object_IO').asemonChart({
    title: {
      text: 'Physical IO / s (cumulated)'
    },
    queryFile : '../ASE/sql/graph_Object_IO.php',
    data: {
      ObjectDbName: ObjectDbName,
      ObjectName: ObjectName,
      ObjectID_clause: ObjectID_clause,
      IndexID: '0'
    },
    tableName : 'OpObjAct',
    chart: {
        type: 'area'
    },
    series: [
      {
        name: 'PhysicalReads / s'
      },
      {
        name: 'APFReads / s'
      },
      {
        name: 'PhysicalWrites / s'
      }
    ],
    legend: {
       enabled: true
      },
    yAxis: {
            minRange: 1,
            min : 0
      }
  
    });
  $('#graph_Object_IO').asemonChart('refresh', threadDelays);

  refresh_index_stats();

  if (StmtStatExists == 1) {
    render_Statements_statistics();
  }
  else
    $('#Statements_statisticsDIV').hide();

}
</script>


<div class="AllAseParams nondisplay">
  <center>
  <div class="maingrid">
    <div ID="AllAseParamsList" class="asemongrid singlegrid" ></div>
  </div>
  </center>
</div>


<script type="text/javascript">

  var height =    $('#page-content').innerHeight()-50;

  if (typeof detail_type != 'undefined')
    $('.AllAseParams').removeClass('nondisplay');

  $('#AllAseParamsList').asemonGrid({
    'title' : 'All ASE Parameters',
    'width' : '100%',
    'height' : height,
    'rowcount': '0',
    'editable': false,
    'filterable': true,
    'cursor' : 'pointer',
    'beforeRefresh': function() {refresh_AllAseParamsList (this[0]);},
    'querydata' : {'queryfile' : '', 'selparams' : 'All'},
    'datafieldsMapping': {},
    'datafields': [
     { name: 'srvname', type: 'string'}
     ],
    'columns': [
     { text: 'srvname', datafield: 'srvname',     width: 100, filterable: true}
     ],
     'buttons' : [
       {
        'id': 'differBTN',
        'text': 'DifferConfig',
        'title': 'Select params which have different values on all servers',
        'onclick' : function ( ) {
          var selparams;
          if (this.value == 'All') {
            this.value = 'DifferConfig';
            this.title = 'Select params which have different values on all servers';
            selparams = 'All';
          }
          else {
            this.value = 'All';
            selparams = 'DifferConfig';
            this.title = 'Select all params';
          }
          var selector = $('#AllAseParamsList')[0];
          var asemondata = jQuery.data( selector , 'asemondata');
          $.extend(asemondata.querydata, {'selparams' : selparams});
          $(selector).asemonGrid('refresh');
        }
       }
      ]
  });

  $("#AllAseParamsList").bind('cellclick', function (event) {
    var column = event.args.column;
    var rowindex = event.args.rowindex;
    //alert ("row "+rowindex+" clicked");

    rowdata = $('#AllAseParamsList').jqxGrid('getrowdatabyid', rowindex);
    if (typeof rowdata == 'undefined') return 0;

    ARContext.ServerName = rowdata.srvname;
    
    openWindowFromGrid ("#AllAseParamsList", "detail_page.php", {ARContextJSON: ARContext, 'displaylevel' : 2, 'detail_type': 'PARAMDETAIL', 'srvname': rowdata.srvname, 'ParamName': rowdata.ParamName});

    ARContext.ServerName = "";
  });



  function refresh_AllAseParamsList (grid) {
    var asemondata = jQuery.data(grid, 'asemondata');
    var cols = [];
    var fields = [];
    var queryfile = '../ASE/sql/sql_allaseparams.php';

    fields = [
           { name: 'srvname',      type: 'string'},
           { name: 'ParamName',    type: 'string'},
           { name: 'CfgValue',     type: 'string'},
           { name: 'RunValue',     type: 'string'}
    ];

    cols= [
           { text: 'srvname'  ,      datafield: 'srvname',       width: 200, filterable: true},
           { text: 'ParamName',    datafield: 'ParamName',     width: 300, filterable: true},
           { text: 'CfgValue' ,     datafield: 'CfgValue',      width: 150, filterable: true},
           { text: 'RunValue' ,     datafield: 'RunValue',      width: 150, filterable: true},
           { text: '', width: 25,  filterable: false}
    ];

    $(grid).asemonGrid({
      'querydata' : {
                     'queryfile' : queryfile ,
                     'default_order_by': 'ParamName'
                    },
      'datafields': fields,
      'columns': cols
    });
  }

  onArchCnxOpened = function(){
    $('.AllAseParams').removeClass('nondisplay');
    $('#AllAseParamsList').asemonGrid('refresh');
  }

</script>
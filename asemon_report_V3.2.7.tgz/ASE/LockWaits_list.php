<div class="ASE-LockWaits nondisplay">
  <center>
  <div class="maingrid">
    <div ID="lockwaits_list" class="asemongrid singlegrid" ></div>
    <div ID="lockwaits_list_mess" class="nodisplay" >  </div>
  </div>
  </center>
</div>


<script type="text/javascript">

  var height =    $('#page-content').innerHeight() - 55;

  if (typeof detail_type != 'undefined')
    $('.ASE-LockWaits').removeClass('nondisplay');

  $('#lockwaits_list').asemonGrid({
    'title' : 'LockWaits list',
    'width' : '100%',
    'height' : height,
    'rowcount': '200',
    'filterable': true,
    'sortable': true,
    'altrows': true,
    'cursor' : 'pointer',
    'beforeRefresh': function() {refresh_lockwaits_list (this[0]);},
    'querydata' : {
                     'queryfile' : ''
                  },
    'datafields': [
     { name: 'DbName', type: 'string'}
     ],
    'columns': [
     { text: 'DbName',         datafield: 'DbName',         width: 90, filterable: true}
     ],
    'datafieldsMapping' : { }
  });

  $("#lockwaits_list").on('rowselect', function (event) {
    var rowindex = event.args.rowindex;
    alert ("row "+rowindex+" selected");
  });


  function refresh_lockwaits_list (grid) {
    var asemondata = jQuery.data(grid, 'asemondata');
    var LockWaitsExists = 0;
    var cols = [];
    var fields = [];
    var queryfile = '../ASE/sql/sql_LockWaits_list.php';


    if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_LockWaits') )  )
      LockWaitsExists = 1;

    if ( LockWaitsExists == 0) {
      $('#lockwaits_list').hide();
      $('#lockwaits_list_mess').show();
      $('#lockwaits_list_mess').html('<p>LockWait data is not available. The LockWait collector has not been activated for server '+ARContext.ServerName+', may be for performance reasons. </p>');
      $.extend(asemondata, {'querydata' : {'queryfile' : '', 'query': ''}});
      return;
    }
    else {
      $('#lockwaits_list').show();
      $('#lockwaits_list_mess').hide();
    }


    fields = [
           { name: 'DbName',         type: 'string'},
           { name: 'TabName',        type: 'string'},
           { name: 'LockScheme',     type: 'string'},
           { name: 'Pagetype',       type: 'number'},
           { name: 'StatName',       type: 'string'},
           { name: 'WaitTime_ms',    type: 'number'},
           { name: 'sumWaits',       type: 'number'},
           { name: 'AvgWaitTime_ms', type: 'number'}
    ];
    cols= [
           { text: 'DbName',         datafield: 'DbName',         width: 90, filterable: true},
           { text: 'TabName',        datafield: 'TabName',        width: 90, filterable: true},
           { text: 'LockScheme',     datafield: 'LockScheme',     width: 90, filterable: true},
           { text: 'Pagetype',       datafield: 'Pagetype',       width: 90, filterable: true},
           { text: 'StatName',       datafield: 'StatName',       width: 90, filterable: true},
           { text: 'WaitTime_ms',    datafield: 'WaitTime_ms',    width: 90, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']},
           { text: 'Waits',          datafield: 'sumWaits',       width: 90, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']},
           { text: 'AvgWaitTime_ms', datafield: 'AvgWaitTime_ms', width: 90, filterable: false, cellsformat: 'd2', cellsalign: 'right'},
           { text: '', width: 25,  filterable: false}
     ];



    if ( LockWaitsExists == 1)
      $(grid).asemonGrid({
        'querydata' : {
                       'queryfile' : queryfile,
                       'default_order_by': 'WaitTime_ms DESC'
                      },
        'datafields': fields,
        'columns': cols 
      });
   
  }

  onArchCnxOpened = function(){
    $('.ASE-LockWaits').removeClass('nondisplay');
    $('#lockwaits_list').asemonGrid('refresh');
  }

</script>
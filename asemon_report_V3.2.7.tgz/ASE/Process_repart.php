
<center>
<div id="allinfo">
  <h1> Pie Graphs by Usernames and by Program_names </h1>
  <div style="display: flex;flex-direction: row;justify-content: space-around;flex-wrap: wrap;align-items: center;">
    <div id="graphPie-Login-logical"  class="mainchart" style="min-width:700px;max-width:800px" > </div>
    <div id="graphPie-Prog-logical"   class="mainchart" style="min-width:700px;max-width:800px" > </div>
    <div id="graphPie-Login-cpu"      class="mainchart" style="min-width:700px;max-width:800px" > </div>
    <div id="graphPie-Prog-cpu"       class="mainchart" style="min-width:700px;max-width:800px" > </div>
    <div id="graphPie-Login-physical" class="mainchart" style="min-width:700px;max-width:800px" > </div>
    <div id="graphPie-Prog-physical"  class="mainchart" style="min-width:700px;max-width:800px" > </div>
  </div>
</div>
</center>


<script type="text/javascript">

var filter_clause = "<?php echo $filter_clause; ?>";


onArchCnxOpened = function(){
  var graph;

  graph = $('#graphPie-Login-logical').highcharts();
  if (typeof graph == 'undefined')
    //graph.destroy();
    $('#graphPie-Login-logical').asemonChart_nots({
    title: {
      text: "Logical_reads by 'username'"
    },
    queryFile : '../ASE/sql/graphPieProcess.php',
    tableName : 'Engines',
    chart: {
        type: 'pie',
        marginBottom: 5,
        marginLeft: 5,
        marginRight: 5
    },
    plotOptions: {
      pie: {
          cursor: 'pointer',
          dataLabels: {
              enabled: true,
              format: '{point.name}: {point.percentage:.1f} %',
              style: {"color": "contrast", "fontSize": "11px", "fontWeight": "normal", "textShadow": "0 0 6px contrast, 0 0 3px contrast" }
          },
          size : '60%'
      }
    },
    series: [
      {
        name: 'I/O'
      }
    ],
    data: {
      group: 'login',
      indicator: 'logical',
      filter_clause: filter_clause
    }
    });
  $('#graphPie-Login-logical').asemonChart_nots('refresh');

  graph = $('#graphPie-Prog-logical').highcharts();
  if (typeof graph == 'undefined')
    //graph.destroy();
    $('#graphPie-Prog-logical').asemonChart_nots({
    title: {
      text: "Logical_reads by 'program_name'"
    },
    queryFile : '../ASE/sql/graphPieProcess.php',
    tableName : 'Engines',
    chart: {
        type: 'pie',
        marginBottom: 5,
        marginLeft: 5,
        marginRight: 5
    },
    plotOptions: {
      pie: {
          cursor: 'pointer',
          dataLabels: {
              enabled: true,
              format: '{point.name}: {point.percentage:.1f} %',
              style: {"color": "contrast", "fontSize": "11px", "fontWeight": "normal", "textShadow": "0 0 6px contrast, 0 0 3px contrast" }
          },
          size : '60%'
      }
    },
    series: [
      {
        name: 'I/O'
      }
    ],
    data: {
      group: 'program',
      indicator: 'logical',
      filter_clause: filter_clause
    }
    });
  $('#graphPie-Prog-logical').asemonChart_nots('refresh');

  graph = $('#graphPie-Login-cpu').highcharts();
  if (typeof graph == 'undefined')
    //graph.destroy();
    $('#graphPie-Login-cpu').asemonChart_nots({
    title: {
      text: "CPU by 'username'"
    },
    queryFile : '../ASE/sql/graphPieProcess.php',
    tableName : 'Engines',
    chart: {
        type: 'pie',
        marginBottom: 5,
        marginLeft: 5,
        marginRight: 5
    },
    plotOptions: {
      pie: {
          cursor: 'pointer',
          dataLabels: {
              enabled: true,
              format: '{point.name}: {point.percentage:.1f} %',
              style: {"color": "contrast", "fontSize": "11px", "fontWeight": "normal", "textShadow": "0 0 6px contrast, 0 0 3px contrast" }
          },
          size : '60%'
      }
    },
    series: [
      {
        name: 'I/O'
      }
    ],
    data: {
      group: 'login',
      indicator: 'cpu',
      filter_clause: filter_clause
    }
    });
  $('#graphPie-Login-cpu').asemonChart_nots('refresh');

  graph = $('#graphPie-Prog-cpu').highcharts();
  if (typeof graph == 'undefined')
    //graph.destroy();
    $('#graphPie-Prog-cpu').asemonChart_nots({
    title: {
      text: "CPU by 'program_name'"
    },
    queryFile : '../ASE/sql/graphPieProcess.php',
    tableName : 'Engines',
    chart: {
        type: 'pie',
        marginBottom: 5,
        marginLeft: 5,
        marginRight: 5
    },
    plotOptions: {
      pie: {
          cursor: 'pointer',
          dataLabels: {
              enabled: true,
              format: '{point.name}: {point.percentage:.1f} %',
              style: {"color": "contrast", "fontSize": "11px", "fontWeight": "normal", "textShadow": "0 0 6px contrast, 0 0 3px contrast" }
          },
          size : '60%'
      }
    },
    series: [
      {
        name: 'I/O'
      }
    ],
    data: {
      group: 'program',
      indicator: 'cpu',
      filter_clause: filter_clause
    }
    });
  $('#graphPie-Prog-cpu').asemonChart_nots('refresh');

  graph = $('#graphPie-Login-physical').highcharts();
  if (typeof graph == 'undefined')
    //graph.destroy();
    $('#graphPie-Login-physical').asemonChart_nots({
    title: {
      text: "physreads by 'username'"
    },
    queryFile : '../ASE/sql/graphPieProcess.php',
    tableName : 'Engines',
    chart: {
        type: 'pie',
        marginBottom: 5,
        marginLeft: 5,
        marginRight: 5
    },
    plotOptions: {
      pie: {
          cursor: 'pointer',
          dataLabels: {
              enabled: true,
              format: '{point.name}: {point.percentage:.1f} %',
              style: {"color": "contrast", "fontSize": "11px", "fontWeight": "normal", "textShadow": "0 0 6px contrast, 0 0 3px contrast" }
          },
          size : '60%'
      }
    },
    series: [
      {
        name: 'I/O'
      }
    ],
    data: {
      group: 'login',
      indicator: 'physreads',
      filter_clause: filter_clause
    }
    });
  $('#graphPie-Login-physical').asemonChart_nots('refresh');

  graph = $('#graphPie-Prog-physical').highcharts();
  if (typeof graph == 'undefined')
    //graph.destroy();
    $('#graphPie-Prog-physical').asemonChart_nots({
    title: {
      text: "physreads by 'program_name'"
    },
    queryFile : '../ASE/sql/graphPieProcess.php',
    tableName : 'Engines',
    chart: {
        type: 'pie',
        marginBottom: 5,
        marginLeft: 5,
        marginRight: 5
    },
    plotOptions: {
      pie: {
          cursor: 'pointer',
          dataLabels: {
              enabled: true,
              format: '{point.name}: {point.percentage:.1f} %',
              style: {"color": "contrast", "fontSize": "11px", "fontWeight": "normal", "textShadow": "0 0 6px contrast, 0 0 3px contrast" }
          },
          size : '60%'
      }
    },
    series: [
      {
        name: 'I/O'
      }
    ],
    data: {
      group: 'program',
      indicator: 'physreads',
      filter_clause: filter_clause
    }
    });
  $('#graphPie-Prog-physical').asemonChart_nots('refresh');
}
</script>


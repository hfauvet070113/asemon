<div class="ASE-CursLocks nondisplay">
  <center>
  <div class="maingrid">
    <div ID="CursLocks_statistics" class="asemongrid singlegrid" ></div>
    <div ID="CursLocks_statistics_mess" class="nodisplay" >  </div>
  </div>
  </center>
</div>

<script type="text/javascript">
  var height =    $('#page-content').innerHeight() - 55;




  if (typeof detail_type != 'undefined')
    $('.ASE-CursLocks').removeClass('nondisplay');

  $('#CursLocks_statistics').asemonGrid({
    'title' : 'CursLocks statistics',
    'width' : '100%',
    'height' : height,
    'rowcount': 200,
    'filterable': true,
    'sortable': true,
    'showaggregates': false,
    'querydata': {'queryfile' : '', 'default_order_by' : 'spid, class'},
    'beforeRefresh': function() {refresh_CursLocks_statistics (this[0]);},
    'datafieldsMapping': {},
    'datafieldsTS' : [],
    'datafields': [
           { name: 'bootcount',      type: 'number'}
    ],
    'columns': [
           { text: 'bootcount'   , datafield: 'bootcount',    width: 70,   filterable: true, cellsformat: 'd',  cellsalign: 'right'}
    ]
  });

  function refresh_CursLocks_statistics (grid) {
    var asemondata = jQuery.data(grid, 'asemondata');
    var CursLocksExists = 0;


    if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_CursLocks') )  )
      CursLocksExists = 1;
    
    if ( CursLocksExists == 0) {
      $('#CursLocks_statistics').hide();
      $('#CursLocks_statistics_mess').show();
      $('#CursLocks_statistics_mess').html('<p>CursLocks data is not available. The CursLocks collector has not been activated for server '+ARContext.ServerName+', may be for performance reasons. </p>');
      $.extend(asemondata, {'querydata' : {'queryfile' : '', 'query': ''}});
      return;
    }
    else {
      $('#CursLocks_statistics').show();
      $('#CursLocks_statistics_mess').hide();
    }


    $(grid).asemonGrid({
      'querydata': {'queryfile' : '../ASE/sql/sql_curslocks_statistics.php'},
      'datafields': [
           { name: 'bootcount',      type: 'number'},
           { name: 'spid',           type: 'number'},
           { name: 'class',          type: 'string'},
           { name: 'minTsCurs',      type: 'string'},
           { name: 'maxTsCurs',      type: 'string'},
           { name: 'maxOpen',        type: 'number'},
           { name: 'locktype',       type: 'string'},
           { name: 'dbname',         type: 'string'},
           { name: 'name',           type: 'string'},
           { name: 'context',        type: 'string'},
           { name: 'fid',            type: 'number'},
           { name: 'loid',           type: 'number'},
           { name: 'partitionid',    type: 'number'},
           { name: 'page',           type: 'number'},
           { name: 'row',            type: 'number'}
      ],
      'columns': [
           { text: 'bootcount'   , datafield: 'bootcount',    width: 70,   filterable: true, cellsformat: 'd',  cellsalign: 'right'},
           { text: 'spid'        , datafield: 'spid',         width: 100,  filterable: true, cellsformat: 'd',  cellsalign: 'right'},
           { text: 'class'       , datafield: 'class',        width: 150,  filterable: true},
           { text: 'minTsCurs'   , datafield: 'minTsCurs',    width: 150},
           { text: 'maxTsCurs'   , datafield: 'maxTsCurs',    width: 150},
           { text: 'maxOpen'     , datafield: 'maxOpen',      width: 70,   filterable: true, cellsformat: 'd',  cellsalign: 'right'},
           { text: 'locktype'    , datafield: 'locktype',     width: 100,  filterable: true},
           { text: 'dbname'      , datafield: 'dbname',       width: 100,  filterable: true},
           { text: 'name'        , datafield: 'name',         width: 150,  filterable: true},
           { text: 'context'     , datafield: 'context',      width: 100,  filterable: true},
           { text: 'fid'         , datafield: 'fid',          width: 100,  filterable: true, cellsformat: 'd',  cellsalign: 'right'},
           { text: 'loid'        , datafield: 'loid',         width: 100,  filterable: true, cellsformat: 'd',  cellsalign: 'right'},
           { text: 'partitionid' , datafield: 'partitionid',  width: 100,  filterable: true, cellsformat: 'd',  cellsalign: 'right'},
           { text: 'page'        , datafield: 'page',         width: 100,  filterable: true, cellsformat: 'd',  cellsalign: 'right'},
           { text: 'row'         , datafield: 'row',          width: 100,  filterable: true, cellsformat: 'd',  cellsalign: 'right'},
           { text: '', width: 25,  filterable: false}
     ]
    });
   
  }

  onArchCnxOpened = function(){
    $('.ASE-CursLocks').removeClass('nondisplay');
    $('#CursLocks_statistics').asemonGrid('refresh');
  }

</script>
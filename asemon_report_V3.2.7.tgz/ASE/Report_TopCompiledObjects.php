<div class="ASE-Procs">
  <center>
  <div class="maingrid_dashboard">
    <H2>Top procedures order by avg CPU time descending</H2>
    <div id="graphTopCompObj_AvgCPU" class="chart_nots" style="width:998px;height:300px;margin-bottom: 20px;" > </div>
    <div id="graphTopCompObj_TotCPU" class="chart_nots" style="width:998px;height:300px;margin-bottom: 20px;" > </div>


    <div ID="CompObjects_statistics" class="asemongrid singlegrid" ></div>
  </div>
  </center>


<?php
  // This php section is in this DIV to allow display of "echo" messages (for debug)
  // echo "pid=".$pid."<br>";

  $InReport=true;  // Used in getgraphdata_xxxx


  // Check some table/col existance
  $support157=0;
  if (in_array("ClientName",$SRVcatalog[$ServerName."_StmtStat"])) $support157 = 1;
  //echo "support157=".$support157."<br>";
  
  /*
  $StmtSQLHKExists=0;
  if (array_key_exists ($ServerName."_StmtSQLHK",$SRVcatalog)) $StmtSQLHKExists = 1;
  //echo "StmtSQLHKExists=".$StmtSQLHKExists."<br>";
  
  $StmtPlnHKExists=0;
  if (array_key_exists ($ServerName."_StmtPlnHK",$SRVcatalog)) $StmtPlnHKExists = 1;
  //echo "StmtPlnHKExists=".$StmtPlnHKExists."<br>";
  
  $colV16SP03Exist=0;
  if (in_array("QueryOptimizationTime",$SRVcatalog[$ServerName."_StmtStat"])) $colV16SP03Exists = 1;
  //echo "colV16SP03Exists=".$colV16SP03Exists."<br>";

  $SQLHashKeyExists=0;
  if (in_array("SQLHashKey",$SRVcatalog[$ServerName."_StmtStat"])) $SQLHashKeyExists = 1;
  //echo "SQLHashKeyExists=".$SQLHashKeyExists."<br>";

  $supportFieldsAnja=0;
  if ( (in_array("StatementNumber",$SRVcatalog[$ServerName."_StmtStat"])) && (in_array("ProcNestLevel",$SRVcatalog[$ServerName."_StmtStat"])) )
    $supportFieldsAnja = 1;
  //echo "supportFieldsAnja=".$supportFieldsAnja."<br>";
  */


  $supportSQLHashKey=0;   // Not necessary to retreive HashKey for procedures (other than '*s%' )

  
  $rowcount = 50;
  $filter_clause = " and ObjectName not like '*%'";


  // Aggregate comp obj data into  result
  include ("ASE/sql/graph_TOP_CompObj.php");
  //echo "query=".$query."<br>";

  // Get data for first graph
  $result = asemon_query("select ID, avgCPUTime from #result order by ID", $pid);
  include ("COMMON/getgraphdata_nots.php");
  $graphAvgCPUdataJSON = addslashes( json_encode($data));

  // Get data for seconf graph
  $result = asemon_query("select ID, sumCPUTime from #result order by ID", $pid);
  include ("COMMON/getgraphdata_nots.php");
  $graphTotCPUdataJSON = addslashes( json_encode($data));



  // get data for grid
  $sort_clause = "order by avgCPUTime desc";
  $group = "Y";
  include ("ASE/sql/sql_CachedProc_statistics.php");
  //echo "query=".$query."<br>";
  $query_stat_top_compobjects = $query;
  
 
   // Get data for grid

  $total_rows=0;
  $error="";
  $datafieldsTS=array();
  $datafieldsHK=array();
  $SQLTextIsCompressed=false;
  $query = $query_stat_top_compobjects;
  include ("COMMON/getgriddata_for_dashboard.php");
  // use addslashes to escape \ chars like \n in strings
  $griddataJSON = addslashes( json_encode($data));
  
?>







</div>

<script type="text/javascript">

  var SRVcatalog = JSON.parse('<?php echo $SRVcatalogJSON     ?>');


  var height =    $('#page-content').innerHeight() - 55;
 // var colors = ['#2f7ed8', '#8bbc21', '#0d233a', '#910000', '#1aadce', 
 //  '#492970', '#f28f43', '#77a1e5', '#c42525', '#a6c96a'];
  var colors = [
      'rgb(135,206,235)',
      'rgb(50,205,50)',
      'rgb(186,85,211)',
      'rgb(240,128,128)',
      'rgb(70,130,180)',
      'rgb(154,205,50)',
      'rgb(64,224,208)',
      'rgb(255,105,180)',
      'rgb(240,230,140)',
      'rgb(210,180,140)',
               ];

  var graphAvgCPUdata = JSON.parse('<?php echo $graphAvgCPUdataJSON     ?>');
  var graphTotCPUdata = JSON.parse('<?php echo $graphTotCPUdataJSON     ?>');



  Highcharts.chart('graphTopCompObj_AvgCPU', {

    title: {
      text: 'Top compiled object per avg CPU'
    },
    colors: colors,
    tableName : 'StmtStat',
    chart: {
        type: 'column',
        spacingLeft: 50,
    },
    legend: {
      enabled: false
    },
    xAxis: {
      title: {
            enabled: true,
            text: 'Queries',
            style: {
                fontWeight: 'normal'
            }
        },
       categories: graphAvgCPUdata.series[0]
    },
    yAxis: {
      min: 0,
      title: {
            enabled: true,
            text: 'AvgCpuTime (ms)',
            style: {
                fontWeight: 'normal'
            }
      },
      labels: {
            format: '{value} ms'
      }
    },
    plotOptions: {
        series: {
            animation: false
        }
    },
    series: [
      {
        name: 'Avg CPU',
        colorByPoint: true,
        pointPadding: 0,
        groupPadding: 0,
        borderWidth: 0,
        shadow: false,
        data: graphAvgCPUdata.series[1]
      }
    ]
  
  });

  Highcharts.chart('graphTopCompObj_TotCPU', {

    title: {
      text: 'Total CPU per top compiled object'
    },
    colors: colors,
    tableName : 'StmtStat',
    chart: {
        type: 'column',
        spacingLeft: 50,
    },
    legend: {
      enabled: false
    },
    xAxis: {
      title: {
            enabled: true,
            text: 'Queries',
            style: {
                fontWeight: 'normal'
            }
        },
       categories: graphTotCPUdata.series[0]
    },
    yAxis: {
      min: 0,
      title: {
            enabled: true,
            text: 'TotCpuTime (ms)',
            style: {
                fontWeight: 'normal'
            }
      },
      labels: {
            format: '{value} ms'
      }
    },
    plotOptions: {
        series: {
            animation: false
        }
    },
    series: [
      {
        name: 'Avg CPU',
        colorByPoint: true,
        pointPadding: 0,
        groupPadding: 0,
        borderWidth: 0,
        shadow: false,
        data: graphTotCPUdata.series[1]
      }
    ]
  
  });




  var griddata = JSON.parse('<?php echo $griddataJSON     ?>');

  var rownumberrenderer = function (row, columnfield, value, defaulthtml, columnproperties, rowdata) {
        var element = $(defaulthtml);
        //element.css({ 'background-color': colors [row], 'width': '100%', 'height': '100%', 'margin': '0px', 'padding' : '4px' , 'font-weight': '900'});
        element.css({ 'background-color': colors [row], 'width': '100%', 'height': '100%', 'margin': '0px', 'padding' : '4px' , 'font-weight': '900'});
        element[0].innerHTML = "<div>" + (row + 1) + "</div>";
        return element[0].outerHTML;
  }

  var colorcell = function (row, columnfield, value, defaulthtml, columnproperties, rowdata) {
        var element = $(defaulthtml);
        element.css({ 'background-color': colors [8], 'width': '100%', 'height': '100%', 'margin': '0px', 'padding' : '4px' });
        return element[0].outerHTML;
  }


  $('#CompObjects_statistics').asemonGridReport({
    'title' : 'TOP Compiled Objects',
    'width' : '998px',
    'height' : height,
    'editable': false,
    'localdata': griddata.Rows,
    'rowsheight': 18,
    'datafields': [
           { name: 'RowIndex',         type: 'number'},
           { name: 'DBName',               type: 'string'},
           { name: 'ObjectName',           type: 'string'},
           { name: 'ObjectType',           type: 'string'},
           { name: 'sumExecutionCount',         type: 'number'},
           { name: 'sumCPUTime',         type: 'number'},
           { name: 'avgCPUTime',         type: 'number'},
           { name: 'sumWaitTime',        type: 'number'},
           { name: 'avgWaitTime',        type: 'number'},
           { name: 'MaxMemUsageKB',      type: 'number'},
           { name: 'sumPhysicalReads',   type: 'number'},
           { name: 'avgPhysicalReads',   type: 'number'},
           { name: 'sumLogicalReads',    type: 'number'},
           { name: 'avgLogicalReads',    type: 'number'},
           ],
    'columns': [
           { text: '#',              datafield: 'RowIndex',          width: 30,  cellsrenderer: rownumberrenderer },
           { text: 'DBName',         datafield: 'DBName',            width: 87, },
           { text: 'Name',           datafield: 'ObjectName',        width: 180, },
           { text: 'Type',           datafield: 'ObjectType',        width: 90, },
           { text: 'NbExec',         datafield: 'sumExecutionCount', width: 80,  cellsformat: 'd', cellsalign: 'right' },
           { text: 'SumCpu_ms',      datafield: 'sumCPUTime',        width: 85,  cellsformat: 'd', cellsalign: 'right' },
           { text: 'AvgCpu_ms',      datafield: 'avgCPUTime',        width: 85,  cellsformat: 'd2', cellsalign: 'right', cellsrenderer: colorcell},
           { text: 'SumLReads',      datafield: 'sumLogicalReads',   width: 100,  cellsformat: 'd0', cellsalign: 'right'},
           { text: 'AvgLReads',      datafield: 'avgLogicalReads',   width: 100,  cellsformat: 'd2', cellsalign: 'right'},
           { text: 'SumPReads',      datafield: 'sumPhysicalReads',  width: 80,  cellsformat: 'd0', cellsalign: 'right'},
           { text: 'AvgPReads',      datafield: 'avgPhysicalReads',  width: 80,  cellsformat: 'd2', cellsalign: 'right'},
          // { text: 'MaxMemKB',       datafield: 'MaxMemUsageKB',     width: 80,  cellsformat: 'd0', cellsalign: 'right'},
           ]
  });
  



</script>
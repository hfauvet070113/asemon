
<center>
<div class="">

  <h1> Top objects in caches  </h1>

<div id="allinfo">
</div>
</center>


<script type="text/javascript">
  
  function render_pool_statistics (CacheID, CacheName) {
    var support157 = 0;
    var v157fields = [];
    var v157cols = [];
    if (existColumn(ARContext.ServerName+'_CachePool', 'LogicalReads')) {
      support157 = 1;
      v157fields = [
                   { name: 'sumLogicalReads',   type: 'number'},
                   { name: 'sumPhysicalWrites', type: 'number'},
                   { name: 'sumAPFReads',       type: 'number'},
                   { name: 'avgAPFPercentage',  type: 'number'},
                   { name: 'avgWashSize',       type: 'number'}
                   ];
      v157cols= [
                { text: 'LogicalReads',   datafield: 'sumLogicalReads',   width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
                { text: 'PhysicalWrites', datafield: 'sumPhysicalWrites', width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
                { text: 'APFReads',       datafield: 'sumAPFReads',       width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
                { text: 'APFPercentage',  datafield: 'avgAPFPercentage',  width: 90, filterable: false, cellsformat: 'd2', filtertype: 'number', cellsalign: 'right'},
                { text: 'WashSize',       datafield: 'avgWashSize',       width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'}
                ];
    }

    $('#allinfo').append('<div id="poolStatistics_'+CacheID+'" class="asemongrid singlegrid" > </div>');
    $('#poolStatistics_'+CacheID).asemonGrid({
    'title' : 'Pool Statistics for cache "'+CacheName+'"',
    'width' : 1200,
    'height' : 400,
    'minimizeheight': true,
    'rowcount': 0,
    'filterable': false,
    'sortable': true,
    'toolbar': false,
    'showaggregates': true,
    'querydata' : {'queryfile' : '../ASE/sql/sql_pool_statistics.php',
                   'support157' : support157,
                   'CacheName': CacheName},
    'datafieldsMapping' : { },
    'datafields': [
     { name: 'CacheName',        type: 'string'},
     { name: 'IOBufferSize',     type: 'number'},
     { name: 'AllocatedKB',      type: 'number'},
     { name: 'sumPagesReads',    type: 'number'},
     { name: 'sumPhysicalReads', type: 'number'},
     { name: 'sumStalls"]',      type: 'number'},
     { name: 'sumBuffersToMRU',  type: 'number'},
     { name: 'sumBuffersToLRU',  type: 'number'},
     { name: 'PhysReads_s',      type: 'number'},
     { name: 'Turnover_s',       type: 'string'}
    ]
    .concat(v157fields),
    
    'columns': [
     { text: 'CacheName    ', datafield: 'CacheName',        width: 240, filterable: false},
     { text: 'IOBufferSize ', datafield: 'IOBufferSize',     width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
     { text: 'AllocatedKB  ', datafield: 'AllocatedKB',      width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
     { text: 'PagesReads   ', datafield: 'sumPagesReads',    width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
     { text: 'PhysicalReads', datafield: 'sumPhysicalReads', width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
     { text: 'Stalls       ', datafield: 'sumStalls"]',      width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
     { text: 'BuffersToMRU ', datafield: 'sumBuffersToMRU',  width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
     { text: 'BuffersToLRU ', datafield: 'sumBuffersToLRU',  width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
     { text: 'PhysReads/s  ', datafield: 'PhysReads_s',      width: 90, filterable: false, cellsformat: 'd2', filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
     { text: 'Turnover_s   ', datafield: 'Turnover_s',       width: 90, filterable: false, cellsalign: 'right'}
    ]
    .concat(v157cols),
    });

  }



var ASM_XHR_refresh_data_caches_stats;


onArchCnxOpened = function(){
  var CacheName;

  var query = 
     "select distinct CacheID, CacheName"
   + " from "+ARContext.ServerName+"_CachedObj"
   + " where Timestamp >='"+ARContext.StartTimestamp+"'"
   + " and Timestamp <='"+ARContext.EndTimestamp+"'"
   + " order by CacheID";

  $('#allinfo').empty();

  var data = {ARContextJSON: JSON.stringify(ARContext), 'query' : query};

  if (ASM_XHR_refresh_data_caches_stats != null) {
    ASM_XHR_refresh_data_caches_stats.abort();
    ASM_XHR_refresh_data_caches_stats = null;
  }
  incXHRcnt();
  ASM_XHR_refresh_data_caches_stats = $.post( 'COMMON/simplequery.php', data ).done(function(res) {
    var result = JSON.parse(res);
    if ( checkSQLError(result, 'refresh_data_caches_stats') ) return;
    
    if (result.TotalRows > 0) {
      for (var i = 0; i < result.TotalRows; i++) {
        CacheID = result.Rows[i].CacheID;
        CacheName = result.Rows[i].CacheName;
        $('#allinfo').append('<h2>'+CacheName+'</h2>');

        $('#allinfo').append('<div ID="graphcache_'+CacheID+'" class="mainchart" > </div>'); 

        graph = $('#graphcache_'+CacheID).highcharts();
        if (typeof graph == 'undefined')
          $('#graphcache_'+CacheID).asemonChart({
          title: {
            text: 'Top 5 objects in "'+CacheName+'"'
          },
          queryFile : '../ASE/sql/graphCachedObj_TOPperCache.php',
          data: {
            CacheName: CacheName
          },
          tableName : 'CachedObj',
          chart: {
              type: 'column'
          },
          series: [
            {name: 'CachedMB_0'},
            {name: 'CachedMB_1'},
            {name: 'CachedMB_2'},
            {name: 'CachedMB_3'},
            {name: 'CachedMB_4'}
          ],
          plotOptions: {
            series: {stacking: 'normal'}
          },
          legend: {
             enabled: true
            },
          yAxis: {
                  minRange: 0.5,
                  min : 0  ,
                  reversedStacks: false,
                  title: {text: 'Obj. size (Mb)'}
            }
        
          });
        $('#graphcache_'+CacheID).asemonChart('refresh', threadDelays);
        render_pool_statistics(CacheID, CacheName);
      }
    }
    else {
      $('#allinfo').hide();
    }
  })
  .fail(function(data) {
    if (data.statusText == 'abort')
      return;
    alert( "error in refresh_data_caches_stats()" );
      $('#allinfo').hide();
  })
  .always(function() {
    decXHRcnt();
  });
}
</script>


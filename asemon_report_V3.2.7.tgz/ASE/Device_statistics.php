<div class="ASE-Devices nondisplay">
  <center>
  <div class="maingrid">
    <div ID="devstats" class="asemongrid singlegrid" ></div>
  </div>
  </center>
</div>

<script type="text/javascript">
  var height =    $('#page-content').innerHeight() - 55;

  if (typeof detail_type != 'undefined')
    $('.ASE-Devices').removeClass('nondisplay');

  $('#devstats').asemonGrid({
    'title' : 'Device Statistics',
    'width' : '100%',
    'height' : height,
    'rowcount': 20,
    'filterable': true,
    'cursor' : 'pointer',
    'beforeRefresh': function() {refresh_device_statistics (this[0]);},
    'querydata' : {'queryfile' : '',
                   'default_order_by' : 'Device'},
    'datafields': [
     { name: 'Device', type: 'string'}

      ],
    'columns': [
     { text: 'Device',                    datafield: 'Device',                    width: 150, filterable: true}
      ],
    'buttons' : [
       {
        'id': 'GraphALLBTN',
        'text': 'GraphALL',
        'onclick' : function ( ) {
          var selector = $('#devstats')[0];
          var asemondata = jQuery.data( selector , 'asemondata');
          var filterdevice = '%';
          if (typeof asemondata.filters != 'undefined'){
            filterdevice = asemondata.filters[0].filters[0].value;
          }
            
          //var filters = $('#devstats').jqxGrid('getfilterinformation');
          openWindow ("detail_page.php", {ARContextJSON: ARContext, 'displaylevel' : 1, 'detail_type': 'DEVICEDETAIL', 'Device': filterdevice});
        }
       }
    ]

  });

  $("#devstats").on('rowselect', function (event) {
    var rowindex = event.args.rowindex;
    //alert ("row "+rowindex+" selected");

    rowdata = $('#devstats').jqxGrid('getrowdatabyid', rowindex);
    if (typeof rowdata == 'undefined') return 0;

    openWindowFromGrid ("#devstats", "detail_page.php", {ARContextJSON: ARContext, 'displaylevel' : 1, 'detail_type': 'DEVICEDETAIL', 'Device': rowdata.Device});
  });


function refresh_device_statistics (grid) {
  var asemondata = jQuery.data(grid, 'asemondata');
  var rwtime_exists = 0;
  var tmpcols = [];
  var tmpfields = [];
  if ( (ARContext.ServerName!="") &&(  existColumn(ARContext.ServerName+'_DevIO', 'ReadTime') ) && (  existColumn(ARContext.ServerName+'_DevIO', 'WriteTime') ) ){
    rwtime_exists = 1;
    tmpfields = [{ name: 'avgReads_ms', type: 'number'},
                 { name: 'avgWrites_ms', type: 'number'}];
    tmpcols= [{ text: 'avgReads_ms'       , datafield: 'avgReads_ms',    width: 90, filterable: false, cellsformat: 'd2', filtertype: 'number', cellsalign: 'right' },
              { text: 'avgWrites_ms'      , datafield: 'avgWrites_ms',   width: 90, filterable: false, cellsformat: 'd2', filtertype: 'number', cellsalign: 'right' }];
  }
  


  $(grid).asemonGrid({
    'querydata' : {'queryfile' : '../ASE/sql/sql_devices_statistics.php',
                   'rwtime_exists' : rwtime_exists
                  },
    'datafieldsMapping' : { 'Device' : 'LogicalName'},
    'datafields': [
     { name: 'Device', type: 'string'},
     { name: 'PReads', type: 'number'},
     { name: 'AReads', type: 'number'},
     { name: 'PWrites', type: 'number'},
     { name: 'avgserv_ms', type: 'number'},
     { name: 'DevSemaphoreContentionPCT', type: 'number'}
    ]
    .concat(tmpfields),

    'columns': [
     { text: 'Device',                    datafield: 'Device',                    width: 150, filterable: true},
     { text: 'PReads',                    datafield: 'PReads',                    width: 90, filterable: false, cellsformat: 'd', filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
     { text: 'AReads',                    datafield: 'AReads',                    width: 90, filterable: false, cellsformat: 'd', filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
     { text: 'PWrites',                   datafield: 'PWrites',                   width: 90, filterable: false, cellsformat: 'd', filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
     { text: 'avgserv_ms',                datafield: 'avgserv_ms',                width: 90, filterable: false, cellsformat: 'd2', filtertype: 'number', cellsalign: 'right'},
     { text: 'DevSemaphoreContentionPCT', datafield: 'DevSemaphoreContentionPCT', width: 90, filterable: false, cellsformat: 'd2', filtertype: 'number', cellsalign: 'right' }
    ]
    .concat(tmpcols)
    .concat(
    [
         { text: '', width: 25,  filterable: false}
    ])
  });


}

  onArchCnxOpened = function(){
    $('.ASE-Devices').removeClass('nondisplay');
    $('#devstats').asemonGrid('refresh');
  }

</script>
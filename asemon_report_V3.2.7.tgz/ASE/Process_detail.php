<?php
    if (isset($Timestamp) && isset($KPID)) {
          // we come from Locks_list page
          include ("COMMON/connectArchiveServer.php");
          $query = "select Loggedindatetime=convert(varchar,max(Loggedindatetime),109) from ".$ServerName."_Cnx where Loggedindatetime<='".$Timestamp."' and Spid=".$Spid." and Kpid=".$KPID;
          //echo $query;
          $result = asemon_query($query,$pid);
          $row = asemon_fetch_assoc($result);
          $Loggedindatetime = $row['Loggedindatetime'];
    }
    else
      if (!isset($Loggedindatetime) || ($Loggedindatetime == "")) {
          //echo "no loggedindatetime";
          // search loggedindatetime of this spid
          include ("COMMON/connectArchiveServer.php");
          $query = "select Loggedindatetime=convert(varchar,max(Loggedindatetime),109), TsDiff=datediff(ss,'".$StartTimestamp."', '".$EndTimestamp."') from ".$ServerName."_Cnx where Loggedindatetime<='".$StartTimestamp."' and Spid=".$Spid;
          //echo $query;
          $result = asemon_query($query,$pid);
          $row = asemon_fetch_assoc($result);
          $Loggedindatetime = $row['Loggedindatetime'];
          $TsDiff=$row['TsDiff'];
          /*
          if ($TsDiff < 60) {
              $result = asemon_query("select EndTimestamp=convert(varchar,dateadd(ss,60,'".$StartTimestamp."'),109)",$pid);
              $row = asemon_fetch_assoc($result);
              $EndTimestamp= $row['EndTimestamp'];
              //echo $EndTimestamp;
          }
          */
      }
?>
<script type="text/javascript" src="js/shCore.js"></script>
<script type="text/javascript" src="js/shBrushSql.js"></script>

<center>

  <h1> Detail for Process SPID = <?php echo $Spid ?>, connected at '<?php echo $Loggedindatetime ?>' </h1>

<div>

    <div class="boxinmain detailbox" style="max-width:1200px";>
      <div class="statTitle" ><strong>Process Statistics</strong></div>
      <div id="processStats" class="boxcontent"></div>
    </div>
  
  <div id="allinfo" >
    <div id="indic_graphsDIV" ></div>
  
    <div id="graphIOcnx" class="mainchart" > </div>
    <div id="graphNetcnx" class="mainchart" > </div>
    <div id="graphTmpPages_cnx" class="mainchart" > </div>
    <div id="graphLocksHeld_cnx" class="mainchart" > </div>
    <div id="graphPCache_cnx" class="mainchart" > </div>
    
  
    <div ID="Statements_statisticsDIV" class="detailbox">
      <div ID="Statements_statistics"></div>
    </div>
  
    <div class="detailbox">
      <div ID="Procedures_statistics"></div>
    </div>
  
    <div id="graphWaits_cnx" class="mainchart" > </div>
    <div ID="Waits_statisticsDIV" class="detailbox" style="max-width:1200px";>
      <div ID="Waits_statistics"></div>
    </div>
  
  </div>
  <div id="messageDIV" style="display:none;">
    No data for this time range
  </div>
</div>
</center>


<script type="text/javascript">

var Loggedindatetime = "<?php echo $Loggedindatetime ?>"; 
var Spid = <?php echo $Spid ?>;
var starttm = "<?php if (isset($starttm)) echo $starttm; else echo ''; ?>";

var queryrangesel = "select Ts=convert(varchar,ListTimestamp.Timestamp,109), LogicalReads" 
                  + " from (select distinct Timestamp from "+ARContext.ServerName+"_CnxActiv" 
                  + "      where Timestamp >= dateadd(ss,-1,'"+Loggedindatetime+"')"
                  + "        and Timestamp <= (select max(Timestamp) from "+ARContext.ServerName+"_CnxActiv where Loggedindatetime between dateadd(ss,-1,'"+Loggedindatetime+"') and dateadd(ss,+1,'"+Loggedindatetime+"') and Spid="+Spid+")"
                  + "      ) ListTimestamp"
                  + "   left outer join "+ARContext.ServerName+"_CnxActiv B on ListTimestamp.Timestamp = B.Timestamp and Loggedindatetime between dateadd(ss,-1,'"+Loggedindatetime+"') and dateadd(ss,+1,'"+Loggedindatetime+"')"
                  + "   and B.Spid="+Spid
                  + "   where ListTimestamp.Timestamp between '?STARTTIMESTAMP?' and '?ENDTIMESTAMP?'"
                  + " order by ListTimestamp.Timestamp"; 

var dt_Loggedindatetime = new Date(Loggedindatetime);
var dt_StartTimestamp = new Date(getDateFromDFormat(ARContext.StartTimestamp));
if ( dt_StartTimestamp < dt_Loggedindatetime )
  ARContext.StartTimestamp = Date.Format( Loggedindatetime , genDFormatOut()); 


/* next instructions for range selector */
var adjustTimestampWithRangeSel = 1;
var d1 =  getDateFromDFormat(ARContext.StartTimestamp);
var d2 =  getDateFromDFormat(ARContext.EndTimestamp);
ARContext.savStartRangeSel=getDateLocal_intvalue(d1);
ARContext.savEndRangeSel=getDateLocal_intvalue(d2);

var dbid_tmp_pages_exists = 0;
var sel_tempdb_clause = "";
var grp_tempdb_clause = "";

var StmtStatExists = 0;
var CnxWaitsExists = 0;
var support157 = 0;

var Kpid;
var CPUTime;

var colV157SP130Exists;
var sel_colV157SP130_clause = "";

var colV16SP03Exists = 0;
var sel_colV16SP03_clause = "";

var dyn_graphs = [];
dyn_graphs["LogicalReads"] = {rate: 1};

var ASM_XHR_refresh_processStats;

var supportFieldsAnja = 0;
var StmtPlnHKExists = 0;

var colV16SP04Exists = 0;
var sel_colV16SP04_clause = "";


function refresh_processStats () {


  var query = 
     "select                "
   + " C.Loggedindatetime,  "
   + " C.Kpid,              "
   + " C.Spid,              "
   + " UserName,            "
   + " program_name,        "
   + " DBName,              "
   + " execlass,            "
   + " ipaddr,              "
   + " hostname,            "
   + " hostprocess,         "
   + " clientname,          "
   + " clienthostname,      "
   + " clientapplname,      "
   + " CPUTime=sum(CPUTime),"
   + " WaitTime=max(WaitTime)-min(WaitTime),             "
   + " LogicalReads=sum(convert(float,LogicalReads)),    "
   + " PhysicalReads=sum(convert(float,PhysicalReads)),  "
   + " PagesRead=sum(convert(float,PagesRead)),          "
   + " PhysicalWrites=sum(convert(float,PhysicalWrites)),"
   + " PagesWritten=sum(convert(float,PagesWritten)),    "
   + " ScanPgs=sum(convert(float,ScanPgs)),              "
   + " IdxPgs=sum(convert(float,IdxPgs)),                "
   + " TmpTbl=sum(TmpTbl),                               "
   + " UlcBytWrite=sum(convert(float,UlcBytWrite)),      "
   + " UlcFlush=sum(UlcFlush),                           "
   + " ULCFlushFull=sum(ULCFlushFull),                   "
   + " Transactions=sum(Transactions),                   "
   + " Commits=sum(Commits),                             "
   + " Rollbacks=sum(Rollbacks),                         "
   + " PacketsSent=sum(PacketsSent),                     "
   + " PacketsReceived=sum(PacketsReceived),             "
   + " BytesSent=sum(convert(float,BytesSent)),          "
   + " BytesReceived=sum(convert(float,BytesReceived)),  "
   + " MaxLocksHeld=max(LocksHeld),                      "
   + " MaxMemusageKB=max(memusage)*2                     "
   +   sel_tempdb_clause
   +   sel_colV157SP130_clause
   +   sel_colV16SP03_clause
   +   sel_colV16SP04_clause
   + " from "+ARContext.ServerName+"_Cnx C, "+ARContext.ServerName+"_CnxActiv A"
   + " where C.Spid="+Spid
   + " and C.Loggedindatetime between dateadd(ss,-1,'"+Loggedindatetime+"') and dateadd(ss,+1,'"+Loggedindatetime+"') /* added between because IQ has more precision on timestamps */"
   + " and C.Loggedindatetime=A.Loggedindatetime         "
   + " and C.Spid=A.Spid                                 "
   + " and C.Kpid=A.Kpid                                 "
   + " and Timestamp >= '"+ARContext.StartTimestamp+"'   "
   + " and Timestamp <= '"+ARContext.EndTimestamp+"'    " 
   + "group by            "
   + " C.Loggedindatetime,"
   + " C.Kpid,            "
   + " C.Spid,            "
   + " UserName,          "
   + " program_name,      "
   + " DBName,            "
   + " execlass,          "
   + " ipaddr,            "
   + " hostname,          "
   + " hostprocess,       "
   + " clientname,        "
   + " clienthostname,    "
   + " clientapplname     "
   + grp_tempdb_clause;


  var data = {ARContextJSON: JSON.stringify(ARContext), 'query' : query};
  $('#processStats').html('<div> Loading...</div>');
  $('#processStats').addClass('detailboxcontent_loading');

  if (ASM_XHR_refresh_processStats != null) {
    ASM_XHR_refresh_processStats.abort();
    ASM_XHR_refresh_processStats = null;
  }
  incXHRcnt();
  ASM_XHR_refresh_processStats = $.post( 'COMMON/simplequery.php', data ).done(function(res) {
    var result = JSON.parse(res);
    if ( checkSQLError(result, 'refresh_processStats') ) return;
    $('#processStats').removeClass('detailboxcontent_loading');
    
    if (result.TotalRows == 0) {
      $('#allinfo').hide();
      $('#messageDIV').show();
    }
    else {
      $('#allinfo').show();
      $('#messageDIV').hide();

      Kpid = result.Rows[0].Kpid;
      // save CPUTime. Used latter in elasped time graph 
      CPUTime = result.Rows[0].CPUTime;
      render_processStats(result);
      refresh_dynchkbox ();
      if (StmtStatExists == 1)
        render_Statements_statistics();
      else
        $('#Statements_statisticsDIV').hide();

      render_Procedures_statistics();

      if (CnxWaitsExists == 1) {
        render_Waits_statistics();
      }
      else {
        $('#graphWaits_cnx').hide();
        $('#Waits_statisticsDIV').hide();
      }
    }
  })
  .fail(function(data) {
    if (data.statusText == 'abort')
      return;
    alert( "error in refresh_processStats()" );
    $('#processStats').html('<div> Error when loading data </div>');
  })
  .always(function() {
    decXHRcnt();
  });
}


function render_processStats(result) {


  $('#processStats').empty();
  if (result.TotalRows == 0) {
    $('#processStats').addClass('detailboxcontent_nodata');
    $('#processStats').append('<div>No data to display</div>');
  }
  else {
    var Tempdb_idLBL = "";
    var Tempdb_idVAL = "";
    var Tempdb_nameLBL = "";
    var Tempdb_nameVAL = "";
    if ( dbid_tmp_pages_exists == 1) { 
      Tempdb_idLBL =   "Tempdb_id";
      Tempdb_idVAL =   result.Rows[0].tempdbid;
      Tempdb_nameLBL = "Tempdb_name";
      Tempdb_nameVAL = result.Rows[0].tempdbname;
    }
    
    $('#processStats').append('<table id="stmtstatsTable" >');
    $('#processStats').append('<tr> <td class="statTableUpperTitle" colspan="2" style="width:600px;"> Process Info </td> <td class="statTableUpperTitle" colspan="3" style="width:600px"> Process Statistics</td> </tr>');
    $('#processStats').append('<tr> <td class="statTableLabel">Loggedindatetime    </td> <td class="statTable">' + Loggedindatetime              + ' </td> <td><input type="checkbox" ID="CKB_CPUTime"         title="check to graph" onclick="click_chkbox(\'CPUTime\'        , 0 )"> </td><td class="statTableLabel"> CPUTime_ms      </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].CPUTime        ) + ' </td></tr>');
    $('#processStats').append('<tr> <td class="statTableLabel">Kpid                </td> <td class="statTable">' + Kpid                          + ' </td> <td><input type="checkbox" ID="CKB_WaitTime"        title="check to graph" onclick="click_chkbox(\'WaitTime\'       , 0 )"> </td><td class="statTableLabel"> WaitTime_ms     </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].WaitTime       ) + ' </td></tr>');
    $('#processStats').append('<tr> <td class="statTableLabel">Spid                </td> <td class="statTable">' + Spid                          + ' </td> <td><input type="checkbox" ID="CKB_LogicalReads"    title="check to graph" onclick="click_chkbox(\'LogicalReads\'   , 1 )"> </td><td class="statTableLabel"> LogicalReads    </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].LogicalReads   ) + ' </td></tr>');
    $('#processStats').append('<tr> <td class="statTableLabel">UserName            </td> <td class="statTable">' + result.Rows[0].UserName       + ' </td> <td>                                                                                                                            <td class="statTableLabel"> PhysicalReads   </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].PhysicalReads  ) + ' </td></tr>');
    $('#processStats').append('<tr> <td class="statTableLabel">program_name        </td> <td class="statTable">' + result.Rows[0].program_name   + ' </td> <td><input type="checkbox" ID="CKB_PagesRead"       title="check to graph" onclick="click_chkbox(\'PagesRead\'      , 1 )"> </td><td class="statTableLabel"> PagesRead       </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].PagesRead      ) + ' </td></tr>');
    $('#processStats').append('<tr> <td class="statTableLabel">DBName              </td> <td class="statTable">' + result.Rows[0].DBName         + ' </td> <td>                                                                                                                            <td class="statTableLabel"> PhysicalWrites  </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].PhysicalWrites ) + ' </td></tr>');
    $('#processStats').append('<tr> <td class="statTableLabel">execlass            </td> <td class="statTable">' + result.Rows[0].execlass       + ' </td> <td><input type="checkbox" ID="CKB_PagesWritten"    title="check to graph" onclick="click_chkbox(\'PagesWritten\'   , 1 )"> </td><td class="statTableLabel"> PagesWritten    </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].PagesWritten   ) + ' </td></tr>');
    $('#processStats').append('<tr> <td class="statTableLabel">ipaddr              </td> <td class="statTable">' + result.Rows[0].ipaddr         + ' </td> <td><input type="checkbox" ID="CKB_ScanPgs"         title="check to graph" onclick="click_chkbox(\'ScanPgs\'        , 1 )"> </td><td class="statTableLabel"> ScanPgs         </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].ScanPgs        ) + ' </td></tr>');
    $('#processStats').append('<tr> <td class="statTableLabel">hostname            </td> <td class="statTable">' + result.Rows[0].hostname       + ' </td> <td><input type="checkbox" ID="CKB_IdxPgs"          title="check to graph" onclick="click_chkbox(\'IdxPgs\'         , 1 )"> </td><td class="statTableLabel"> IdxPgs          </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].IdxPgs         ) + ' </td></tr>');
    $('#processStats').append('<tr> <td class="statTableLabel">hostprocess         </td> <td class="statTable">' + result.Rows[0].hostprocess    + ' </td> <td><input type="checkbox" ID="CKB_TmpTbl"          title="check to graph" onclick="click_chkbox(\'TmpTbl\'         , 0 )"> </td><td class="statTableLabel"> TmpTbl          </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].TmpTbl         ) + ' </td></tr>');
    $('#processStats').append('<tr> <td class="statTableLabel">clientname          </td> <td class="statTable">' + result.Rows[0].clientname     + ' </td> <td><input type="checkbox" ID="CKB_UlcBytWrite"     title="check to graph" onclick="click_chkbox(\'UlcBytWrite\'    , 1 )"> </td><td class="statTableLabel"> UlcBytWrite     </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].UlcBytWrite    ) + ' </td></tr>');
    $('#processStats').append('<tr> <td class="statTableLabel">clienthostname      </td> <td class="statTable">' + result.Rows[0].clienthostname + ' </td> <td><input type="checkbox" ID="CKB_UlcFlush"        title="check to graph" onclick="click_chkbox(\'UlcFlush\'       , 1 )"> </td><td class="statTableLabel"> UlcFlush        </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].UlcFlush       ) + ' </td></tr>');
    $('#processStats').append('<tr> <td class="statTableLabel">clientapplname      </td> <td class="statTable">' + result.Rows[0].clientapplname + ' </td> <td><input type="checkbox" ID="CKB_ULCFlushFull"    title="check to graph" onclick="click_chkbox(\'ULCFlushFull\'   , 1 )"> </td><td class="statTableLabel"> ULCFlushFull    </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].ULCFlushFull   ) + ' </td></tr>');
    $('#processStats').append('<tr> <td class="statTableLabel">'+ Tempdb_idLBL   +'</td> <td class="statTable">' + Tempdb_idVAL                  + ' </td> <td><input type="checkbox" ID="CKB_Transactions"    title="check to graph" onclick="click_chkbox(\'Transactions\'   , 0 )"> </td><td class="statTableLabel"> Transactions    </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].Transactions   ) + ' </td></tr>');
    $('#processStats').append('<tr> <td class="statTableLabel">'+ Tempdb_nameLBL +'</td> <td class="statTable">' + Tempdb_nameVAL                + ' </td> <td><input type="checkbox" ID="CKB_Commits"         title="check to graph" onclick="click_chkbox(\'Commits\'        , 0 )"> </td><td class="statTableLabel"> Commits         </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].Commits        ) + ' </td></tr>');
    $('#processStats').append('<tr> <td class="statTableLabel">                    </td> <td class="statTable">                                      </td> <td><input type="checkbox" ID="CKB_Rollbacks"       title="check to graph" onclick="click_chkbox(\'Rollbacks\'      , 0 )"> </td><td class="statTableLabel"> Rollbacks       </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].Rollbacks      ) + ' </td></tr>');
    $('#processStats').append('<tr> <td class="statTableLabel">                    </td> <td class="statTable">                                      </td> <td>                                                                                                                            <td class="statTableLabel"> PacketsSent     </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].PacketsSent    ) + ' </td></tr>');
    $('#processStats').append('<tr> <td class="statTableLabel">                    </td> <td class="statTable">                                      </td> <td>                                                                                                                            <td class="statTableLabel"> PacketsReceived </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].PacketsReceived) + ' </td></tr>');
    $('#processStats').append('<tr> <td class="statTableLabel">                    </td> <td class="statTable">                                      </td> <td><input type="checkbox" ID="CKB_BytesSent"       title="check to graph" onclick="click_chkbox(\'BytesSent\'      , 1 )"> </td><td class="statTableLabel"> BytesSent       </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].BytesSent      ) + ' </td></tr>');
    $('#processStats').append('<tr> <td class="statTableLabel">                    </td> <td class="statTable">                                      </td> <td><input type="checkbox" ID="CKB_BytesReceived"   title="check to graph" onclick="click_chkbox(\'BytesReceived\'  , 1 )"> </td><td class="statTableLabel"> BytesReceived   </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].BytesReceived  ) + ' </td></tr>');
    $('#processStats').append('<tr> <td class="statTableLabel">                    </td> <td class="statTable">                                      </td> <td>                                                                                                                       </td><td class="statTableLabel"> MaxLocksHeld    </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].MaxLocksHeld   ) + ' </td></tr>');
    $('#processStats').append('<tr> <td class="statTableLabel">                    </td> <td class="statTable">                                      </td> <td>                                                                                                                       </td><td class="statTableLabel"> MaxMemusageKB   </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].MaxMemusageKB  ) + ' </td></tr>');

    if (dbid_tmp_pages_exists == 1) {
      $('#processStats').append('<tr> <td class="statTableLabel">                  </td> <td class="statTable">                                      </td> <td>                                                                                                                       </td><td class="statTableLabel"> Maxtmp_pages   </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].Maxtmp_pages  ) + ' </td></tr>');
    }

    if (colV157SP130Exists == 1) {
      $('#processStats').append('<tr> <td class="statTableLabel">                    </td> <td class="statTable">                                      </td> <td><input type="checkbox" ID="CKB_HeapMemoryAllocs"     title="check to graph" onclick="click_chkbox(\'HeapMemoryAllocs\'          , 0 )"> </td><td class="statTableLabel"> SumHeapMemoryAllocs     </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].SumHeapMemoryAllocs          ) + ' </td></tr>');
      $('#processStats').append('<tr> <td class="statTableLabel">                    </td> <td class="statTable">                                      </td> <td><input type="checkbox" ID="CKB_HeapMemoryReservedKB" title="check to graph" onclick="click_chkbox(\'HeapMemoryReservedKB\'      , 0 )"> </td><td class="statTableLabel"> MaxHeapMemoryReservedKB </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].MaxHeapMemoryReservedKB      ) + ' </td></tr>');
      $('#processStats').append('<tr> <td class="statTableLabel">                    </td> <td class="statTable">                                      </td> <td><input type="checkbox" ID="CKB_HeapMemoryUsedHWM_KB" title="check to graph" onclick="click_chkbox(\'HeapMemoryUsedHWM_KB\'      , 0 )"> </td><td class="statTableLabel"> MaxHeapMemoryUsedHWM_KB </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].MaxHeapMemoryUsedHWM_KB      ) + ' </td></tr>');
      $('#processStats').append('<tr> <td class="statTableLabel">                    </td> <td class="statTable">                                      </td> <td><input type="checkbox" ID="CKB_IOSize1Page"          title="check to graph" onclick="click_chkbox(\'IOSize1Page\'               , 0 )"> </td><td class="statTableLabel"> SumIOSize1Page          </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].SumIOSize1Page               ) + ' </td></tr>');
      $('#processStats').append('<tr> <td class="statTableLabel">                    </td> <td class="statTable">                                      </td> <td><input type="checkbox" ID="CKB_IOSize2Pages"         title="check to graph" onclick="click_chkbox(\'IOSize2Pages\'              , 0 )"> </td><td class="statTableLabel"> SumIOSize2Pages         </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].SumIOSize2Pages              ) + ' </td></tr>');
      $('#processStats').append('<tr> <td class="statTableLabel">                    </td> <td class="statTable">                                      </td> <td><input type="checkbox" ID="CKB_IOSize4Pages"         title="check to graph" onclick="click_chkbox(\'IOSize4Pages\'              , 0 )"> </td><td class="statTableLabel"> SumIOSize4Pages         </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].SumIOSize4Pages              ) + ' </td></tr>');
      $('#processStats').append('<tr> <td class="statTableLabel">                    </td> <td class="statTable">                                      </td> <td><input type="checkbox" ID="CKB_IOSize8Pages"         title="check to graph" onclick="click_chkbox(\'IOSize8Pages\'              , 0 )"> </td><td class="statTableLabel"> SumIOSize8Pages         </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].SumIOSize8Pages              ) + ' </td></tr>');
      $('#processStats').append('<tr> <td class="statTableLabel">                    </td> <td class="statTable">                                      </td> <td><input type="checkbox" ID="CKB_ULCMaxUsage"          title="check to graph" onclick="click_chkbox(\'ULCMaxUsage\'               , 0 )"> </td><td class="statTableLabel"> MaxULCMaxUsage          </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].MaxULCMaxUsage               ) + ' </td></tr>');
      $('#processStats').append('<tr> <td class="statTableLabel">                    </td> <td class="statTable">                                      </td> <td><input type="checkbox" ID="CKB_WorkTables"           title="check to graph" onclick="click_chkbox(\'WorkTables\'                , 0 )"> </td><td class="statTableLabel"> SumWorkTables           </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].SumWorkTables                ) + ' </td></tr>');
    }
    if (colV16SP03Exists == 1) {
      $('#processStats').append('<tr> <td class="statTableLabel">                    </td> <td class="statTable">                                      </td> <td><input type="checkbox" ID="CKB_QueryOptimizationTime"     title="check to graph" onclick="click_chkbox(\'QueryOptimizationTime\', 0 )"> </td><td class="statTableLabel"> QueryOptimizationTime     </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].sumQueryOptimizationTime          ) + ' </td></tr>');
    }

    if (colV16SP04Exists == 1) {
      $('#processStats').append('<tr> <td class="statTableLabel">                    </td> <td class="statTable">                                      </td> <td>                                                                                                                                         </td><td class="statTableLabel"> prepared_stmt_count     </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].prepared_stmt_count          ) + ' </td></tr>');
      $('#processStats').append('<tr> <td class="statTableLabel">                    </td> <td class="statTable">                                      </td> <td>                                                                                                                                         </td><td class="statTableLabel"> MaxPrepared_stmt_memusageKb     </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].MaxPrepared_stmt_memusageKb          ) + ' </td></tr>');
    }

    $('#processStats').append('</table>');

  }
}

function click_chkbox (indic, rate) {
  if ( ( typeof dyn_graphs[indic] == 'undefined') || (dyn_graphs[indic] == 0) )
    setChkBox (indic, rate);
  else
    unsetChkBox (indic);
}

function setChkBox (indic, rate) {
  dyn_graphs[indic] = {rate: rate};
  display_graph(indic, rate);
}

function unsetChkBox (indic) {
  dyn_graphs[indic] = "";
  hide_graph(indic);
}

function refresh_dyngraphs () {

  for (var key in dyn_graphs) {
    if (dyn_graphs[key] != ""){
      $('#CKB_'+key).prop('checked', true);
      display_graph(key, dyn_graphs[key].rate);
    }
  }
}

function refresh_dynchkbox () {

  for (var key in dyn_graphs) {
    if (dyn_graphs[key] != ""){
      $('#CKB_'+key).prop('checked', true);
    }
  }
}

  function render_Statements_statistics () {
    var cols = [];
    var fields = [];
    var cols157 = [];
    var fields157 = [];

    fields = [
           { name: 'stat_StmtID',   type: 'number'},
           { name: 'Debut',         type: 'string'},
           { name: 'Elapsed_s',     type: 'number'},
           { name: 'SPID',          type: 'number'},
           { name: 'DBID',          type: 'number'},
           { name: 'Application',   type: 'string'},
           { name: 'ClientHost',    type: 'string'},
           { name: 'ProcName',      type: 'string'},
           { name: 'LineNumber',    type: 'number'},
           { name: 'CpuTime',       type: 'number'},
           { name: 'WaitTime',      type: 'number'},
           { name: 'MemUsageKB',    type: 'number'},
           { name: 'PhysicalReads', type: 'number'},
           { name: 'LogicalReads',  type: 'number'},
           { name: 'PagesModified', type: 'number'},
           { name: 'PacketsSent',   type: 'number'},
           { name: 'planOK',        type: 'string'},
           { name: 'PlanID',        type: 'number'},
           { name: 'BatchID',       type: 'number'},
           { name: 'ContextID',     type: 'number'}
    ];
    cols = [
           { text: 'StmtID',      datafield: 'stat_StmtID',   width: 70,  filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number'},
           { text: 'StartTime',   datafield: 'Debut',         width: 170, filterable: false},
           { text: 'Elapsed_s',   datafield: 'Elapsed_s',     width: 70, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number'},
           { text: 'SPID',        datafield: 'SPID',          width: 50, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number'},
           { text: 'DBID',        datafield: 'DBID',          width: 50, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number'},
           { text: 'Application', datafield: 'Application',   width: 90, filterable: true},
           { text: 'ClientHost',  datafield: 'ClientHost',    width: 150, filterable: true},
           { text: 'Proc',        datafield: 'ProcName',      width: 150, filterable: true},
           { text: 'Line',        datafield: 'LineNumber',    width: 70, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number'},
           { text: 'CpuTime_ms',  datafield: 'CpuTime',       width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']},
           { text: 'WaitTime_ms', datafield: 'WaitTime',      width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']},
           { text: 'MemUsageKB',  datafield: 'MemUsageKB',    width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['max']},
           { text: 'PReads',      datafield: 'PhysicalReads', width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']},
           { text: 'LReads',      datafield: 'LogicalReads',  width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']},
           { text: 'PgsModified', datafield: 'PagesModified', width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']},
           { text: 'PktsSent',    datafield: 'PacketsSent',   width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']},
           { text: 'Plan',        datafield: 'planOK',        width: 50, filterable: false},
           { text: 'PlanID',      datafield: 'PlanID',        width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number'},
           { text: 'BatchID',     datafield: 'BatchID',       width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number'},
           { text: 'ContextID',   datafield: 'ContextID',     width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number'}
    ];
    fields157 = [
           { name: 'ClientName',     type: 'string'},
           { name: 'ClientHostName', type: 'string'},
           { name: 'ClientApplName', type: 'string'}
    ];
    cols157= [
           { text: 'ClientName',     datafield: 'ClientName',     width: 90, filterable: true},
           { text: 'ClientHostName', datafield: 'ClientHostName', width: 90, filterable: true},
           { text: 'ClientApplName', datafield: 'ClientApplName', width: 90, filterable: true}
    ];


    if (support157 == 1) {
      fields = fields.concat(fields157);
      cols = cols.concat(cols157);
    }

    grid = $('#Statements_statistics').data('jqxWidget');
    if (typeof grid == 'undefined')
      $('#Statements_statistics').asemonGrid({
        'title' : 'Statements statistics',
        'width' : '100%',
        'height' : 350,
        'rowcount': 200,
        'editable': false,
        'filterable': true,
        'showaggregates': false,
        'querydata': {'queryfile' : '../ASE/sql/sql_stmt_statistics.php', 'default_order_by' : 'stat_StmtID',
                       'support157': support157,
                       'Spid': Spid,
                       'Kpid': Kpid,
                       'StmtPlnHKExists' : StmtPlnHKExists,
                       'colV16SP03Exists': colV16SP03Exists,
                       'supportFieldsAnja': supportFieldsAnja
        },
        'datafieldsMapping': {'Debut': 'StartTime', 'stat_StmtID': 'stat.StmtID'},
        'datafields':fields,
        'columns': cols,
        'datafieldsTS' : []
      
      });
    else
      $('#Statements_statistics').asemonGrid('refresh');

  
    $("#Statements_statistics").on('rowselect', function (event) {
      var rowindex = event.args.rowindex;
      //alert ("row "+rowindex+" selected");
      
      rowdata = $('#Statements_statistics').jqxGrid('getrowdatabyid', rowindex);
      if (typeof rowdata == 'undefined') return 0;
      var StmtID = rowdata.stat_StmtID;
        
        openWindowFromGrid ("#Statements_statistics", "detail_page.php", {ARContextJSON: ARContext, 'displaylevel' : 2, 'detail_type': 'STMT', 'StmtID': StmtID});
    });
  }

  function render_Procedures_statistics () {
    var cols = [];
    var fields = [];

    fields = [
           { name: 'ts',         type: 'string'},
           { name: 'proc_name',  type: 'string'},
           { name: 'linenum',    type: 'number'},
           { name: 'tran_name',  type: 'string'},
           { name: 'LocksHeld',  type: 'number'},
           { name: 'memusageKB', type: 'number'}
    ];
    cols = [
           { text: 'Timestamp    ', datafield: 'ts',         width: 170,  filterable: false},
           { text: 'Procname     ', datafield: 'proc_name',  width: 170, filterable: true},
           { text: 'Linenum      ', datafield: 'linenum',    width: 70, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number'},
           { text: 'tran_name    ', datafield: 'tran_name',  width: 150, filterable: true},
           { text: 'LocksHeld    ', datafield: 'LocksHeld',  width: 100, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number'},
           { text: 'memusage (Kb)', datafield: 'memusageKB', width: 100, filterable: false, cellsformat: 'd', cellsalign: 'right'}
    ];

    grid = $('#Procedures_statistics').data('jqxWidget');
    if (typeof grid == 'undefined')
      $('#Procedures_statistics').asemonGrid({
        'title' : 'Procedures captured for this connection',
        'width' : '100%',
        'height' : 350,
        'rowcount': 200,
        'filterable': true,
        'showaggregates': false,
        'querydata': {'queryfile' : '../ASE/sql/sql_process_procedures_statistics.php', 'default_order_by' : 'Timestamp',
                       'Loggedindatetime': Loggedindatetime,
                       'Spid': Spid,
                       'Kpid': Kpid},
        'datafields':fields,
        'columns': cols
      });
    else
      $('#Procedures_statistics').asemonGrid('refresh');
  
  }

  function after_refresh_Waits_statistics (grid) {
    var rows = $(grid).jqxGrid('getrows');
    if (rows.length != 0) {
        $('#graphWaits_cnx').show();
        render_graphWaits_cnx();
    }
    else
      $('#graphWaits_cnx').hide();

  }

  function render_Waits_statistics() {
    var grid;
    var cols = [];
    var fields = [];

    fields = [
           { name: 'Class',       type: 'string'},
           { name: 'WaitEventID', type: 'number'},
           { name: 'Waits',       type: 'number'},
           { name: 'WaitTime_ms', type: 'number'},
           { name: 'Description', type: 'string'},
           { name: 'avgwaittime', type: 'number'}
    ];
    cols = [
           { text: 'ClassDesc',      datafield: 'Class',       width: 300,  filterable: true},
           { text: 'WaitEventID',    datafield: 'WaitEventID', width: 100,  filterable: true,  cellsformat: 'd', cellsalign: 'right', filtertype: 'number'},
           { text: 'Waits',          datafield: 'Waits',       width: 100,   filterable: false, cellsformat: 'd', cellsalign: 'right'},
           { text: 'WaitTime_ms',    datafield: 'WaitTime_ms', width: 100,  filterable: false, cellsformat: 'd', cellsalign: 'right'},
           { text: 'avgwaittime_ms', datafield: 'avgwaittime', width: 90,   filterable: false, cellsformat: 'd2', cellsalign: 'right'},
           { text: 'Description',      datafield: 'Description', width: 500,  filterable: true}
    ];

    grid = $('#Waits_statistics').data('jqxWidget');
    if (typeof grid == 'undefined')
      $('#Waits_statistics').asemonGrid({
        'title' : 'Process elasped time distribution',
        'width' : '100%',
        'height' : 350,
        'rowcount': '0',
        'filterable': true,
        'showaggregates': false,
        'afterRefresh': function() {after_refresh_Waits_statistics (this);},
        'datafieldsMapping': {'Class': 'C.Description', 'WaitEventID': 'W.WaitEventID', 'Description': 'E.Description'},
        'querydata': {'queryfile' : '../ASE/sql/sql_waits_process_statistics.php', 'default_order_by' : 'WaitTime_ms desc',
                       'Loggedindatetime': Loggedindatetime,
                       'Spid': Spid,
                       'Kpid': Kpid},
        'datafields':fields,
        'columns': cols
      });
    else
      $('#Waits_statistics').asemonGrid('refresh');
  }

  function render_graphWaits_cnx() {
    var graph;
  
    graph = $('#graphWaits_cnx').highcharts();
    if (typeof graph == 'undefined')
      $('#graphWaits_cnx').asemonChart_nots({
      title: {
        text: 'CPU time / Wait time per class of wait events'
      },
      queryFile : '../ASE/sql/graphWaitsPerClassEvents.php',
      data: {
        Loggedindatetime: Loggedindatetime,
        Spid: Spid,
        Kpid: Kpid,
        CPUTime: CPUTime
      },
      tableName : 'CnxWaits',
      chart: {
          type: 'pie',
          marginBottom: 5,
          marginLeft: 5,
          marginRight: 5
      },
      plotOptions: {
        pie: {
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
                format: '{point.name}: {point.percentage:.1f} %',
                style: {"color": "contrast", "fontSize": "11px", "fontWeight": "normal", "textShadow": "0 0 6px contrast, 0 0 3px contrast" }
            },
            size : '60%',
            startAngle: 270
        }
      },
      series: [
        {
          name: 'Time (ms)'
        }
      ],
      pieMD5colors: 0
    
      });
    // refresh CPUTime in graph's data
    graph = $('#graphWaits_cnx').highcharts(); 
    graph.options.data.CPUTime=CPUTime;
    $('#graphWaits_cnx').asemonChart_nots('refresh');
  }

function display_graph(indic, rate) {
  var graph;
  var title_text = indic;
  if (rate==1)
    title_text = indic+" per second";
  
  graph = $('#graph_'+indic).highcharts();
  if (typeof graph == 'undefined') {
    $('#indic_graphsDIV').append('<div ID="graph_'+indic+'" class="mainchart" ></div>');
    $('#graph_'+indic).asemonChart({
      title: {
        text: title_text
      },
      queryFile : '../ASE/sql/graph_CnxIndic.php',
      data: {
        Loggedindatetime: Loggedindatetime,
        Spid: Spid,
        indic: indic,
        rate: rate
      },
      tableName : 'CnxActiv',
      chart: {
          type: 'area'
      },
      plotOptions: {
              series: {
                  pointWidth: 4
              }
          },
      series: [
        {
          name: indic
        }
      ],
      legend: {
         enabled: true
        },
      yAxis: {
              minRange: 1,
              min : 0
        }
      
    });
    graph = $('#graph_'+indic).highcharts();
  }
  $('#graph_'+indic).show();
  $('#graph_'+indic).asemonChart('refresh',threadDelays);

}

function hide_graph(indic) {
  var graph;
  graph = $('#graph_'+indic).highcharts();
  if (typeof graph != 'undefined') {
    $('#graph_'+indic).hide();
    //$('#graph_'+key).asemonChart('destroy');
  }
}



onArchCnxOpened = function(){

  if ( existColumn(ARContext.ServerName+'_Cnx', 'tempdbid') 
    && existColumn(ARContext.ServerName+'_Cnx', 'tempdbname')
    && existColumn(ARContext.ServerName+'_CnxActiv', 'tmp_pages')
     ) {
    dbid_tmp_pages_exists = 1;
    sel_tempdb_clause = ", tempdbid, tempdbname, Maxtmp_pages=max(tmp_pages)";
    grp_tempdb_clause = ", tempdbid, tempdbname";
  }

  if ( existTable(ARContext.ServerName+'_StmtStat' ) ) {
    StmtStatExists = 1;
  }

  if ( existTable(ARContext.ServerName+'_CnxWaits' ) ) {
    CnxWaitsExists = 1;
  }

  if ( (ARContext.ServerName!="") && ( existColumn(ARContext.ServerName+'_StmtStat', 'ClientName') )  ) {
    support157 = 1;
  }

  if ( (ARContext.ServerName!="") &&( existColumn(ARContext.ServerName+'_CnxActiv', 'HeapMemoryAllocs') )){
    colV157SP130Exists = 1;

    if ( (ARContext.ServerName!="") && ( existColumn(ARContext.ServerName+'_StmtStat', 'StatementNumber') ) && ( existColumn(ARContext.ServerName+'_StmtStat', 'ProcNestLevel') ) ) {
      supportFieldsAnja = 1;
    }
    
    if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_StmtPlnHK') )  ) {
      StmtPlnHKExists = 1;
    }
    
    
      sel_colV157SP130_clause =
        ",SumHeapMemoryAllocs     = sum(1.*HeapMemoryAllocs    )"
      + ",MaxHeapMemoryReservedKB = max(   HeapMemoryReservedKB)"
      + ",MaxHeapMemoryUsedHWM_KB = max(   HeapMemoryUsedHWM_KB)"
      + ",SumIOSize1Page          = sum(1.*IOSize1Page         )"
      + ",SumIOSize2Pages         = sum(1.*IOSize2Pages        )"
      + ",SumIOSize4Pages         = sum(1.*IOSize4Pages        )"
      + ",SumIOSize8Pages         = sum(1.*IOSize8Pages        )"
      + ",MaxULCMaxUsage          = max(   ULCMaxUsage         )"
      + ",SumWorkTables           = sum(1.*WorkTables          )";
    
  }
  if ( (ARContext.ServerName!="") &&( existColumn(ARContext.ServerName+'_CnxActiv', 'QueryOptimizationTime') )){
    colV16SP03Exists = 1;
  
    sel_colV16SP03_clause =
      ",sumQueryOptimizationTime     = sum(1.*QueryOptimizationTime    )";
  }

  if ( (ARContext.ServerName!="") &&( existColumn(ARContext.ServerName+'_CnxActiv', 'prepared_stmt_count') )  ){
      colV16SP04Exists = 1;
      sel_colV16SP04_clause =
         ",prepared_stmt_count          = sum(1.*prepared_stmt_count  )"
       + ",MaxPrepared_stmt_memusageKb  = max(prepared_stmt_memusage)*2";
  }

  refresh_processStats();
  refresh_dyngraphs();



  var graph;


  graph = $('#graphIOcnx').highcharts();
  if (typeof graph == 'undefined')
    $('#graphIOcnx').asemonChart({
    title: {
      text: 'Process Physical I/O per second'
    },
    queryFile : '../ASE/sql/graph_IOcnx.php',
    data: {
      Loggedindatetime: Loggedindatetime,
      Spid: Spid
    },
    tableName : 'CnxActiv',
    plotOptions: {
            series: {
                stacking: 'area'
            }
        },
    chart: {
        type: 'area'
    },
    series: [
      {
        name: 'PhysicalReads'
      },
      {
        name: 'PhysicalWrites'
      }
    ],
    legend: {
       enabled: true
      },
    yAxis: {
            minRange: 1,
            min : 0
      }
  
    });
  $('#graphIOcnx').asemonChart('refresh',threadDelays);

  graph = $('#graphNetcnx').highcharts();
  if (typeof graph == 'undefined')
    $('#graphNetcnx').asemonChart({
    title: {
      text: 'Network bytes I/O per second'
    },
    queryFile : '../ASE/sql/graph_Netcnx.php',
    data: {
      Loggedindatetime: Loggedindatetime,
      Spid: Spid
    },
    tableName : 'CnxActiv',
    plotOptions: {
            series: {
                stacking: 'area'
            }
        },
    chart: {
        type: 'area'
    },
    series: [
      {
        name: 'BytesSent'
      },
      {
        name: 'BytesReceived'
      }
    ],
    legend: {
       enabled: true
      },
    yAxis: {
            minRange: 1,
            min : 0
      }
  
    });
  $('#graphNetcnx').asemonChart('refresh',threadDelays);


  if ( dbid_tmp_pages_exists == 1 ) {

    graph = $('#graphTmpPages_cnx').highcharts();
    if (typeof graph == 'undefined')
      $('#graphTmpPages_cnx').asemonChart({
      title: {
        text: 'Tempdb pages'
      },
      queryFile : '../ASE/sql/graph_TmpPages_cnx.php',
      data: {
        Loggedindatetime: Loggedindatetime,
        Spid: Spid
      },
      tableName : 'CnxActiv',
      chart: {
          type: 'area'
      },
      series: [
        {
          name: 'Value'
        }
      ],
      legend: {
         enabled: false
        },
      yAxis: {
            minRange: 1,
            min : 0
      }

    
      });
    $('#graphTmpPages_cnx').asemonChart('refresh',threadDelays);
  }
  else
    $('#graphTmpPages_cnx').hide();

  graph = $('#graphLocksHeld_cnx').highcharts();
  if (typeof graph == 'undefined')
    $('#graphLocksHeld_cnx').asemonChart({
    title: {
      text: 'Locks held'
    },
    queryFile : '../ASE/sql/graph_LocksHeld_cnx.php',
    data: {
      Loggedindatetime: Loggedindatetime,
      Spid: Spid
    },
    tableName : 'CnxActiv',
    chart: {
        type: 'area'
    },
    series: [
      {
        name: 'LocksHeld'
      }
    ],
    legend: {
       enabled: true
      },
    yAxis: {
            minRange: 1,
            min : 0
      }
  
    });
  $('#graphLocksHeld_cnx').asemonChart('refresh',threadDelays);

  graph = $('#graphPCache_cnx').highcharts();
  if (typeof graph == 'undefined')
    $('#graphPCache_cnx').asemonChart({
    title: {
      text: 'Procedure cache pages (2K pages)'
    },
    queryFile : '../ASE/sql/graph_PCachecnx.php',
    data: {
      Loggedindatetime: Loggedindatetime,
      Spid: Spid,
      colV16SP04Exists: colV16SP04Exists
    },
    tableName : 'CnxActiv',
    series: [
      {
        name: 'memusage',
        type: 'area'
      },
      {
        name: 'prepared_stmt_memusage',
        type: 'line'
      }
    ],
    legend: {
       enabled: true
      },
    yAxis: {
            minRange: 1,
            min : 0
      }
  
    });
  $('#graphPCache_cnx').asemonChart('refresh',threadDelays);







};

  
</script>


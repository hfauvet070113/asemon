
<script type="text/javascript" src="js/shCore.js"></script>
<script type="text/javascript" src="js/shBrushSql.js"></script>

<center>
<div class="">
  <h1> Detail for cached statement SSQLID : <?php echo $SSQLID; ?> </h1>

  <div id="CSstatsFromStmtsDIV" class="boxinmain detailbox" style="max-width:1200px";>
    <div class="statTitle" ><strong>Cached Statement Statistics (from monCachedStatement)</strong></div>
    <div id="CSstatsFromStmts" class="boxcontent">
    </div>
  </div>

  <div id="stmtSQLDIV" class="boxinmain detailbox" style="max-width:1200px";>
    <div class="statTitle" ><strong>SQL</strong></div>
    <div class="statLowerTitle" ><div style="margin-left: 10px;" align="left" ><input id="FormatSQLBTN" value="FormatSQL" type="button" class="btn btn-primary btn-xs" /></div></div>
    <div id="stmtSQL" class="boxcontent">
    </div>
  </div>

  <div id="stmtPLANDIV" class="boxinmain detailbox" style="max-width:1200px";>
    <div class="statTitle" ><strong>Plan</strong></div>
    <div id="stmtPLAN" class="boxcontent detailboxcontent_nodata">
    </div>
  </div>

  <div id="CSstatsFromProcsDIV" class="boxinmain detailbox" style="max-width:1200px";>
    <div class="statTitle" ><strong>Cached Statement Statistics (from monCachedProcedures)</strong></div>
    <div id="CSstatsFromProcs" class="boxcontent">
    </div>
  </div>


  <div id="XMLPlans" style="max-width:1200px";> 
  </div>

</div>
</center>


<script type="text/javascript">

<?php if (!isset($SSQLID)) $SSQLID = '""'; ?>
<?php if (!isset($bootcount)) $bootcount = '""'; ?>
<?php if (!isset($PlanID)) $PlanID = '""'; ?>
<?php if (!isset($CompileDate)) $CompileDate = ''; ?>
<?php if (!isset($ProcName)) $ProcName = ''; ?>

var SSQLID = <?php echo $SSQLID ?>;
var bootcount = <?php echo $bootcount ?>; 
var CompileDate = <?php echo '"'.$CompileDate.'"' ?>; 
var PlanID = <?php echo $PlanID ?>; 
var ProcName = <?php echo '"'.$ProcName.'"' ?>; 
var support157 = 0;
var sel_157_cols = "";
var grp_157_cols = "";
var support157ESD2 = 0;
var support157SP100 = 0;
var avgPIO = ", AvgPIO=avg(1.*AvgPIO)";
var avgLIO = ", AvgLIO=avg(1.*AvgLIO)";
var avgCpuTime = ", AvgCpuTime=avg(1.*AvgCpuTime)";
var avgElapsedTime = ", AvgElapsedTime=avg(1.*AvgElapsedTime)";
var SQLtableExists = 0;
var PrctableExists = 0;
var PrctableV157 = 0;
var CachedSTMExists = 0;
var CachedXMLExists = 0;
var Hashkey;
var CachedDate;
var resultXML;
var result_cachedstmtSQL;

var ASM_XHR_refresh_CSstatsFromStmts;
var ASM_XHR_refresh_CSstatsFromProcs;
var ASM_XHR_refresh_cachedstmtSQL;
var ASM_XHR_refresh_cachedstmtPLAN;
var ASM_XHR_refresh_stmtXML;

function refresh_CSstatsFromStmts () {


  var data = {ARContextJSON: JSON.stringify(ARContext), 'bootcount' : bootcount, 'avgPIO': avgPIO, 'avgLIO': avgLIO, 
              'avgCpuTime': avgCpuTime, 'avgElapsedTime': avgElapsedTime, 'sel_157_cols': sel_157_cols, 'grp_157_cols': grp_157_cols,
              'SSQLID': SSQLID,
              'datafieldsTSJSON' : JSON.stringify(['CachedDt', 'LastRecompiledDt', 'LastUsedDt'])};

  $('#CSstatsFromStmts').html('<div> Loading...</div>');
  $('#CSstatsFromStmts').addClass('detailboxcontent_loading');

  if (ASM_XHR_refresh_CSstatsFromStmts != null) {
    ASM_XHR_refresh_CSstatsFromStmts.abort();
    ASM_XHR_refresh_CSstatsFromStmts = null;
  }
  incXHRcnt();
  ASM_XHR_refresh_CSstatsFromStmts = $.post( 'ASE/sql/sql_CachedStmtstatsFromStmts.php', data ).done(function(res) {

    var result = JSON.parse(res);
    if ( checkSQLError(result, 'refresh_CSstatsFromStmts') ) return;
    $('#CSstatsFromStmts').removeClass('detailboxcontent_loading');
    if (result.TotalRows == 1) {
      Hashkey=result.row.Hashkey;
      CachedDate=result.row.CachedDt;
      bootcount=result.row.bootcount;
      
      render_CSstatsFromStmts(result);
      
    }
    else {
      //$('#CSstatsFromStmts').html('<div> No data to display</div>');
      //$('#CSstatsFromStmts').addClass('detailboxcontent_nodata');
      $('#CSstatsFromStmtsDIV').remove();
    }

    if (PrctableV157 == 1) 
      refresh_CSstatsFromProcs();

    if (bootcount != '') {
      refresh_cachedstmtSQL();
      refresh_cachedstmtPLAN(); 
    }
    else {
      $('#stmtSQLDIV').remove();
      $('#stmtPLANDIV').remove();
    }
      
    
    if (CachedXMLExists == 1)
      refresh_stmtXML();
  })
  .fail(function(data) {
    if (data.statusText == 'abort')
      return;
    alert( "error in refresh_CSstatsFromStmts()" );
    $('#CSstatsFromStmts').html('<div> Error when loading data </div>');
  })
  .always(function() {
    decXHRcnt();
  });
}

function refresh_XMLPlan_only () {
  $('#CSstatsFromStmtsDIV').hide();
  $('#stmtSQLDIV').hide();
  $('#stmtPLANDIV').hide();
  $('#CSstatsFromProcsDIV').hide();
  if (CachedXMLExists == 1)
    refresh_stmtXML();
  else
      $('#XMLPlans').html('<div> No captured data for this statement</div>');

}


function render_CSstatsFromStmts(result) {
  var OptimizationGoalLBL = "";
  var OptimizerLevelLBL   = "";
  var OptimizationGoalVAL = "";
  var OptimizerLevelVAL   = "";
  if (support157 == 1) {
    OptimizationGoalLBL = "OptimizationGoal     :";
    OptimizerLevelLBL   = "OptimizerLevel       :";
    OptimizationGoalVAL = result.row.OptimizationGoal;
    OptimizerLevelVAL   = result.row.OptimizerLevel;  
  }

  $('#CSstatsFromStmts').empty();
  $('#CSstatsFromStmts').append('<table id="stmtstatsTable" >');
  $('#CSstatsFromStmts').append('<tr> <td class="statTableUpperTitle" colspan="2" style="width:600px;"> Statement Info</td> <td class="statTableUpperTitle" colspan="2" style="width:600px"> Statement Statistics</td> </tr>');
  $('#CSstatsFromStmts').append('<tr> <td class="statTableLabel">bootcount                : </td> <td class="statTable">' + result.row.bootcount                    + ' </td> <td class="statTableLabel"> UseCount                   : </td> <td class="statTable alignRight"> ' + number_format(result.row.UseCount)                   + ' </td></tr>');
  $('#CSstatsFromStmts').append('<tr> <td class="statTableLabel">SSQLID                   : </td> <td class="statTable">' + SSQLID                                  + ' </td> <td class="statTableLabel"> MinPIO                     : </td> <td class="statTable alignRight"> ' + number_format(result.row.MinPIO)                     + ' </td></tr>');
  $('#CSstatsFromStmts').append('<tr> <td class="statTableLabel">Hashkey                  : </td> <td class="statTable">' + Hashkey                                 + ' </td> <td class="statTableLabel"> MaxPIO                     : </td> <td class="statTable alignRight"> ' + number_format(result.row.MaxPIO)                     + ' </td></tr>');
  $('#CSstatsFromStmts').append('<tr> <td class="statTableLabel">UserID                   : </td> <td class="statTable">' + result.row.UserID                       + ' </td> <td class="statTableLabel"> AvgPIO                     : </td> <td class="statTable alignRight"> ' + number_format(result.row.AvgPIO)                     + ' </td></tr>');
  $('#CSstatsFromStmts').append('<tr> <td class="statTableLabel">SUserID                  : </td> <td class="statTable">' + result.row.SUserID                      + ' </td> <td class="statTableLabel"> MinLIO                     : </td> <td class="statTable alignRight"> ' + number_format(result.row.MinLIO)                     + ' </td></tr>');
  $('#CSstatsFromStmts').append('<tr> <td class="statTableLabel">DBID                     : </td> <td class="statTable">' + result.row.DBID                         + ' </td> <td class="statTableLabel"> MaxLIO                     : </td> <td class="statTable alignRight"> ' + number_format(result.row.MaxLIO)                     + ' </td></tr>');
  $('#CSstatsFromStmts').append('<tr> <td class="statTableLabel">DBName                   : </td> <td class="statTable">' + result.row.DBName                       + ' </td> <td class="statTableLabel"> AvgLIO                     : </td> <td class="statTable alignRight"> ' + number_format(result.row.AvgLIO)                     + ' </td></tr>');
  $('#CSstatsFromStmts').append('<tr> <td class="statTableLabel">CachedDate               : </td> <td class="statTable">' + CachedDate                              + ' </td> <td class="statTableLabel"> MinCpuTime (ms)            : </td> <td class="statTable alignRight"> ' + number_format(result.row.MinCpuTime)                 + ' </td></tr>');
  $('#CSstatsFromStmts').append('<tr> <td class="statTableLabel">LastRecompiledDate       : </td> <td class="statTable">' + result.row.LastRecompiledDt             + ' </td> <td class="statTableLabel"> MaxCpuTime (ms)            : </td> <td class="statTable alignRight"> ' + number_format(result.row.MaxCpuTime)                 + ' </td></tr>');
  $('#CSstatsFromStmts').append('<tr> <td class="statTableLabel">LastUsedDate             : </td> <td class="statTable">' + result.row.LastUsedDt                   + ' </td> <td class="statTableLabel"> AvgCpuTime (ms)            : </td> <td class="statTable alignRight"> ' + number_format(result.row.AvgCpuTime)                 + ' </td></tr>');
  $('#CSstatsFromStmts').append('<tr> <td class="statTableLabel">HasAutoParams            : </td> <td class="statTable">' + result.row.HasAutoParams                + ' </td> <td class="statTableLabel"> MinElapsedTime (ms)        : </td> <td class="statTable alignRight"> ' + number_format(result.row.MinElapsedTime)             + ' </td></tr>');
  $('#CSstatsFromStmts').append('<tr> <td class="statTableLabel">ParallelDegree           : </td> <td class="statTable">' + result.row.ParallelDegree               + ' </td> <td class="statTableLabel"> MaxElapsedTime (ms)        : </td> <td class="statTable alignRight"> ' + number_format(result.row.MaxElapsedTime)             + ' </td></tr>');
  $('#CSstatsFromStmts').append('<tr> <td class="statTableLabel">QuotedIdentifier         : </td> <td class="statTable">' + result.row.QuotedIdentifier             + ' </td> <td class="statTableLabel"> AvgElapsedTime (ms)        : </td> <td class="statTable alignRight"> ' + number_format(result.row.AvgElapsedTime)             + ' </td></tr>');
  $('#CSstatsFromStmts').append('<tr> <td class="statTableLabel">TransactionIsolationLevel: </td> <td class="statTable">' + result.row.TransactionIsolationLevel    + ' </td> <td class="statTableLabel"> MinPlanSizeKB              : </td> <td class="statTable alignRight"> ' + number_format(result.row.MinPlanSizeKB)              + ' </td></tr>');
  $('#CSstatsFromStmts').append('<tr> <td class="statTableLabel">TransactionMode          : </td> <td class="statTable">' + result.row.TransactionMode              + ' </td> <td class="statTableLabel"> MaxPlanSizeKB              : </td> <td class="statTable alignRight"> ' + number_format(result.row.MaxPlanSizeKB)              + ' </td></tr>');
  $('#CSstatsFromStmts').append('<tr> <td class="statTableLabel">SAAuthorization          : </td> <td class="statTable">' + result.row.SAAuthorization              + ' </td> <td class="statTableLabel"> MaxCurrentUsageCount       : </td> <td class="statTable alignRight"> ' + number_format(result.row.MaxCurrentUsageCount)       + ' </td></tr>');
  $('#CSstatsFromStmts').append('<tr> <td class="statTableLabel">SystemCatalogUpdate      : </td> <td class="statTable">' + result.row.SystemCatalogUpdate          + ' </td> <td class="statTableLabel"> MaxUsageCount              : </td> <td class="statTable alignRight"> ' + number_format(result.row.MaxUsageCount)              + ' </td></tr>');
  $('#CSstatsFromStmts').append('<tr> <td class="statTableLabel">StatementSize            : </td> <td class="statTable">' + number_format(result.row.StatementSize) + ' </td> <td class="statTableLabel"> NumRecompilesSchemaChanges : </td> <td class="statTable alignRight"> ' + number_format(result.row.NumRecompilesSchemaChanges) + ' </td></tr>');
  $('#CSstatsFromStmts').append('<tr> <td class="statTableLabel">'+OptimizationGoalLBL    +'</td> <td class="statTable">' + OptimizationGoalVAL                     + ' </td> <td class="statTableLabel"> NumRecompilesPlanFlushes   : </td> <td class="statTable alignRight"> ' + number_format(result.row.NumRecompilesPlanFlushes)   + ' </td></tr>');
  $('#CSstatsFromStmts').append('<tr> <td class="statTableLabel">'+OptimizerLevelLBL      +'</td> <td class="statTable">' + OptimizerLevelVAL                       + ' </td> <td class="statTableLabel"> MetricsCount               : </td> <td class="statTable alignRight"> ' + number_format(result.row.MetricsCount)               + ' </td></tr>');
  
  if (support157ESD2 == 1) {
    $('#CSstatsFromStmts').append('<tr> <td class="statTableLabel"></td> <td class="statTable"> </td> <td class="statTableLabel"> Avg_ScanRows              </td> <td class="statTable alignRight"> '+number_format(result.row.Avg_ScanRows)             +' </td></tr>');
    $('#CSstatsFromStmts').append('<tr> <td class="statTableLabel"></td> <td class="statTable"> </td> <td class="statTableLabel"> Max_ScanRows              </td> <td class="statTable alignRight"> '+number_format(result.row.Max_ScanRows)             +' </td></tr>');
    $('#CSstatsFromStmts').append('<tr> <td class="statTableLabel"></td> <td class="statTable"> </td> <td class="statTableLabel"> Avg_QualifyingReadRows    </td> <td class="statTable alignRight"> '+number_format(result.row.Avg_QualifyingReadRows)   +' </td></tr>');
    $('#CSstatsFromStmts').append('<tr> <td class="statTableLabel"></td> <td class="statTable"> </td> <td class="statTableLabel"> Max_QualifyingReadRows    </td> <td class="statTable alignRight"> '+number_format(result.row.Max_QualifyingReadRows)   +' </td></tr>');
    $('#CSstatsFromStmts').append('<tr> <td class="statTableLabel"></td> <td class="statTable"> </td> <td class="statTableLabel"> Avg_QualifyingWriteRows   </td> <td class="statTable alignRight"> '+number_format(result.row.Avg_QualifyingWriteRows)  +' </td></tr>');
    $('#CSstatsFromStmts').append('<tr> <td class="statTableLabel"></td> <td class="statTable"> </td> <td class="statTableLabel"> Max_QualifyingWriteRows   </td> <td class="statTable alignRight"> '+number_format(result.row.Max_QualifyingWriteRows)  +' </td></tr>');
    $('#CSstatsFromStmts').append('<tr> <td class="statTableLabel"></td> <td class="statTable"> </td> <td class="statTableLabel"> Tot_LockWaits             </td> <td class="statTable alignRight"> '+number_format(result.row.Tot_LockWaits)            +' </td></tr>');
    $('#CSstatsFromStmts').append('<tr> <td class="statTableLabel"></td> <td class="statTable"> </td> <td class="statTableLabel"> Tot_LockWaitTime          </td> <td class="statTable alignRight"> '+number_format(result.row.Tot_LockWaitTime)         +' </td></tr>');
    $('#CSstatsFromStmts').append('<tr> <td class="statTableLabel"></td> <td class="statTable"> </td> <td class="statTableLabel"> Tot_SortCount             </td> <td class="statTable alignRight"> '+number_format(result.row.Tot_SortCount)            +' </td></tr>');
    $('#CSstatsFromStmts').append('<tr> <td class="statTableLabel"></td> <td class="statTable"> </td> <td class="statTableLabel"> Tot_SortSpilledCount      </td> <td class="statTable alignRight"> '+number_format(result.row.Tot_SortSpilledCount)     +' </td></tr>');
    $('#CSstatsFromStmts').append('<tr> <td class="statTableLabel"></td> <td class="statTable"> </td> <td class="statTableLabel"> Tot_SortTime              </td> <td class="statTable alignRight"> '+number_format(result.row.Tot_SortTime)             +' </td></tr>');
    $('#CSstatsFromStmts').append('<tr> <td class="statTableLabel"></td> <td class="statTable"> </td> <td class="statTableLabel"> Max_SortTime              </td> <td class="statTable alignRight"> '+number_format(result.row.Max_SortTime)             +' </td></tr>');
    $('#CSstatsFromStmts').append('<tr> <td class="statTableLabel"></td> <td class="statTable"> </td> <td class="statTableLabel"> Tot_ParallelDegreeReduced </td> <td class="statTable alignRight"> '+number_format(result.row.Tot_ParallelDegreeReduced)+' </td></tr>');
    $('#CSstatsFromStmts').append('<tr> <td class="statTableLabel"></td> <td class="statTable"> </td> <td class="statTableLabel"> Tot_ParallelPlanRanSerial </td> <td class="statTable alignRight"> '+number_format(result.row.Tot_ParallelPlanRanSerial)+' </td></tr>');
    $('#CSstatsFromStmts').append('<tr> <td class="statTableLabel"></td> <td class="statTable"> </td> <td class="statTableLabel"> Tot_WorkerThreadDeficit   </td> <td class="statTable alignRight"> '+number_format(result.row.Tot_WorkerThreadDeficit)  +' </td></tr>');
  }
  $('#CSstatsFromStmts').append('</table>');

}


function refresh_CSstatsFromProcs () {


  var data = {ARContextJSON: JSON.stringify(ARContext), 'SSQLID': SSQLID, 'CompileDate': CompileDate, 'PlanID': PlanID};

  $('#CSstatsFromProcs').html('<div> Loading...</div>');
  $('#CSstatsFromProcs').addClass('detailboxcontent_loading');

  if (ASM_XHR_refresh_CSstatsFromProcs != null) {
    ASM_XHR_refresh_CSstatsFromProcs.abort();
    ASM_XHR_refresh_CSstatsFromProcs = null;
  }
  incXHRcnt();
  ASM_XHR_refresh_CSstatsFromProcs = $.post( 'ASE/sql/sql_cachedstmtstatsFromProcs.php', data ).done(function(res) {
    var result = JSON.parse(res);
    if ( checkSQLError(result, 'refresh_CSstatsFromProcs') ) return;
    $('#CSstatsFromProcs').removeClass('detailboxcontent_loading');
    if (result.TotalRows == 1) {
      render_CSstatsFromProcs(result);
    }
    else {
      //$('#CSstatsFromProcs').html('<div> No data to display</div>');
      //$('#CSstatsFromProcs').addClass('detailboxcontent_nodata');
      $('#CSstatsFromProcsDIV').remove();
    }
  })
  .fail(function(data) {
    if (data.statusText == 'abort')
      return;
    alert( "error in refresh_CSstatsFromProcs()" );
    $('#CSstatsFromProcs').html('<div> Error when loading data </div>');
  })
  .always(function() {
    decXHRcnt();
  });
}


function render_CSstatsFromProcs(result) {

  $('#CSstatsFromProcs').empty();
  $('#CSstatsFromProcs').append('<table id="stmtstatsTable" >');
  $('#CSstatsFromProcs').append('<tr> <td class="statTableUpperTitle" colspan="2" style="width:600px;"> Statement Info</td> <td class="statTableUpperTitle" colspan="2" style="width:600px"> Statement Statistics</td> </tr>');
  $('#CSstatsFromProcs').append('<tr> <td class="statTableLabel">ObjectID   : </td> <td class="statTable">' + SSQLID                                  + ' </td> <td class="statTableLabel"> MaxMemUsageKB          : </td> <td class="statTable alignRight"> ' + number_format(result.row.MaxMemUsageKB)      + ' </td></tr>');
  $('#CSstatsFromProcs').append('<tr> <td class="statTableLabel">CompileDate: </td> <td class="statTable">' + CompileDate                             + ' </td> <td class="statTableLabel"> sumExecutionCount      : </td> <td class="statTable alignRight"> ' + number_format(result.row.sumExecutionCount)  + ' </td></tr>');
  $('#CSstatsFromProcs').append('<tr> <td class="statTableLabel">PlanID     : </td> <td class="statTable">' + PlanID                                  + ' </td> <td class="statTableLabel"> avgCPUTime       (ms)  : </td> <td class="statTable alignRight"> ' + number_format(result.row.avgCPUTime)         + ' </td></tr>');
  $('#CSstatsFromProcs').append('<tr> <td class="statTableLabel">DBID       : </td> <td class="statTable">' + result.row.DBID                         + ' </td> <td class="statTableLabel"> avgExecutionTime (ms)  : </td> <td class="statTable alignRight"> ' + number_format(result.row.avgExecutionTime)   + ' </td></tr>');
  $('#CSstatsFromProcs').append('<tr> <td class="statTableLabel">DBName     : </td> <td class="statTable">' + result.row.DBName                       + ' </td> <td class="statTableLabel"> avgPhysicalReads       : </td> <td class="statTable alignRight"> ' + number_format(result.row.avgPhysicalReads)   + ' </td></tr>');
  $('#CSstatsFromProcs').append('<tr> <td class="statTableLabel">OwnerUID   : </td> <td class="statTable">' + result.row.OwnerUID                     + ' </td> <td class="statTableLabel"> avgLogicalReads        : </td> <td class="statTable alignRight"> ' + number_format(result.row.avgLogicalReads)    + ' </td></tr>');
  $('#CSstatsFromProcs').append('<tr> <td class="statTableLabel">OwnerName  : </td> <td class="statTable">' + result.row.OwnerName                    + ' </td> <td class="statTableLabel"> avgPhysicalWrites      : </td> <td class="statTable alignRight"> ' + number_format(result.row.avgPhysicalWrites)  + ' </td></tr>');
  $('#CSstatsFromProcs').append('<tr> <td class="statTableLabel">ObjectName : </td> <td class="statTable">' + result.row.ObjectName                   + ' </td> <td class="statTableLabel"> avgPagesWritten        : </td> <td class="statTable alignRight"> ' + number_format(result.row.avgPagesWritten)    + ' </td></tr>');
  $('#CSstatsFromProcs').append('<tr> <td class="statTableLabel">ObjectType : </td> <td class="statTable">' + result.row.ObjectType                   + ' </td> <td class="statTableLabel"> sumTempdbRemapCnt      : </td> <td class="statTable alignRight"> ' + number_format(result.row.sumTempdbRemapCnt)  + ' </td></tr>');
  $('#CSstatsFromProcs').append('<tr> <td class="statTableLabel">             </td> <td class="statTable">                                                </td> <td class="statTableLabel"> avgTempdbRemapTime (ms): </td> <td class="statTable alignRight"> ' + number_format(result.row.avgTempdbRemapTime) + ' </td></tr>');
  $('#CSstatsFromProcs').append('<tr> <td class="statTableLabel">             </td> <td class="statTable">                                                </td> <td class="statTableLabel"> sumRequestCnt          : </td> <td class="statTable alignRight"> ' + number_format(result.row.sumRequestCnt)      + ' </td></tr>');
  $('#CSstatsFromProcs').append('</table>');

}


function refresh_cachedstmtSQL () {

  if ( !existTable(ARContext.ServerName+'_CachedSQL')  ) return;

  var data = {ARContextJSON: JSON.stringify(ARContext), 'bootcount' : bootcount, 'SSQLID' : SSQLID, 'Hashkey' : Hashkey};
  $('#stmtSQL').html('<div> Loading...</div>');
  $('#stmtSQL').removeClass('detailboxcontent_nodata');
  $('#stmtSQL').addClass('detailboxcontent_loading');

  if (ASM_XHR_refresh_cachedstmtSQL != null) {
    ASM_XHR_refresh_cachedstmtSQL.abort();
    ASM_XHR_refresh_cachedstmtSQL = null;
  }
  incXHRcnt();
  ASM_XHR_refresh_cachedstmtSQL = $.post( 'ASE/sql/sql_cachedstmtSQL.php', data ).done(function(res) {
    result_cachedstmtSQL = JSON.parse(res);
    if ( checkSQLError(result_cachedstmtSQL, 'refresh_cachedstmtSQL') ) return;
    $('#stmtSQL').removeClass('detailboxcontent_loading');
    if (result_cachedstmtSQL.TotalRows == 0) {
      //$('#stmtSQL').html('<div> No data to display</div>');
      //$('#stmtSQL').addClass('detailboxcontent_nodata');
      $('#stmtSQLDIV').remove();
    }
    else
      render_cachedstmtSQL();
  })
  .fail(function(data) {
    if (data.statusText == 'abort')
      return;
    alert( "error in refresh_cachedstmtSQL()" );
    $('#stmtSQL').html('<div> Error when loading data </div>');
  })
  .always(function() {
    decXHRcnt();
  });
}


function render_cachedstmtSQL() {

  sqltext = result_cachedstmtSQL.SQLText.replace('<', '&lt;');
  //$('#stmtSQL').html('<div style="font-size:12px;text-align:left; padding:10px">'+sqltext+'</div>');
  $('#stmtSQL').html('<pre class="brush: sql">'+sqltext+'</pre>');
  SyntaxHighlighter.highlight();
}

function render_cachedstmtformattedSQL () {
  $('#stmtSQL').html('<pre class="brush: sql">'+result_cachedstmtSQL.FormattedSQL+'</pre>');
  SyntaxHighlighter.highlight();
}


function refresh_cachedstmtPLAN () {
  if ( !existTable(ARContext.ServerName+'_CachedPLN')  ) return;

  var data = {ARContextJSON: JSON.stringify(ARContext), 'bootcount' : bootcount, 'SSQLID' : SSQLID, 'Hashkey' : Hashkey};
  $('#stmtPLAN').html('<div> Loading...</div>');
  $('#stmtPLAN').addClass('detailboxcontent_loading');

  if (ASM_XHR_refresh_cachedstmtPLAN != null) {
    ASM_XHR_refresh_cachedstmtPLAN.abort();
    ASM_XHR_refresh_cachedstmtPLAN = null;
  }
  incXHRcnt();
  ASM_XHR_refresh_cachedstmtPLAN = $.post( 'ASE/sql/sql_cachedstmtPLAN.php', data ).done(function(res) {
    var result = JSON.parse(res);
    if ( checkSQLError(result, 'refresh_cachedstmtPLAN') ) return;
    $('#stmtPLAN').removeClass('detailboxcontent_loading');
    if (result.TotalRows == 0) {
      //$('#stmtPLAN').html('<div> No data to display</div>');
      //$('#stmtPLAN').addClass('detailboxcontent_nodata');
      $('#stmtPLANDIV').remove();
    }
    else
      render_cachedstmtPLAN(result);
  })
  .fail(function(data) {
    if (data.statusText == 'abort')
      return;
    alert( "error in refresh_cachedstmtPLAN()" );
    $('#stmtPLAN').html('<div> Error when loading data </div>');
  })
  .always(function() {
    decXHRcnt();
  });
}

function render_cachedstmtPLAN(result) {


    var plan = "";
    var SQLPlan;
    var sep = "\n";
    for (var i=0; i < result.TotalRows; i++) {
      SQLPlan = result.Rows[i].SQLPlan.replace('<', '&lt;');
      plan = plan  + sep + SQLPlan;
      
    }
    $('#stmtPLAN').html('<pre class="brush: sql">'+plan+'</pre>');
    SyntaxHighlighter.highlight();

}

function refresh_stmtXML () {


  var data = {ARContextJSON: JSON.stringify(ARContext), 'ProcName': ProcName, 'SSQLID': SSQLID, 'CompileDate' : CompileDate, 'PlanID' : PlanID, 'CachedDate' : CachedDate};

  if (ASM_XHR_refresh_stmtXML != null) {
    ASM_XHR_refresh_stmtXML.abort();
    ASM_XHR_refresh_stmtXML = null;
  }
  incXHRcnt();
  ASM_XHR_refresh_stmtXML = $.post( 'ASE/sql/sql_stmt_XML.php', data ).done(function(res) {
    var result = JSON.parse(res);
    if ( checkSQLError(result, 'refresh_stmtXML') ) return;
    if (result.TotalPlans > 0)
      render_stmtXML(result);
  })
  .fail(function(data) {
    if (data.statusText == 'abort')
      return;
    alert( "error in refresh_stmtXML()" );
  })
  .always(function() {
    decXHRcnt();
  });
}

function render_stmtXML(result) {

  resultXML = result;

  for (var i=0; i < result.TotalPlans; i++) {

    $('#XMLPlans').append('<div class="boxinmain detailbox"  >'
                        //+ '  <div class="statTitle" ><strong>XML Plan ID : '+result.Plans[i].PlanID+' Captured at : '+result.Plans[i].ts+'</strong></div>'
                        + '  <div class="statTitle" ><strong>XML Plan ID : '+result.Plans[i].PlanID+' Compiled at : '+result.Plans[i].CompDate+' Captured at : '+result.Plans[i].ts+' MemUsageKB : '+result.Plans[i].MemUsageKB+'</strong></div>'
                        + '  <div class="statLowerTitle" ><div style="margin-left: 10px;" align="left" ><input id="XMLBtn_'+i+'" value="ShowRawXML" type="button" class="btn btn-primary btn-xs" /></div></div>'
                        + '  <div id="XMLText_'+i+'" class="boxcontent" style="width:100%" align="left" >'+result.Plans[i].FormattedXML+'</div>'
                        + '</div>');

    $('#XMLBtn_'+i).click(function() {
      var i = this.id.substring(7);
      if (this.value == 'ShowRawXML') {
        $('#XMLText_'+i).html(resultXML.Plans[i].RawXML);
        this.value = 'ShowFormattedXML';
      }
      else {
        $('#XMLText_'+i).html(resultXML.Plans[i].FormattedXML);
        this.value = 'ShowRawXML';
      }
    });

    //$('#stmtXML').html(resultXML.Plans[i].RawXML);
    
  }

}


onArchCnxOpened = function(){

  $('#XMLPlans').empty();
  
  if ( existColumn(ARContext.ServerName+'_CachedSTM', 'OptimizationGoal') ) {
    support157 = 1;
    sel_157_cols=", OptimizationGoal,OptimizerLevel";
    grp_157_cols=", OptimizationGoal,OptimizerLevel";
  }

  if ( existColumn(ARContext.ServerName+'_CachedSTM', 'AvgScanRows') ) {
    support157ESD2 = 1;
    sel_157_cols = sel_157_cols 
      + ", Avg_ScanRows=avg(1.*AvgScanRows),                           "
      + "Max_ScanRows=max(1.*MaxScanRows),                              "
      + "Avg_QualifyingReadRows=avg(1.*AvgQualifyingReadRows),          "
      + "Max_QualifyingReadRows=max(1.*MaxQualifyingReadRows),          "
      + "Avg_QualifyingWriteRows=avg(1.*AvgQualifyingWriteRows),        "
      + "Max_QualifyingWriteRows=max(1.*MaxQualifyingWriteRows),        "
      + "Tot_LockWaits=sum(1.*LockWaits_smp),                        "
      + "Tot_LockWaitTime=sum(1.*LockWaitTime_smp),                  "
      + "Tot_SortCount=sum(1.*SortCount_smp),                        "
      + "Tot_SortSpilledCount=sum(1.*SortSpilledCount_smp),          "
      + "Tot_SortTime=sum(1.*SortTime_smp),                          "
      + "Max_SortTime=max(1.*MaxSortTime),                              "
      + "Tot_ParallelDegreeReduced=sum(1.*ParallelDegreeReduced_smp),"
      + "Tot_ParallelPlanRanSerial=sum(1.*ParallelPlanRanSerial_smp),"
      + "Tot_WorkerThreadDeficit=sum(1.*WorkerThreadDeficit_smp)     ";
  }

  if ( existColumn(ARContext.ServerName+'_CachedSTM', 'TotalPIO_smp') ) {
    support157SP100 = 1;
    avgPIO=",AvgPIO=sum(1.*TotalPIO_smp)/sum(UseCount_smp)";
    avgLIO=",AvgLIO=sum(1.*TotalLIO_smp)/sum(UseCount_smp)";
    avgCpuTime=",AvgCpuTime=sum(1.*TotalCpuTime_smp)/sum(UseCount_smp)";
    avgElapsedTime=",AvgElapsedTime=sum(1.*TotalElapsedTime_smp)/sum(UseCount_smp)";
  }


  if ( existTable(ARContext.ServerName+'_CachedSQL') ) {
    SQLtableExists = 1;
  }

  if ( existTable(ARContext.ServerName+'_CachedPrc') ) {
    PrctableExists = 1;
    if ( existColumn(ARContext.ServerName+'_CachedPrc', 'RequestCnt') ) {
      PrctableV157 = 1;
    }
  }

  if ( existTable(ARContext.ServerName+'_CachedSTM') ) {
    CachedSTMExists = 1;
  }

  if ( existTable(ARContext.ServerName+'_CachedXML') ) {
    CachedXMLExists = 1;
  }


  if (CachedSTMExists == 1)
    refresh_CSstatsFromStmts();
  else
    refresh_XMLPlan_only();


  $('#FormatSQLBTN').click(function() {
    if (this.value == 'FormatSQL') {
      render_cachedstmtformattedSQL ();
      this.value = 'OriginalSQL';
    }
    else {
      render_cachedstmtSQL ();
      this.value = 'FormatSQL';
    }
  });





};

  
</script>


<?php

  $InReport=true;  // Used in getgraphdata_xxxx

  // Default sort clause : by CPU
  $sort_clause = "order by SumCpuTime desc";
  $firstGraphTitle = "Total CPU per top queries";
  $secondGraphTitle = "Avg CPU for these queries";
  $indicSUM="SumCpuTime";
  $indicAVG="AvgCpuTime";
  $yaxisunit=" (ms)";
  if (isset($ORDERBY)) {
    if ( ($ORDERBY=="LIO") || ($ORDERBY=="LREADS") || ($ORDERBY=="LREAD") ){
      $sort_clause = "order by SumLogicalReads desc";
      $firstGraphTitle = "Total LogicalReads per top queries";
      $secondGraphTitle = "Avg LReads for these queries";
      $indicSUM="SumLogicalReads";
      $indicAVG="AvgLogicalReads";
      $yaxisunit="";
    }
    if ($ORDERBY=="CPU") {
      $sort_clause = "order by SumCpuTime desc";
      $firstGraphTitle = "Total CPU per top queries";
      $secondGraphTitle = "Avg CPU for these queries";
      $indicSUM="SumCpuTime";
      $indicAVG="AvgCpuTime";
      $yaxisunit=" (ms)";
    }
  }
?>


<div class="ASE-Statements">
  <center>
  <div class="maingrid_dashboard">

    <H2>Top statements <?php echo $sort_clause ?></H2>
    <div id="firstGraph" class="chart_nots" style="width:998px;height:300px;margin-bottom: 20px;" > </div>

    <H2><?php echo $indicAVG ?> for these queries</H2>
    <div id="secondGraph" class="chart_nots" style="width:998px;height:300px;margin-bottom: 20px;" > </div>

    <div ID="Statements_statistics" class="asemongrid singlegrid" ></div>

    <div ID="TrendsHeader" class="nodisplay" > <H2>Trends for these queries</H2> </div>
    <div ID="TrendsDIV"> </div>
  </div>
  </center>


<?php
  // This php section is in this DIV to allow display of "echo" messages (for debug)
  // echo "pid=".$pid."<br>";

  // Check some table/col existance
  $support157=0;
  if (in_array("ClientName",$SRVcatalog[$ServerName."_StmtStat"])) $support157 = 1;
  //echo "support157=".$support157."<br>";
  
  $StmtSQLHKExists=0;
  if (array_key_exists ($ServerName."_StmtSQLHK",$SRVcatalog)) $StmtSQLHKExists = 1;
  //echo "StmtSQLHKExists=".$StmtSQLHKExists."<br>";
  
  $StmtPlnHKExists=0;
  if (array_key_exists ($ServerName."_StmtPlnHK",$SRVcatalog)) $StmtPlnHKExists = 1;
  //echo "StmtPlnHKExists=".$StmtPlnHKExists."<br>";
  
  $colV16SP03Exists=0;
  if (in_array("QueryOptimizationTime",$SRVcatalog[$ServerName."_StmtStat"])) $colV16SP03Exists = 1;
  //echo "colV16SP03Exists=".$colV16SP03Exists."<br>";

  $SQLHashKeyExists=0;
  if (in_array("SQLHashKey",$SRVcatalog[$ServerName."_StmtStat"])) $SQLHashKeyExists = 1;
  //echo "SQLHashKeyExists=".$SQLHashKeyExists."<br>";

  $supportFieldsAnja=0;
  if ( (in_array("StatementNumber",$SRVcatalog[$ServerName."_StmtStat"])) && (in_array("ProcNestLevel",$SRVcatalog[$ServerName."_StmtStat"])) )
    $supportFieldsAnja = 1;
  //echo "supportFieldsAnja=".$supportFieldsAnja."<br>";

  $TrendStmtExists=0;
  if (array_key_exists ($ServerName."_TrendStmt",$SRVcatalog)) $TrendStmtExists = 1;
  //echo "TrendStmtExists=".$TrendStmtExists."<br>";


//$result = asemon_query("select db=db_name()", $pid);
//$row=asemon_fetch_assoc($result);
//echo "db_name=".$row["db"]."<BR>";

  
  $rowcount = 10;
  
  include ('ASE/sql/sql_stmt_statistics_HASHKEY.php');
  $query_sql_top_statements = $query;
  //echo "query=".$query."<br>";

  // Prepare temp table for stats on the selected statements
  include ("ASE/sql/graph_TOP_stmt_HASHKEY.php");



  // Get data for first graph
  $query = "select ID, ".$indicSUM." from #result order by ID";
  //echo "query=".$query."<br>";
  $result = asemon_query($query, $pid);
  include ("COMMON/getgraphdata_nots.php");
  //print_r ($data);
  //echo "<BR>";
  //if ($data["TotalRows"]==0) {
  //  echo "<H2><CENTER>No data for this time range</H2><BR>";
  //}
  $firstGraphdataJSON = json_encode($data);
  //print_r($firstGraphdataJSON);
  
  // Get data for second graph
  $query = "select ID, ".$indicAVG." from #result order by ID";
  //echo "query=".$query."<br>";
  $result = asemon_query($query, $pid);
  include ("COMMON/getgraphdata_nots.php");
  $secondGraphdataJSON = json_encode($data);
    
   // Get data for grid
  
  $total_rows=0;
  $error="";
  $datafieldsTS=array();
  $datafieldsHK=array();
  $SQLTextIsCompressed=false;
  $query = $query_sql_top_statements;  
  //echo "query=".$query."<br>";
  include ("COMMON/getgriddata_for_dashboard.php");
  // use addslashes to escape \ chars like \n in strings
  $griddata = $data;
  $griddataJSON = addslashes( json_encode($griddata));
  
  // Get trends for these queries
  
  //echo "avant querytrends<br>";
  $graphTrendData = [];
  if ($TrendStmtExists==1) {
    //print_r($griddata);
    
    //echo "<br>"."TotalRows=".$griddata["TotalRows"]."<br>";
    // get trends data for top queries
    for ($numquery=0; $numquery < $griddata["TotalRows"]; $numquery++) {
      //echo "SQLHashKey=".$griddata["Rows"][$numquery]["SQLHashKey"]."<br>";
      $SQLHashKey = $griddata["Rows"][$numquery]["SQLHashKey"];
      // get trend data for this query 
      $indic=$indicAVG;
      include ("ASE/sql/graphTrendStmt.php");
      $result = asemon_query($query, $pid);
      include ("COMMON/getgraphdata_querymulticol.php");
      $graphTrendData[$numquery] = $data;
    }
  }
  $graphTrendDataJSON = addslashes( json_encode($graphTrendData));

  
?>







</div>

<script type="text/javascript">

  var SRVcatalog = JSON.parse('<?php echo $SRVcatalogJSON     ?>');


  var height =    $('#page-content').innerHeight() - 55;
 // var colors = ['#2f7ed8', '#8bbc21', '#0d233a', '#910000', '#1aadce', 
 //  '#492970', '#f28f43', '#77a1e5', '#c42525', '#a6c96a'];
  var colors = [
      'rgb(135,206,235)',
      'rgb(50,205,50)',
      'rgb(186,85,211)',
      'rgb(240,128,128)',
      'rgb(70,130,180)',
      'rgb(154,205,50)',
      'rgb(64,224,208)',
      'rgb(255,105,180)',
      'rgb(240,230,140)',
      'rgb(210,180,140)',
               ];


  var firstGraphdata = JSON.parse('<?php echo $firstGraphdataJSON     ?>');
  var secondGraphdata = JSON.parse('<?php echo $secondGraphdataJSON     ?>');
  
  //if (firstGraphdata.TotalRows==0) {
  //  $("#main").hide();
  //  //window.stop();
  //}

  Highcharts.chart('firstGraph', {

    title: {
      text: '<?php echo $firstGraphTitle     ?>'
    },
    colors: colors,
    tableName : 'StmtStat',
    chart: {
        type: 'column',
        spacingLeft: 50,
    },
    legend: {
      enabled: false
    },
    xAxis: {
      title: {
            enabled: true,
            text: 'Queries',
            style: {
                fontWeight: 'normal'
            }
        },
       categories: firstGraphdata.series[0]
    },
    yAxis: {
      min: 0,
      title: {
            enabled: true,
            text: '<?php echo $indicSUM; echo $yaxisunit ?> ',
            style: {
                fontWeight: 'normal'
            }
      }/*,
      labels: {
            format: '{value} ms'
      }*/
    },
    plotOptions: {
        series: {
            animation: false
        }
    },
    series: [
      {
        name: 'Tot CPU',
        colorByPoint: true,
        pointPadding: 0,
        groupPadding: 0,
        borderWidth: 0,
        shadow: false,
        data: firstGraphdata.series[1]
      }
    ],
    credits: {
        enabled: false
    },
    lang: {
        noData: "No data for this time range"
    },
    noData: {
        style: {
            fontWeight: 'bold',
            fontSize: '15px',
            color: '#303030'
        }
    }  
  });

  
  
  Highcharts.chart('secondGraph', {

    title: {
      text: '<?php echo $secondGraphTitle     ?>'
    },
    colors: colors,
    tableName : 'StmtStat',
    chart: {
        type: 'column',
        spacingLeft: 50,
    },
    legend: {
      enabled: false
    },
    xAxis: {
      title: {
            enabled: true,
            text: 'Queries',
            style: {
                fontWeight: 'normal'
            }
        },
       categories: secondGraphdata.series[0]
    },
    yAxis: {
      min: 0,
      title: {
            enabled: true,
            text: '<?php echo $indicAVG; echo $yaxisunit ?>',
            style: {
                fontWeight: 'normal'
            }
      }/*,
      labels: {
            format: '{value} ms'
      }*/
    },
    plotOptions: {
        series: {
            animation: false
        }
    },
    series: [
      {
        name: 'Avg CPU',
        colorByPoint: true,
        pointPadding: 0,
        groupPadding: 0,
        borderWidth: 0,
        shadow: false,
        data: secondGraphdata.series[1]
      }
    ],
    credits: {
        enabled: false
    },
    lang: {
        noData: "No data for this time range"
    },
    noData: {
        style: {
            fontWeight: 'bold',
            fontSize: '15px',
            color: '#303030'
        }
    }
  
  });

  $('#TrendsHeader').hide();
  if (firstGraphdata.TotalRows > 0) {
    // Some queries have been retreived, so continue
    var griddataJSON='<?php echo $griddataJSON     ?>';
    if (griddataJSON.length > 0) {
      var griddata = JSON.parse(griddataJSON);
      
      var rownumberrenderer = function (row, columnfield, value, defaulthtml, columnproperties, rowdata) {
            var element = $(defaulthtml);
            element.css({ 'background-color': colors [row], 'width': '100%', 'height': '100%', 'margin': '0px', 'padding' : '4px' , 'font-weight': '900'});
            element[0].innerHTML = "<div>" + (row + 1) + "</div>";
            return element[0].outerHTML;
      }
      
      var statsrenderer = function (row, columnfield, value, defaulthtml, columnproperties, rowdata) {
            var element = $(defaulthtml);
            element.css({ 'width': '100%', 'height': '86px', 'margin': '0px', 'padding' : '4px' , 'font-size': 'smaller'});
            element[0].innerHTML = "<div>" + "AvgCPU (ms) : "+parseInt(rowdata.AvgCpuTime.toFixed(0)).toLocaleString('fr')+
                                           "<br>AvgLReads : "+parseInt(rowdata.AvgLogicalReads.toFixed(0)).toLocaleString('fr')+
                                           "<br>AvgPReads: " +parseInt(rowdata.AvgPhysicalReads.toFixed(0)).toLocaleString('fr')+ 
                                           "<br>Nb. exec. : "+rowdata.cnt.toLocaleString('fr')+ 
                                           "<br>SumCPU (ms) : " +rowdata.SumCpuTime.toLocaleString('fr')+
                                           "<br>SumLReads : "+rowdata.SumLogicalReads.toLocaleString('fr')+
                                           "<br>SumPReads : "+rowdata.SumPhysicalReads.toLocaleString('fr') + 
                                   "</div>";
            return element[0].outerHTML;
      }
      
      
      
      if (griddata.Rows.length > 0) {
        $('#Statements_statistics').asemonGridReport({
          'title' : 'Queries',
          'width' : '998px',
          'height' : height,
          'editable': false,
          'localdata': griddata.Rows,
          'datafields': [
                 { name: 'RowIndex',         type: 'number'},
                 { name: 'SQLText',          type: 'string'},
                 { name: 'AvgCpuTime',       type: 'number'},
                 { name: 'cnt',              type: 'number'},
                 { name: 'SumCpuTime',       type: 'number'},
                 { name: 'SumLogicalReads',  type: 'number'},
                 { name: 'AvgLogicalReads',  type: 'number'},
                 { name: 'SumPhysicalReads', type: 'number'},
                 { name: 'AvgPhysicalReads', type: 'number'}
                 ],
          'columns': [
                 { text: 'Item #',         datafield: 'RowIndex' ,  width: 48, cellsrenderer: rownumberrenderer },
                 { text: 'SQLText',        datafield: 'SQLText',    width: 790},
                 { text: 'Stats',          datafield: 'AvgCpuTime', width: 160, cellsrenderer: statsrenderer}
                 ]
        });
      }
    }
    
    var graphTrendDataJSON = '<?php echo $graphTrendDataJSON     ?>';
    if (graphTrendDataJSON.length > 2) {
      var graphTrendData = JSON.parse(graphTrendDataJSON);
      var querynumber;
      if (graphTrendData.length > 0) {
        $('#TrendsHeader').show();
        // Display trend graphs   
        var data;
        for (numquery=0; numquery<graphTrendData.length; numquery++) {
          querynumber=numquery+1;
          if (graphTrendData[numquery].TotalRows > 0) {
            // This statement has trend history data
            data =  graphTrendData[numquery].series[0];
          }
          else
            data = null;
          $('#TrendsDIV').append('<div ID="Trend_'+numquery+'" class="trendchart" ></div>');
          Highcharts.chart('Trend_'+numquery, {
            colors: ['#0076c8', '#dd4d40', '#ffff00', '#a0e000', '#00ffff', '#ff00ff', '#fe5921', '#ff41bb', '#a3571d', '#2e8b57'],
            title: {
              text: '<?php echo $indicAVG ?> for query Q'+querynumber+' with HashKey='+griddata.Rows[numquery].SQLHashKey,
              style: { "color": "#333333", "fontSize": "14px" }
            },
            subtitle: {
              style: { "color": "#333333", "fontSize": "12px" }
            },
            chart: {
                type: 'area',
                borderWidth: 1,
                marginBottom: 80,
                marginLeft: 80,
                marginRight: 80
            },
            legend: {
               enabled: false
              },
            plotOptions: {
                area: {
                    stacking: 'normal',
                    lineWidth: 1,
                    marker: {
                        lineWidth: 1,
                    }
                },
                series: {
                    marker: {
                        enabled: false
                    }
                }
            },
            xAxis: {
              type: 'datetime',
              labels : {
                format: '{value:%Y-%m-%d}',
                rotation: -45,
                align: 'right',
                style: {"fontSize": "8px"}
              },
              endOnTick: false,
              showFirstLabel: true,
              startOnTick: false,
              minPadding: 0,
              maxPadding: 0,
            },
            yAxis: {
              minRange: 1,
              min : 0, 
              lineWidth: 1,
              minorTickInterval: 'auto',
              max: null,
              title: {
                enabled: true,
                text: '<?php echo $yaxisunit ?>',
                style: {
                  fontWeight: 'normal'
                }
              }
            },
            series: [
              {
                name: 'Value',
                data: data
              }
            ],
            credits: {
                enabled: false
            },
            lang: {
                noData: "No trend data for this query"
            },
            noData: {
                style: {
                    fontWeight: 'bold',
                    fontSize: '15px',
                    color: '#303030'
                }
            }
          });  // End chart
        }
      }
    }
  }


</script>

<center>
<div id="allinfo">
  <H1> Activity for device : <?php echo $Device; ?> </H1>

  <div style="display: flex;flex-direction: row;justify-content: space-around;flex-wrap: wrap;align-items: center;">
    <div id="graph_DeviceIO"    class="mainchart" style="min-width:700px;width:1200px" > </div>
    <div id="graph_DeviceAvgServ"         class="mainchart" style="min-width:700px;width:1200px" > </div>
    <div id="graph_DeviceContention"         class="mainchart" style="min-width:700px;width:1200px" > </div>
  </div>
</div>
</center>


<script type="text/javascript">

var Device = "<?php echo $Device; ?>";


onArchCnxOpened = function(){
  var graph;
  var rwtime_exists = 0;

  if ( (ARContext.ServerName!="") &&(  existColumn(ARContext.ServerName+'_DevIO', 'ReadTime') ) && (  existColumn(ARContext.ServerName+'_DevIO', 'WriteTime') ) ){
    rwtime_exists = 1;
  }


  graph = $('#graph_DeviceIO').highcharts();
  if (typeof graph == 'undefined')
    $('#graph_DeviceIO').asemonChart({
    title: {
      text: "Device I/O"
    },
    queryFile : '../ASE/sql/graph_DeviceIO.php',
    tableName : 'DevIO',
    data: {
      Device: Device
    },
    chart: {
       type: 'line'
    },
    series: [
      { name: 'Reads/s'      },
      { name: 'APFReads/s'      },
      { name: 'Writes/s'      }
    ],
    legend: {
       enabled: true
    },
    yAxis: {
      minRange: 0.5,
      min : 0 
      }
  
    });
  $('#graph_DeviceIO').asemonChart('refresh',threadDelays);   

  var indic = "avgserv_ms = case when sum(Reads+Writes) >0 then sum(1.*IOTime) / sum(Reads+Writes) else 0 end";
  if (rwtime_exists == 1)
    indic = "avgreads_ms  = case when sum(Reads)  > 0 then sum(1.*ReadTime)  / sum(Reads)  else 0 end,"
          + "avgwrites_ms = case when sum(Writes) > 0 then sum(1.*WriteTime) / sum(Writes) else 0 end";

  graph = $('#graph_DeviceAvgServ').highcharts();
  if (typeof graph == 'undefined')
    $('#graph_DeviceAvgServ').asemonChart({
    title: {
      text: "Device service time (ms)"
    },
    queryFile : '../ASE/sql/graph_DeviceAvgServ.php',
    tableName : 'DevIO',
    data: {
      Device: Device,
      indic: indic
    },
    chart: {
       type: 'line'
    },
    series: [
      { name: 'serie1'},
      { name: 'serie2'}
    ],
    legend: {
       enabled: true
    },
    yAxis: {
      minRange: 0.5,
      min : 0 
      }
  
    });
  $('#graph_DeviceAvgServ').asemonChart('refresh', threadDelays);

  graph = $('#graph_DeviceContention').highcharts();
  if (typeof graph == 'undefined')
    $('#graph_DeviceContention').asemonChart({
    title: {
      text: "Device contention"
    },
    queryFile : '../ASE/sql/graph_DeviceContention.php',
    tableName : 'DevIO',
    data: {
      Device: Device
    },
    chart: {
       type: 'line'
    },
    series: [
      { name: 'DevSemaphoreContentionPCT'      }
    ],
    legend: {
       enabled: true
    },
    yAxis: {
      minRange: 1,
      min : 0 
      }
  
    });
  $('#graph_DeviceContention').asemonChart('refresh', threadDelays);

}
</script>


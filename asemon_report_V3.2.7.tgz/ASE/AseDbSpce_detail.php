
<center>
<div id="allinfo">
  <H1> Space detail for DB : "<?php echo $dbname ?>" </H1>
  <div style="display: flex;flex-direction: row;justify-content: space-around;flex-wrap: wrap;align-items: center;">
    <div id="dbspace_graph"    class="mainchart" style="min-width:700px;width:1200px" > </div>
    <div id="logspace_graph"    class="mainchart" style="min-width:700px;width:1200px" > </div>
  </div>
</div>
</center>


<script type="text/javascript">


var dbid = <?php echo $dbid ?>;
var dbname= "<?php echo $dbname ?>";
var isMixedLog= <?php echo $isMixedLog ?>;

var RSinitialized = false;
var TTinitialized = false;

var queryrangesel = "select Ts=convert(varchar,Timestamp,109),"
//                  + " Value=AVG(1.*Total_pgs)"
                  + " Value=(1.*Total_pgs)"
                  + " from "+ARContext.ServerName+"_AseDbSpce" 
                  + " where dbname='"+dbname+"'"
                  + " order by Timestamp";
var delayRangeSel = 300;
//var setTimestampToRSExtremes=1;


onArchCnxOpened = function(){

  var graph;
  var series = [
      { name: 'DataSize_Mb'      },
      { name: 'DataUsed_Mb'      }
    ];
  var title = dbname + " : DATA usage (Mb)";
  
  if (isMixedLog==1) {
    series = series.concat([
      { name: 'LogUsed_Mb'      },
      { name: 'LogClr_Mb'      }
    ]);
    title = dbname + " : DATA and LOG usage (Mb)";
  }

  graph = $('#dbspace_graph').highcharts();
  if (typeof graph == 'undefined') {
    $('#dbspace_graph').asemonChart({
    title: {
      text: title
    },
    queryFile : '../ASE/sql/graphDBUsage.php',
    tableName : 'AseDbSpce',
    data: {
      dbid: dbid,
      typeGraph: "DATA"
    },
    chart: {
       type: 'line'
    },
    series: series,
    legend: {
       enabled: true
    },
    yAxis: {
      minRange: 0.5,
      min : 0 
      }
  
    });
  }
  $('#dbspace_graph').asemonChart('refresh',threadDelays);   


  if (isMixedLog==0) {
    graph = $('#logspace_graph').highcharts();
    if (typeof graph == 'undefined') {
      $('#logspace_graph').asemonChart({
      title: {
        text: dbname + " : LOG usage (Mb)"
      },
      queryFile : '../ASE/sql/graphDBUsage.php',
      tableName : 'AseDbSpce',
      data: {
        dbid: dbid,
        typeGraph: "LOG"
      },
      chart: {
         type: 'line'
      },
      series: [
        { name: 'LogSize_Mb'      },
        { name: 'LogUsed_Mb'      },
        { name: 'LogClr_Mb'      }
      ],
      legend: {
         enabled: true
      },
      yAxis: {
        minRange: 0.5,
        min : 0 
        }
    
      });
    }
    $('#logspace_graph').asemonChart('refresh',threadDelays);   
  }
  else 
    $('#logspace_graph').hide();

}
</script>


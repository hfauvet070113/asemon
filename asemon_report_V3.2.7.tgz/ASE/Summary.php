<div class="ASE-Summary nondisplay">
  <center>

  <div style="display: flex;flex-direction: row;justify-content: space-around;flex-wrap: wrap;align-items: center;">

    <div>
      <div class="boxinmain" style="border-right-style: none">
        <div class="statTitle" ><strong>Summary Statistics</strong></div>
        <div id="ASE_summary_data" class="boxcontent boxcontent_nodata">
          <div>No data to display</div>
        </div>
      </div>
    </div>

    <div id="graphEngineCPU" class="ASE-Summary chart_nots mainpie" > </div>
  </div>

  <div id="graphCPU" class="ASE-Summary mainchart" > </div>
  <div id="graphIOCPUTime" class="ASE-Summary mainchart" > </div>
  <div id="graphCache" class="ASE-Summary mainchart" > </div>
  <div id="graphIO" class="ASE-Summary mainchart" > </div>
  <div id="graphNETIO" class="ASE-Summary mainchart" > </div>

  <div style="display: flex;flex-direction: row;justify-content: space-around;flex-wrap: wrap;">

    <div id="graphPieProcess-physical" class="ASE-Summary chart_nots mainpie" > </div>
    <div id="graphPieProcess-logical" class="ASE-Summary chart_nots mainpie" > </div>
    <div id="graphPieProcess-cpu" class="ASE-Summary chart_nots mainpie" > </div>
  </div>

  <div id="graphUserCnx" class="ASE-Summary mainchart" > </div>
  <div id="graphActiveCnx" class="ASE-Summary mainchart" > </div>
  <div id="graphProcCacheUsage" class="ASE-Summary mainchart" > </div>
  <div id="graphRecompProcs" class="ASE-Summary mainchart" > </div>



  <div id="graphProcCache_TOP8modules" class="ASE-Summary mainchart" > </div>
  <div id="graphProcCacheMemUsage" class="ASE-Summary mainchart" > </div>
  <div id="graphLocksUsage" class="ASE-Summary mainchart" > </div>


  <div style="display: flex;flex-direction: row;justify-content: space-around;flex-wrap: wrap;align-items: center;margin-top:20px">
    <div id="modulesStatisticsDIV" class="maingrid">
      <div id="modulesStatistics" class="asemongrid" > </div>
    </div>


    <div class="maingrid">
      <div class="boxinmain" style="border-right-style: none">
        <div class="statTitle" ><strong>Lock analysis</strong></div>
        <div id="ASE_lockAnalysis" class="boxcontent boxcontent_nodata">
          <div>No data to display</div>
        </div>
      </div>
    </div>
  </div>





  <div style="display: flex;flex-direction: row;justify-content: space-around;flex-wrap: wrap;align-items: center;">
    <div id="devstatsReadDescUpperDIV" class="maingrid">
      <div id="devstatsReadDesc" class="asemongrid" > </div>
    </div>
    <div id="devstatsWriteDescUpperDIV" class="maingrid">
      <div id="devstatsWriteDesc" class="asemongrid" > </div>
    </div>
  </div>


  <div id="sysWaitsStatisticsDIV" class="maingrid">
    <div id="sysWaitsStatistics" class="asemongrid" > </div>
  </div>

  <div id="cachesStatisticsDIV" class="maingrid">
    <div id="cachesStatistics" class="asemongrid" > </div>
  </div>

  <div id="poolStatisticsDIV" class="maingrid">
    <div id="poolStatistics" class="asemongrid" > </div>
  </div>

  <div id="logsContStatisticsDIV" class="maingrid">
    <div id="logsContStatistics" class="asemongrid" > </div>
  </div>

  <div id="raStatisticsDIV" class="maingrid">
    <div id="raStatistics" class="asemongrid" > </div>
  </div>

  <div id="procHistStatisticsDIV" class="maingrid">
    <div id="procHistStatistics" class="asemongrid" > </div>
  </div>

  </center>
</div>


<script type="text/javascript">

var ASM_XHR_refresh_summary_statistics;
var ASM_XHR_refresh_lock_contention;
var cpu_offset = '<?php if (isset($cpu_offset) ) echo $cpu_offset; else echo ""; ?>';

function clear_ASE_Summary () {
  $('#ASE_summary_data').empty();
  $('#ASE_lockAnalysis').empty();
}

function refresh_summary_statistics () {
  var queries = {};

  var selrwtime = '';
  // Check if DevIO has ReadTime and WriteTime fields (added in asemon_logger V2.7.8)
  if ( (  existColumn(ARContext.ServerName+'_DevIO', 'ReadTime') ) && (  existColumn(ARContext.ServerName+'_DevIO', 'WriteTime') ) )
    selrwtime =
      ", avgReads_ms=case when sum(1.*d.Reads) = 0 then 0 else sum(convert(numeric(20,0),ReadTime)) / sum(convert(numeric(20,0),1.*d.Reads)) end"
     +", avgWrites_ms=case when sum(1.*d.Writes) = 0 then 0 else sum(convert(numeric(20,0),WriteTime)) / sum(convert(numeric(20,0),1.*d.Writes)) end ";


  var engOnline = 
     "select avgNbEnginesOnline=avg(NbEnginesOnline)    "
    +" from (                                           "
    +"       select NbEnginesOnline =count(*)           "
    +"       from "+ARContext.ServerName+"_Engines      "
    +" where Timestamp >='"+ARContext.StartTimestamp+"' "
    +" and Timestamp <='"+ARContext.EndTimestamp+"'     "
    +" and ContextSwitches>0 /* for online engines only */ "
    +" group by Timestamp                               "
    +" ) engonline";
    queries['engOnline']= engOnline;

  var avgCPU =
     "select avgUserCPU_pct=avg(convert(float,UserCPUTime*1000)/Interval)*100"
    +" from "+ARContext.ServerName+"_Engines                                 "
    +" where Timestamp >='"+ARContext.StartTimestamp+"'                      "
    +" and Timestamp <='"+ARContext.EndTimestamp+"'                          "
    +" and ContextSwitches>0";
    queries['avgCPU']= avgCPU;

  var deadlocks = 
     "select numdeadlocks =sum(ms.NumDeadlocks), OpenedConnections = sum(ms.OpenedConnections)" 
    +" from "+ARContext.ServerName+"_MonState ms                                              "
    +" where Timestamp >='"+ARContext.StartTimestamp+"'                                       "
    +" and Timestamp <='"+ARContext.EndTimestamp+"'                                           ";
    queries['deadlocks']= deadlocks;
    
  var DATAios =
     "select" 
    +" Reads= sum (convert(numeric(16,0),Reads)),        "
    +" APFReads = sum (convert(numeric(16,0),APFReads ))," 
    +" Writes= sum (convert(numeric(16,0),Writes)),      "
    +" avgserv_ms=case when sum(1.*d.Reads+d.Writes) = 0 then 0 else sum(convert(numeric(20,0),IOTime)) / sum(convert(numeric(20,0),1.*d.Reads+d.Writes)) end"
    +" "+selrwtime
    +" from "+ARContext.ServerName+"_DevIO d            "
    +" where Timestamp >='"+ARContext.StartTimestamp+"' "
    +" and Timestamp <='"+ARContext.EndTimestamp+"'     "
    +"             and LogicalName not like 'SYSDEV$[_][_]%' /* ignore crazy values for devices of archive db's */"
    +" and lower(LogicalName) not like '%tempdb%'"
    +" and lower(LogicalName) not like '%ramfs%' "
    +" and lower(LogicalName) not like 'vdisk%'  "
    +" and lower(LogicalName) not like 'lst[_]%' "          // For Local System Temporary database device in a Cluster Edition
    +" and lower(LogicalName) not like '%log%'   "
    +" and upper(LogicalName) not like '%[_]L[0-9][0-9]'   ";
    queries['DATAios']= DATAios;

  var LOGios =
     "select" 
    +" Reads= sum (convert(numeric(16,0),Reads)),        "
    +" APFReads = sum (convert(numeric(16,0),APFReads )),"
    +" Writes= sum (convert(numeric(16,0),Writes)),      "
    +" avgserv_ms=case when sum(1.*d.Reads+d.Writes) = 0 then 0 else sum(convert(numeric(20,0),IOTime)) / sum(convert(numeric(20,0),1.*d.Reads+d.Writes)) end"
    +" "+selrwtime
    +" from "+ARContext.ServerName+"_DevIO d           "
    +" where Timestamp >='"+ARContext.StartTimestamp+"'"
    +" and Timestamp <='"+ARContext.EndTimestamp+"'    "
    +" and (lower(LogicalName) like '%log%' or upper(LogicalName) like '%[_]L[0-9][0-9]') and lower(LogicalName) not like '%tempdb%' and lower(LogicalName) not like '%ramfs%' and lower(LogicalName) not like 'vdisk%' and lower(LogicalName) not like 'lst[_]%'";
    queries['LOGios']= LOGios;

  var TEMPDBios =
     "select" 
    +" Reads= sum (convert(numeric(16,0),Reads)),        "
    +" APFReads = sum (convert(numeric(16,0),APFReads )),"
    +" Writes= sum (convert(numeric(16,0),Writes)),      "
    +" avgserv_ms=case when sum(1.*d.Reads+d.Writes) = 0 then 0 else sum(convert(numeric(20,0),IOTime)) / sum(convert(numeric(20,0),1.*d.Reads+d.Writes)) end"
    +" "+selrwtime
    +" from "+ARContext.ServerName+"_DevIO d           "
    +" where Timestamp >='"+ARContext.StartTimestamp+"'"
    +" and Timestamp <='"+ARContext.EndTimestamp+"'    "
    +" and (lower(LogicalName) like '%tempdb%'         "
    +" or lower(LogicalName) like '%ramfs%'            "
    +" or lower(LogicalName) like 'vdisk%')";
    queries['TEMPDBios']= TEMPDBios;

  var LSTios =
     "select" 
    +" Reads= sum (convert(numeric(16,0),Reads)),        "
    +" APFReads = sum (convert(numeric(16,0),APFReads )),"
    +" Writes= sum (convert(numeric(16,0),Writes)),      "
    +" avgserv_ms=case when sum(1.*d.Reads+d.Writes) = 0 then 0 else sum(convert(numeric(20,0),IOTime)) / sum(convert(numeric(20,0),1.*d.Reads+d.Writes)) end"
    +" "+selrwtime
    +" from "+ARContext.ServerName+"_DevIO d           "
    +" where Timestamp >='"+ARContext.StartTimestamp+"'"
    +" and Timestamp <='"+ARContext.EndTimestamp+"'    "
    +" and lower(LogicalName) like 'lst[_]%'           ";
    queries['LSTios']= LSTios;

  var SPactivity =
     "select" 
    +" sumExec=sum(1.0*Requests), sumloads=sum(1.0*Loads),                     " 
    +" procCacheHit= convert(float,sum(Requests)-sum(Loads))*100/sum(Requests),"
    +" sumWrites=sum(1.0*Writes), sumStalls=sum(1.0*Stalls)                    "
    +" from "+ARContext.ServerName+"_ProcCache                                 "
    +" where Timestamp >='"+ARContext.StartTimestamp+"'                        "
    +" and Timestamp <'"+ARContext.EndTimestamp+"'                             "
    +" and Requests >=0 /* ignore negative counters */                         "
    +" and Loads >=0                                                           "
    +" and Writes >=0";
    queries['SPactivity']= SPactivity;

  var NETactivity =
     "select" 
    +" PacketsSnt=sum(convert(numeric(15,0),case when PacketsSent<0 then power(2.,31)+PacketsSent else PacketsSent end)),"
    +" PacketsRcvd=sum(convert(numeric(15,0),case when PacketsReceived<0 then power(2.,31)+PacketsReceived else PacketsReceived end)),"
    +" BytesSnt=str(1.*sum(convert(numeric(15,0),case when BytesSent<0 then power(2.,31)+BytesSent else BytesSent end))/(1024*1024),12,2)+' Mb',"
    +" BytesRcvd=str(1.*sum(convert(numeric(15,0),case when BytesReceived <0 then power(2.,31)+BytesReceived else BytesReceived end))/(1024*1024),12,2)+' Mb',"
    +" avgPktRcvSize=str(sum(convert(numeric(15,0),case when BytesReceived <0 then power(2.,31)+BytesReceived else BytesReceived end))/sum(case when PacketsReceived<0 then power(2.,31)+PacketsReceived else PacketsReceived end),8,2),"
    +" avgPktSentSize=str(sum(convert(numeric(15,0),case when BytesSent<0 then power(2.,31)+BytesSent else BytesSent end))/sum(case when PacketsSent<0 then power(2.,31)+PacketsSent else PacketsSent end),8,2)"
    +" from "+ARContext.ServerName+"_NetworkIO"
    +" where Timestamp >='"+ARContext.StartTimestamp+"'"
    +" and Timestamp <'"+ARContext.EndTimestamp+"'";
    queries['NETactivity']= NETactivity;




if ( existTable(ARContext.ServerName+"_StmtCache") ) {
  var STMTCacheActivity =
     "select"
    +" MaxTotalSizeKB=max(TotalSizeKB), AvgUsedSizeKB=avg(1.*UsedSizeKB),MaxUsedSizeKB=max(UsedSizeKB),"
    +" AvgNumStatements=Avg(NumStatements), MaxNumStatements=max(NumStatements),"
    +" NumSearches=sum(1.*sc.NumSearches), HitCount=sum(1.*sc.HitCount), CacheHit= case when sum(1.*sc.NumSearches) =0 then 100 else 100.*sum(1.*sc.HitCount)/ sum(1.*sc.NumSearches) end,"
    +" NumInserts=sum(1.*NumInserts),  NumRemovals=sum(1.*NumRemovals),"
    +" NumRecompilesSchemaChanges=sum(1.*NumRecompilesSchemaChanges),"
    +" NumRecompilesPlanFlushes =sum(1.*NumRecompilesPlanFlushes)"
    +" from "+ARContext.ServerName+"_StmtCache sc"
    +" where Timestamp >='"+ARContext.StartTimestamp+"'"
    +" and Timestamp <'"+ARContext.EndTimestamp+"'";
    queries['STMTCacheActivity']= STMTCacheActivity;
}

if ( existColumn(ARContext.ServerName+'_Engines', 'InstanceID') ) {
  var INSTANCEID =
     "select top 1 InstanceID"
    +" from "+ARContext.ServerName+"_Engines"
    +" where Timestamp >='"+ARContext.StartTimestamp+"'"
    +" and Timestamp <'"+ARContext.EndTimestamp+"'";
    queries['INSTANCEID'] = INSTANCEID;
}

  var data = {ARContextJSON: JSON.stringify(ARContext), queriesJSON: JSON.stringify(queries)};
  $('#ASE_summary_data').empty();
  $('#ASE_summary_data').removeClass('boxcontent_nodata');
  $('#ASE_summary_data').addClass('boxcontent_loading');
  $('#ASE_summary_data').append('<div>Loading...<div>');

  if (ASM_XHR_refresh_summary_statistics != null) {
    ASM_XHR_refresh_summary_statistics.abort();
    ASM_XHR_refresh_summary_statistics = null;
  }
  incXHRcnt();
  ASM_XHR_refresh_summary_statistics = $.post( 'COMMON/multiquery.php', data ).done(function(res) {
    $('#ASE_summary_data').removeClass('boxcontent_loading');
    var result = JSON.parse(res);
    if ( checkSQLError(result, 'refresh_summary_statistics') ) return;
    render_summary_statistics(result.ResultSets);
  })
  .fail(function(data) {
    if (data.statusText == 'abort')
      return;
    alert( "error in refresh_summary_statistics()" );
  })
  .always(function() {
    decXHRcnt();
  });
}


function render_summary_statistics(rs) {
  var InstanceID = 0;
  var InstanceIDHeader = "";
  var nbcolumns = 6;
  var rwtime_exists = false;
  var rwcols = '';
  var tmpnbcols;
  var stmtcache = false;
  if ( (  existColumn(ARContext.ServerName+'_DevIO', 'ReadTime') ) && (  existColumn(ARContext.ServerName+'_DevIO', 'WriteTime') ) ){
    rwtime_exists = true;
    nbcolumns = 8;
  }

  if ( existColumn(ARContext.ServerName+'_Engines', 'InstanceID') ) {
    if (rs.INSTANCEID.length > 0) {
      InstanceID = rs.INSTANCEID[0].InstanceID;
      if (InstanceID > 0) {
        // It is a Cluster Edition
        InstanceIDHeader = '<tr> <td class="statTableUpperTitle" colspan="'+nbcolumns+'" style="text-align:center"> Cluster Edition Instance ID : '+InstanceID+'</td></tr>';
      }
      }
  }

  var rowHcpu = '<tr> <td class="statTableUpperTitle" colspan="'+nbcolumns+'"> CPU : </td></tr>';

  rwcols = '';
  tmpnbcols = 1;
  if (rwtime_exists) {
    tmpnbcols = 2;
  }
  var rowCcpu = '<tr align="center">'
    +'<td class="statTabletitle" colspan="2"> avgNbEnginesOnline  </td>'
    +'<td class="statTabletitle" colspan="2"> avgUserCPU_pct  </td>'
    +'<td class="statTabletitle" colspan="'+tmpnbcols+'"> OpenedConnections  </td>'
    +'<td class="statTabletitle" colspan="'+tmpnbcols+'"> deadlocks  </td>'
    +'</tr>';

  var rowDcpu = '<tr align="right">'
    +'<td class="statTable" colspan="2">' + number_format(rs.engOnline[0].avgNbEnginesOnline)+'</td>'
    +'<td class="statTable" colspan="2">' + number_format(rs.avgCPU[0].avgUserCPU_pct,2)+'</td>'
    +'<td class="statTable" colspan="'+tmpnbcols+'">' + number_format(rs.deadlocks[0].OpenedConnections)+'</td>'
    +'<td class="statTable" colspan="'+tmpnbcols+'">' + number_format(rs.deadlocks[0].numdeadlocks)+'</td>'
    +'</tr>';

  var rowHdevIO = '<tr> <td class="statTableUpperTitle"  colspan="'+nbcolumns+'"> Device IO : </td></tr>';

  rwcols = '';
  if (rwtime_exists) {
    rwcols = '<td class="statTabletitle" > avgReads_ms  </td>'  
                   +'<td class="statTabletitle" > avgWrites_ms  </td>';
  }
  var rowCdevIO = '<tr align="center">'
    +'<td class="statTabletitle" colspan = "2"> Type  </td>'
    +'<td class="statTabletitle" title="This column includes APFReads. READS = standard reads + APFRreads"> Reads  </td>'
    +'<td class="statTabletitle" > APFReads  </td>'
    +'<td class="statTabletitle" > Writes  </td>'
    +'<td class="statTabletitle" > Avgserv_ms  </td>'
    + rwcols
    +'</tr>';

  rwcols = '';
  if (rwtime_exists) {
      rwcols = '<td class="statTable">' + number_format(rs.DATAios[0].avgReads_ms,2)  +'</td>'
              +'<td class="statTable">' + number_format(rs.DATAios[0].avgWrites_ms,2) +'</td>';
  }
  var rowDdevIOdata = '<tr align="right">'
    +'<td class="statTable" colspan="2" align="left"> DATA : </td>  '
    +'<td class="statTable">' + number_format(rs.DATAios[0].Reads) +        '</td>'
    +'<td class="statTable">' + number_format(rs.DATAios[0].APFReads) +     '</td>'
    +'<td class="statTable">' + number_format(rs.DATAios[0].Writes) +       '</td>'
    +'<td class="statTable">' + number_format(rs.DATAios[0].avgserv_ms,2) + '</td>'
    + rwcols
    +'</tr>';

  rwcols = '';
  if (rwtime_exists) {
      rwcols = '<td class="statTable">' + number_format(rs.LOGios[0].avgReads_ms,2)  + '</td>'
              +'<td class="statTable">' + number_format(rs.LOGios[0].avgWrites_ms,2) + '</td>';
  }
  var rowDdevIOlog = '<tr align="right">'
    +'<td class="statTable" colspan="2" align="left"> LOG : </td>'
    +'<td class="statTable">' + number_format(rs.LOGios[0].Reads) +        '</td>'
    +'<td class="statTable">' + number_format(rs.LOGios[0].APFReads) +     '</td>'
    +'<td class="statTable">' + number_format(rs.LOGios[0].Writes) +       '</td>'
    +'<td class="statTable">' + number_format(rs.LOGios[0].avgserv_ms,2) + '</td>'
    + rwcols
    +'</tr>';

  rwcols = '';
  if (rwtime_exists) {
      rwcols = '<td class="statTable">' + number_format(rs.TEMPDBios[0].avgReads_ms,2) +  '</td>'
              +'<td class="statTable">' + number_format(rs.TEMPDBios[0].avgWrites_ms,2) + '</td>';
  }
  var rowDdevIOtempdb = '<tr align="right">'
    +'<td class="statTable" colspan="2" align="left"> TEMPDB : </td>'
    +'<td class="statTable">' + number_format(rs.TEMPDBios[0].Reads) +        '</td>'
    +'<td class="statTable">' + number_format(rs.TEMPDBios[0].APFReads) +     '</td>'
    +'<td class="statTable">' + number_format(rs.TEMPDBios[0].Writes) +       '</td>'
    +'<td class="statTable">' + number_format(rs.TEMPDBios[0].avgserv_ms,2) + '</td>'
    + rwcols
    +'</tr>';

  if (InstanceID > 0) {
    rwcols = '';
    if (rwtime_exists) {
        rwcols = '<td class="statTable">' + number_format(rs.LSTios[0].avgReads_ms,2) +  '</td>'
                +'<td class="statTable">' + number_format(rs.LSTios[0].avgWrites_ms,2) + '</td>';
    }
    var rowLSTio = '<tr align="right">'
      +'<td class="statTable" colspan="2" align="left" title="Local System Temporary Database"> LST DB : </td>'
      +'<td class="statTable">' + number_format(rs.LSTios[0].Reads) +        '</td>'
      +'<td class="statTable">' + number_format(rs.LSTios[0].APFReads) +     '</td>'
      +'<td class="statTable">' + number_format(rs.LSTios[0].Writes) +       '</td>'
      +'<td class="statTable">' + number_format(rs.LSTios[0].avgserv_ms,2) + '</td>'
      + rwcols
      +'</tr>';
  }


  var rowHsp = '<tr><td class="statTableUpperTitle" colspan= "'+nbcolumns+'" > Stored procs activity : </td></tr>';
  var rowCsp = '<tr align="center"> '
    +'<td class="statTabletitle" colspan= "2"> sumExec  </td>'
    +'<td class="statTabletitle" > sumloads  </td>'
    +'<td class="statTabletitle" > procCacheHit   </td>'
    +'<td class="statTabletitle" colspan="'+tmpnbcols+'"> sumWrites   </td>'
    +'<td class="statTabletitle" colspan="'+tmpnbcols+'"> sumStalls   </td>'
    +'</tr>';


  var rowDsp = '<tr align="right">'
    +'<td class="statTable" colspan= "2">'            + number_format(rs.SPactivity[0].sumExec)        + '</td>'
    +'<td class="statTable">'                         + number_format(rs.SPactivity[0].sumloads)       + '</td>'
    +'<td class="statTable">'                         + number_format(rs.SPactivity[0].procCacheHit,2) + '</td>'
    +'<td class="statTable" colspan="'+tmpnbcols+'">' + number_format(rs.SPactivity[0].sumWrites)      + '</td>'
    +'<td class="statTable" colspan="'+tmpnbcols+'">' + number_format(rs.SPactivity[0].sumStalls)      + '</td>'
    +'</tr>';

  var rowHnet = '<tr><td class="statTableUpperTitle" colspan= "'+nbcolumns+'" > Network activity : </td></tr>';
  var rowCnet = '<tr align="center">'
    +'<td class="statTabletitle" colspan= "3">   </td>'
    +'<td class="statTabletitle" > Packets  </td>'
    +'<td class="statTabletitle" colspan="'+tmpnbcols+'"> Bytes  </td>'
    +'<td class="statTabletitle" colspan="'+tmpnbcols+'"> avgSize   </td>'
    +'</tr>';
  var rowDnetrcv = '<tr align="right">'
    +'<td class="statTable" colspan= "3" align="left" nowrap> RECEIVED : </td>'
    +'<td class="statTable">                         ' + number_format(rs.NETactivity[0].PacketsRcvd) + '</td>'
    +'<td class="statTable" colspan="'+tmpnbcols+'"> ' +               rs.NETactivity[0].BytesRcvd    + '</td>'
    +'<td class="statTable" colspan="'+tmpnbcols+'"> ' +               rs.NETactivity[0].avgPktRcvSize    + '</td>'
    +'</tr>';
  var rowDnetsnt = '<tr align="right">'
    +'<td class="statTable" colspan= "3" align="left"> SENT : </td>'
    +'<td class="statTable">                        ' + number_format(rs.NETactivity[0].PacketsSnt)   + '</td>'
    +'<td class="statTable" colspan="'+tmpnbcols+'">' +               rs.NETactivity[0].BytesSnt      + '</td>'
    +'<td class="statTable" colspan="'+tmpnbcols+'">' +               rs.NETactivity[0].avgPktSentSize + '</td>'
    +'</tr>';



 if ( existTable(ARContext.ServerName+"_StmtCache") && (rs.STMTCacheActivity[0].MaxTotalSizeKB > 0) ) {
  stmtcache = true; 

  var rowHstmt = '<tr><td class="statTableUpperTitle" colspan= "'+nbcolumns+'" > Statement cache activity : </td></tr>';

  var rowC1stmt = '<tr align="center"> '
    +'<td class="statTabletitle" colspan="2"> MaxTotalSizeKB  </td>'
    +'<td class="statTabletitle" > AvgUsedSizeKB  </td>'
    +'<td class="statTabletitle" > MaxUsedSizeKB   </td>'
    +'<td class="statTabletitle" colspan="'+tmpnbcols+'" > AvgNumStatements   </td>'
    +'<td class="statTabletitle" colspan="'+tmpnbcols+'" > MaxNumStatements   </td>'
    +'</tr>';

    var rowD1stmt = '<tr align="right">'
    +'<td class="statTable" colspan="2">              ' + number_format(rs.STMTCacheActivity[0].MaxTotalSizeKB,0)  + '</td>'
    +'<td class="statTable">                          ' + number_format(rs.STMTCacheActivity[0].AvgUsedSizeKB,0)   + '</td>'
    +'<td class="statTable">                          ' + number_format(rs.STMTCacheActivity[0].MaxUsedSizeKB)     + '</td>'
    +'<td class="statTable" colspan="'+tmpnbcols+'" > ' + number_format(rs.STMTCacheActivity[0].AvgNumStatements,0)+ '</td>'
    +'<td class="statTable" colspan="'+tmpnbcols+'" > ' + number_format(rs.STMTCacheActivity[0].MaxNumStatements)  + '</td>'
    +'</tr>';

    var rowC2stmt = '<tr align="center"> '
    +'<td class="statTabletitle" colspan="2"> NumSearches  </td>'
    +'<td class="statTabletitle" > HitCount  </td>'
    +'<td class="statTabletitle" > CacheHit   </td>'
    +'<td class="statTabletitle" colspan="'+tmpnbcols+'" > NumInserts   </td>'
    +'<td class="statTabletitle" colspan="'+tmpnbcols+'" > NumRemovals   </td>'
    +'</tr>';

    var rowD2stmt = '<tr align="right">'
    +'<td class="statTable" colspan="2">              ' + number_format(rs.STMTCacheActivity[0].NumSearches) + '</td>'
    +'<td class="statTable">                          ' + number_format(rs.STMTCacheActivity[0].HitCount)    + '</td>'
    +'<td class="statTable">                          ' + number_format(rs.STMTCacheActivity[0].CacheHit,2)  + '</td>'
    +'<td class="statTable" colspan="'+tmpnbcols+'" > ' + number_format(rs.STMTCacheActivity[0].NumInserts)  + '</td>'
    +'<td class="statTable" colspan="'+tmpnbcols+'" > ' + number_format(rs.STMTCacheActivity[0].NumRemovals) + '</td>'
    +'</tr>';
    
    var tmpnbcols2 = tmpnbcols+2;
    var rowC3stmt = '<tr align="center">'
    +'<td class="statTabletitle" colspan="'+tmpnbcols2 +'"> NumRecompilesSchemaChanges  </td>'
    +'<td class="statTabletitle" colspan="'+tmpnbcols2 +'"> NumRecompilesPlanFlushes  </td>'
    +'</tr>';

    var rowD3stmt = '<tr align="right">'
    +'<td class="statTable" colspan="'+tmpnbcols2 +'">' + number_format(rs.STMTCacheActivity[0].NumRecompilesSchemaChanges) + '</td>'
    +'<td class="statTable" colspan="'+tmpnbcols2 +'">' + number_format(rs.STMTCacheActivity[0].NumRecompilesPlanFlushes)   + '</td>'
    +'</tr>';

 } // end Check if xxxx_StmtCache exists 


  $('#ASE_summary_data').empty();
  if (rs.engOnline[0].avgNbEnginesOnline == null) {
    $('#ASE_summary_data').addClass('boxcontent_nodata');
    $('#ASE_summary_data').append('<div>No data to display</div>');
  }
  else {
    $('#ASE_summary_data').append('<table id="sumDataTable">');
    if (InstanceIDHeader!="") $('#ASE_summary_data').append(InstanceIDHeader);
    $('#ASE_summary_data').append(rowHcpu,rowCcpu,rowDcpu);
    $('#ASE_summary_data').append(rowHdevIO,rowCdevIO,rowDdevIOdata,rowDdevIOlog,rowDdevIOtempdb); 
    if (InstanceID > 0) $('#ASE_summary_data').append(rowLSTio);
    $('#ASE_summary_data').append(rowHsp,rowCsp,rowDsp);
    $('#ASE_summary_data').append(rowHnet,rowCnet,rowDnetrcv,rowDnetsnt);  
    if (stmtcache)
      $('#ASE_summary_data').append(rowHstmt,rowC1stmt,rowD1stmt,rowC2stmt,rowD2stmt,rowC3stmt,rowD3stmt);  
    $('#ASE_summary_data').append('</table>');
    //$(#maTable > tbody:last).append(<tr>...</tr><tr>...</tr>);
  }
}



function refresh_lock_contention(sqlfile) {
  var data = {ARContextJSON: JSON.stringify(ARContext)};
  $('#ASE_lockAnalysis').empty();
  $('#ASE_lockAnalysis').removeClass('boxcontent_nodata');
  $('#ASE_lockAnalysis').addClass('boxcontent_loading');
  $('#ASE_lockAnalysis').append('<div>Loading...<div>');

  if (ASM_XHR_refresh_lock_contention != null) {
    ASM_XHR_refresh_lock_contention.abort();
    ASM_XHR_refresh_lock_contention = null;
  }
  incXHRcnt();
  ASM_XHR_refresh_lock_contention = $.post( 'ASE/sql/'+sqlfile, data ).done(function(res) {
    $('#ASE_lockAnalysis').removeClass('boxcontent_loading');
    var result = JSON.parse(res);
    if ( checkSQLError(result, 'refresh_lock_contention') ) return;
    render_lock_contention(result);
  })
  .fail(function(data) {
    if (data.statusText == 'abort')
      return;
    alert( "error in refresh_lock_contention()" );
  })
  .always(function() {
    decXHRcnt();
  });
}

function render_lock_contention (result) {

  $('#ASE_lockAnalysis').empty();
  $('#ASE_lockAnalysis').append('<table id="LockAnalysisDataTable">');
  $('#ASE_lockAnalysis').append('<tr> <td class="statTableUpperTitle" colspan="5" align="center"> Total time blocked (s) :</td></tr>');
  $('#ASE_lockAnalysis').append('<tr> <td class="statTable" colspan="5" align="center">'+ result.total_time_blocked +'</td></tr>');
  $('#ASE_lockAnalysis').append('<tr>'
      + '<td class="statTabletitle" colspan="1">  nb_block </td>'
      + '<td class="statTabletitle" colspan="1">  avg_blocked_proc </td>  '
      + '<td class="statTabletitle" colspan="1">  max_blocked_proc </td>  '
      + '<td class="statTabletitle" colspan="1">  avg_time_blocked_s </td>'
      + '<td class="statTabletitle" colspan="1">  max_time_blocked_s </td>'
      + '</tr>');
  $('#ASE_lockAnalysis').append('<tr align="right">'
      + '<td class="statTable" colspan="1"> '+ result.nb_block           +'</td>'
      + '<td class="statTable" colspan="1"> '+ result.avg_blocked_proc   +'</td>'
      + '<td class="statTable" colspan="1"> '+ result.max_blocked_proc   +'</td>'
      + '<td class="statTable" colspan="1"> '+ result.avg_time_blocked_s +'</td>'
      + '<td class="statTable" colspan="1"> '+ result.max_time_blocked_s +'</td>'
      + '</tr>');
  $('#ASE_lockAnalysis').append('<tr>'
      + '<td class="statTableUpperTitle" colspan="5"> Top20 Blocking Objects :</td>'
      + '</tr>'
      + '<tr>' 
      + '<td class="statTabletitle" > Database    </td>'
      + '<td class="statTabletitle" > Table       </td>'
      + '<td class="statTabletitle" > LockName    </td>'
      + '<td class="statTabletitle" > nb_block    </td>'
      + '<td class="statTabletitle" > tps_block_s </td>'
      + '</tr>');  
  for (var i=0; i < result.lockdetail.length; i++) {
    $('#ASE_lockAnalysis').append('<tr class="statTable">'
        + '<td class="statTable"  align="left" >' + result.lockdetail[i].lckBase     + ' </td>'
        + '<td class="statTable"  align="left" >' + result.lockdetail[i].lckObjet    + ' </td>'
        + '<td class="statTable"  align="left" >' + result.lockdetail[i].LockType    + ' </td>'
        + '<td class="statTable"  align="right">' + result.lockdetail[i].nb_block    + ' </td>'
        + '<td class="statTable"  align="right">' + result.lockdetail[i].tps_block_s + ' </td>'
        + '</tr>');
  }
  $('#ASE_lockAnalysis').append('<tr>'
      + '<td class="statTableUpperTitle" colspan="5"> Top20 Blocking situations :</td>'
      + '</tr>'
      + '<tr>' 
      + '<td class="statTabletitle" colspan="3"> Timestamp  </td>'
      + '<td class="statTabletitle" > nb_blocked_proc  </td>'
      + '<td class="statTabletitle" > max_time_blocked_s   </td>'
      + '</tr>');
  for (var i=0; i < result.toplocks.length; i++) {
    $('#ASE_lockAnalysis').append('<tr class="statTable">'
        + '<td class="statTable"  align="left" colspan="3">' + result.toplocks[i].max_TS          + '</td>'
        + '<td class="statTable"  align="right">           ' + result.toplocks[i].nb_blocked_proc + '</td>'
        + '<td class="statTable"  align="right">           ' + result.toplocks[i].max_WT          + '</td>'
        + '</tr>'); 
  }

  $('#ASE_lockAnalysis').append('</table>');

}


function refresh_ASE_Summary() {

  refresh_summary_statistics();

  var graph, grid;
  var IOCPUTime_exists = 0;
  if (existColumn(ARContext.ServerName+'_Engines', 'IOCPUTime')) {
    IOCPUTime_exists = 1;
  }
  
  graph = $('#graphEngineCPU').highcharts();
  if (typeof graph == 'undefined')
    //graph.destroy();
    $('#graphEngineCPU').asemonChart_nots({
    title: {
      text: '% Engines Usage'
    },
    queryFile : '../ASE/sql/graphAvgEngineUsage.php',
    tableName : 'Engines',
    chart: {
        type: 'column'
    },
    legend: {
      enabled: false
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.y:,.2f}</b><br/>'
    },
    yAxis: [{
      min: 0,
      max: 100
    }],
    series: [
      {
        name: '% CPU'
      }
    ]

    });
  $('#graphEngineCPU').asemonChart_nots('refresh');

  graph = $('#graphCPU').highcharts();
  if (typeof graph == 'undefined')
    //graph.destroy();
    if (cpu_offset == '')
      $('#graphCPU').asemonChart({
      title: {
        text: 'CPU usage'
      },
      queryFile : '../ASE/sql/graphCPU.php',
      tableName : 'Engines',
      chart: {
          type: 'area'
      },
      yAxis: [{
        min: 0,
        max: 100
      }] ,
      series: [
        {
          name: 'CPU user'
        },
        {
          name: 'CPU system'
        }
      ]
      
      });

    else
      $('#graphCPU').asemonChart({
      title: {
        text: 'CPU usage'
      },
      queryFile : '../ASE/sql/graphCPU.php',
      tableName : 'Engines',
      chart: {
//          type: 'area'
      },
      yAxis: [{
        min: 0,
        max: 100
      }] ,
      series: [
        {
          name: 'CPU user',
          type: 'area'
        },
        {
          name: 'CPU system',
          type: 'area'
        },
        {
          name: 'CPU User (prev week)',
          type: 'line',    
          color: '#000000',
          lineWidth: 1
        }
      ],
      data: {
        cpu_offset: 'cpu_offset'
      }
      });
  $('#graphCPU').asemonChart('refresh',threadDelays);

  graph = $('#graphIOCPUTime').highcharts();
  if (typeof graph != 'undefined')
    graph.destroy();
  if (IOCPUTime_exists == 1) {
    $('#graphIOCPUTime').asemonChart({
    title: {
      text: 'IOCPUTime %'
    },
    queryFile : '../ASE/sql/graphIOCPUTime.php',
    tableName : 'Engines',
    chart: {
        type: 'line'
    },
    yAxis: [{
      min: 0,
      max: 100
    }] ,
    series: [
      {
        name: 'IOCPUTime'
      }
    ]
    
    });
    $('#graphIOCPUTime').show();
    $('#graphIOCPUTime').asemonChart('refresh',threadDelays);
    graph = $('#graphIOCPUTime').highcharts();
    graph.reflow();

  }
  else
    $('#graphIOCPUTime').hide();


  graph = $('#graphCache').highcharts();
  if (typeof graph == 'undefined')
    //graph.destroy();
    $('#graphCache').asemonChart({
    title: {
      text: "Caches IO (Logical reads / s) 'default data cache' + other caches (accumulated)"
    },
    queryFile : '../ASE/sql/graphCache.php',
    tableName : 'DataCache',
    chart: {
        type: 'area'
    },
    series: [
      {
        name: 'Default data cache',
      },
      {
        name: 'Other caches',
        color: '#00ffff'
      }
    ],
    yAxis: 
    {
      min: 0
    }

    });
  $('#graphCache').asemonChart('refresh',threadDelays);

  var InstanceIDexists = 0;
  if ( existColumn(ARContext.ServerName+'_Engines', 'InstanceID') )
    InstanceIDexists = 1;
  graph = $('#graphIO').highcharts();
  if (typeof graph == 'undefined')
    //graph.destroy();
    $('#graphIO').asemonChart({
    title: {
      text: "Device IO (IO/s DATA, LOG, TEMPDB accumulated)"
    },
    queryFile : '../ASE/sql/graphIO.php',
    tableName : 'DevIO',
    chart: {
        type: 'area'
    },
    data: {
        'InstanceIDexists': InstanceIDexists
    },
    series: [
      {
        name: 'Data'
      },
      {
        name: 'Log'
      },
      {
        name: 'Tempdb'
      },
      {
        name: 'Lst'
      }
    ],
    yAxis: 
    {
      min: 0
    }

    });
  $('#graphIO').asemonChart('refresh',threadDelays);


  graph = $('#graphNETIO').highcharts();
  if (typeof graph == 'undefined')
    //graph.destroy();
    $('#graphNETIO').asemonChart({
    title: {
      text: "Network IO (Read + writes accumulated)"
    },
    queryFile : '../ASE/sql/graphNETIO.php',
    tableName : 'NetworkIO',
    chart: {
        type: 'area'
    },
    series: [
      {
        name: 'Sent (KB/s)',
      },
      {
        name: 'Recieved (KB/s)',
      }
    ],
    yAxis: 
    {
      min: 0
    }

    });
  $('#graphNETIO').asemonChart('refresh',threadDelays);



  graph = $('#graphPieProcess-physical').highcharts();
  if (typeof graph == 'undefined')
    //graph.destroy();
    $('#graphPieProcess-physical').asemonChart_nots({
    title: {
      text: "Physical IO by 'Program_name'"
    },
    queryFile : '../ASE/sql/graphPieProcess.php',
    tableName : 'Engines',
    chart: {
        type: 'pie',
        marginBottom: 5,
        marginLeft: 5,
        marginRight: 5
    },
    plotOptions: {
      pie: {
          cursor: 'pointer',
          dataLabels: {
              enabled: true,
              format: '{point.name}: {point.percentage:.1f} %',
              style: {"color": "contrast", "fontSize": "11px", "fontWeight": "normal", "textShadow": "0 0 6px contrast, 0 0 3px contrast" }
          },
          size : '60%'
      }
    },
    series: [
      {
        name: 'I/O'
      }
    ],
    data: {
      group: 'program',
      indicator: 'physical'
    }
    });
  $('#graphPieProcess-physical').asemonChart_nots('refresh');

  graph = $('#graphPieProcess-logical').highcharts();
  if (typeof graph == 'undefined')
    //graph.destroy();
    $('#graphPieProcess-logical').asemonChart_nots({
    title: {
      text: "Logical IO by 'Program_name'"
    },
    queryFile : '../ASE/sql/graphPieProcess.php',
    tableName : 'Engines',
    chart: {
        type: 'pie',
        marginBottom: 5,
        marginLeft: 5,
        marginRight: 5
    },
    plotOptions: {
      pie: {
          cursor: 'pointer',
          dataLabels: {
              enabled: true,
              format: '{point.name}: {point.percentage:.1f} %',
              style: {"color": "contrast", "fontSize": "11px", "fontWeight": "normal", "textShadow": "0 0 6px contrast, 0 0 3px contrast" }
          },
          size : '60%'
      }
    },
    series: [
      {
        name: 'I/O'
      }
    ],
    data: {
      group: 'program',
      indicator: 'logical'
    }
    });
  $('#graphPieProcess-logical').asemonChart_nots('refresh');

  graph = $('#graphPieProcess-cpu').highcharts();
  if (typeof graph == 'undefined')
    //graph.destroy();
    $('#graphPieProcess-cpu').asemonChart_nots({
    title: {
      text: "CPU by 'Program_name'"
    },
    queryFile : '../ASE/sql/graphPieProcess.php',
    tableName : 'Engines',
    chart: {
        type: 'pie',
        marginBottom: 5,
        marginLeft: 5,
        marginRight: 5
    },
    plotOptions: {
      pie: {
          cursor: 'pointer',
          dataLabels: {
              enabled: true,
              format: '{point.name}: {point.percentage:.1f} %',
              style: {"color": "contrast", "fontSize": "11px", "fontWeight": "normal", "textShadow": "0 0 6px contrast, 0 0 3px contrast" }
          },
          size : '60%'
      }
    },
    series: [
      {
        name: 'CPU'
      }
    ],
    data: {
      group: 'program',
      indicator: 'cpu'
    }
    });
  $('#graphPieProcess-cpu').asemonChart_nots('refresh');



  graph = $('#graphUserCnx').highcharts();
  if (typeof graph == 'undefined')
    //graph.destroy();
    $('#graphUserCnx').asemonChart({
    title: {
      text: 'Number of user connections'
    },
    queryFile : '../ASE/sql/graphUserCnx.php',
    tableName : 'MonConf',
    chart: {
        
    },
    series: [
      {
        name: 'Num connected',
        type: 'area'
      },
      {
        name: 'Max connected',
        type: 'line'
      }
    ],
    yAxis: 
    {
      min: 0
    }

    });
  $('#graphUserCnx').asemonChart('refresh',threadDelays);

  graph = $('#graphActiveCnx').highcharts();
  if (typeof graph == 'undefined')
    //graph.destroy();
    $('#graphActiveCnx').asemonChart({
    title: {
      text: 'Number of active connections'
    },
    queryFile : '../ASE/sql/graphActiveCnx.php',
    tableName : 'CnxActiv',
    chart: {
        
    },
    series: [
      {
        name: 'Num active',
        type: 'area'
      }
    ],
    yAxis: 
    {
      min: 0
    }

    });
  $('#graphActiveCnx').asemonChart('refresh',threadDelays);

  graph = $('#graphProcCacheUsage').highcharts();
  if (typeof graph == 'undefined')
    //graph.destroy();
    $('#graphProcCacheUsage').asemonChart({
    title: {
      text: 'Procedure cache usage (number of 2K memory pages)'
    },
    queryFile : '../ASE/sql/graphProcCacheUsage.php',
    tableName : 'MonConf',
    chart: {
        
    },
    series: [
      {
        name: 'Num_active',
        type: 'area'
      },
      {
        name: 'Max_configured',
        type: 'line'
      },
      {
        name: 'Max_used',
        type: 'line'
      }
    ],
    yAxis: 
    {
      min: 0
    }

    });
  $('#graphProcCacheUsage').asemonChart('refresh',threadDelays);

  graph = $('#graphRecompProcs').highcharts();
  if (typeof graph == 'undefined')
    //graph.destroy();
    $('#graphRecompProcs').asemonChart({
    title: {
      text: 'Stored procs activity (for Loads/s and Writes/s : use the right axis)'
    },
    queryFile : '../ASE/sql/graphRecompProcs.php',
    tableName : 'ProcCache',
    chart: {
        
    },
    series: [
      {
        name: 'Requests / s',
        type: 'line'
      },
      {
        name: 'Loads / s',
        type: 'line',
        yAxis: 1
      },
      {
        name: 'Writes / s',
        type: 'line',
        yAxis: 1
      }
    ]
    });
  $('#graphRecompProcs').asemonChart('refresh',threadDelays);

  graph = $('#graphProcCache_TOP8modules').highcharts();
  if (typeof graph != 'undefined')
    graph.destroy();
  // Check if table xxxx_PModUse exists
  if ( existTable(ARContext.ServerName+'_PModUse') ) {
    $('#graphProcCache_TOP8modules').asemonChart({
      title: {
        text: 'Modules usage in Procedure Cache (Unit : Mb)'
      },
      queryFile : '../ASE/sql/graphProcCache_TOP8modules.php',
      tableName : 'PModUse',
      chart: {
          
      },
      series: [
        {
          name: 'Sum ActiveMB',
          type: 'line'
        },
        {
          name: 'module',
          type: 'area'
        },
        {
          name: 'module',
          type: 'area'
        },
        {
          name: 'module',
          type: 'area'
        },
        {
          name: 'module',
          type: 'area'
        },
        {
          name: 'module',
          type: 'area'
        },
        {
          name: 'module',
          type: 'area'
        },
        {
          name: 'module',
          type: 'area'
        },
        {
          name: 'module',
          type: 'area'
        }
      ],
      yAxis: 
      {
        min: 0
      }
    });
    $('#graphProcCache_TOP8modules').show();
    $('#graphProcCache_TOP8modules').asemonChart('refresh',threadDelays);
  }
  else
    $('#graphProcCache_TOP8modules').hide();
  

  graph = $('#graphProcCacheMemUsage').highcharts();
  if (typeof graph != 'undefined')
    graph.destroy();
  // Check if table xxxx_ProcMem exists
  if ( existTable(ARContext.ServerName+'_ProcMem') ) {
    $('#graphProcCacheMemUsage').asemonChart({
      title: {
        text: 'Memory usage (from monCachedProcedures and sysprocesses)'
      },
      queryFile : '../ASE/sql/graphProcCacheMemUsage.php',
      tableName : 'ProcMem',
      chart: {
          
      },
      series: [
        {
          name: 'Procedures KB',
          type: 'area'
        },
        {
          name: 'Statement Cache KB',
          type: 'area'
        },
        {
          name: 'User memory KB',
          type: 'area'
        }
      ],
      yAxis: 
      {
        min: 0
      }
    });
    $('#graphProcCacheMemUsage').show();
    $('#graphProcCacheMemUsage').asemonChart('refresh',threadDelays);
    graph = $('#graphProcCacheMemUsage').highcharts();
    graph.reflow();
  }
  else
    $('#graphProcCacheMemUsage').hide();

  graph = $('#graphLocksUsage').highcharts();
  if (typeof graph != 'undefined')
    graph.destroy();
  // Check if table xxxx_MonConf exists
  if ( existTable(ARContext.ServerName+'_MonConf') ) {
    $('#graphLocksUsage').asemonChart({
      title: {
        text: 'Locks usage'
      },
      queryFile : '../ASE/sql/graphLocksUsage.php',
      tableName : 'MonConf',
      chart: {
          
      },
      series: [
        {
          name: 'Num_active',
          type: 'line'
        },
        {
          name: 'Max_used',
          type: 'line'
        },
        {
          name: 'Num locks configured',
          type: 'line',
          color: 'green'
        }
      ],
      yAxis: 
      {
        min: 0
      }
    });
    $('#graphLocksUsage').show();
    $('#graphLocksUsage').asemonChart('refresh',threadDelays);
    graph = $('#graphLocksUsage').highcharts();
    graph.reflow();
  }
  else
    $('#graphLocksUsage').hide();


  grid = $('#modulesStatistics').data('jqxWidget');
  if (typeof grid != 'undefined') {
    $('#modulesStatistics').asemonGrid('destroy');
    $('#modulesStatisticsDIV').append('<div id="modulesStatistics" class="asemongrid" > </div>');
  }
  // Check if table xxxx_PModUse exists
  if ( existTable(ARContext.ServerName+'_PModUse') ) {
    $('#modulesStatistics').asemonGrid({
    'title' : 'Modules Statistics',
    'width' : 650,
    'height' : 400,
    'minimizeheight': true,
    'rowcount': 0,
    'filterable': false,
    'sortable': true,
    'toolbar': false,
    'showaggregates': false,
    'querydata' : {'queryfile' : '../ASE/sql/sql_module_statistics.php'},
    'datafieldsMapping' : { },
    'datafields': [
     { name: 'ModuleID'  , type: 'number'},
     { name: 'ModuleName', type: 'string'},
     { name: 'Avg_Active', type: 'number'},
     { name: 'Max_used'  , type: 'number'},
     { name: 'Last_used' , type: 'number'},
     { name: 'Tot_reused', type: 'number'}
    ],
  
    'columns': [
     { text: 'ModuleID'  , datafield: 'ModuleID'  , width: 80, filterable: false, cellsformat: 'd'},
     { text: 'ModuleName', datafield: 'ModuleName', width: 150, filterable: false},
     { text: 'Avg_Active', datafield: 'Avg_Active', width: 90, filterable: false, cellsformat: 'd2',  filtertype: 'number', cellsalign: 'right'},
     { text: 'Max_used'  , datafield: 'Max_used'  , width: 90, filterable: false, cellsformat: 'd0',  filtertype: 'number', cellsalign: 'right'},
     { text: 'Last_used' , datafield: 'Last_used' , width: 90, filterable: false, cellsformat: 'd0', filtertype: 'number', cellsalign: 'right'},
     { text: 'Tot_reused', datafield: 'Tot_reused', width: 90, filterable: false, cellsformat: 'd0', filtertype: 'number', cellsalign: 'right' },
     { text: '', width: 25,  filterable: false}
    ]
    });
  }
  else 
    $('#modulesStatisticsDIV').hide();


  // Check if BlockedP table has new V15 structure
  if ( existColumn(ARContext.ServerName+'_BlockedP', 'WaitTime') ) {
    // V15
      refresh_lock_contention('sqlLockAnalysis_V15.php');
  }
  else {
    // Before V15
      refresh_lock_contention('sqlLockAnalysis.php');
  }

  var rwtime_exists = 0;
  var tmpcols = [];
  var tmpfields = [];
  if ( (ARContext.ServerName!="") &&(  existColumn(ARContext.ServerName+'_DevIO', 'ReadTime') ) && (  existColumn(ARContext.ServerName+'_DevIO', 'WriteTime') ) ){
    rwtime_exists = 1;
    tmpfields = [{ name: 'avgReads_ms', type: 'number'},
                 { name: 'avgWrites_ms', type: 'number'}];
    tmpcols= [{ text: 'avgReads_ms'       , datafield: 'avgReads_ms',    width: 90, filterable: false, cellsformat: 'd2', filtertype: 'number', cellsalign: 'right' ,aggregates: ['avg']},
              { text: 'avgWrites_ms'      , datafield: 'avgWrites_ms',   width: 90, filterable: false, cellsformat: 'd2', filtertype: 'number', cellsalign: 'right' ,aggregates: ['avg']}];
  }




  grid = $('#devstatsReadDesc').data('jqxWidget');
  if (typeof grid != 'undefined') {
    $('#devstatsReadDesc').asemonGrid('destroy');
    $('#devstatsReadDescUpperDIV').append('<div id="devstatsReadDesc" class="asemongrid" > </div>');
  }
  $('#devstatsReadDesc').asemonGrid({
  'title' : 'Device Statistics : top 20 per Read activity',
  'columnTooltipsKey' : 'devstats',
  'width' : 800,
  'height' : 400,
  'minimizeheight': true,
  'rowcount': 20,
  'filterable': false,
  'sortable': false,
  'toolbar': false,
  'showaggregates': false,
  'querydata' : {'queryfile' : '../ASE/sql/sql_devices_statistics.php',
                 'default_order_by' : 'sum(convert(numeric(20,0),Reads)) desc',
                 'rwtime_exists' : rwtime_exists},
  'datafieldsMapping' : { 'Device' : 'LogicalName'},
  'datafields': [
   { name: 'Device', type: 'string'},
   { name: 'PReads', type: 'number'},
   { name: 'AReads', type: 'number'},
   { name: 'PWrites', type: 'number'},
   { name: 'avgserv_ms', type: 'number'},
   { name: 'DevSemaphoreContentionPCT', type: 'number'}
  ]
  .concat(tmpfields),

  'columns': [
   { text: 'Device',                    datafield: 'Device',                    width: 150, filterable: true},
   { text: 'PReads',                    datafield: 'PReads',                    width: 90, filterable: false, cellsformat: 'd', filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
   { text: 'AReads',                    datafield: 'AReads',                    width: 90, filterable: false, cellsformat: 'd', filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
   { text: 'PWrites',                   datafield: 'PWrites',                   width: 90, filterable: false, cellsformat: 'd', filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
   { text: 'avgserv_ms',                datafield: 'avgserv_ms',                width: 90, filterable: false, cellsformat: 'd2', filtertype: 'number', cellsalign: 'right' ,aggregates: ['avg']},
   { text: 'DevSemaphoreContentionPCT', datafield: 'DevSemaphoreContentionPCT', width: 90, filterable: false, cellsformat: 'd2', filtertype: 'number', cellsalign: 'right' }
  ]
  .concat(tmpcols)
    .concat(
    [
         { text: '', width: 25,  filterable: false}
    ])
  });



  grid = $('#devstatsWriteDesc').data('jqxWidget');
  if (typeof grid != 'undefined') {
    $('#devstatsWriteDesc').asemonGrid('destroy');
    $('#devstatsWriteDescUpperDIV').append('<div id="devstatsWriteDesc" class="asemongrid" > </div>');
  }
  $('#devstatsWriteDesc').asemonGrid({
  'title' : 'Device Statistics : top 20 per Write activity',
  'columnTooltipsKey' : 'devstats',
  'width' : 800,
  'height' : 400,
  'minimizeheight': true,
  'rowcount': 20,
  'filterable': false,
  'sortable': false,
  'toolbar': false,
  'showaggregates': false,
  'querydata' : {'queryfile' : '../ASE/sql/sql_devices_statistics.php',
                 'default_order_by' : 'sum(convert(numeric(20,0),Writes)) desc',
                 'rwtime_exists' : rwtime_exists},
  'datafieldsMapping' : { 'Device' : 'LogicalName'},
  'datafields': [
   { name: 'Device', type: 'string'},
   { name: 'PReads', type: 'number'},
   { name: 'AReads', type: 'number'},
   { name: 'PWrites', type: 'number'},
   { name: 'avgserv_ms', type: 'number'},
   { name: 'DevSemaphoreContentionPCT', type: 'number'}
  ]
  .concat(tmpfields),

  'columns': [
   { text: 'Device',                    datafield: 'Device',                    width: 150, filterable: true},
   { text: 'PReads',                    datafield: 'PReads',                    width: 90, filterable: false, cellsformat: 'd', filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
   { text: 'AReads',                    datafield: 'AReads',                    width: 90, filterable: false, cellsformat: 'd', filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
   { text: 'PWrites',                   datafield: 'PWrites',                   width: 90, filterable: false, cellsformat: 'd', filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
   { text: 'avgserv_ms',                datafield: 'avgserv_ms',                width: 90, filterable: false, cellsformat: 'd2', filtertype: 'number', cellsalign: 'right' ,aggregates: ['avg']},
   { text: 'DevSemaphoreContentionPCT', datafield: 'DevSemaphoreContentionPCT', width: 90, filterable: false, cellsformat: 'd2', filtertype: 'number', cellsalign: 'right' }
  ]
  .concat(tmpcols)
    .concat(
    [
         { text: '', width: 25,  filterable: false}
    ])
  });


  grid = $('#sysWaitsStatistics').data('jqxWidget');
  if (typeof grid != 'undefined') {
    $('#sysWaitsStatistics').asemonGrid('destroy');
    $('#sysWaitsStatisticsDIV').append('<div id="sysWaitsStatistics" class="asemongrid" > </div>');
  }
  // Check if table xxxx_SysWaits, xxx__WEvInf and xxx__WClassInf exists
  if ( existTable(ARContext.ServerName+'_SysWaits') &&
       existTable(ARContext.ServerName+'_WEvInf') &&
       existTable(ARContext.ServerName+'_WClassInf') ) {

    $('#sysWaitsStatistics').asemonGrid({
    'title' : 'SysWaits',
    'columnTooltipsKey' : 'SysWaits_statistics',
    'width' : 890,
    'height' : 400,
    'minimizeheight': true,
    'rowcount': 0,
    'filterable': false,
    'sortable': true,
    'toolbar': false,
    'showaggregates': false,
    'querydata' : {'queryfile' : '../ASE/sql/sql_SysWaits_list.php',
                   'default_order_by' : 'SumWaitTime desc'},
    'datafieldsMapping' : { },
    'datafields': [
     { name: 'WaitEventID'      , type: 'number'},
     { name: 'ClassDesc'      , type: 'string'},
     { name: 'EventDesc'      , type: 'string'},
     { name: 'SumWaitTime'    , type: 'number'},
     { name: 'Sumwaits'       , type: 'number'},
     { name: 'AvgWaitTime_ms' , type: 'number'}
    ],
  
    'columns': [
     { text: 'WaitEventID',     datafield: 'WaitEventID',    width: 90, filterable: false, cellsformat: 'd0',  filtertype: 'number', cellsalign: 'right'},
     { text: 'ClassDesc',       datafield: 'ClassDesc',      width: 200, filterable: false},
     { text: 'EventDesc',       datafield: 'EventDesc',      width: 290, filterable: false},
     { text: 'WaitTime(s)',     datafield: 'SumWaitTime',    width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
     { text: 'Waits',           datafield: 'Sumwaits',       width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
     { text: 'AvgWaitTime(ms)', datafield: 'AvgWaitTime_ms', width: 90, filterable: false, cellsformat: 'd2', filtertype: 'number', cellsalign: 'right'},
     { text: '', width: 25,  filterable: false}

    ]
    });
  }
  else 
    $('#sysWaitsStatisticsDIV').hide();

  grid = $('#cachesStatistics').data('jqxWidget');
  if (typeof grid != 'undefined') {
    $('#cachesStatistics').asemonGrid('destroy');
    $('#cachesStatisticsDIV').append('<div id="cachesStatistics" class="asemongrid" > </div>');
  }
  $('#cachesStatistics').asemonGrid({
  'title' : 'Caches Statistics',
  'width' : 780,
  'height' : 400,
  'minimizeheight': true,
  'rowcount': 0,
  'filterable': false,
  'sortable': true,
  'toolbar': false,
  'showaggregates': false,
  'querydata' : {'queryfile' : '../ASE/sql/sql_cache_statistics.php',
                 'default_order_by' : 'SumWaitTime desc'},
  'datafieldsMapping' : { },
  'datafields': [
   { name: 'CacheName' , type: 'string'},
   { name: 'sumSearch' , type: 'string'},
   { name: 'sumLReads' , type: 'number'},
   { name: 'sumReads'  , type: 'number'},
   { name: 'sumWrites' , type: 'number'},
   { name: 'sumStalls' , type: 'number'},
   { name: 'Hit_pct'   , type: 'number'}
  ],

  'columns': [
   { text: 'CacheName',    datafield: 'CacheName', width: 240, filterable: false},
   { text: 'sumSearch',    datafield: 'sumSearch', width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
   { text: 'CachesHits',   datafield: 'sumLReads', width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
   { text: 'CachesMisses', datafield: 'sumReads',  width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
   { text: 'sumWrites',    datafield: 'sumWrites', width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
   { text: 'sumStalls',    datafield: 'sumStalls', width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
   { text: 'Hit_pct',      datafield: 'Hit_pct',   width: 90, filterable: false, cellsformat: 'd2', filtertype: 'number', cellsalign: 'right'}
  ]
  });


  var support157 = 0;
  var v157fields = [];
  var v157cols = [];
  if (existColumn(ARContext.ServerName+'_CachePool', 'LogicalReads')) {
    support157 = 1;
    v157fields = [
                 { name: 'sumLogicalReads',   type: 'number'},
                 { name: 'sumPhysicalWrites', type: 'number'},
                 { name: 'sumAPFReads',       type: 'number'},
                 { name: 'avgAPFPercentage',  type: 'number'},
                 { name: 'avgWashSize',       type: 'number'}
                 ];
    v157cols= [
              { text: 'LogicalReads',   datafield: 'sumLogicalReads',   width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
              { text: 'PhysicalWrites', datafield: 'sumPhysicalWrites', width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
              { text: 'APFReads',       datafield: 'sumAPFReads',       width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
              { text: 'APFPercentage',  datafield: 'avgAPFPercentage',  width: 90, filterable: false, cellsformat: 'd2', filtertype: 'number', cellsalign: 'right'},
              { text: 'WashSize',       datafield: 'avgWashSize',       width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'}
              ];
  }


  grid = $('#poolStatistics').data('jqxWidget');
  if (typeof grid != 'undefined') {
    $('#poolStatistics').asemonGrid('destroy');
    $('#poolStatisticsDIV').append('<div id="poolStatistics" class="asemongrid" > </div>');
  }
  $('#poolStatistics').asemonGrid({
  'title' : 'Pool Statistics',
  'width' : 800,
  'height' : 400,
  'minimizeheight': true,
  'rowcount': 0,
  'filterable': false,
  'sortable': true,
  'toolbar': false,
  'showaggregates': true,
  'querydata' : {'queryfile' : '../ASE/sql/sql_pool_statistics.php',
                 'support157' : support157},
  'datafieldsMapping' : { },
  'datafields': [
   { name: 'CacheName',        type: 'string'},
   { name: 'IOBufferSize',     type: 'number'},
   { name: 'AllocatedKB',      type: 'number'},
   { name: 'sumPagesReads',    type: 'number'},
   { name: 'sumPhysicalReads', type: 'number'},
   { name: 'sumStalls"]',      type: 'number'},
   { name: 'sumBuffersToMRU',  type: 'number'},
   { name: 'sumBuffersToLRU',  type: 'number'},
   { name: 'PhysReads_s',      type: 'number'},
   { name: 'Turnover_s',       type: 'string'}
  ]
  .concat(v157fields),

  'columns': [
   { text: 'CacheName    ', datafield: 'CacheName',        width: 240, filterable: false},
   { text: 'IOBufferSize ', datafield: 'IOBufferSize',     width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
   { text: 'AllocatedKB  ', datafield: 'AllocatedKB',      width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
   { text: 'PagesReads   ', datafield: 'sumPagesReads',    width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
   { text: 'PhysicalReads', datafield: 'sumPhysicalReads', width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
   { text: 'Stalls       ', datafield: 'sumStalls"]',      width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
   { text: 'BuffersToMRU ', datafield: 'sumBuffersToMRU',  width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
   { text: 'BuffersToLRU ', datafield: 'sumBuffersToLRU',  width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
   { text: 'PhysReads/s  ', datafield: 'PhysReads_s',      width: 90, filterable: false, cellsformat: 'd2', filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
   { text: 'Turnover_s   ', datafield: 'Turnover_s',       width: 90, filterable: false, cellsalign: 'right'}
  ]
  .concat(v157cols),
  });

  grid = $('#logsContStatistics').data('jqxWidget');
  if (typeof grid != 'undefined') {
    $('#logsContStatistics').asemonGrid('destroy');
    $('#logsContStatisticsDIV').append('<div id="logsContStatistics" class="asemongrid" > </div>');
  }
  $('#logsContStatistics').asemonGrid({
  'title' : 'Logs contention',
  'width' : 510,
  'height' : 400,
  'minimizeheight': true,
  'rowcount': 0,
  'filterable': false,
  'sortable': true,
  'toolbar': false,
  'showaggregates': false,
  'querydata' : {'queryfile' : '../ASE/sql/sql_logcontention_statistics.php'},
  'datafieldsMapping' : { },
  'datafields': [
   { name: 'DBName' ,      type: 'string'},
   { name: 'sumAppendLog', type: 'number'},
   { name: 'sumLogWaits',  type: 'number'},
   { name: 'waitPct',      type: 'number'}
  ],

  'columns': [
   { text: 'DBName' ,      datafield: 'DBName' ,      width: 240, filterable: false},
   { text: 'sumAppendLog', datafield: 'sumAppendLog', width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
   { text: 'sumLogWaits',  datafield: 'sumLogWaits',  width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
   { text: 'waitPct',      datafield: 'waitPct',      width: 90, filterable: false, cellsformat: 'd2', filtertype: 'number', cellsalign: 'right'}
  ]
  });



  grid = $('#raStatistics').data('jqxWidget');
  if (typeof grid != 'undefined') {
    $('#raStatistics').asemonGrid('destroy');
    $('#raStatisticsDIV').append('<div id="raStatistics" class="asemongrid" > </div>');
  }
  // Check if table xxxx_SysMon AND xxxx_AseDbSpce exist
  if ( existTable(ARContext.ServerName+'_SysMon') && existTable(ARContext.ServerName+'_AseDbSpce') ) {
    if ( !existColumn(ARContext.ServerName+'_Engines', 'HkgcMaxQSize')) {
      // BEFORE V15
      sqlfile = 'sql_ra_from_sysmon_statistics.php';
      $('#raStatistics').asemonGrid({
      'title' : 'Replication Agents Statistics',
      'width' : 1200,
      'height' : 400,
      'minimizeheight': true,
      'rowcount': 0,
      'filterable': false,
      'sortable': true,
      'toolbar': false,
      'showaggregates': false,
      'querydata' : {'queryfile' : '../ASE/sql/sql_ra_from_sysmon_statistics.php',
                     'add1' : ' + 1 '},
      'datafieldsMapping' : { },
      'datafields': [
       { name: 'dbname',                  type: 'string'},
       { name: 'ra_log_records_scanned',  type: 'number'},
       { name: 'ra_log_records_processed',type: 'number'},
       { name: 'ra_xupdate_processed',    type: 'number'},
       { name: 'ra_xinsert_processed',    type: 'number'},
       { name: 'ra_xdelete_processed',    type: 'number'},
       { name: 'ra_xexec_processed',      type: 'number'},
       { name: 'ra_xcmdtext_processed',   type: 'number'},
       { name: 'ra_xwrtext_processed',    type: 'number'},
       { name: 'ra_xrowimage_processed',  type: 'number'},
       { name: 'ra_xclr_processed',       type: 'number'},
       { name: 'ra_open_xact',            type: 'number'},
       { name: 'ra_commit_xact',          type: 'number'},
       { name: 'ra_abort_xact',           type: 'number'},
       { name: 'ra_prepare_xact',         type: 'number'},
       { name: 'ra_maintuser_xact',       type: 'number'},
       { name: 'ra_packets_sent',         type: 'number'},
       { name: 'ra_full_packets_sent',    type: 'number'},
       { name: 'ra_largest_packet',       type: 'number'},
       { name: 'ra_sum_packet',           type: 'number'},
       { name: 'avg_packet',              type: 'number'},
       { name: 'ra_io_wait',              type: 'number'},
       { name: 'ra_sum_io_wait',          type: 'number'},
       { name: 'ra_longest_io_wait',      type: 'number'},
       { name: 'AvgWait_ms',              type: 'number'}
      ],
      
      'columns': [
       { text: 'DbName',              datafield: 'dbname',                   width: 140, filterable: false},
       { text: 'LogRecordsScanned',   datafield: 'ra_log_records_scanned',   width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'LogRecordsProcessed', datafield: 'ra_log_records_processed', width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'Updates',             datafield: 'ra_xupdate_processed',     width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'Inserts',             datafield: 'ra_xinsert_processed',     width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'Deletes',             datafield: 'ra_xdelete_processed',     width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'StoredProcs',         datafield: 'ra_xexec_processed',       width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'DDLLogRecords',       datafield: 'ra_xcmdtext_processed',    width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'WritetextLogRecords', datafield: 'ra_xwrtext_processed',     width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'TextImageLogRecords', datafield: 'ra_xrowimage_processed',   width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'Clrs',                datafield: 'ra_xclr_processed',        width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'OpenTran',            datafield: 'ra_open_xact',             width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'CommitTran',          datafield: 'ra_commit_xact',           width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'AbortTran',           datafield: 'ra_abort_xact',            width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'PreparedTran',        datafield: 'ra_prepare_xact',          width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'MaintUserTran',       datafield: 'ra_maintuser_xact',        width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'PacketSent',          datafield: 'ra_packets_sent',          width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'FullPacketSent',      datafield: 'ra_full_packets_sent',     width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'LargestPacket',       datafield: 'ra_largest_packet',        width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'TotalByteSent',       datafield: 'ra_sum_packet',            width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'AvgPacket',           datafield: 'avg_packet',               width: 90, filterable: false, cellsformat: 'd2', filtertype: 'number', cellsalign: 'right'},
       { text: 'WaitRs',              datafield: 'ra_io_wait',               width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'TimeWaitRs_ms',       datafield: 'ra_sum_io_wait',           width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'LongestWait_ms',      datafield: 'ra_longest_io_wait',       width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'AvgWait_ms',          datafield: 'AvgWait_ms',               width: 90, filterable: false, cellsformat: 'd2', filtertype: 'number', cellsalign: 'right'}
      ]
      });
  
    }
    else {
      // V15 or higher
      $('#raStatistics').asemonGrid({
      'title' : 'Replication Agents Statistics',
      'width' : 1200,
      'height' : 400,
      'minimizeheight': true,
      'rowcount': 0,
      'filterable': false,
      'sortable': true,
      'toolbar': false,
      'showaggregates': false,
      'querydata' : {'queryfile' : '../ASE/sql/sql_ra_from_sysmon_statistics_V15.php',
                     'add1' : ''},
      'datafieldsMapping' : { },
      'datafields': [
       { name: 'dbname',                   type: 'string'},
       { name: 'ra_log_records_scanned',   type: 'number'},
       { name: 'ra_log_records_processed', type: 'number'},
       { name: 'ra_xupdate_processed',     type: 'number'},
       { name: 'ra_xinsert_processed',     type: 'number'},
       { name: 'ra_xdelete_processed',     type: 'number'},
       { name: 'ra_xexec_processed',       type: 'number'},
       { name: 'ra_xcmdtext_processed',    type: 'number'},
       { name: 'ra_xwrtext_processed',     type: 'number'},
       { name: 'ra_xrowimage_processed',   type: 'number'},
       { name: 'ra_xclr_processed',        type: 'number'},
       { name: 'ra_open_xact',             type: 'number'},
       { name: 'ra_commit_xact',           type: 'number'},
       { name: 'ra_abort_xact',            type: 'number'},
       { name: 'ra_prepare_xact',          type: 'number'},
       { name: 'ra_maintuser_xact',        type: 'number'},
       { name: 'ra_packets_sent',          type: 'number'},
       { name: 'ra_full_packets_sent',     type: 'number'},
       { name: 'ra_sum_packet',            type: 'number'},
       { name: 'avg_packet',               type: 'number'},
       { name: 'ra_io_send',               type: 'number'},
       { name: 'ra_sum_io_send_wait',      type: 'number'},
       { name: 'AvgWaitSendRS_ms',         type: 'number'},
       { name: 'ra_io_recv',               type: 'number'},
       { name: 'ra_sum_io_recv_wait',      type: 'number'},
       { name: 'AvgWaitRecvRS_ms',         type: 'number'}
      ],
      
      'columns': [
       { text: 'DbName',              datafield: 'dbname',                   width: 140, filterable: false},
       { text: 'LogRecordsScanned',   datafield: 'ra_log_records_scanned',   width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'LogRecordsProcessed', datafield: 'ra_log_records_processed', width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'Updates',             datafield: 'ra_xupdate_processed',     width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'Inserts',             datafield: 'ra_xinsert_processed',     width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'Deletes',             datafield: 'ra_xdelete_processed',     width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'StoredProcs',         datafield: 'ra_xexec_processed',       width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'DDLLogRecords',       datafield: 'ra_xcmdtext_processed',    width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'WritetextLogRecords', datafield: 'ra_xwrtext_processed',     width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'TextImageLogRecords', datafield: 'ra_xrowimage_processed',   width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'Clrs',                datafield: 'ra_xclr_processed',        width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'OpenTran',            datafield: 'ra_open_xact',             width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'CommitTran',          datafield: 'ra_commit_xact',           width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'AbortTran',           datafield: 'ra_abort_xact',            width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'PreparedTran',        datafield: 'ra_prepare_xact',          width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'MaintUserTran',       datafield: 'ra_maintuser_xact',        width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'PacketSent',          datafield: 'ra_packets_sent',          width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'FullPacketSent',      datafield: 'ra_full_packets_sent',     width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'TotalByteSent',       datafield: 'ra_sum_packet',            width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'AvgPacket',           datafield: 'avg_packet',               width: 90, filterable: false, cellsformat: 'd2', filtertype: 'number', cellsalign: 'right'},
       { text: 'WaitSendRs',          datafield: 'ra_io_send',               width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'TimeWaitSendRs_ms',   datafield: 'ra_sum_io_send_wait',      width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'AvgWaitSendRS_ms',    datafield: 'AvgWaitSendRS_ms',         width: 90, filterable: false, cellsformat: 'd2', filtertype: 'number', cellsalign: 'right'},
       { text: 'WaitRecvRs',          datafield: 'ra_io_recv',               width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'TimeWaitRecvRs_ms',   datafield: 'ra_sum_io_recv_wait',      width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'AvgWaitRecvRS_ms',    datafield: 'AvgWaitRecvRS_ms',         width: 90, filterable: false, cellsformat: 'd2', filtertype: 'number', cellsalign: 'right'}
      ]
      });
    }
  
  }
  else
    // Check if table xxxx_RaActiv exists
    if ( existTable(ARContext.ServerName+'_RaActiv') ) {
      $('#raStatistics').asemonGrid({
      'title' : 'Replication Agents Statistics',
      'width' : 1200,
      'height' : 400,
      'minimizeheight': true,
      'rowcount': 0,
      'filterable': false,
      'sortable': true,
      'toolbar': false,
      'showaggregates': false,
      'querydata' : {'queryfile' : '../ASE/sql/sql_ra_statistics.php'},
      'datafieldsMapping' : { },
      'datafields': [
       { name: 'DbName',              type: 'string'},
       { name: 'LogRecordsScanned',   type: 'number'},
       { name: 'LogRecordsProcessed', type: 'number'},
       { name: 'Updates',             type: 'number'},
       { name: 'Inserts',             type: 'number'},
       { name: 'Deletes',             type: 'number'},
       { name: 'StoredProcs',         type: 'number'},
       { name: 'DDLLogRecords',       type: 'number'},
       { name: 'WritetextLogRecords', type: 'number'},
       { name: 'TextImageLogRecords', type: 'number'},
       { name: 'Clrs',                type: 'number'},
       { name: 'OpenTran',            type: 'number'},
       { name: 'CommitTran',          type: 'number'},
       { name: 'AbortTran',           type: 'number'},
       { name: 'PreparedTran',        type: 'number'},
       { name: 'MaintUserTran',       type: 'number'},
       { name: 'PacketSent',          type: 'number'},
       { name: 'FullPacketSent',      type: 'number'},
       { name: 'LargestPacket',       type: 'number'},
       { name: 'TotalByteSent',       type: 'number'},
       { name: 'AvgPacket',           type: 'number'},
       { name: 'WaitRs',              type: 'number'},
       { name: 'TimeWaitRs',          type: 'number'},
       { name: 'LongestWait',         type: 'number'},
       { name: 'AvgWait',             type: 'number'}
      ],
      
      'columns': [
       { text: 'DbName',              datafield: 'DbName',              width: 140, filterable: false},
       { text: 'LogRecordsScanned',   datafield: 'LogRecordsScanned',   width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'LogRecordsProcessed', datafield: 'LogRecordsProcessed', width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'Updates',             datafield: 'Updates',             width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'Inserts',             datafield: 'Inserts',             width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'Deletes',             datafield: 'Deletes',             width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'StoredProcs',         datafield: 'StoredProcs',         width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'DDLLogRecords',       datafield: 'DDLLogRecords',       width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'WritetextLogRecords', datafield: 'WritetextLogRecords', width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'TextImageLogRecords', datafield: 'TextImageLogRecords', width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'Clrs',                datafield: 'Clrs',                width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'OpenTran',            datafield: 'OpenTran',            width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'CommitTran',          datafield: 'CommitTran',          width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'AbortTran',           datafield: 'AbortTran',           width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'PreparedTran',        datafield: 'PreparedTran',        width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'MaintUserTran',       datafield: 'MaintUserTran',       width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'PacketSent',          datafield: 'PacketSent',          width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'FullPacketSent',      datafield: 'FullPacketSent',      width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'LargestPacket',       datafield: 'LargestPacket',       width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'TotalByteSent',       datafield: 'TotalByteSent',       width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'AvgPacket',           datafield: 'AvgPacket',           width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'WaitRs',              datafield: 'WaitRs',              width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'TimeWaitRs',          datafield: 'TimeWaitRs',          width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'LongestWait',         datafield: 'LongestWait',         width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
       { text: 'AvgWait',             datafield: 'AvgWait',             width: 90, filterable: false, cellsformat: 'd2', filtertype: 'number', cellsalign: 'right'}
      ]
      });
    }
    else
      $('#raStatisticsDIV').hide();

  grid = $('#procHistStatistics').data('jqxWidget');
  if (typeof grid != 'undefined') {
    $('#procHistStatistics').asemonGrid('destroy');
    $('#procHistStatisticsDIV').append('<div id="procHistStatistics" class="asemongrid" > </div>');
  }
  // Check if table xxxx_procs exists
  if ( existTable(ARContext.ServerName+'_procs') ) {
    $('#procHistStatistics').asemonGrid({
    'title' : 'SysWaits',
    'width' : 780,
    'height' : 400,
    'minimizeheight': true,
    'rowcount': 0,
    'filterable': false,
    'sortable': true,
    'toolbar': false,
    'showaggregates': false,
    'querydata' : {'queryfile' : '../ASE/sql/procHistStatistics.php',
                   'default_order_by' : 'LReads desc'},
    'datafieldsMapping' : { },
    'datafields': [
     { name: 'DB',           type: 'string'},
     { name: 'ProcName',     type: 'string'},
     { name: 'NbExec',       type: 'number'},
     { name: 'ElapsedAvg_s', type: 'number'},
     { name: 'CpuAvg',       type: 'number'},
     { name: 'PageIORte',    type: 'number'},
     { name: 'PageHitPct',   type: 'number'},
     { name: 'LReads',       type: 'number'},
     { name: 'PReads',       type: 'number'},
     { name: 'PWrites',      type: 'number'},
     { name: 'ILReads',      type: 'number'},
     { name: 'IPReads',      type: 'number'}
    ],
  
    'columns': [
     { text: 'DB',           datafield: 'DB',           width: 100, filterable: false},
     { text: 'ProcName',     datafield: 'ProcName',     width: 290, filterable: false},
     { text: 'NbExec',       datafield: 'NbExec',       width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
     { text: 'ElapsedAvg_s', datafield: 'ElapsedAvg_s', width: 90, filterable: false, cellsformat: 'd2', filtertype: 'number', cellsalign: 'right'},
     { text: 'CpuAvg',       datafield: 'CpuAvg',       width: 90, filterable: false, cellsformat: 'd2', filtertype: 'number', cellsalign: 'right'},
     { text: 'PageIORte',    datafield: 'PageIORte',    width: 90, filterable: false, cellsformat: 'd2', filtertype: 'number', cellsalign: 'right'},
     { text: 'PageHitPct',   datafield: 'PageHitPct',   width: 90, filterable: false, cellsformat: 'd2', filtertype: 'number', cellsalign: 'right'},
     { text: 'LReads',       datafield: 'LReads',       width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
     { text: 'PReads',       datafield: 'PReads',       width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
     { text: 'PWrites',      datafield: 'PWrites',      width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
     { text: 'ILReads',      datafield: 'ILReads',      width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
     { text: 'IPReads',      datafield: 'IPReads',      width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'}
    ]
    });
  }
  else 
    $('#procHistStatisticsDIV').hide();

}

  onArchCnxOpened = function(){
    $('.ASE-Summary').removeClass('nondisplay');
    refresh_ASE_Summary();
  }


</script>

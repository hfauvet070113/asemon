<div class="ASE-Fragmentation nondisplay">
  <center>
  <div class="maingrid">
    <div ID="Fragmentation_statistics" class="asemongrid singlegrid" ></div>
    <div ID="Fragmentation_statistics_mess" class="nodisplay" >  </div>
  </div>
  </center>
</div>


<script type="text/javascript">

  var height =    $('#page-content').innerHeight() - 55;

  var calccolor = function (row, column, value, defaultHtml) {
    var selector = $('#Fragmentation_statistics')[0];
    var asemondata = jQuery.data( selector , 'asemondata');
    var element = $(defaultHtml);
    var color = "";
    var severity = calcSeverity(row, column);


    if (severity == 2)
         color = 'red';
    else if (severity == 1)
         color = 'yellow';

    if (color != "") {
      element.css({ 'background-color': color, 'width': '100%', 'height': '100%', 'margin': '0px', 'padding' : '4px' });
      return element[0].outerHTML; 
    }
    else
      return defaultHtml;
  }

  if (typeof detail_type != 'undefined')
    $('.ASE-Fragmentation').removeClass('nondisplay');

  $('#Fragmentation_statistics').asemonGrid({
    'title' : 'Fragmentation statistics',
    'width' : '100%',
    'height' : height,
    'rowcount': '0',
    'editable': false,
    'filterable': true,
    'sortable': true,
    'altrows': true,
    'showaggregates': false,
    'cursor' : 'pointer',
    'beforeRefresh': function() {refresh_Fragmentation_statistics (this[0]);},
    //'afterRefresh': function() {postrefresh_Fragmentation_statistics (this);},
    'datafields': [
     { name: 'F_Timestamp', type: 'string'}
     ],
    'columns': [
     { text: 'Timestamp',         datafield: 'Timestamp',         width: 150, filterable: true}
     ],
    'datafieldsMapping' : { 'F_dbname' : 'F.dbname', 'F_owner' : 'F.owner', 'F_tabname' : 'F.tabname' , 'F_indname' : 'F.indname', 'F_indid' : 'F.indid', 'F_lockmode' : 'F.lockmode', 'F_Timestamp' : 'F.Timestamp', 'F_clu' : 'F.clu'},
    'datafieldsTS' : ['F_Timestamp'],
    'querydata' : {
                     'queryfile' : '',
                     'pagenum': 1000,
                     'default_order_by': 'F_tabname'
                  },



    'fields' : [
       {
        'id': 'pagenumFLD',
        'label': 'Min page cnt : ',
        'size': 6,
        'value': '1000',
        'onchange' : function ( ) {
          var pagenum = this.value;
          var selector = $('#Fragmentation_statistics')[0];
          var asemondata = jQuery.data( selector , 'asemondata');
          $.extend(asemondata.querydata, {'pagenum' : pagenum});
        }
      }/*,
       {
        'id': 'showlevelFLD',
        'label': 'Show Severity Level (0,1,2) : ',
        'value': '2',
        'size': 4,
        'onchange' : function ( ) {
          var severity = this.value;
          var selector = $('#Fragmentation_statistics')[0];
          var asemondata = jQuery.data( selector , 'asemondata');
          asemondata.severity = severity;
        }
      }*/
    ],
    'severity': 2




  });

  $("#Fragmentation_statistics").on('rowselect', function (event) {
    var rowindex = event.args.rowindex;
//    alert ("row "+rowindex+" selected");

    rowdata = $('#Fragmentation_statistics').jqxGrid('getrowdatabyid', rowindex);
    if (typeof rowdata == 'undefined') return 0;
    var dbname = rowdata.F_dbname;
    var owner = rowdata.F_owner;
    var tabname = rowdata.F_tabname;
    var indid = rowdata.F_indid;
    var indname = rowdata.F_indname;
    var lockmode = rowdata.F_lockmode;
    var clu = rowdata.F_clu;
    if (clu == "clu")
      clu = 'YES';
    else
      clu = 'NO';

    openWindowFromGrid ("#Fragmentation_statistics", "detail_page.php", {ARContextJSON: ARContext, 'displaylevel' : 2, 'detail_type': 'FRAGMENTDETAIL', 'dbname': dbname, 'owner': owner, 'tabname': tabname, 'indid': indid, 'indname': indname, 'lockmode': lockmode, 'clu': clu});
  });


  function refresh_Fragmentation_statistics (grid) {
    var asemondata = jQuery.data(grid, 'asemondata');
    var FragmentExists = false;
    var has_Dpage_utilization = 0;
    var has_oam_cols = 0;
    var cols = [];
    var fields = [];
    var cols_oam = [];
    var fields_oam = [];

    if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_Fragment') )  )
      FragmentExists = true;
    if ( (ARContext.ServerName!="") && ( existColumn(ARContext.ServerName+'_Fragment', 'Dpage_utilization') )  ) {
      has_Dpage_utilization = 1;
    }

    if ( (ARContext.ServerName!="") && ( existColumn(ARContext.ServerName+'_Fragment', 'oamapgcnt') )  ) {
      has_oam_cols = 1;
    }

    if ( !FragmentExists) {
      $('#Fragmentation_statistics').hide();
      $('#Fragmentation_statistics_mess').show();
      $('#Fragmentation_statistics_mess').html('<p>Table '+ARContext.ServerName+'_Fragment does not exists</p><p>Activate Asemon_logger\'s collector : "Fragment.xml"</p>');
      $.extend(asemondata, {'querydata' : {'queryfile' : '', 'query': ''}});
      return;
    }
    else {
      $('#Fragmentation_statistics').show();
      $('#Fragmentation_statistics_mess').hide();
    }







    fields =  [
           { name: 'F_Timestamp',           type: 'string'},
           { name: 'F_dbname',              type: 'string'},
           { name: 'F_owner',               type: 'string'},
           { name: 'F_tabname',             type: 'string'},
           { name: 'F_indname',             type: 'string'},
           { name: 'F_indid',               type: 'number'},
           { name: 'F_lockmode',            type: 'string'},
           { name: 'F_clu',                 type: 'string'},
           { name: 'avg_Rowcnt',            type: 'number'},
           { name: 'avg_pagecnt',           type: 'number'},
           { name: 'avg_leafcnt',           type: 'number'},
           { name: 'avg_emptypgcnt',        type: 'number'},
           { name: 'avg_Forwardrowcnt',     type: 'number'},
           { name: 'avg_Delrowcnt',         type: 'number'},
           { name: 'avg_dpageCR',           type: 'number'},
           { name: 'avg_ipageCR',           type: 'number'},
           { name: 'avg_drowCR',            type: 'number'},
           { name: 'avg_space_utilization', type: 'number'},
           { name: 'avg_largeIO_eff',       type: 'number'},
           { name: 'avg_Dpage_utilization', type: 'number'},
           { name: 'object_Mb',             type: 'number'},
           { name: 'delta_Mb',              type: 'number'}
    ];
    cols = [
           { text: 'Timestamp',         datafield: 'F_Timestamp',           width: 85,  filterable: true},
           { text: 'dbname',            datafield: 'F_dbname',              width: 100, filterable: true},
           { text: 'owner',             datafield: 'F_owner',               width: 90,  filterable: true},
           { text: 'tabname',           datafield: 'F_tabname',             width: 130, filterable: true},
           { text: 'indname',           datafield: 'F_indname',             width: 130, filterable: true},
           { text: 'indid',             datafield: 'F_indid',               width: 50,  filterable: true, filtertype: 'number',  cellsalign: 'right'},
           { text: 'lockmode',          datafield: 'F_lockmode',            width: 90,  filterable: true},
           { text: 'clu',               datafield: 'F_clu',                 width: 70,  filterable: true},
           { text: 'Rowcnt',            datafield: 'avg_Rowcnt',            width: 90,  filterable: false, cellsformat: 'd', cellsalign: 'right'},
           { text: 'pagecnt',           datafield: 'avg_pagecnt',           width: 90,  filterable: false, cellsformat: 'd', cellsalign: 'right'},
           { text: 'leafcnt',           datafield: 'avg_leafcnt',           width: 90,  filterable: false, cellsformat: 'd', cellsalign: 'right'},
           { text: 'Emptpgcnt',         datafield: 'avg_emptypgcnt',        width: 90,  filterable: false, cellsformat: 'd', cellsalign: 'right', cellsrenderer: calccolor},
           { text: 'Fwdrowcnt',         datafield: 'avg_Forwardrowcnt',     width: 90,  filterable: false, cellsformat: 'd', cellsalign: 'right', cellsrenderer: calccolor},
           { text: 'Delrowcnt',         datafield: 'avg_Delrowcnt',         width: 90,  filterable: false, cellsformat: 'd', cellsalign: 'right', cellsrenderer: calccolor},
           { text: 'dpageCR',           datafield: 'avg_dpageCR',           width: 90,  filterable: false, cellsformat: 'd', cellsalign: 'right', cellsrenderer: calccolor},
           { text: 'ipageCR',           datafield: 'avg_ipageCR',           width: 90,  filterable: false, cellsformat: 'd', cellsalign: 'right', cellsrenderer: calccolor},
           { text: 'drowCR',            datafield: 'avg_drowCR',            width: 90,  filterable: false, cellsformat: 'd', cellsalign: 'right', cellsrenderer: calccolor},
           { text: 'space_utilization', datafield: 'avg_space_utilization', width: 90,  filterable: false, cellsformat: 'd', cellsalign: 'right'},
           { text: 'largeIO_eff',       datafield: 'avg_largeIO_eff',       width: 90,  filterable: false, cellsformat: 'd', cellsalign: 'right'/*, cellsrenderer: calccolor*/},
           //{ text: 'Dpage_utilization', datafield: 'avg_Dpage_utilization', width: 90,  filterable: false, cellsformat: 'd', cellsalign: 'right', cellsrenderer: calccolor},
           { text: 'Object_Mb',         datafield: 'object_Mb',             width: 90,  filterable: false, cellsformat: 'd2', cellsalign: 'right'},
           { text: 'Delta_Mb',          datafield: 'delta_Mb',              width: 90,  filterable: false, cellsformat: 'd2', cellsalign: 'right'}
    ];

    fields_oam =  [
           { name: 'avg_oamapgcnt',           type: 'number'},
           { name: 'avg_oampagecnt',          type: 'number'}
    ];

    cols_oam = [
           { text: 'oamapgcnt',         datafield: 'avg_oamapgcnt',         width: 90,  filterable: false, cellsformat: 'd', cellsalign: 'right'},
           { text: 'oampagecnt',        datafield: 'avg_oampagecnt',        width: 90,  filterable: false, cellsformat: 'd', cellsalign: 'right'}
    ];
 
    if (has_oam_cols==1) {
      fields = fields.concat(fields_oam);
      cols = cols.concat(cols_oam);
    }




    $(grid).asemonGrid({
      'querydata' : {
                      'queryfile' : '../ASE/sql/sql_fragment_statistics.php',
                      'has_Dpage_utilization': has_Dpage_utilization,
                      'has_oam_cols': has_oam_cols
                    },
      'datafields': fields,
      'columns': cols 
    });
   
  }




  function calcSeverity(row, colname) {
    var severity = 0;
    var ratio_pg = 0;
    var ratioCR = 1.;
    var pageUtil = 100;
    var dspaceCR = 1.;
    var ispaceCR = 1.;
    var drowCR   = 1.;
    var rowdata = {};

    if (colname == "") return 0;
    rowdata = $('#Fragmentation_statistics').jqxGrid('getrowdatabyid', row);
    if (typeof rowdata == 'undefined') return 0;

    if (rowdata.F_indid == 0 )
    {
    
      // Check empty page count
      if ( (colname=="avg_emptypgcnt") && (rowdata.avg_pagecnt > 0) )  {
         ratio_pg = rowdata.avg_emptypgcnt / rowdata.avg_pagecnt;
      }
    
    
      // Check forwarded rows
      if ( (colname=="avg_Forwardrowcnt") && (rowdata.avg_Rowcnt > 0) )  {
         ratio_pg = rowdata.avg_Forwardrowcnt / rowdata.avg_Rowcnt;
      }
      
      // Check deleted rows
      if ( (colname=="avg_Delrowcnt") && (rowdata.avg_Rowcnt > 0) )  {
         ratio_pg = rowdata.avg_Delrowcnt / rowdata.avg_Rowcnt;
      }
    
    
    
      if (colname=="avg_dpageCR") ratioCR = rowdata.avg_dpageCR;
    
    
        
    }
    if ( (rowdata.F_indid > 1 ) && (rowdata.F_indid < 255 ) ) {
        // This is for a non clustered index	 (or DOL clustered index)
        if (colname=="avg_ipageCR") ratioCR = rowdata.avg_ipageCR;
    
         // Check INDEX empty page count
        if ( (colname=="avg_emptypgcnt") && (rowdata.avg_leafcnt > 0) )  {
          ratio_pg = rowdata.avg_emptypgcnt / rowdata.avg_leafcnt;
        }
    }
    
    if ( (colname == "avg_drowCR") && (rowdata.F_clu == "clu" ) )
    {
         drowCR = rowdata.avg_drowCR;
    }
  
    if (colname == "avg_largeIO_eff") ratioCR = rowdata.avg_largeIO_eff;

    if (colname == "avg_Dpage_utilization") ratioCR = rowdata.avg_Dpage_utilization;

    if (ratio_pg > .2 ) severity = 2;
      else if (ratio_pg > .05) severity = 1;

    if (ratioCR < .5 ) severity = 2 ;
      else if (ratioCR < .7) severity = 1;

    //if (pageUtil < 50 ) severity = 2 ;
    //   else if (pageUtil < 90) severity = 1;

    if (dspaceCR < .50 ) severity = 2 ;
      else if (dspaceCR < .80) severity = 1;

    if (ispaceCR < .20 ) severity = 2 ;
      else if (ispaceCR < .5) severity = 1;

    if (drowCR < .50 ) severity = 2 ;
      else if (drowCR < .8) severity = 1;

    return severity;
  }


  onArchCnxOpened = function(){
    $('.ASE-Fragmentation').removeClass('nondisplay');
    $('#Fragmentation_statistics').asemonGrid('refresh');
  }

</script>
<div class="ASE-Spinlocks nondisplay">
  <center>
  <div class="maingrid">
    <div ID="Spinlocks" class="asemongrid singlegrid" ></div>
    <div ID="Spinlocks_mess" class="nodisplay" >  </div>
  </div>
  </center>
</div>

<script type="text/javascript">
  var height =    $('#page-content').innerHeight() - 55;
  var field_id_normalized_Exists = 0;

  if (typeof detail_type != 'undefined')
    $('.ASE-Spinlocks').removeClass('nondisplay');

  $('#Spinlocks').asemonGrid({
    'title' : 'Spinlocks Statistics',
    'width' : '100%',
    'height' : height,
    'rowcount': 200,
    'editable': false,
    'filterable': true,
    'cursor' : 'pointer',
    'querydata': {'queryfile' : '', 'groupByName' : 'Name'},
    'beforeRefresh': function() {refresh_spinlocks_statistics (this[0]);},
    'datafieldsMapping': {'name': 'field_name'},
    'datafields': [
     { name: 'fid',        type: 'number'}
      ],
    'columns': [
     { text: 'Field_id',                           datafield: 'fid',       width: 70,  filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number'}
      ],
    'buttons' : [
       {
        'id': 'GroupbyBTN',
        'text': 'Ungroup',
        'onclick' : function ( ) {
          var groupByName;
          if (this.value == 'Ungroup') {
            this.value = 'Group By Name';
            groupByName = '';
          }
          else {
            this.value = 'Ungroup';
            groupByName = 'Name';
          }
          var selector = $('#Spinlocks')[0];
          var asemondata = jQuery.data( selector , 'asemondata');
          $.extend(asemondata.querydata, {'groupByName' : groupByName});
          $(selector).asemonGrid('refresh');
        }
       }
      ]
  });

  $("#Spinlocks").on('rowselect', function (event) {
    var rowindex = event.args.rowindex;
    //alert ("row "+rowindex+" selected");
    var selector = $('#Spinlocks')[0];
    var asemondata = jQuery.data( selector , 'asemondata');
    var field_id_normalized = 0;

    rowdata = $('#Spinlocks').jqxGrid('getrowdatabyid', rowindex);
    if (typeof rowdata == 'undefined') return 0;
    var name = rowdata.name;
    var fid = rowdata.fid;
    var fldname = rowdata.fldname;
    if (asemondata.querydata.groupByName != "")
      fid = "";
      
    if (field_id_normalized_Exists == 1)
      field_id_normalized = rowdata.field_id_normalized;

    openWindowFromGrid ("#Spinlocks", "detail_page.php", {ARContextJSON: ARContext, 'displaylevel' : 1, 'detail_type': 'SPINLOCKDETAIL', 'name': name, 'fid': fid, 'fldname': fldname, 'field_id_normalized_Exists': field_id_normalized_Exists, 'field_id_normalized': field_id_normalized});
  });

function refresh_spinlocks_statistics (grid) {
  var asemondata = jQuery.data(grid, 'asemondata');
  var SysMon_Exists = 0;
  var cols = [];
  var fields = [];


  if ( (ARContext.ServerName!="") && existTable(ARContext.ServerName+'_SysMon') )
    SysMon_Exists = 1;
  if ( SysMon_Exists == 0) {
    $('#Spinlocks').hide();
    $('#Spinlocks_mess').show();
    $('#Spinlocks_mess').html('<p>Spinlock data is not available. The sysmon collector has not been activated for server '+ARContext.ServerName+'<P> (Add SysMon.xml, SysMonFld.xml, SysDev.xml, SysCaches.xml and SysConf.xml in the asemon_logger config file)</p>');
    $.extend(asemondata, {'querydata' : {'queryfile' : ''}});
    return;
  }
  else {
    $('#Spinlocks').show();
    $('#Spinlocks_mess').hide();
  }

  if ( (ARContext.ServerName!="") && existColumn(ARContext.ServerName+'_SysMon', 'field_id_normalized') ) {
    field_id_normalized_Exists = 1;
    field_id_normalized_datafield = [{ name: 'field_id_normalized',        type: 'number'}];
  }
  else {
    field_id_normalized_Exists = 0;
    field_id_normalized_datafield = [];
  }


  $(grid).asemonGrid({
    'querydata' : {'queryfile' : '../ASE/sql/sql_spinlocks_statistics.php',
                   'default_order_by' : 'totspins desc',
                   'field_id_normalized_Exists' : field_id_normalized_Exists
                  },
     'datafields': [
     { name: 'fid',        type: 'number'},
     { name: 'name',       type: 'string'},
     { name: 'totgrabs',   type: 'number'},
     { name: 'totwaits',   type: 'number'},
     { name: 'totspins',   type: 'number'},
     { name: 'ratio1',     type: 'number'},
     { name: 'ratio2',     type: 'number'},
     { name: 'fldname',    type: 'string'}
      ]
     .concat(field_id_normalized_datafield),
     'columns': [
     { text: 'Field_id',                           datafield: 'fid',       width: 70,  filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number'},
     { text: 'Name',                               datafield: 'name',      width: 150, filterable: true},
     { text: 'Grabs',                              datafield: 'totgrabs',  width: 110,  filterable: false, cellsformat: 'd', cellsalign: 'right' },
     { text: 'Waits',                              datafield: 'totwaits',  width: 110,  filterable: false, cellsformat: 'd', cellsalign: 'right' },
     { text: 'Spins',                              datafield: 'totspins',  width: 110,  filterable: false, cellsformat: 'd', cellsalign: 'right' },
     { text: 'Ratio(Spinsperwaits)',               datafield: 'ratio1',    width: 160,  filterable: false, cellsformat: 'd2', cellsalign: 'right' },
     { text: '%Spinlockcontention(Waitspergrabs)', datafield: 'ratio2',    width: 220,  filterable: false, cellsformat: 'd2', cellsalign: 'right' },
      { text: '', width: 25,  filterable: false}
      ]
  });


}

  onArchCnxOpened = function(){
    $('.ASE-Spinlocks').removeClass('nondisplay');
    $('#Spinlocks').asemonGrid('refresh');
  }


</script>
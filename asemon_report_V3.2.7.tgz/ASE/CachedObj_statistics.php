<div class="ASE-Objects_Cached nondisplay">
  <center>
  <div class="maingrid">
    <div ID="cachedobj_statistics" class="asemongrid singlegrid" ></div>
    <div ID="cachedobj_statistics_mess" class="nodisplay" >  </div>
  </div>
  </center>
</div>


<script type="text/javascript">

  var height =    $('#page-content').innerHeight() - 55;

  if (typeof detail_type != 'undefined')
    $('.ASE-Objects_Cached').removeClass('nondisplay');

  $('#cachedobj_statistics').asemonGrid({
    'title' : 'Cached Objects Statistics',
    'width' : '100%',
    'height' : height,
    'rowcount': '200',
    'editable': false,
    'filterable': true,
    'cursor' : 'pointer',
    'beforeRefresh': function() {refresh_cached_objects_statistics (this[0]);},
    'querydata' : {
                     'queryfile' : ''
                  },
    'datafields': [
     { name: 'CacheName', type: 'string'}
     ],
    'columns': [
     { text: 'CacheName', datafield: 'CacheName',     width: 100, filterable: false}
     ],
    'datafieldsMapping' : {'OwnerN': "isnull(OwnerName,'dbo')" },
    'buttons' : [
       {
        'id': 'TopObjBTN',
        'text': 'Top Objects in caches',
        'onclick' : function ( ) {
          openWindow ("detail_page.php", {ARContextJSON: ARContext, 'displaylevel' : 1, 'detail_type': 'TOPOBJINCACHE'});
        }
       }
     ]
    //'datafieldsTS' : ['Loggedindt']
  });

  $("#cachedobj_statistics").on('rowselect', function (event) {
    var rowindex = event.args.rowindex;
    //alert ("row "+rowindex+" selected");

    rowdata = $('#cachedobj_statistics').jqxGrid('getrowdatabyid', rowindex);
    if (typeof rowdata == 'undefined') return 0;
    var ObjectDbName = rowdata.DBName;
    var ObjectName = rowdata.ObjectName;
    var OwnerUserID = rowdata.OwnerUserID;
    var OwnerName = rowdata.OwnerN;
    var ObjectID = rowdata.ObjectID;

    openWindowFromGrid ("#cachedobj_statistics", "detail_page.php", {ARContextJSON: ARContext, 'displaylevel' : 2, 'detail_type': 'OBJDETAIL', 'ObjectDbName': ObjectDbName, 'ObjectName': ObjectName, 'ObjectID': ObjectID, 'OwnerUserID': OwnerUserID, 'OwnerName': OwnerName});
  });

  function refresh_cached_objects_statistics (grid) {
    var asemondata = jQuery.data(grid, 'asemondata');
    var CachedObjExists = false;
    var support150 = false;
    var cols150 = [];
    var fields150 = [];
    var queryfile = '../ASE/sql/sql_CachedObj_statistics.php';
    if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_CachedObj') )  )
      CachedObjExists = true;
    if ( (ARContext.ServerName!="") && ( existColumn(ARContext.ServerName+'_CachedObj', 'PartitionName') )  ) {
      support150 = true;
      queryfile = '../ASE/sql/sql_CachedObj_V15_statistics.php';
    }
    
    if ( !CachedObjExists) {
      $('#cachedobj_statistics').hide();
      $('#cachedobj_statistics_mess').show();
      $('#cachedobj_statistics_mess').html('<p>Table '+ARContext.ServerName+'_CachedObj does not exists</p><p>Activate Asemon_logger\'s collector : "CachedObj.xml"</p>');
      $.extend(asemondata, {'querydata' : {'queryfile' : '', 'query': ''}});
      return;
    }
    else {
      $('#cachedobj_statistics').show();
      $('#cachedobj_statistics_mess').hide();
    }

    if (support150)
    {
          fields150 = [
                 { name: 'PartitionName',  type: 'string'},
                 { name: 'avgTotalSizeKB', type: 'number'},
                 { name: 'PartitionID',    type: 'number'}
          ];
          cols150= [
                 { text: 'PartitionName ', datafield: 'PartitionName',  width: 150, filterable: true},
                 { text: 'avgTotalSizeKB', datafield: 'avgTotalSizeKB', width: 90, filterable: false, cellsformat: 'd0', cellsalign: 'right' },
                 { text: 'PartitionID   ', datafield: 'PartitionID',    width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right'}
          ];
    }

  
    $(grid).asemonGrid({
      'querydata' : {
                     'queryfile' : queryfile,
                     'support150' : support150,
                     'default_order_by': 'avgCachedKB DESC'
                    },
      'datafields': [
         { name: 'CacheName',             type: 'string'},
         { name: 'DBName',                type: 'string'},
         { name: 'OwnerN',                type: 'string'},
         { name: 'ObjectName',            type: 'string'},
         { name: 'IndexID',               type: 'number'},
         { name: 'ObjectType',            type: 'string'},
         { name: 'minCachedKB',           type: 'number'},
         { name: 'avgCachedKB',           type: 'number'},
         { name: 'maxCachedKB',           type: 'number'},
         { name: 'avgProcessesAccessing', type: 'number'}
        ]
        .concat(fields150).concat(
        [
         { name: 'CacheID',               type: 'number'},
         { name: 'DBID',                  type: 'number'},
         { name: 'ObjectID',              type: 'number'},
         { name: 'OwnerUserID',           type: 'number'}
        ]),
      'columns': [
         { text: 'CacheName',             datafield: 'CacheName',             width: 100, filterable: true},
         { text: 'DBName',                datafield: 'DBName',                width: 120, filterable: true},
         { text: 'OwnerID',               datafield: 'OwnerUserID',           width: 70, filterable: true,  cellsformat: 'd', cellsalign: 'right'},
         { text: 'OwnerName',             datafield: 'OwnerN',                width: 90, filterable: true},
         { text: 'ObjectName',            datafield: 'ObjectName',            width: 150, filterable: true},
         { text: 'IndexID',               datafield: 'IndexID',               width: 50,  filterable: true, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
         { text: 'ObjectType',            datafield: 'ObjectType',            width: 90, filterable: true},
         { text: 'minCachedKB',           datafield: 'minCachedKB',           width: 90, filterable: true, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right' ,aggregates: ['min']},
         { text: 'avgCachedKB',           datafield: 'avgCachedKB',           width: 90, filterable: true, cellsformat: 'd0',  filtertype: 'number', cellsalign: 'right' ,aggregates: ['avg']},
         { text: 'maxCachedKB',           datafield: 'maxCachedKB',           width: 90, filterable: true, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right' ,aggregates: ['max']},
         { text: 'avgProcessesAccessing', datafield: 'avgProcessesAccessing', width: 90, filterable: true, cellsformat: 'd2',  filtertype: 'number', cellsalign: 'right' ,aggregates: ['avg']}
        ]
         .concat(cols150).concat(
        [
         { text: 'CacheID',               datafield: 'CacheID',               width: 50, filterable: true,  cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
         { text: 'DBID',                  datafield: 'DBID',                  width: 90, filterable: true,  cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
         { text: 'ObjectID',              datafield: 'ObjectID',              width: 90, filterable: true,  cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'}
        ])
    });
   
  }

  onArchCnxOpened = function(){
    $('.ASE-Objects_Cached').removeClass('nondisplay');
    $('#cachedobj_statistics').asemonGrid('refresh');
  }

</script>
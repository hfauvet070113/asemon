<center>
<div class="">
  <h1 id="headertitle"> Trends for procedure = <?php echo $ProcName ?> in DBID =  <?php echo $DBID ?></h1>

  <div id="message_TrendProc"> </div>
  
  <div id="Executions" class="trendchart" > </div>
  <div id="NbPlans" class="trendchart" > </div>
  <div id="AvgLogicalReads" class="trendchart" > </div>
  <div id="AvgPhysicalReads" class="trendchart" > </div>
  <div id="AvgCpuTime" class="trendchart" > </div>
  <div id="AvgWaitTime" class="trendchart" > </div>
  <div id="AvgMemUsageKB" class="trendchart" > </div>
  <div id="AvgPagesModified" class="trendchart" > </div>
  <div id="AvgPacketsSent" class="trendchart" > </div>
  <div id="AvgPacketsReceived" class="trendchart" > </div>
  <div id="AvgRowsAffected" class="trendchart" > </div>

</div>
</center>

<script type="text/javascript">

var ProcName = "<?php echo $ProcName ?>"; 
var DBID = <?php echo $DBID ?>;
var support157 = 0;


var queryrangesel = "select Ts=convert(varchar,convert(datetime,convert(varchar,day,3),3),109),"
                  + " Value=AVG(case when Executions <0 then 0 else Executions end)  /* Ignore negatives values */" 
                  + " from "+ARContext.ServerName+"_TrendProc" 
                  + " where ProcName='"+ProcName+"'"
                  + "   and DBID="+DBID
                  + " group by convert(datetime,convert(varchar,day,3),3)"
                  + " order by convert(datetime,convert(varchar,day,3),3)";
var delayRangeSel = 86400;
var setTimestampToRSExtremes=1;

//function refresh_trendProc(){
onArchCnxOpened = function (){
  var height =    $('#page-content').innerHeight() - $('#headertitle').height() - 65;
  var graph;

  if ( ! existTable(ARContext.ServerName+'_TrendProc') || ! existTable(ARContext.ServerName+'_TrendsCfg') ) {
    $('#message_TrendProc').append('TrendProc data is not available. The indicators aggregation has not been activated for server "'+ARContext.ServerName+'".<P> (Add Trends.xml in the asemon_logger config file)');
  }
  else {
    if ( existColumn(ARContext.ServerName+'_CachedPrc', 'ExecutionCount') )
      support157 = 1;

    // Display trends up to now  MARCHE PAS POUR L'INSTANT (modifier asemonChart !!!!!!!!!)
    ARContext.EndTimestamp = '01/01/2100';

    graph = $('#Executions').highcharts();
    if (typeof graph == 'undefined')
      //graph.destroy();
      $('#Executions').asemonChart({
      title: {
        text: 'Executions (number per day)'
      },
      queryFile : '../ASE/sql/graphTrendProc.php',
      data: {
        indic: 'RequestCnt',
        DBID: DBID,
        ProcName: ProcName
      },
      tableName : 'TrendProc',
      chart: {
               marginTop: 50,
               marginBottom: 60,
          type: 'area'
      },
      series: [
        {
          name: 'Value'
        }
      ],
      legend: {
         enabled: false
        },
      xAxis: {
        labels : {
          format: '{value:%Y-%m-%d}',
        }
      },
      tooltip: {
            xDateFormat: '%Y-%m-%d'
        }
      });
    $('#Executions').asemonChart('refresh');
    
    
    graph = $('#NbPlans').highcharts();
    if (typeof graph == 'undefined')
      //graph.destroy();
      $('#NbPlans').asemonChart({
      title: {
        text: 'NbPlans (number per day)'
      },
      queryFile : '../ASE/sql/graphTrendProc.php',
      data: {
        indic: 'NbPlans',
        DBID: DBID,
        ProcName: ProcName
      },
      tableName : 'TrendProc',
      chart: {
               marginTop: 50,
               marginBottom: 60,
          type: 'area'
      },
      series: [
        {
          name: 'Value'
        }
      ],
      xAxis: {
        labels : {
          format: '{value:%Y-%m-%d}',
        }
      },
      tooltip: {
            xDateFormat: '%Y-%m-%d'
        },
      legend: {
         enabled: false
        }
    
      });
    $('#NbPlans').asemonChart('refresh');
    
    
    graph = $('#AvgLogicalReads').highcharts();
    if (typeof graph == 'undefined')
      //graph.destroy();
      $('#AvgLogicalReads').asemonChart({
      title: {
        text: 'AvgLogicalReads (avg per execution of proc)'
      },
      queryFile : '../ASE/sql/graphTrendProc_withAVGfix.php',
      data: {
        indic: 'AvgLogicalReads',
        DBID: DBID,
        ProcName: ProcName
      },
      tableName : 'TrendProc',
      chart: {
               marginTop: 50,
               marginBottom: 60,
          type: 'area'
      },
      series: [
        {
          name: 'Value'
        }
      ],
      xAxis: {
        labels : {
          format: '{value:%Y-%m-%d}',
        }
      },
      tooltip: {
            xDateFormat: '%Y-%m-%d'
        },
      legend: {
         enabled: false
        }
    
      });
    $('#AvgLogicalReads').asemonChart('refresh');
    
    
    graph = $('#AvgPhysicalReads').highcharts();
    if (typeof graph == 'undefined')
      //graph.destroy();
      $('#AvgPhysicalReads').asemonChart({
      title: {
        text: 'AvgPhysicalReads (avg per execution of proc)'
      },
      queryFile : '../ASE/sql/graphTrendProc_withAVGfix.php',
      data: {
        indic: 'AvgPhysicalReads',
        DBID: DBID,
        ProcName: ProcName
      },
      tableName : 'TrendProc',
      chart: {
               marginTop: 50,
               marginBottom: 60,
          type: 'area'
      },
      series: [
        {
          name: 'Value'
        }
      ],
      xAxis: {
        labels : {
          format: '{value:%Y-%m-%d}',
        }
      },
      tooltip: {
            xDateFormat: '%Y-%m-%d'
        },
      legend: {
         enabled: false
        }
    
      });
    $('#AvgPhysicalReads').asemonChart('refresh');
    
    
    graph = $('#AvgCpuTime').highcharts();
    if (typeof graph == 'undefined')
      //graph.destroy();
      $('#AvgCpuTime').asemonChart({
      title: {
        text: 'AvgCpuTime (avg per execution of proc)'
      },
      queryFile : '../ASE/sql/graphTrendProc_withAVGfix.php',
      data: {
        indic: 'AvgCpuTime',
        DBID: DBID,
        ProcName: ProcName
      },
      tableName : 'TrendProc',
      chart: {
               marginTop: 50,
               marginBottom: 60,
          type: 'area'
      },
      series: [
        {
          name: 'Value'
        }
      ],
      xAxis: {
        labels : {
          format: '{value:%Y-%m-%d}',
        }
      },
      tooltip: {
            xDateFormat: '%Y-%m-%d'
        },
      legend: {
         enabled: false
        }
    
      });
    $('#AvgCpuTime').asemonChart('refresh');
    
    
    graph = $('#AvgWaitTime').highcharts();
    if (typeof graph == 'undefined')
      //graph.destroy();
      $('#AvgWaitTime').asemonChart({
      title: {
        text: 'AvgWaitTime (avg per execution of proc)'
      },
      queryFile : '../ASE/sql/graphTrendProc_withAVGfix.php',
      data: {
        indic: 'AvgWaitTime',
        DBID: DBID,
        ProcName: ProcName
      },
      tableName : 'TrendProc',
      chart: {
               marginTop: 50,
               marginBottom: 60,
          type: 'area'
      },
      series: [
        {
          name: 'Value'
        }
      ],
      xAxis: {
        labels : {
          format: '{value:%Y-%m-%d}',
        }
      },
      tooltip: {
            xDateFormat: '%Y-%m-%d'
        },
      legend: {
         enabled: false
        }
    
      });
    $('#AvgWaitTime').asemonChart('refresh');
    
    
    graph = $('#AvgMemUsageKB').highcharts();
    if (typeof graph == 'undefined')
      //graph.destroy();
      $('#AvgMemUsageKB').asemonChart({
      title: {
        text: 'AvgMemUsageKB (avg per execution of proc)'
      },
      queryFile : '../ASE/sql/graphTrendProc.php',
      data: {
        indic: 'AvgMemUsageKB',
        DBID: DBID,
        ProcName: ProcName
      },
      tableName : 'TrendProc',
      chart: {
               marginTop: 50,
               marginBottom: 60,
          type: 'area'
      },
      series: [
        {
          name: 'Value'
        }
      ],
      xAxis: {
        labels : {
          format: '{value:%Y-%m-%d}',
        }
      },
      tooltip: {
            xDateFormat: '%Y-%m-%d'
        },
      legend: {
         enabled: false
        }
    
      });
    $('#AvgMemUsageKB').asemonChart('refresh');
    
    if (support157 == 0) {
      // Old counters no longer avail. in 15.7
      graph = $('#AvgPagesModified').highcharts();
      if (typeof graph == 'undefined')
        //graph.destroy();
        $('#AvgPagesModified').asemonChart({
        title: {
          text: 'AvgPagesModified (avg per execution of proc)'
        },
        queryFile : '../ASE/sql/graphTrendProc.php',
        data: {
          indic: 'AvgPagesModified',
          DBID: DBID,
          ProcName: ProcName
        },
        tableName : 'TrendProc',
        chart: {
               marginTop: 50,
               marginBottom: 60,
            type: 'area'
        },
        series: [
          {
            name: 'Value'
          }
        ],
        xAxis: {
          labels : {
            format: '{value:%Y-%m-%d}',
          }
        },
        tooltip: {
            xDateFormat: '%Y-%m-%d'
        },
        legend: {
           enabled: false
          }
      
        });
      $('#AvgPagesModified').asemonChart('refresh');
      
      
      graph = $('#AvgPacketsSent').highcharts();
      if (typeof graph == 'undefined')
        //graph.destroy();
        $('#AvgPacketsSent').asemonChart({
        title: {
          text: 'AvgPacketsSent (avg per execution of proc)'
        },
        queryFile : '../ASE/sql/graphTrendProc.php',
        data: {
          indic: 'AvgPacketsSent',
          DBID: DBID,
          ProcName: ProcName
        },
        tableName : 'TrendProc',
        chart: {
               marginTop: 50,
               marginBottom: 60,
            type: 'area'
        },
        series: [
          {
            name: 'Value'
          }
        ],
        xAxis: {
          labels : {
            format: '{value:%Y-%m-%d}',
          }
        },
        xAxis: {
          labels : {
            format: '{value:%Y-%m-%d}',
          }
        },
        tooltip: {
            xDateFormat: '%Y-%m-%d'
        },
        legend: {
           enabled: false
          }
      
        });
      $('#AvgPacketsSent').asemonChart('refresh');
      
      
      graph = $('#AvgPacketsReceived').highcharts();
      if (typeof graph == 'undefined')
        //graph.destroy();
        $('#AvgPacketsReceived').asemonChart({
        title: {
          text: 'AvgPacketsReceived (avg per execution of proc)'
        },
        queryFile : '../ASE/sql/graphTrendProc.php',
        data: {
          indic: 'AvgPacketsReceived',
          DBID: DBID,
          ProcName: ProcName
        },
        tableName : 'TrendProc',
        chart: {
               marginTop: 50,
               marginBottom: 60,
            type: 'area'
        },
        series: [
          {
            name: 'Value'
          }
        ],
        xAxis: {
          labels : {
            format: '{value:%Y-%m-%d}',
          }
        },
        tooltip: {
            xDateFormat: '%Y-%m-%d'
        },
        legend: {
           enabled: false
          }
      
        });
      $('#AvgPacketsReceived').asemonChart('refresh');
      
      
      graph = $('#AvgRowsAffected').highcharts();
      if (typeof graph == 'undefined')
        //graph.destroy();
        $('#AvgRowsAffected').asemonChart({
        title: {
          text: 'AvgRowsAffected (avg per execution of proc)'
        },
        queryFile : '../ASE/sql/graphTrendProc.php',
        data: {
          indic: 'AvgRowsAffected',
          DBID: DBID,
          ProcName: ProcName
        },
        tableName : 'TrendProc',
        chart: {
               marginTop: 50,
               marginBottom: 60,
            type: 'area'
        },
        series: [
          {
            name: 'Value'
          }
        ],
        xAxis: {
          labels : {
            format: '{value:%Y-%m-%d}',
          }
        },
        tooltip: {
            xDateFormat: '%Y-%m-%d'
        },
        legend: {
           enabled: false
          }
      
        });
      $('#AvgRowsAffected').asemonChart('refresh');
    }
    else {
      $('#AvgPagesModified').remove();
      $('#AvgPacketsSent').remove();
      $('#AvgPacketsReceived').remove();
      $('#AvgRowsAffected').remove();
    }
  }



}


</script>


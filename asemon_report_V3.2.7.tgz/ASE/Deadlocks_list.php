<div class="ASE-Deadlocks nondisplay">
  <center>
  <div class="maingrid">
    <div ID="deadlock_list" class="asemongrid singlegrid" ></div>
  </div>
  </center>
</div>


<script type="text/javascript">

  var height =    $('#page-content').innerHeight() - 55;

  if (typeof detail_type != 'undefined')
    $('.ASE-Deadlocks').removeClass('nondisplay');

  $('#deadlock_list').asemonGrid({
    'title' : 'Deadlocks list',
    'width' : '100%',
    'height' : height,
    'rowcount': '200',
    'filterable': true,
    'sortable': false,
    'altrows': false,
    //'cursor' : 'pointer',
    'beforeRefresh': function() {refresh_deadlock_list (this[0]);},
    'querydata' : {
                     'queryfile' : ''
                  },
    'datafields': [
     { name: 'DeadlockID', type: 'number'}
     ],
    'columns': [
     { text: 'DeadlockID', datafield: 'DeadlockID',     width: 100, filterable: false}
     ],
    'datafieldsMapping' : { },
    'datafieldsTS' : ['ResolveTime']
  });

  //$("#deadlock_list").on('rowselect', function (event) {
  //  var rowindex = event.args.rowindex;
  //  alert ("row "+rowindex+" selected");
  //});


  function refresh_deadlock_list (grid) {
    var asemondata = jQuery.data(grid, 'asemondata');
    var support157 = 0;
    var cols = [];
    var fields = [];
    var queryfile = '../ASE/sql/sql_deadlocks_list.php';
    if ( (ARContext.ServerName!="") && ( existColumn(ARContext.ServerName+'_DeadLock', 'WaitApplName') )  ) {
      support157 = 1;
    }

    var previousValue = '';
    var altcolor = true;
    var cellsrenderer = function (row, column, value, defaultHtml) {
      if (column == 'DeadlockID') {
        if (value != previousValue) {
          // change color
          if (altcolor)
            altcolor = false;
          else
            altcolor = true;
          previousValue = value;
        }
      }
      if (altcolor) {
        var element = $(defaultHtml);
        element.css({ 'background-color': '#e0e9f5', 'width': '100%', 'height': '100%', 'margin': '0px', 'padding' : '4px' });
        return element[0].outerHTML;
      }
      else
        return defaultHtml;
    }


    if (support157 == 1)
    {
          fields = [
                 { name: 'DeadlockID',         type: 'number'},
                 { name: 'VictimKPID',         type: 'number'},
                 { name: 'ResolveTime_str',    type: 'string'},
                 { name: 'InstanceID',         type: 'number'},
                 { name: 'ObjectID',           type: 'number'},
                 { name: 'ObjectDBID',         type: 'number'},
                 { name: 'ObjectDBName',       type: 'string'},
                 { name: 'ObjectName',         type: 'string'},
                 { name: 'PageNumber',         type: 'number'},
                 { name: 'RowNumber',          type: 'number'},
                 { name: 'HeldApplName',       type: 'string'},
                 { name: 'HeldUserName',       type: 'string'},
                 { name: 'HeldTranName',       type: 'string'},
                 { name: 'HeldLockType',       type: 'string'},
                 { name: 'HeldCommand',        type: 'string'},
                 { name: 'HeldInstanceID',     type: 'number'},
                 { name: 'HeldStmtNumber',     type: 'number'},
                 { name: 'HeldNumLocks',       type: 'number'},
                 { name: 'HeldHostName',       type: 'string'},
                 { name: 'HeldClientName',     type: 'string'},
                 { name: 'HeldClientHostName', type: 'string'},
                 { name: 'HeldClientApplName', type: 'string'},
                 { name: 'HeldProcDBName',     type: 'string'},
                 { name: 'HeldProcedureName',  type: 'string'},
                 { name: 'HeldSourceCodeID',   type: 'number'},
                 { name: 'HeldFamilyID',       type: 'number'},
                 { name: 'HeldSPID',           type: 'number'},
                 { name: 'HeldKPID',           type: 'number'},
                 { name: 'HeldProcDBID',       type: 'number'},
                 { name: 'HeldProcedureID',    type: 'number'},
                 { name: 'HeldBatchID',        type: 'number'},
                 { name: 'HeldContextID',      type: 'number'},
                 { name: 'HeldLineNumber',     type: 'number'},
                 { name: 'WaitApplName',       type: 'string'},
                 { name: 'WaitUserName',       type: 'string'},
                 { name: 'WaitTranName',       type: 'string'},
                 { name: 'WaitLockType',       type: 'string'},
                 { name: 'WaitCommand',        type: 'string'},
                 { name: 'WaitStmtNumber',     type: 'number'},
                 { name: 'WaitHostName',       type: 'string'},
                 { name: 'WaitClientName',     type: 'string'},
                 { name: 'WaitClientHostName', type: 'string'},
                 { name: 'WaitClientApplName', type: 'string'},
                 { name: 'WaitProcDBName',     type: 'string'},
                 { name: 'WaitProcedureName',  type: 'string'},
                 { name: 'WaitSourceCodeID',   type: 'number'},
                 { name: 'WaitFamilyID',       type: 'number'},
                 { name: 'WaitSPID',           type: 'number'},
                 { name: 'WaitKPID',           type: 'number'},
                 { name: 'WaitProcDBID',       type: 'number'},
                 { name: 'WaitProcedureID',    type: 'number'},
                 { name: 'WaitBatchID',        type: 'number'},
                 { name: 'WaitContextID',      type: 'number'},
                 { name: 'WaitLineNumber',     type: 'number'},
                 { name: 'WaitTime',           type: 'number'}
          ];
          cols= [
                 { text: 'DeadlockID',         datafield: 'DeadlockID',         width: 70, cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'VictimKPID',         datafield: 'VictimKPID',         width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'ResolveTime',        datafield: 'ResolveTime_str',    width: 150,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'InstanceID',         datafield: 'InstanceID',         width: 70,  cellsrenderer: cellsrenderer, filterable: true, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'ObjectID',           datafield: 'ObjectID',           width: 90,  cellsrenderer: cellsrenderer, filterable: true, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'ObjectDBID',         datafield: 'ObjectDBID',         width: 90,  cellsrenderer: cellsrenderer, filterable: true, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'ObjectDBName',       datafield: 'ObjectDBName',       width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'ObjectName',         datafield: 'ObjectName',         width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'PageNumber',         datafield: 'PageNumber',         width: 90,  cellsrenderer: cellsrenderer, filterable: true, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'RowNumber',          datafield: 'RowNumber',          width: 90,  cellsrenderer: cellsrenderer, filterable: true, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'HeldApplName',       datafield: 'HeldApplName',       width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'HeldUserName',       datafield: 'HeldUserName',       width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'HeldTranName',       datafield: 'HeldTranName',       width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'HeldLockType',       datafield: 'HeldLockType',       width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'HeldCommand',        datafield: 'HeldCommand',        width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'HeldInstanceID',     datafield: 'HeldInstanceID',     width: 90,  cellsrenderer: cellsrenderer, filterable: true, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'HeldStmtNumber',     datafield: 'HeldStmtNumber',     width: 90,  cellsrenderer: cellsrenderer, filterable: true, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'HeldNumLocks',       datafield: 'HeldNumLocks',       width: 90,  cellsrenderer: cellsrenderer, filterable: true, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'HeldHostName',       datafield: 'HeldHostName',       width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'HeldClientName',     datafield: 'HeldClientName',     width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'HeldClientHostName', datafield: 'HeldClientHostName', width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'HeldClientApplName', datafield: 'HeldClientApplName', width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'HeldProcDBName',     datafield: 'HeldProcDBName',     width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'HeldProcedureName',  datafield: 'HeldProcedureName',  width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'HeldSourceCodeID',   datafield: 'HeldSourceCodeID',   width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'HeldFamilyID',       datafield: 'HeldFamilyID',       width: 90,  cellsrenderer: cellsrenderer, filterable: true, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'HeldSPID',           datafield: 'HeldSPID',           width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'HeldKPID',           datafield: 'HeldKPID',           width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'HeldProcDBID',       datafield: 'HeldProcDBID',       width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'HeldProcedureID',    datafield: 'HeldProcedureID',    width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'HeldBatchID',        datafield: 'HeldBatchID',        width: 90,  cellsrenderer: cellsrenderer, filterable: true, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'HeldContextID',      datafield: 'HeldContextID',      width: 90,  cellsrenderer: cellsrenderer, filterable: true, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'HeldLineNumber',     datafield: 'HeldLineNumber',     width: 90,  cellsrenderer: cellsrenderer, filterable: true, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'WaitApplName',       datafield: 'WaitApplName',       width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'WaitUserName',       datafield: 'WaitUserName',       width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'WaitTranName',       datafield: 'WaitTranName',       width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'WaitLockType',       datafield: 'WaitLockType',       width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'WaitCommand',        datafield: 'WaitCommand',        width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'WaitStmtNumber',     datafield: 'WaitStmtNumber',     width: 90,  cellsrenderer: cellsrenderer, filterable: true, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'WaitHostName',       datafield: 'WaitHostName',       width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'WaitClientName',     datafield: 'WaitClientName',     width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'WaitClientHostName', datafield: 'WaitClientHostName', width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'WaitClientApplName', datafield: 'WaitClientApplName', width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'WaitProcDBName',     datafield: 'WaitProcDBName',     width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'WaitProcedureName',  datafield: 'WaitProcedureName',  width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'WaitSourceCodeID',   datafield: 'WaitSourceCodeID',   width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'WaitFamilyID',       datafield: 'WaitFamilyID',       width: 90,  cellsrenderer: cellsrenderer, filterable: true, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'WaitSPID',           datafield: 'WaitSPID',           width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'WaitKPID',           datafield: 'WaitKPID',           width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'WaitProcDBID',       datafield: 'WaitProcDBID',       width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'WaitProcedureID',    datafield: 'WaitProcedureID',    width: 90,  cellsrenderer: cellsrenderer, filterable: true, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'WaitBatchID',        datafield: 'WaitBatchID',        width: 90,  cellsrenderer: cellsrenderer, filterable: true, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'WaitContextID',      datafield: 'WaitContextID',      width: 90,  cellsrenderer: cellsrenderer, filterable: true, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'WaitLineNumber',     datafield: 'WaitLineNumber',     width: 90,  cellsrenderer: cellsrenderer, filterable: true, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'WaitTime',           datafield: 'WaitTime',           width: 90,  cellsrenderer: cellsrenderer, filterable: true, cellsformat: 'd', cellsalign: 'right'}
          ];
    }
    else
    {
          fields = [
                 { name: 'DeadlockID',      type: 'number'},
                 { name: 'VictimKPID',      type: 'number'},
                 { name: 'ResolveTime',     type: 'number'},
                 { name: 'ObjectDBID',      type: 'number'},
                 { name: 'ObjectName',      type: 'string'},
                 { name: 'PageNumber',      type: 'number'},
                 { name: 'RowNumber',       type: 'number'},
                 { name: 'HeldFamilyID',    type: 'number'},
                 { name: 'HeldSPID',        type: 'number'},
                 { name: 'HeldKPID',        type: 'number'},
                 { name: 'HeldUserName',    type: 'string'},
                 { name: 'HeldProcDBID',    type: 'number'},
                 { name: 'HeldProcedureID', type: 'number'},
                 { name: 'HeldProcName',    type: 'string'},
                 { name: 'HeldBatchID',     type: 'number'},
                 { name: 'HeldContextID',   type: 'number'},
                 { name: 'HeldLineNumber',  type: 'number'},
                 { name: 'HeldApplName',    type: 'string'},
                 { name: 'HeldTranName',    type: 'string'},
                 { name: 'HeldLockType',    type: 'string'},
                 { name: 'HeldCommand',     type: 'string'},
                 { name: 'WaitFamilyID',    type: 'number'},
                 { name: 'WaitSPID',        type: 'number'},
                 { name: 'WaitKPID',        type: 'number'},
                 { name: 'WaitUserName',    type: 'string'},
                 { name: 'WaitLockType',    type: 'string'},
                 { name: 'WaitTime',        type: 'number'}
          ];
          cols= [
                 { text: 'DeadlockID',      datafield: 'DeadlockID',      width: 90, cellsrenderer: cellsrenderer, filterable: true, cellsformat: 'd', cellsalign: 'right' },
                 { text: 'VictimKPID',      datafield: 'VictimKPID',      width: 90,  cellsrenderer: cellsrenderer, filterable: true, cellsformat: 'd', cellsalign: 'right' },
                 { text: 'ResolveTime',     datafield: 'ResolveTime',     width: 90,  cellsrenderer: cellsrenderer, filterable: true, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'ObjectDBID',      datafield: 'ObjectDBID',      width: 90,  cellsrenderer: cellsrenderer, filterable: true, cellsformat: 'd', cellsalign: 'right' },
                 { text: 'ObjectName',      datafield: 'ObjectName',      width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'PageNumber',      datafield: 'PageNumber',      width: 90,  cellsrenderer: cellsrenderer, filterable: true, cellsformat: 'd', cellsalign: 'right' },
                 { text: 'RowNumber',       datafield: 'RowNumber',       width: 90,  cellsrenderer: cellsrenderer, filterable: true, cellsformat: 'd', cellsalign: 'right' },
                 { text: 'HeldFamilyID',    datafield: 'HeldFamilyID',    width: 90,  cellsrenderer: cellsrenderer, filterable: true, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'HeldSPID',        datafield: 'HeldSPID',        width: 90,  cellsrenderer: cellsrenderer, filterable: true, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'HeldKPID',        datafield: 'HeldKPID',        width: 90,  cellsrenderer: cellsrenderer, filterable: true, cellsformat: 'd', cellsalign: 'right' },
                 { text: 'HeldUserName',    datafield: 'HeldUserName',    width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'HeldProcDBID',    datafield: 'HeldProcDBID',    width: 90,  cellsrenderer: cellsrenderer, filterable: true, cellsformat: 'd', cellsalign: 'right' },
                 { text: 'HeldProcedureID', datafield: 'HeldProcedureID', width: 90,  cellsrenderer: cellsrenderer, filterable: true, cellsformat: 'd', cellsalign: 'right' },
                 { text: 'HeldProcName',    datafield: 'HeldProcName',    width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'HeldBatchID',     datafield: 'HeldBatchID',     width: 90,  cellsrenderer: cellsrenderer, filterable: true, cellsformat: 'd', cellsalign: 'right' },
                 { text: 'HeldContextID',   datafield: 'HeldContextID',   width: 90,  cellsrenderer: cellsrenderer, filterable: true, cellsformat: 'd', cellsalign: 'right' },
                 { text: 'HeldLineNumber',  datafield: 'HeldLineNumber',  width: 90,  cellsrenderer: cellsrenderer, filterable: true, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'HeldApplName',    datafield: 'HeldApplName',    width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'HeldTranName',    datafield: 'HeldTranName',    width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'HeldLockType',    datafield: 'HeldLockType',    width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'HeldCommand',     datafield: 'HeldCommand',     width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'WaitFamilyID',    datafield: 'WaitFamilyID',    width: 90,  cellsrenderer: cellsrenderer, filterable: true, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'WaitSPID',        datafield: 'WaitSPID',        width: 90,  cellsrenderer: cellsrenderer, filterable: true, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'WaitKPID',        datafield: 'WaitKPID',        width: 90,  cellsrenderer: cellsrenderer, filterable: true, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'WaitUserName',    datafield: 'WaitUserName',    width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'WaitLockType',    datafield: 'WaitLockType',    width: 90,  cellsrenderer: cellsrenderer, filterable: true},
                 { text: 'WaitTime',        datafield: 'WaitTime',        width: 90,  cellsrenderer: cellsrenderer, filterable: true, cellsformat: 'd', cellsalign: 'right'}
          ];
    }



    $(grid).asemonGrid({
      'querydata' : {
                     'queryfile' : queryfile,
                     'support157' : support157
                    },
      'datafields': fields,
      'columns': cols 
    });
   
  }

  onArchCnxOpened = function(){
    $('.ASE-Deadlocks').removeClass('nondisplay');
    $('#deadlock_list').asemonGrid('refresh');
  }

</script>
<div id="info_TrendsDIV">
  <div style="float:left; width:300px;  " class="boxinmain">
    <div class="statTitle" ><strong>Indicators</strong>
                    <button type="button" class="btn btn-primary btn-xs" style="float:right" onClick="javascript:uncheckAll();"> Uncheck ALL </button>
                    <button type="button" class="btn btn-primary btn-xs" style="float:right;margin-right:5px"onClick="javascript:checkAll();"> Check ALL </button>
    </div>
    <div style="margin-bottom:15px">
      <table class="table_trends">
      <tr><td><label>Days : </label></td><td><label>From : </label></td><td><label>To : </label></td></tr>
      <tr><td>
                    <select ID="days" title="Choose days to graph">
                      <option SELECTED>All days</option>
                      <option>no_weekend</option>
                      <option>Monday   </option>
                      <option>Tuesday  </option>
                      <option>Wednesday</option>
                      <option>Thursday </option>
                      <option>Friday   </option>
                      <option>Saturday </option>
                      <option>Sunday   </option>
                    </select>
      </td><td>
                    <select ID="hourfrom" style="width: 50px"  title="Choose start hour to graph">
                      <option SELECTED>0</option>
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                      <option>6</option>
                      <option>7</option>
                      <option>8</option>
                      <option>9</option>
                      <option>10</option>
                      <option>11</option>
                      <option>12</option>
                      <option>13</option>
                      <option>14</option>
                      <option>15</option>
                      <option>16</option>
                      <option>17</option>
                      <option>18</option>
                      <option>19</option>
                      <option>20</option>
                      <option>21</option>
                      <option>22</option>
                      <option>23</option>
                    </select>
      </td><td>
                    <select ID="hourto" style="width: 50px" title="Choose end hour to graph (ex. 16 for 16h59)">
                      <option>0</option>
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                      <option>6</option>
                      <option>7</option>
                      <option>8</option>
                      <option>9</option>
                      <option>10</option>
                      <option>11</option>
                      <option>12</option>
                      <option>13</option>
                      <option>14</option>
                      <option>15</option>
                      <option>16</option>
                      <option>17</option>
                      <option>18</option>
                      <option>19</option>
                      <option>20</option>
                      <option>21</option>
                      <option>22</option>
                      <option SELECTED>23</option>
                    </select>
      </td></tr>
    </table>
    </div>

    <div id="treeDiv1" style="overflow: auto; margin:10px"></div>
  </div>
  <div ID="TrendsDIV" style="margin-left:320px">
  </div>
</div>
<center>
<div ID="message_TrendsDIV"></div>
</center>

<script type="text/javascript" src="blueshoes-4.5/javascript/core/lang/Bs_Misc.lib.js"></script>
<script type="text/javascript" src="blueshoes-4.5/javascript/core/lang/Bs_Array.class.js"></script>
<script type="text/javascript" src="blueshoes-4.5/javascript/components/tree/Bs_Tree.class.js"></script>
<script type="text/javascript" src="blueshoes-4.5/javascript/components/tree/Bs_TreeElement.class.js"></script>
<script type="text/javascript" src="blueshoes-4.5/javascript/components/checkbox/Bs_Checkbox.class.js"></script>
<script type="text/javascript" >

var RSinitialized = false;
var TTinitialized = false;

var queryrangesel = "select Ts=convert(varchar,convert(datetime,convert(varchar,dt,3),3),109),"
                  + " Value=AVG(case when Value <0 then 0 else Value end)  /* Ignore negatives values */" 
                  + " from "+ARContext.ServerName+"_Trends" 
                  + " where TrendID=1"
                  + "   and dt between '?STARTTIMESTAMP?' and '?ENDTIMESTAMP?'"
                  + " group by convert(datetime,convert(varchar,dt,3),3)"
                  + " order by convert(datetime,convert(varchar,dt,3),3)";
var delayRangeSel = 86400;
//var adjustStartTimestampWithRangeSel = 0;
//var adjustEndTimestampWithRangeSel = 0;
var setTimestampToRSExtremes=1;

var TrendsTree;
var TrendsCfg = new Array;

var ASM_XHR_initTrendsTree;

function addTreeElement(id, caption, TrendsCfgID, ckbn, isopen, ischecked) {
 var someElement = TrendsTree .getElement(id);
 if (typeof(someElement) == 'undefined') someElement = TrendsTree._pseudoElement;
 var elementData = new Array;
 elementData.caption = caption;
 elementData.target = TrendsCfgID;
 elementData.checkboxName = ckbn;
 elementData.isOpen=isopen;
 elementData.isChecked=ischecked;
 elementData.onChangeCheckbox = checkboxChanged;
 elementData.TrendsCfgID = TrendsCfgID;
  
 var newElement = someElement.addChildByArray(elementData);
 return newElement.id;
}

function checkboxChanged(treeElement) {
  var chk;
  if (treeElement.target != '_blank') {
        chk = treeElement.isChecked;
        if (chk == 'undefined') chk=0;
      TrendsCfg[treeElement.target].isChecked = chk;
  }

  var TrendID= TrendsCfg[treeElement.target].TrendID;
  var graph = $('#Trend_'+TrendID).highcharts();
  if (typeof graph == 'undefined')
    return;

  if (chk == 0)
    $('#Trend_'+TrendID).hide();
  else
    $('#Trend_'+TrendID).show();

}

function initTrendsTree() {
  var TrendID;
  var grpname;
  var description;
  var aggfunction;
  var currentCfg=0;
  var currentGrp="";
  var query = "select TrendID,grpname,description,aggfunction from "+ARContext.ServerName+"_TrendsCfg order by grpname,description";
  var data = {ARContextJSON: JSON.stringify(ARContext), query: query};

  if (ASM_XHR_initTrendsTree != null) {
    ASM_XHR_initTrendsTree.abort();
    ASM_XHR_initTrendsTree = null;
  }
  incXHRcnt();
  ASM_XHR_initTrendsTree = $.post( 'COMMON/simplequery.php', data ).done(function(res) {
    var result = JSON.parse(res);
    if ( checkSQLError(result, 'refresh_trends') ) return;
    for (var i=0; i < result.TotalRows; i++) {
      TrendID = result.Rows[i].TrendID;
      grpname = result.Rows[i].grpname;
      description = result.Rows[i].description;
      aggfunction = result.Rows[i].aggfunction;
      if (currentGrp != grpname) {
        // new group
        TrendsCfg[currentCfg] = {"TrendID" : -1, "TrendGrp" : grpname, "isChecked" : 1};
        currentCfg++;
        currentGrp = grpname;
      }
      TrendsCfg[currentCfg] = {"TrendID" : TrendID, "TrendGrp" : grpname, "description" : description, "isChecked" : 1, "aggfunction" : aggfunction};
      currentCfg++;
    }

    TrendsTree  = new Bs_Tree();
    TrendsTree.imageDir = 'blueshoes-4.5/javascript/components/tree/img/win98/';
    TrendsTree.checkboxSystemImgDir = 'blueshoes-4.5/javascript/components/checkbox/img/win2k_noBorder/';
    TrendsTree.useCheckboxSystem      = true;
    TrendsTree.checkboxSystemWalkTree = 3;
    TrendsTree.drawInto('treeDiv1');
    TrendsTree.useAutoSequence=true;
    TrendsTree.useFolderIcon = false;
    
    var curGrpName="";
    var curGrpID=0;
    
    for (var loopTrends=0; loopTrends < TrendsCfg.length; loopTrends++) {
        if (TrendsCfg[loopTrends].TrendID == -1 ) {
            curGrpName = TrendsCfg[loopTrends].TrendGrp;
            curGrpID = addTreeElement(0, curGrpName, loopTrends,  'CKB'+loopTrends,  TrendsCfg[loopTrends].isOpen, TrendsCfg[loopTrends].isChecked);
            TrendsCfg[loopTrends].TreeViewElemID = curGrpID;
        }
        else
            TrendsCfg[loopTrends].TreeViewElemID = addTreeElement(curGrpID, TrendsCfg[loopTrends].description, loopTrends, 'CKB'+loopTrends, TrendsCfg[loopTrends].isOpen, TrendsCfg[loopTrends].isChecked);
    }
    
    TTinitialized = true;
    refresh_trends();

  })
  .fail(function(data) {
    if (data.statusText == 'abort')
      return;
    alert( "error in refresh_trends()" );
  })
  .always(function() {
    decXHRcnt();
  });

}

function checkAll()
{
    var elem;
    for (var i=0; i < TrendsTree._pseudoElement._children.length; i++) {
        elem=TrendsTree.getElement(TrendsTree._pseudoElement._children[i].id);
        elem.setCheckboxValue(2);
    }
}   


function uncheckAll()
{
    var elem;
    for (var i=0; i < TrendsTree._pseudoElement._children.length; i++) {
        elem=TrendsTree.getElement(TrendsTree._pseudoElement._children[i].id);
        elem.setCheckboxValue(0);
    }
}















function refresh_trends() {
    var TrendID;
    var isChecked;
    var graph;
    var days = $('#days').val();
    var hourfrom = $('#hourfrom').val();
    var hourto = $('#hourto').val();

    for (var loopTrends=0; loopTrends < TrendsCfg.length; loopTrends++) {
      TrendID = TrendsCfg[loopTrends].TrendID ;
      isChecked = TrendsCfg[loopTrends].isChecked ;
      description = TrendsCfg[loopTrends].description ;
      aggfunction = TrendsCfg[loopTrends].aggfunction ;
      
      if (TrendID != -1 ) {
        graph = $('#Trend_'+TrendID).highcharts();
        if (isChecked == 0) {
          if (typeof graph != 'undefined')
            $('#Trend_'+TrendID).hide();
          continue;
        }
        else {
          if (typeof graph == 'undefined') {
            $('#TrendsDIV').append('<div ID="Trend_'+TrendID+'" class="trendchart" ></div>');
            $('#Trend_'+TrendID).asemonChart({
            title: {
              text: aggfunction + ' - ' +description
            },
            queryFile : '../ASE/sql/graphTrend.php',
            data: {
              TrendID: TrendID,
              aggfunction: aggfunction
            },
            tableName : 'Trends',
            chart: {
               marginTop: 50,
               marginBottom: 60,
                type: 'column'
            },
            series: [
              {
                name: 'counter_obs'
              }
            ],
            legend: {
               enabled: false
              },
            tooltip: {
                  xDateFormat: '%Y-%m-%d'
              },
            xAxis: {
                labels : {
                  format: '{value:%Y-%m-%d}'
                }
            },
            yAxis: {
              minRange: 1,
              min : 0 
              }
            });
            graph = $('#Trend_'+TrendID).highcharts();
          }
          $('#Trend_'+TrendID).show();
          $.extend(graph.options.data, {'days': days, 'hourfrom': hourfrom, 'hourto': hourto});
          $('#Trend_'+TrendID).asemonChart('refresh');
        }
      }
    }
  }



onRangeSelRefreshed = function(){
  RSinitialized = true;
}

onArchCnxOpened = function(){
  if (!TTinitialized) {
    if ( ! existTable(ARContext.ServerName+'_Trends') || ! existTable(ARContext.ServerName+'_TrendsCfg') ) {
      $('#message_TrendsDIV').append('Trends data is not available. The indicators aggregation has not been activated for server "'+ARContext.ServerName+'".<P> (Add Trends.xml in the asemon_logger config file)');
      $('#info_TrendsDIV').hide();
    }
    else
      initTrendsTree();
  }
  if (RSinitialized && TTinitialized)
    refresh_trends();
}
</script>
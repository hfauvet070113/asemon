<div class="ASE-QPMetrics nondisplay">
  <center>
  <div class="maingrid">
    <div ID="QPMetrics_statistics" class="asemongrid singlegrid" ></div>
    <div ID="QPMetrics_statistics_mess" class="nondisplay" >  </div>
  </div>
  </center>
</div>

<script type="text/javascript">
  var height =    $('#page-content').innerHeight() - 55;

    var dispSQLText = function (row, column, value, defaultHtml) {
      
      var element = $('<textarea style="border:0px; margin: 0px; padding: 5px; width: 100%; height: 100%;overflow-y: auto; resize: none" spellcheck="false" >'+value+'</textarea>');
      return element[0].outerHTML; 
    }

  if (typeof detail_type != 'undefined')
    $('.ASE-QPMetrics').removeClass('nondisplay');

  $('#QPMetrics_statistics').asemonGrid({
    'title' : 'Query Processing Metrics',
    'width' : '100%',
    'height' : height,
    'rowsheight': 80,
    'rowcount': 200,
    'filterable': true,
    'showaggregates': false,
    'querydata': {'queryfile' : '', 'default_order_by' : 'usecount desc'},
    'beforeRefresh': function() {refresh_QPMetrics_statistics (this[0]);},
    'datafieldsMapping': {'Q_dbname': 'Q.dbname', 'Q_owneruid': 'Q.uid', 'Q_id': 'Q.id', 'Q_hashkey': 'Q.hashkey'},
    'datafields': [
           { name: 'Q_dbname',   type: 'string'}
    ],
    'columns': [
           { text: 'dbname  ', datafield: 'Q_dbname',   width: 70,  filterable: true}
    ]
  });

  function refresh_QPMetrics_statistics (grid) {
    var asemondata = jQuery.data(grid, 'asemondata');
    var QPMetricsExists = 0;
    var QPMSQLExists = 0;


    if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_QPMetrics') )  )
      QPMetricsExists = 1;
    if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_QPMSQL') )  )
      QPMSQLExists = 1;
    
    if (( QPMetricsExists == 0) || ( QPMSQLExists == 0)) {
      $('#QPMetrics_statistics').hide();
      $('#QPMetrics_statistics_mess').show();
      $('#QPMetrics_statistics_mess').html('<p>QPMetrics data is not available. The QPMetrics collector has not been activated for server '+ARContext.ServerName+'.<P> (Add  QPMetrics.xml and QPMSQL.xml in the asemon_logger config file</p>');
      $.extend(asemondata, {'querydata' : {'queryfile' : '', 'query': ''}});
      return;
    }
    else {
      $('#QPMetrics_statistics').show();
      $('#QPMetrics_statistics_mess').hide();
    }


    $(grid).asemonGrid({
      'querydata': {'queryfile' : '../ASE/sql/sql_QPMetrics_statistics.php'},
      'datafields': [
           { name: 'Q_dbname',   type: 'string'},
           { name: 'Q_owneruid',      type: 'number'},
           { name: 'Q_id',       type: 'number'},
           { name: 'Q_hashkey',  type: 'number'},
           { name: 'usecount', type: 'number'},
           { name: 'lio_avg',  type: 'number'},
           { name: 'totlio',   type: 'number'},
           { name: 'pio_avg',  type: 'number'},
           { name: 'totpio',   type: 'number'},
           { name: 'exec_avg', type: 'number'},
           { name: 'elap_avg', type: 'number'},
           { name: 'qtext',    type: 'string'}
      ],
      'columns': [
           { text: 'dbname  ', datafield: 'Q_dbname',   width: 70,  filterable: true},
           { text: 'uid     ', datafield: 'Q_owneruid',      width: 50,  filterable: true, filtertype: 'number'},
           { text: 'id      ', datafield: 'Q_id',       width: 90,  filterable: true, filtertype: 'number'},
           { text: 'hashkey ', datafield: 'Q_hashkey',  width: 100, filterable: true, filtertype: 'number'},
           { text: 'usecount', datafield: 'usecount', width: 90,  filterable: false, cellsformat: 'd0',  cellsalign: 'right'},
           { text: 'lio_avg ', datafield: 'lio_avg',  width: 90,  filterable: false, cellsformat: 'd0',  cellsalign: 'right'},
           { text: 'totlio  ', datafield: 'totlio',   width: 90,  filterable: false, cellsformat: 'd0', cellsalign: 'right'},
           { text: 'pio_avg ', datafield: 'pio_avg',  width: 90,  filterable: false, cellsformat: 'd0',  cellsalign: 'right'},
           { text: 'totpio  ', datafield: 'totpio',   width: 90,  filterable: false, cellsformat: 'd0', cellsalign: 'right'},
           { text: 'exec_avg', datafield: 'exec_avg', width: 90,  filterable: false, cellsformat: 'd2',  cellsalign: 'right'},
           { text: 'elap_avg', datafield: 'elap_avg', width: 90,  filterable: false, cellsformat: 'd2', cellsalign: 'right'},
           { text: 'qtext   ', datafield: 'qtext',    width: 700,  filterable: true,  sortable: false, editable: false, cellsrenderer: dispSQLText }
      ]
    });
   
  }

  onArchCnxOpened = function(){
    $('.ASE-QPMetrics').removeClass('nondisplay');
    $('#QPMetrics_statistics').asemonGrid('refresh');
  }


</script>
<div class="ASE-Procs nondisplay">
  <center>
  <div class="maingrid">
    <div ID="procMDA_statistics" class="asemongrid singlegrid" ></div>
  </div>
  </center>
</div>


<script type="text/javascript">

  var height =    $('#page-content').innerHeight() - 55;

  if (typeof detail_type != 'undefined')
    $('.ASE-Procs').removeClass('nondisplay');

  $('#procMDA_statistics').asemonGrid({
    'title' : 'Procedure Statistics (derived from captured statements)',
    'width' : '100%',
    'height' : height,
    'rowcount': '200',
    'editable': false,
    'filterable': true,
    'sortable': true,
    'altrows': true,
    'cursor' : 'pointer',
    'querydata' : {
                     'queryfile' : ''
                  },
    'beforeRefresh': function() {refresh_procMDA_statistics (this[0]);},
    'datafields': [
     { name: 'DbName', type: 'string'}
     ],
    'columns': [
     { text: 'DbName',         datafield: 'DbName',         width: 90, filterable: true}
     ],
    'datafieldsMapping' : { }
  });

  $("#procMDA_statistics").bind('cellclick', function (event) {
    var column = event.args.column;
    var rowindex = event.args.rowindex;
    //alert ("row "+rowindex+" selected");
    
    var rowdata = $('#procMDA_statistics').jqxGrid('getrowdatabyid', rowindex);
    if (typeof rowdata == 'undefined') return 0;

    //var asemondata = jQuery.data(this, 'asemondata');

    if (column.datafield == 'image')
      openWindowFromGrid ("#procMDA_statistics", "detail_page.php", {ARContextJSON: ARContext, 'displaylevel' : 2, 'detail_type': 'TRENDPROC', 'ProcName': rowdata.ProcName, 'DBID': rowdata.DBID});
    else
      openWindowFromGrid ("#procMDA_statistics", "detail_page.php", {ARContextJSON: ARContext, 'displaylevel' : 1, 'detail_type': 'PROCDETAIL', 'ProcName': rowdata.ProcName, 'DBID': rowdata.DBID});

  });


  function refresh_procMDA_statistics (grid) {
    var asemondata = jQuery.data(grid, 'asemondata');
    var support157 = 0;
    var cols = [];
    var fields = [];
    var queryfile = '../ASE/sql/sql_procMDA_statistics.php';

    var cellsrenderer = function (row, column, value, defaultHtml) {
      var rowdata = {};
      if (column == 'image') {
        var element = $(defaultHtml);
        
        // ajouter image ici si ProcName[0] != '*'
        rowdata = $('#procMDA_statistics').jqxGrid('getrowdatabyid', row);
        if (typeof rowdata.ProcName != 'undefined') {
          if (rowdata.ProcName[0] != '*')
            return '<i class="fa fa-area-chart" style="padding: 5px; color: green" TITLE="Display procedure\'s trends"></i>';
          else {
            //element.css({ 'background-color': '#e0e9f5', 'width': '100%', 'height': '100%', 'margin': '0px', 'padding' : '4px' });
            //return element[0].outerHTML; 
            return defaultHtml; 
          }
        }
      }
      else
        return defaultHtml;
    }

    fields = [
           { name: 'DBID',               type: 'number'},
           { name: 'Application',        type: 'string'},
           { name: 'ProcName',           type: 'string'},
           { name: 'Executions',         type: 'number'},
           { name: 'SumCpuTime',         type: 'number'},
           { name: 'AvgCpuTime',         type: 'number'},
           { name: 'SumWaitTime',        type: 'number'},
           { name: 'AvgWaitTime',        type: 'number'},
           { name: 'MaxMemUsageKB',      type: 'number'},
           { name: 'SumPhysicalReads',   type: 'number'},
           { name: 'AvgPhysicalReads',   type: 'number'},
           { name: 'SumLogicalReads',    type: 'number'},
           { name: 'AvgLogicalReads',    type: 'number'},
           { name: 'SumPagesModified',   type: 'number'},
           { name: 'AvgPagesModified',   type: 'number'},
           { name: 'SumPacketsSent',     type: 'number'},
           { name: 'AvgPacketsSent',     type: 'number'},
           { name: 'SumPacketsReceived', type: 'number'},
           { name: 'AvgPacketsReceived', type: 'number'},
           { name: 'SumPlans',           type: 'number'}
    ];
    cols= [
           { text: '',           datafield: 'image',               width: 25, filterable: false, cellsrenderer: cellsrenderer, editable: false},
           { text: 'DBID',           datafield: 'DBID',               width: 70, filterable: true, cellsformat: 'd', cellsalign: 'right'},
           { text: 'Application',    datafield: 'Application',        width: 150, filterable: true},
           { text: 'Proc',           datafield: 'ProcName',           width: 190, filterable: true},
           { text: 'Executions',     datafield: 'Executions',         width: 70, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']},
           { text: 'SumCpuTime',     datafield: 'SumCpuTime',         width: 90, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']},
           { text: 'AvgCpuTime',     datafield: 'AvgCpuTime',         width: 90, filterable: false, cellsformat: 'd2', cellsalign: 'right'},
           { text: 'SumWaitTime',    datafield: 'SumWaitTime',        width: 90, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['avg']},
           { text: 'AvgWaitTime',    datafield: 'AvgWaitTime',        width: 90, filterable: false, cellsformat: 'd2', cellsalign: 'right'},
           { text: 'MaxMemUsageKB',  datafield: 'MaxMemUsageKB',      width: 90, filterable: false, cellsformat: 'd2', cellsalign: 'right',aggregates: ['max']},
           { text: 'SumPReads',      datafield: 'SumPhysicalReads',   width: 90, filterable: false, cellsformat: 'd2', cellsalign: 'right',aggregates: ['sum']},
           { text: 'AvgPReads',      datafield: 'AvgPhysicalReads',   width: 90, filterable: false, cellsformat: 'd2', cellsalign: 'right'},
           { text: 'SumLReads',      datafield: 'SumLogicalReads',    width: 90, filterable: false, cellsformat: 'd2', cellsalign: 'right',aggregates: ['sum']},
           { text: 'AvgLReads',      datafield: 'AvgLogicalReads',    width: 90, filterable: false, cellsformat: 'd2', cellsalign: 'right'},
           { text: 'SumPgsModified', datafield: 'SumPagesModified',   width: 90, filterable: false, cellsformat: 'd2', cellsalign: 'right',aggregates: ['sum']},
           { text: 'AvgPgsModified', datafield: 'AvgPagesModified',   width: 90, filterable: false, cellsformat: 'd2', cellsalign: 'right'},
           { text: 'SumPktsSent',    datafield: 'SumPacketsSent',     width: 90, filterable: false, cellsformat: 'd2', cellsalign: 'right',aggregates: ['sum']},
           { text: 'AvgPktsSent',    datafield: 'AvgPacketsSent',     width: 90, filterable: false, cellsformat: 'd2', cellsalign: 'right'},
           { text: 'SumPktsRcved',   datafield: 'SumPacketsReceived', width: 90, filterable: false, cellsformat: 'd2', cellsalign: 'right',aggregates: ['sum']},
           { text: 'AvgPktsRcved',   datafield: 'AvgPacketsReceived', width: 90, filterable: false, cellsformat: 'd2', cellsalign: 'right'},
           { text: 'SumPlans',       datafield: 'SumPlans',           width: 90, filterable: false, cellsformat: 'd2', cellsalign: 'right',aggregates: ['sum']}
    ];



    $(grid).asemonGrid({
      'querydata' : {
                     'queryfile' : queryfile
                    },
      'datafields': fields,
      'columns': cols 
    });
   
  }

  onArchCnxOpened = function(){
    $('.ASE-Procs').removeClass('nondisplay');
    $('#procMDA_statistics').asemonGrid('refresh');
  }

</script>
<div class="ASE-Statements nondisplay">
  <center>
  <div class="maingrid">
    <div ID="Statements_statistics" class="asemongrid singlegrid" ></div>
  </div>
  </center>
</div>

<script type="text/javascript">
  var height =    $('#page-content').innerHeight() - 55;

  if (typeof detail_type != 'undefined')
    $('.ASE-Statements').removeClass('nondisplay');

  $('#Statements_statistics').asemonGrid({
    'title' : 'Statements statistics',
    'width' : '100%',
    'height' : height,
    'rowcount': 200,
    'editable': false,
    'filterable': true,
    'cursor' : 'pointer',
/*    'querydata' : { 'queryfile' : '../ASE/sql/sql_stmt_statistics.php'},*/
    'querydata' : { 'queryfile' : ''},
    'beforeRefresh': function() {refresh_statement_statistics (this[0]);},
    'onClear': function() {clear_statement_statistics (this[0]);},
    'datafieldsMapping': {'Debut': 'StartTime', 'stat_StmtID': 'stat.StmtID', 'SQLHashKey': 'stat.SQLHashKey'},
    'datafields': [
     { name: 'stat_StmtID',  type: 'number'}
      ],
    'columns': [
     { text: 'StmtID', datafield: 'stat_StmtID', width: 170, filterable: false}
      ],
    'datafieldsTS' : [],
    'buttons' : [
       {
        'id': 'GroupByHashKeyBTN',
        'text': 'Groupby Same Stmts',
        'onclick' : function ( ) {
          if (this.classList.contains('disabled'))
            return;
          var selector = $('#Statements_statistics')[0];
          var asemondata = jQuery.data( selector , 'asemondata');
          if (typeof asemondata.querydata.GroupByHashKey  == 'undefined') 
            asemondata.querydata.GroupByHashKey = 0;

          if (asemondata.querydata.GroupByHashKey == 0) {
            asemondata.querydata.GroupByHashKey = 1;
            this.value = 'UnGroup';
          }
          else {
            asemondata.querydata.GroupByHashKey = 0;
            this.value = 'Groupby Same Stmts';
          }
          
          // Reset sort clause
          if (typeof asemondata.sort_clause != 'undefined') {
            $(selector).jqxGrid('removesort');
            $(selector).jqxGrid('sortby', '', '');
            asemondata.sort_clause = "";
          }

          $.extend(asemondata.querydata, {'GroupByHashKey' : asemondata.querydata.GroupByHashKey});
          $(selector).asemonGrid('refresh');

        }
       }
       ],
    'fields' : [
       {
        'id': 'ObjectDbNameFLD',
        'label': 'Filter on ObjectDbName : ',
        'size': 6,
        'value': '',
        'onchange' : function ( ) {
          var selector = $('#Statements_statistics')[0];
          var asemondata = jQuery.data( selector , 'asemondata');
          $.extend(asemondata.querydata, {'ObjectDbName' : this.value});
        }
      },
       {
        'id': 'ObjectNameFLD',
        'label': 'ObjectName : ',
        'size': 6,
        'value': '',
        'onchange' : function ( ) {
          var selector = $('#Statements_statistics')[0];
          var asemondata = jQuery.data( selector , 'asemondata');
          $.extend(asemondata.querydata, {'ObjectName' : this.value});
        }
      },
       {
        'id': 'IndexIDFLD',
        'label': 'IndexID : ',
        'size': 6,
        'value': '',
        'onchange' : function ( ) {
          var selector = $('#Statements_statistics')[0];
          var asemondata = jQuery.data( selector , 'asemondata');
          $.extend(asemondata.querydata, {'IndexID' : this.value});
        }
      },
       {
        'id': 'ExclHostFLD',
        'label': 'Exclude host : ',
        'size': 6,
        'value': '',
        'onchange' : function ( ) {
          var selector = $('#Statements_statistics')[0];
          var asemondata = jQuery.data( selector , 'asemondata');
          $.extend(asemondata.querydata, {'ExclHost' : this.value});
        }
      },
       {
        'id': 'ExclAppFLD',
        'label': 'Exclude app. : ',
        'size': 6,
        'value': '',
        'onchange' : function ( ) {
          var selector = $('#Statements_statistics')[0];
          var asemondata = jQuery.data( selector , 'asemondata');
          $.extend(asemondata.querydata, {'ExclApp' : this.value});
        }
      }
    ]
  });
  
  
  $("#Statements_statistics").bind('cellclick', function (event) {
    var column = event.args.column;
    var rowindex = event.args.rowindex;
    //alert ("row "+rowindex+" selected");
    
    var rowdata = $('#Statements_statistics').jqxGrid('getrowdatabyid', rowindex);
    if (typeof rowdata == 'undefined') return 0;
  
    var SQLHashKeyExists=false;
    if (typeof rowdata.SQLHashKey != 'undefined') {
      if (rowdata.SQLHashKey != "") SQLHashKeyExists=true;
    }
  
    var asemondata = jQuery.data(this, 'asemondata');
  
    if (column.datafield == 'image') {
      if (SQLHashKeyExists) {
        openWindowFromGrid ("#Statements_statistics", "detail_page.php", {ARContextJSON: ARContext, 'displaylevel' : 1, 'detail_type': 'TRENDSTMT', 'SQLHashKey': rowdata.SQLHashKey});
      }
    }
    else {
      if (asemondata.querydata.GroupByHashKey == 0) {
        var StmtID = rowdata.stat_StmtID;
        openWindowFromGrid ("#Statements_statistics", "detail_page.php", {ARContextJSON: ARContext, 'displaylevel' : 2, 'detail_type': 'STMT', 'StmtID': StmtID});
      }
      else {
        var SQLHashKey = rowdata.SQLHashKey;
        openWindowFromGrid ("#Statements_statistics", "detail_page.php", {ARContextJSON: ARContext, 'displaylevel' : 1, 'detail_type': 'STMTHASHKEY', 'SQLHashKey': SQLHashKey});
      }
    }
  });

  function clear_statement_statistics (grid) {
    var asemondata = jQuery.data(grid, 'asemondata');
    if (typeof asemondata.querydata.GroupByHashKey  != 'undefined')
      asemondata.querydata.GroupByHashKey = 0;
  }

  function refresh_statement_statistics (grid) {
    var asemondata = jQuery.data(grid, 'asemondata');
    var support157 = 0;
    var StmtSQLHKExists = 0;
    var StmtPlnHKExists = 0;
    var colV16SP03Exists = 0;
    var cols = [];
    var fields = [];
    var default_order_by;
    var SQLHashKeyExists = 0;
    var supportFieldsAnja = 0;
    var fieldSQLHashKey = [];
    var colSQLHashKey = [];
    var buttons = [];
    var V16SP03optfieldsNongroup = [];
    var V16SP03optcolsNongroup = [];
    var V16SP03snapfieldsNongroup = [];
    var V16SP03snapcolsNongroup = [];
    var V16SP03optfieldsGroup = [];
    var V16SP03optcolsGroup = [];
    var V16SP03snapfieldsGroup = [];
    var V16SP03snapcolsGroup = [];
    var fieldsAnja = [];
    var colsAnja = [];



    var cellsrenderer_stmtstats = function (row, column, value, defaultHtml) {
      var rowdata = {};
      if (column == 'image') {
        var element = $(defaultHtml);
        var displayIcon=false;
        
        rowdata = $('#Statements_statistics').jqxGrid('getrowdatabyid', row);
    
          
        if (typeof rowdata.SQLHashKey != 'undefined') {
          if (rowdata.SQLHashKey != "") 
            return '<i class="fa fa-area-chart" style="padding: 5px; color: green" TITLE="Display statement\'s trends"></i>';
          else {
            //element.css({ 'background-color': '#e0e9f5', 'width': '100%', 'height': '100%', 'margin': '0px', 'padding' : '4px' });
            //return element[0].outerHTML; 
            return defaultHtml; 
          }
        }
      }
      else
        return defaultHtml;
    }


    if ( (ARContext.ServerName!="") && ( existColumn(ARContext.ServerName+'_StmtStat', 'ClientName') )  ) {
      support157 = 1;
    }

    if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_StmtSQLHK') )  ) {
      StmtSQLHKExists = 1;
    }

    if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_StmtPlnHK') )  ) {
      StmtPlnHKExists = 1;
    }

    if ( (ARContext.ServerName!="") && ( existColumn(ARContext.ServerName+'_StmtStat', 'SQLHashKey') )  ) {
      SQLHashKeyExists = 1;
      $('#GroupByHashKeyBTN').removeClass('disabled');
    }
    else {
      $('#GroupByHashKeyBTN').addClass('disabled');
      $('#GroupByHashKeyBTN').prop('value', 'GroupByHashKey');
      if (typeof asemondata.querydata.GroupByHashKey  != 'undefined') 
        asemondata.querydata.GroupByHashKey = 0;
    }
    if ( (ARContext.ServerName!="") && ( existColumn(ARContext.ServerName+'_StmtStat', 'StatementNumber') ) && ( existColumn(ARContext.ServerName+'_StmtStat', 'ProcNestLevel') ) ) {
      supportFieldsAnja = 1;
    }


    if ( (ARContext.ServerName!="") &&( existColumn(ARContext.ServerName+'_StmtStat', 'QueryOptimizationTime') )  ){
      colV16SP03Exists = 1;
      V16SP03optfieldsNongroup = [
      { name: 'QueryOptimizationTime', type: 'number' }
      ];
      V16SP03optcolsNongroup   = [
      { text: 'QueryOptimizationTime', datafield: 'QueryOptimizationTime', width: 100, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']}
      ];
      V16SP03snapfieldsNongroup = [
      { name: 'SnapCodegenTime',       type: 'number' },
      { name: 'SnapJITTime',           type: 'number' },
      { name: 'SnapExecutionTime',     type: 'number' },
      { name: 'SnapExecutionCount',    type: 'number' }
      ];
      V16SP03snapcolsNongroup   = [
      { text: 'SnapCodegenTime',       datafield: 'SnapCodegenTime',       width: 100, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']},
      { text: 'SnapJITTime',           datafield: 'SnapJITTime',           width: 100, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']},
      { text: 'SnapExecutionTime',     datafield: 'SnapExecutionTime',     width: 100, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']},
      { text: 'SnapExecutionCount',    datafield: 'SnapExecutionCount',    width: 100, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']}
      ];

      V16SP03optfieldsGroup = [
      { name: 'sumQueryOptimizationTime', type: 'number' }
      ];
      V16SP03optcolsGroup   = [
      { text: 'sumQueryOptimizationTime', datafield: 'sumQueryOptimizationTime', width: 100, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']}
      ];
      V16SP03snapfieldsGroup = [
      { name: 'sumSnapCodegenTime',       type: 'number' },
      { name: 'sumSnapJITTime',           type: 'number' },
      { name: 'sumSnapExecutionTime',     type: 'number' },
      { name: 'sumSnapExecutionCount',    type: 'number' }
      ];
      V16SP03snapcolsGroup   = [
      { text: 'SnapCodegenTime',       datafield: 'sumSnapCodegenTime',       width: 100, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']},
      { text: 'SnapJITTime',           datafield: 'sumSnapJITTime',           width: 100, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']},
      { text: 'SnapExecutionTime',     datafield: 'sumSnapExecutionTime',     width: 100, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']},
      { text: 'SnapExecutionCount',    datafield: 'sumSnapExecutionCount',    width: 100, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']}
      ];
    }

    if (typeof asemondata.querydata.GroupByHashKey  == 'undefined') 
      asemondata.querydata.GroupByHashKey = 0;

    if (asemondata.querydata.GroupByHashKey == 0) {
      fields = [
             { name: 'stat_StmtID',   type: 'number'},
             { name: 'Debut',         type: 'string'},
             { name: 'Elapsed_s',     type: 'number'},
             { name: 'SPID',          type: 'number'},
             { name: 'DBID',          type: 'number'},
             { name: 'Application',   type: 'string'},
             { name: 'ClientHost',    type: 'string'},
             { name: 'ProcName',      type: 'string'},
             { name: 'LineNumber',    type: 'number'},
             { name: 'CpuTime',       type: 'number'}]
             .concat(V16SP03optfieldsNongroup)
             .concat([
             { name: 'WaitTime',      type: 'number'},
             { name: 'MemUsageKB',    type: 'number'},
             { name: 'PhysicalReads', type: 'number'},
             { name: 'LogicalReads',  type: 'number'},
             { name: 'PagesModified', type: 'number'},
             { name: 'PacketsSent',   type: 'number'},
             { name: 'planOK',        type: 'string'},
             { name: 'PlanID',        type: 'number'},
             { name: 'BatchID',       type: 'number'},
             { name: 'ContextID',     type: 'number'}
             ])
             .concat(V16SP03snapfieldsNongroup);

      cols = [
             { text: 'StmtID',      datafield: 'stat_StmtID',   width: 70,  filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number'},
             { text: 'StartTime',   datafield: 'Debut',         width: 170, filterable: false},
             { text: 'Elapsed_s',   datafield: 'Elapsed_s',     width: 70, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number'},
             { text: 'SPID',        datafield: 'SPID',          width: 50, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number'},
             { text: 'DBID',        datafield: 'DBID',          width: 50, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number'},
             { text: 'Application', datafield: 'Application',   width: 90, filterable: true},
             { text: 'ClientHost',  datafield: 'ClientHost',    width: 150, filterable: true},
             { text: 'Proc',        datafield: 'ProcName',      width: 150, filterable: true},
             { text: 'Line',        datafield: 'LineNumber',    width: 70, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number'},
             { text: 'CpuTime_ms',  datafield: 'CpuTime',       width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']}]
             .concat(V16SP03optcolsNongroup)
             .concat([
             { text: 'WaitTime_ms', datafield: 'WaitTime',      width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']},
             { text: 'MemUsageKB',  datafield: 'MemUsageKB',    width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['max']},
             { text: 'PReads',      datafield: 'PhysicalReads', width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']},
             { text: 'LReads',      datafield: 'LogicalReads',  width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']},
             { text: 'PgsModified', datafield: 'PagesModified', width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']},
             { text: 'PktsSent',    datafield: 'PacketsSent',   width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']},
             { text: 'Plan',        datafield: 'planOK',        width: 50, filterable: false},
             { text: 'PlanID',      datafield: 'PlanID',        width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number'},
             { text: 'BatchID',     datafield: 'BatchID',       width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number'},
             { text: 'ContextID',   datafield: 'ContextID',     width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number'}])
             .concat(V16SP03snapcolsNongroup);

      fields157 = [
             { name: 'ClientName',     type: 'string'},
             { name: 'ClientHostName', type: 'string'},
             { name: 'ClientApplName', type: 'string'}
      ];
      cols157= [
             { text: 'ClientName',     datafield: 'ClientName',     width: 90, filterable: true},
             { text: 'ClientHostName', datafield: 'ClientHostName', width: 90, filterable: true},
             { text: 'ClientApplName', datafield: 'ClientApplName', width: 90, filterable: true}
      ];
      fieldSQLHashKey = [
             { name: 'SQLHashKey', type: 'string'}
      ];
      colSQLHashKey= [
             { text: '',            datafield: 'image',      width: 25, filterable: false, cellsrenderer: cellsrenderer_stmtstats, editable: false},
             { text: 'SQLHashKey', datafield: 'SQLHashKey', width: 90, filterable: true, cellsalign: 'right'}
      ];
      
      fieldsAnja = [ 
             { name: 'StatementNumber', type: 'number'},
             { name: 'ProcNestLevel', type: 'number'}
      ];
      colsAnja= [
             { text: 'StatementNumber', datafield: 'StatementNumber', width: 90, filterable: true, cellsalign: 'right'},
             { text: 'ProcNestLevel', datafield: 'ProcNestLevel', width: 90, filterable: true, cellsalign: 'right'}
      ];
      
      if (support157 == 1) {
        fields = fields.concat(fields157);
        cols = cols.concat(cols157);
      }

      if (SQLHashKeyExists == 1) {
        fields = fields.concat(fieldSQLHashKey);
        cols = cols.concat(colSQLHashKey);
      }

      if (supportFieldsAnja == 1) {
        fields = fields.concat(fieldsAnja);
        cols = cols.concat(colsAnja);
      }

      default_order_by = 'stat_StmtID';
      queryfile = '../ASE/sql/sql_stmt_statistics.php';
      $(grid).find(' .GridTitle').text( 'Statements statistics');
      var btn=$(grid).find(' #GroupByHashKeyBTN')[0];
      btn.value = 'Groupby Same Stmts';

    }
    else {
      fields = [
             { name: 'SQLHashKey',       type: 'string'},
             { name: 'cnt',              type: 'number'},
             { name: 'SumCpuTime',       type: 'number'},
             { name: 'AvgCpuTime',       type: 'number'},
             { name: 'SumWaitTime',      type: 'number'}]
             .concat(V16SP03optfieldsGroup)
             .concat([
             { name: 'MaxMemUsageKB',    type: 'number'},
             { name: 'SumPhysicalReads', type: 'number'},
             { name: 'SumLogicalReads',  type: 'number'},
             { name: 'AvgLogicalReads',  type: 'number'},
             { name: 'SumPagesModified', type: 'number'},
             { name: 'SumPacketsSent',   type: 'number'},
             { name: 'SQLText',          type: 'string'}
             ])
             .concat(V16SP03snapfieldsGroup);
      cols = [
             { text: '',            datafield: 'image',      width: 25, filterable: false, cellsrenderer: cellsrenderer_stmtstats, editable: false},
             { text: 'SQLHashKey',     datafield: 'SQLHashKey',       width: 130,filterable: true, cellsalign: 'right'},
             { text: 'Count',          datafield: 'cnt',              width: 70, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']},
             { text: 'SumCpuTime_ms',  datafield: 'SumCpuTime',       width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']},
             { text: 'AvgCpuTime_ms',  datafield: 'AvgCpuTime',       width: 90, filterable: true, cellsformat: 'd2', cellsalign: 'right', filtertype: 'number' ,aggregates: ['avg']}]
             .concat(V16SP03optcolsGroup)
             .concat([
             { text: 'SumWaitTime_ms', datafield: 'SumWaitTime',      width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']},
             { text: 'MaxMemUsageKB',  datafield: 'MaxMemUsageKB',    width: 70, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['max']},
             { text: 'SumPReads',      datafield: 'SumPhysicalReads', width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']},
             { text: 'SumLReads',      datafield: 'SumLogicalReads',  width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']},
             { text: 'AvgLReads',      datafield: 'AvgLogicalReads',  width: 90, filterable: true, cellsformat: 'd2', cellsalign: 'right', filtertype: 'number' ,aggregates: ['avg']},
             { text: 'SumPgsModified', datafield: 'SumPagesModified', width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']},
             { text: 'SumPktsSent',    datafield: 'SumPacketsSent',   width: 90, filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number' ,aggregates: ['sum']},
             { text: 'SQLText',        datafield: 'SQLText',          width: 700, filterable: true, sortable: false}])
             .concat(V16SP03snapcolsGroup)
             .concat([
             { text: '', width: 25,  filterable: false}
             ]);
      
      default_order_by = 'SumCpuTime desc';
      queryfile = '../ASE/sql/sql_stmt_statistics_HASHKEY.php';
      
      $(grid).find(' .GridTitle').text( 'Statements statistics - Group by same statements');
      var btn=$(grid).find(' #GroupByHashKeyBTN')[0];
      btn.value = 'UnGroup';

    }




    $(grid).asemonGrid({
      'querydata' : {
                     'queryfile' : queryfile,
                     'support157': support157,
                     'SQLHashKeyExists' : SQLHashKeyExists,
                     'StmtSQLHKExists' : StmtSQLHKExists,
                     'StmtPlnHKExists' : StmtPlnHKExists,
                     'default_order_by' : default_order_by,
                     'colV16SP03Exists': colV16SP03Exists,
                     'supportFieldsAnja': supportFieldsAnja
                    },
      'datafields': fields,
      'columns': cols
 
    });

  }

  onArchCnxOpened = function(){
    $('.ASE-Statements').removeClass('nondisplay');
    $('#Statements_statistics').asemonGrid('refresh');
  }


</script>
<div class="ASE-MemUsage nondisplay">
  <center>
  <div class="maingrid">
    <div ID="MemUsage_statistics" class="asemongrid singlegrid" ></div>
    <div ID="MemUsage_statistics_mess" class="nodisplay" >  </div>
  </div>
  </center>
</div>

<script type="text/javascript">
  var height =    $('#page-content').innerHeight() - 55;




  if (typeof detail_type != 'undefined')
    $('.ASE-MemUsage').removeClass('nondisplay');

  $('#MemUsage_statistics').asemonGrid({
    'title' : 'Memusage statistics',
    'width' : '100%',
    'height' : height,
    'rowcount': 200,
    'filterable': true,
    'showaggregates': true,
    'querydata': {'queryfile' : '', 'default_order_by' : 'ConfigNum'},
    'beforeRefresh': function() {refresh_MemUsage_statistics (this[0]);},
    'datafieldsMapping': {'ConfigOption' : 'B.name'},
    'datafields': [
           { name: 'Flags',                   type: 'number'},
           { name: 'ConfigNum',               type: 'number'},
           { name: 'MemoryPoolName',          type: 'string'},
           { name: 'PoolType',                type: 'string'},
           { name: 'PoolOwnerKPID',           type: 'number'},
           { name: 'ConfigOption',            type: 'string'},
           { name: 'TotalSize',               type: 'number'},
           { name: 'MAX_UsedSize',            type: 'number'},
           { name: 'MAX_FreeSize',            type: 'number'},
           { name: 'SUM_NumAllocs',           type: 'number'},
           { name: 'SUM_NumFrees',            type: 'number'},
           { name: 'SUM_NumSleeps',           type: 'number'},
           { name: 'SUM_NumSearches',         type: 'number'},
           { name: 'SUM_NumRetries',          type: 'number'},
           { name: 'AVG_ItemSize',            type: 'number'},
           { name: 'MinNumItems',             type: 'number'},
           { name: 'MaxNumItems',             type: 'number'},
           { name: 'MAX_NumUsedItems',        type: 'number'},
           { name: 'NumItemsUsedHWM',         type: 'number'},
           { name: 'MinUsedItemSize',         type: 'number'},
           { name: 'AvgUsedItemSize',         type: 'number'},
           { name: 'MaxUsedItemSize',         type: 'number'},
           { name: 'MAX_NumUsedItemsMinSize', type: 'number'},
           { name: 'MAX_NumUsedItemsMaxSize', type: 'number'},
           { name: 'MAX_NumFreeItems',        type: 'number'},
           { name: 'MinFreeItemSize',         type: 'number'},
           { name: 'AvgFreeItemSize',         type: 'number'},
           { name: 'MaxFreeItemSize',         type: 'number'},
           { name: 'MAX_NumFreeItemsMinSize', type: 'number'},
           { name: 'MAX_NumFreeItemsMaxSize', type: 'number'},
           { name: 'MAX_NumBlocks',           type: 'number'},
           { name: 'MAX_MemSize1',            type: 'number'},
           { name: 'MAX_NumUsedItemsSize1',   type: 'number'},
           { name: 'MAX_NumFreeItemsSize1',   type: 'number'},
           { name: 'MAX_MemSize2',            type: 'number'},
           { name: 'MAX_NumUsedItemsSize2',   type: 'number'},
           { name: 'MAX_NumFreeItemsSize2',   type: 'number'}
    ],
    'columns': [
           { text: 'Flags                  ', datafield: 'Flags',                    width: 60,  filterable: true},
           { text: 'ConfigNum              ', datafield: 'ConfigNum',                width: 70,  filterable: true},
           { text: 'MemoryPoolName         ', datafield: 'MemoryPoolName',           width: 150,  filterable: true},
           { text: 'PoolType               ', datafield: 'PoolType',                 width: 100,  filterable: true},
           { text: 'PoolOwnerKPID          ', datafield: 'PoolOwnerKPID',            width: 100,  filterable: true},
           { text: 'ConfigOption           ', datafield: 'ConfigOption',             width: 180,  filterable: true},
           { text: 'TotalSize              ', datafield: 'TotalSize',                width: 100,  filterable: false, cellsformat: 'd',  cellsalign: 'right', aggregates: ['sum']},
           { text: 'MAX_UsedSize           ', datafield: 'MAX_UsedSize',             width: 100,  filterable: false, cellsformat: 'd',  cellsalign: 'right', aggregates: ['max']},
           { text: 'MAX_FreeSize           ', datafield: 'MAX_FreeSize',             width: 100,  filterable: false, cellsformat: 'd',  cellsalign: 'right', aggregates: ['max']},
           { text: 'SUM_NumAllocs          ', datafield: 'SUM_NumAllocs',            width: 100,  filterable: false, cellsformat: 'd',  cellsalign: 'right', aggregates: ['sum']},
           { text: 'SUM_NumFrees           ', datafield: 'SUM_NumFrees',             width: 100,  filterable: false, cellsformat: 'd',  cellsalign: 'right', aggregates: ['sum']},
           { text: 'SUM_NumSleeps          ', datafield: 'SUM_NumSleeps',            width: 100,  filterable: false, cellsformat: 'd',  cellsalign: 'right', aggregates: ['sum']},
           { text: 'SUM_NumSearches        ', datafield: 'SUM_NumSearches',          width: 100,  filterable: false, cellsformat: 'd',  cellsalign: 'right', aggregates: ['sum']},
           { text: 'SUM_NumRetries         ', datafield: 'SUM_NumRetries',           width: 100,  filterable: false, cellsformat: 'd',  cellsalign: 'right', aggregates: ['sum']},
           { text: 'AVG_ItemSize           ', datafield: 'AVG_ItemSize',             width: 100,  filterable: false, cellsformat: 'd2', cellsalign: 'right'},
           { text: 'MinNumItems            ', datafield: 'MinNumItems',              width: 100,  filterable: false, cellsformat: 'd', cellsalign: 'right', aggregates: ['min']},
           { text: 'MaxNumItems            ', datafield: 'MaxNumItems',              width: 100,  filterable: false, cellsformat: 'd', cellsalign: 'right', aggregates: ['max']},
           { text: 'MAX_NumUsedItems       ', datafield: 'MAX_NumUsedItems',         width: 100,  filterable: false, cellsformat: 'd', cellsalign: 'right', aggregates: ['max']},
           { text: 'NumItemsUsedHWM        ', datafield: 'NumItemsUsedHWM',          width: 100,  filterable: false, cellsformat: 'd', cellsalign: 'right'},
           { text: 'MinUsedItemSize        ', datafield: 'MinUsedItemSize',          width: 100,  filterable: false, cellsformat: 'd', cellsalign: 'right', aggregates: ['min']},
           { text: 'AvgUsedItemSize        ', datafield: 'AvgUsedItemSize',          width: 100,  filterable: false, cellsformat: 'd2', cellsalign: 'right'},
           { text: 'MaxUsedItemSize        ', datafield: 'MaxUsedItemSize',          width: 100,  filterable: false, cellsformat: 'd', cellsalign: 'right', aggregates: ['max']},
           { text: 'MAX_NumUsedItemsMinSize', datafield: 'MAX_NumUsedItemsMinSize',  width: 100,  filterable: false, cellsformat: 'd', cellsalign: 'right', aggregates: ['max']},
           { text: 'MAX_NumUsedItemsMaxSize', datafield: 'MAX_NumUsedItemsMaxSize',  width: 100,  filterable: false, cellsformat: 'd', cellsalign: 'right', aggregates: ['max']},
           { text: 'MAX_NumFreeItems       ', datafield: 'MAX_NumFreeItems',         width: 100,  filterable: false, cellsformat: 'd', cellsalign: 'right', aggregates: ['max']},
           { text: 'MinFreeItemSize        ', datafield: 'MinFreeItemSize',          width: 100,  filterable: false, cellsformat: 'd', cellsalign: 'right', aggregates: ['min']},
           { text: 'AvgFreeItemSize        ', datafield: 'AvgFreeItemSize',          width: 100,  filterable: false, cellsformat: 'd2', cellsalign: 'right'},
           { text: 'MaxFreeItemSize        ', datafield: 'MaxFreeItemSize',          width: 100,  filterable: false, cellsformat: 'd', cellsalign: 'right', aggregates: ['max']},
           { text: 'MAX_NumFreeItemsMinSize', datafield: 'MAX_NumFreeItemsMinSize',  width: 100,  filterable: false, cellsformat: 'd', cellsalign: 'right', aggregates: ['max']},
           { text: 'MAX_NumFreeItemsMaxSize', datafield: 'MAX_NumFreeItemsMaxSize',  width: 100,  filterable: false, cellsformat: 'd', cellsalign: 'right', aggregates: ['max']},
           { text: 'MAX_NumBlocks          ', datafield: 'MAX_NumBlocks',            width: 100,  filterable: false, cellsformat: 'd', cellsalign: 'right', aggregates: ['max']},
           { text: 'MAX_MemSize1           ', datafield: 'MAX_MemSize1',             width: 100,  filterable: false, cellsformat: 'd', cellsalign: 'right', aggregates: ['max']},
           { text: 'MAX_NumUsedItemsSize1  ', datafield: 'MAX_NumUsedItemsSize1',    width: 100,  filterable: false, cellsformat: 'd', cellsalign: 'right', aggregates: ['max']},
           { text: 'MAX_NumFreeItemsSize1  ', datafield: 'MAX_NumFreeItemsSize1',    width: 100,  filterable: false, cellsformat: 'd', cellsalign: 'right', aggregates: ['max']},
           { text: 'MAX_MemSize2           ', datafield: 'MAX_MemSize2',             width: 100,  filterable: false, cellsformat: 'd', cellsalign: 'right', aggregates: ['max']},
           { text: 'MAX_NumUsedItemsSize2  ', datafield: 'MAX_NumUsedItemsSize2',    width: 100,  filterable: false, cellsformat: 'd', cellsalign: 'right', aggregates: ['max']},
           { text: 'MAX_NumFreeItemsSize2  ', datafield: 'MAX_NumFreeItemsSize2',    width: 100,  filterable: false, cellsformat: 'd', cellsalign: 'right', aggregates: ['max']}
    ]
  });

  function refresh_MemUsage_statistics (grid) {
    var asemondata = jQuery.data(grid, 'asemondata');
    var MemUsageExists = 0;


    if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_MemUsage') )  )
      MemUsageExists = 1;
    
    if ( MemUsageExists == 0) {
      $('#MemUsage_statistics').hide();
      $('#MemUsage_statistics_mess').show();
      $('#MemUsage_statistics_mess').html('<p>MemUsage data is not available. This collector works with ASE 15.7 and upper. (Add  MemUsage_switch.xml in the asemon_logger config file)</p>');
      $.extend(asemondata, {'querydata' : {'queryfile' : '', 'query': ''}});
      return;
    }
    else {
      $('#MemUsage_statistics').show();
      $('#MemUsage_statistics_mess').hide();
    }


    $(grid).asemonGrid({'querydata': {'queryfile' : '../ASE/sql/sql_MemUsage_statistics.php'}});
   
  }

  onArchCnxOpened = function(){
    $('.ASE-MemUsage').removeClass('nondisplay');
    $('#MemUsage_statistics').asemonGrid('refresh');
  }

</script>
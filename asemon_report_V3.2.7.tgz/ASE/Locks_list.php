<div class="ASE-Locks nondisplay">
  <center>
  <div class="maingrid">
    <div ID="lock_list" class="asemongrid singlegrid" ></div>
  </div>
  </center>
</div>


<script type="text/javascript">

  var height =    $('#page-content').innerHeight() - 55;

  if (typeof detail_type != 'undefined')
    $('.ASE-Locks').removeClass('nondisplay');

  $('#lock_list').asemonGrid({
    'title' : 'Blocking occurences',
    'width' : '100%',
    'height' : height,
    'rowcount': '200',
    'editable': false,
    'filterable': true,
    'sortable': true,
    'altrows': false,
    'cursor' : 'pointer',
    'beforeRefresh': function() {refresh_lock_list (this[0]);},
    'querydata' : {
                     'queryfile' : ''
                  },
    'datafields': [
     { name: 'TS', type: 'string'}
     ],
    'columns': [
     { text: 'Timestamp', datafield: 'TS',     width: 100, filterable: false}
     ],
    'datafieldsMapping' : {'BlockedBy': 'A.BlockedBy' }
  });

  $("#lock_list").on('rowselect', function (event) {
    var rowindex = event.args.rowindex;
    //alert ("row "+rowindex+" selected");

    rowdata = $('#lock_list').jqxGrid('getrowdatabyid', rowindex);
    if (typeof rowdata == 'undefined') return 0;

    openWindowFromGrid ("#lock_list", "detail_page.php", {ARContextJSON: ARContext, 'displaylevel' : 1, 'detail_type': 'PROCESS', 'Timestamp': rowdata.TS, 'Spid': rowdata.SPID, 'KPID': rowdata.KPID});
  });


  $("#lock_list").on('sort', function (event) {
  	if ( (event.args.sortinformation.sortcolumn == null) || (event.args.sortinformation.sortcolumn == "") ) return;// Modif JPM le 29/08/2022 pour evivter une erreur lors du clear du grid
  	$('#lock_list').asemonGrid('refresh');
  });


  function refresh_lock_list (grid) {
    var asemondata = jQuery.data(grid, 'asemondata');
    var support150 = false;
    var cols = [];
    var fields = [];
    var queryfile = '../ASE/sql/sql_locks_list.php';
    if ( (ARContext.ServerName!="") && ( existColumn(ARContext.ServerName+'_BlockedP', 'WaitTime') )  ) {
      support150 = true;
      queryfile = '../ASE/sql/sql_locks_list_V15.php';
    }

    var previousValue = '';
    var altcolor = true;
    var cellsrenderer = function (row, column, value, defaultHtml) {
      if ((column == 'TS')||(column == 'Timestamp')) {
        if (value != previousValue) {
          // change color
          if (altcolor)
            altcolor = false;
          else
            altcolor = true;
          previousValue = value;
        }
      }
      if (altcolor) {
        var element = $(defaultHtml);
        element.css({ 'background-color': '#e0e9f5', 'width': '100%', 'height': '100%', 'margin': '0px', 'padding' : '4px' });
        return element[0].outerHTML;
      }
      else
        return defaultHtml;
    }


    if (support150)
    {
          fields = [
                 { name: 'TS',           type: 'string'},
                 { name: 'WaitTime',     type: 'number'},
                 { name: 'SPID',         type: 'number'},
                 { name: 'KPID',         type: 'number'},
                 { name: 'DBID',         type: 'number'},
                 { name: 'ParentSPID',   type: 'number'},
                 { name: 'LockID',       type: 'number'},
                 { name: 'BlockedBy',    type: 'number'},
                 { name: 'BlockedState', type: 'string'},
                 { name: 'Context',      type: 'number'},
                 { name: 'ObjectID',     type: 'number'},
                 { name: 'lckBase',      type: 'string'},
                 { name: 'lckObjet',     type: 'string'},
                 { name: 'lckPage',      type: 'number'},
                 { name: 'lckRow',       type: 'number'},
                 { name: 'LockState',    type: 'string'},
                 { name: 'LockType',     type: 'string'},
                 { name: 'LockLevel',    type: 'number'},
                 { name: 'Usr',          type: 'string'},
                 { name: 'Trn',          type: 'string'},
                 { name: 'Prg',          type: 'string'},
                 { name: 'Prc',          type: 'string'},
                 { name: 'Line',         type: 'number'}
          ];
          cols= [
                 { text: 'Timestamp',    datafield: 'TS',           width: 171, cellsrenderer: cellsrenderer, sortable:true, filterable: false},
                 { text: 'WaitTime',     datafield: 'WaitTime',     width: 90,  cellsrenderer: cellsrenderer, sortable:true,  filterable: false, cellsformat: 'd0', cellsalign: 'right' },
                 { text: 'SPID',         datafield: 'SPID',         width: 90,  cellsrenderer: cellsrenderer, sortable:false, filterable: true, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'KPID',         datafield: 'KPID',         width: 90,  cellsrenderer: cellsrenderer, sortable:false, filterable: true, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'DBID',         datafield: 'DBID',         width: 90,  cellsrenderer: cellsrenderer, sortable:false, filterable: true, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'ParentSPID',   datafield: 'ParentSPID',   width: 90,  cellsrenderer: cellsrenderer, sortable:false, filterable: true, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'LockID',       datafield: 'LockID',       width: 90,  cellsrenderer: cellsrenderer, sortable:false, filterable: true, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'BlockedBy',    datafield: 'BlockedBy',    width: 90,  cellsrenderer: cellsrenderer, sortable:false, filterable: true, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'BlockedState', datafield: 'BlockedState', width: 90,  cellsrenderer: cellsrenderer, sortable:false, filterable: true},
                 { text: 'Context',      datafield: 'Context',      width: 90,  cellsrenderer: cellsrenderer, sortable:false, filterable: true, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'ObjectID',     datafield: 'ObjectID',     width: 90,  cellsrenderer: cellsrenderer, sortable:false, filterable: true, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'lckBase',      datafield: 'lckBase',      width: 90,  cellsrenderer: cellsrenderer, sortable:false, filterable: true},
                 { text: 'lckObjet',     datafield: 'lckObjet',     width: 90,  cellsrenderer: cellsrenderer, sortable:false, filterable: true},
                 { text: 'lckPage',      datafield: 'lckPage',      width: 90,  cellsrenderer: cellsrenderer, sortable:false, filterable: true, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'lckRow',       datafield: 'lckRow',       width: 90,  cellsrenderer: cellsrenderer, sortable:false, filterable: true, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'LockState',    datafield: 'LockState',    width: 90,  cellsrenderer: cellsrenderer, sortable:false, filterable: true},
                 { text: 'LockType',     datafield: 'LockType',     width: 90,  cellsrenderer: cellsrenderer, sortable:false, filterable: true},
                 { text: 'LockLevel',    datafield: 'LockLevel',    width: 90,  cellsrenderer: cellsrenderer, sortable:false, filterable: true, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'Usr',          datafield: 'Usr',          width: 90,  cellsrenderer: cellsrenderer, sortable:false, filterable: true},
                 { text: 'Trn',          datafield: 'Trn',          width: 90,  cellsrenderer: cellsrenderer, sortable:false, filterable: true},
                 { text: 'Prog',         datafield: 'Prg',          width: 90,  cellsrenderer: cellsrenderer, sortable:false, filterable: true},
                 { text: 'Proc',         datafield: 'Prc',          width: 90,  cellsrenderer: cellsrenderer, sortable:false, filterable: true},
                 { text: 'Line',         datafield: 'Line',         width: 90,  cellsrenderer: cellsrenderer, sortable:false, filterable: true, cellsformat: 'd', cellsalign: 'right'}
          ];
    }
    else
    {
          fields = [
                 { name: 'Timestamp',    type: 'string'},
                 { name: 'time_blocked', type: 'number'},
                 { name: 'blockedSpid',  type: 'number'},
                 { name: 'blockedUsr',   type: 'string'},
                 { name: 'blockedTran',  type: 'string'},
                 { name: 'blockedProg',  type: 'string'},
                 { name: 'blockedProc',  type: 'string'},
                 { name: 'blockedLine',  type: 'number'},
                 { name: 'blockingSpid', type: 'number'},
                 { name: 'blockingUsr',  type: 'string'},
                 { name: 'blockingTran', type: 'string'},
                 { name: 'blockingProg', type: 'string'},
                 { name: 'blockingProc', type: 'string'},
                 { name: 'blockingLine', type: 'number'},
                 { name: 'lckBase',      type: 'string'},
                 { name: 'lckObjet',     type: 'string'},
                 { name: 'lckPage',      type: 'number'},
                 { name: 'lckRow',       type: 'number'},
                 { name: 'lckName',      type: 'string'}
          ];
          cols= [
                 { text: 'Timestamp',    datafield: 'Timestamp',    width: 171, cellsrenderer: cellsrenderer, sortable:true, filterable: false},
                 { text: 'time_blocked', datafield: 'time_blocked', width: 90,  cellsrenderer: cellsrenderer, sortable:true,  filterable: false, cellsformat: 'd', cellsalign: 'right' },
                 { text: 'blockedSpid',  datafield: 'blockedSpid',  width: 90,  cellsrenderer: cellsrenderer, sortable:false, filterable: true, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'blockedUsr',   datafield: 'blockedUsr',   width: 90,  cellsrenderer: cellsrenderer, sortable:false, filterable: true},
                 { text: 'blockedTran',  datafield: 'blockedTran',  width: 90,  cellsrenderer: cellsrenderer, sortable:false, filterable: true},
                 { text: 'blockedProg',  datafield: 'blockedProg',  width: 90,  cellsrenderer: cellsrenderer, sortable:false, filterable: true},
                 { text: 'blockedProc',  datafield: 'blockedProc',  width: 90,  cellsrenderer: cellsrenderer, sortable:false, filterable: true},
                 { text: 'blockedLine',  datafield: 'blockedLine',  width: 90,  cellsrenderer: cellsrenderer, sortable:false, filterable: false, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'blockingSpid', datafield: 'blockingSpid', width: 90,  cellsrenderer: cellsrenderer, sortable:false, filterable: false, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'blockingUsr',  datafield: 'blockingUsr',  width: 90,  cellsrenderer: cellsrenderer, sortable:false, filterable: true},
                 { text: 'blockingTran', datafield: 'blockingTran', width: 90,  cellsrenderer: cellsrenderer, sortable:false, filterable: true},
                 { text: 'blockingProg', datafield: 'blockingProg', width: 90,  cellsrenderer: cellsrenderer, sortable:false, filterable: true},
                 { text: 'blockingProc', datafield: 'blockingProc', width: 90,  cellsrenderer: cellsrenderer, sortable:false, filterable: true},
                 { text: 'blockingLine', datafield: 'blockingLine', width: 90,  cellsrenderer: cellsrenderer, sortable:false, filterable: true, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'lckBase',      datafield: 'lckBase',      width: 90,  cellsrenderer: cellsrenderer, sortable:false, filterable: false},
                 { text: 'lckObjet',     datafield: 'lckObjet',     width: 90,  cellsrenderer: cellsrenderer, sortable:false, filterable: false},
                 { text: 'lckPage',      datafield: 'lckPage',      width: 90,  cellsrenderer: cellsrenderer, sortable:false, filterable: false, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'lckRow',       datafield: 'lckRow',       width: 90,  cellsrenderer: cellsrenderer, sortable:false, filterable: false, cellsformat: 'd', cellsalign: 'right'},
                 { text: 'lckName',      datafield: 'lckName',      width: 90,  cellsrenderer: cellsrenderer, sortable:false, filterable: true}
          ];
    }



    $(grid).asemonGrid({
      'querydata' : {
                     'queryfile' : queryfile,
                     'support150' : support150
                    },
      'datafields': fields,
      'columns': cols 
    });
   
  }

  onArchCnxOpened = function(){
    $('.ASE-Locks').removeClass('nondisplay');
    $('#lock_list').asemonGrid('refresh');
  }

</script>
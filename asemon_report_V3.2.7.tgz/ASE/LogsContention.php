<div class="ASE-LogsCont nondisplay">
  <center>
  <div id="allinfo">
    <H1> Log's Contention graphs </H1>
    <div id="LogsContention_DIV" style="display: flex;flex-direction: row;justify-content: space-around;flex-wrap: wrap;align-items: center;">
    </div>
  </div>
  </center>
</div>

<script type="text/javascript">

  var ASM_XHR_refresh_logscontention;
  
  function refresh_logscontention () {
    
    $('#LogsContention_DIV').empty();
    
    var DBName;
    var query = 
      "select DBName, " 
    + " waitPct= convert(float,sum(AppendLogWaits) )*100/sum(AppendLogRequests) "
    + " from "+ARContext.ServerName+"_OpenDbs          "
    + " where Timestamp >='"+ARContext.StartTimestamp+"'"
    + " and Timestamp <'"+ARContext.EndTimestamp+"'"
    + " group by DBName order by waitPct desc";
    
    
    var data = {ARContextJSON: JSON.stringify(ARContext), query: query};

    if (ASM_XHR_refresh_logscontention != null) {
      ASM_XHR_refresh_logscontention.abort();
      ASM_XHR_refresh_logscontention = null;
    }
    incXHRcnt();
    ASM_XHR_refresh_logscontention = $.post( 'COMMON/simplequery.php', data ).done(function(res) {
      var result = JSON.parse(res);
      if ( checkSQLError(result, 'refresh_logscontention') ) return;
      for (var i=0; i < result.TotalRows; i++) {
        DBName = result.Rows[i].DBName;
        refresh_graphLogContention(DBName);
      }
    
    })
    .fail(function(data) {
      if (data.statusText == 'abort')
        return;
      alert( "error retreiving logscontention" );
    })
    .always(function() {
      decXHRcnt();
    });


  }

  function refresh_graphLogContention (DBName) {

    var graph;
    
    graph = $('#graph_logcont_'+DBName).highcharts();
    if (typeof graph == 'undefined') {
      $('#LogsContention_DIV').append('<div id="graph_logcont_'+DBName+'"  class="mainchart" style="min-width:700px;width:1200px" > </div>');
      $('#graph_logcont_'+DBName).asemonChart({
      title: {
        text: "Log contention on : \""+DBName+"\""
      },
      queryFile : '../ASE/sql/graph_LogContention.php',
      tableName : 'OpenDbs',
      data: {
        DBName: DBName
      },
      chart: {
         type: 'line'
      },
      series: [
        { name: 'LogContention'      }
      ],
      legend: {
         enabled: true
      },
      yAxis: {
        min : 0 ,
        max : 100 
        }
    
      });
    }
    graph = $('#graph_logcont_'+DBName).highcharts();
    $('#graph_logcont_'+DBName).asemonChart('refresh',threadDelays);



  }

</script>
<div class="ASE-ChEvents nondisplay">
  <center>
  <div class="maingrid">
    <div ID="ChEvents_statistics" class="asemongrid singlegrid" ></div>
    <div ID="ChEvents_statistics_mess" class="nodisplay" >  </div>
  </div>
  </center>
</div>

<script type="text/javascript">
  var height =    $('#page-content').innerHeight() - 55;




  if (typeof detail_type != 'undefined')
    $('.ASE-ChEvents').removeClass('nondisplay');

  $('#ChEvents_statistics').asemonGrid({
    'title' : 'Configuration changes',
    'width' : '100%',
    'height' : height,
    'rowcount': 200,
    'filterable': true,
    'showaggregates': false,
    'querydata': {'queryfile' : '', 'default_order_by' : 'ts'},
    'beforeRefresh': function() {refresh_ChEvents_statistics (this[0]);},
    'datafieldsMapping': {},
    'datafields': [
           { name: 'ts',         type: 'string'}
    ],
    'columns': [
           { text: 'Timestamp ', datafield: 'ts',         width: 170,  filterable: false}
    ]
  });

  function refresh_ChEvents_statistics (grid) {
    var asemondata = jQuery.data(grid, 'asemondata');
    var ChEventsExists = 0;


    if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_ChEvents') )  )
      ChEventsExists = 1;
    
    if ( ChEventsExists == 0) {
      $('#ChEvents_statistics').hide();
      $('#ChEvents_statistics_mess').show();
      $('#ChEvents_statistics_mess').html('<p>Configuration change data is not available. This collector works with ASE 16 and upper. ChEvents stats capture  has not been activated for server '+ARContext.ServerName+'.</P><P> (Add  ChEvents.xml in the asemon_logger config file, and configure auditing option \'config_history\' on the monitored server)</p>');
      $.extend(asemondata, {'querydata' : {'queryfile' : '', 'query': ''}});
      return;
    }
    else {
      $('#ChEvents_statistics').show();
      $('#ChEvents_statistics_mess').hide();
    }


    $(grid).asemonGrid({
      'querydata': {'queryfile' : '../ASE/sql/sql_chevents_statistics.php'},
      'datafields': [
           { name: 'ts',         type: 'string'},
           { name: 'area',       type: 'string'},
           { name: 'type',       type: 'string'},
           { name: 'target',     type: 'string'},
           { name: 'element',    type: 'string'},
           { name: 'oldvalue',   type: 'string'},
           { name: 'newvalue',   type: 'string'},
           { name: 'mode',       type: 'string'},
           { name: 'username',   type: 'string'},
           { name: 'instanceid', type: 'number'}
      ],
      'columns': [
           { text: 'Timestamp ', datafield: 'ts',         width: 170,  filterable: false},
           { text: 'area      ', datafield: 'area',       width: 100,  filterable: true},
           { text: 'type      ', datafield: 'type',       width: 100,  filterable: true},
           { text: 'target    ', datafield: 'target',     width: 100,  filterable: true},
           { text: 'element   ', datafield: 'element',    width: 100,  filterable: true},
           { text: 'oldvalue  ', datafield: 'oldvalue',   width: 180,  filterable: true},
           { text: 'newvalue  ', datafield: 'newvalue',   width: 100,  filterable: true},
           { text: 'mode      ', datafield: 'mode',       width: 100,  filterable: true},
           { text: 'username  ', datafield: 'username',   width: 100,  filterable: true},
           { text: 'instanceid', datafield: 'instanceid', width: 100,  filterable: true},
           { text: '', width: 25,  filterable: false}
      ]
    });
   
  }

  onArchCnxOpened = function(){
    $('.ASE-ChEvents').removeClass('nondisplay');
    $('#ChEvents_statistics').asemonGrid('refresh');
  }

</script>
<div class="AllDBs nondisplay">
  <center>
  <div class="maingrid">
    <div ID="AllDatabasesList" class="asemongrid singlegrid" ></div>
  </div>
  </center>
</div>


<script type="text/javascript">

  var height =    $('#page-content').innerHeight()-50;

  if (typeof detail_type != 'undefined')
    $('.AllDBs').removeClass('nondisplay');

  $('#AllDatabasesList').asemonGrid({
    'title' : 'All databases',
    'width' : '100%',
    'height' : height,
    'rowcount': '0',
    'editable': false,
    'filterable': true,
    'cursor' : 'pointer',
    'beforeRefresh': function() {refresh_AllDatabasesList (this[0]);},
    'querydata' : {'queryfile' : ''},
    'datafieldsMapping': {},
    'datafields': [
     { name: 'srvname', type: 'string'}
     ],
    'columns': [
     { text: 'srvname', datafield: 'srvname',     width: 100, filterable: true}
     ]
  });

  var calcColor_pctUsed = function (row, column, value, defaultHtml) {
    var element = $(defaultHtml);
    var color = "";

    if ( value > 90)
      color = "red";
    else
      if ( value > 70)
        color = "yellow";

    if (color != "") {
      element.css({ 'background-color': color, 'width': '100%', 'height': '100%', 'margin': '0px', 'padding' : '4px' });
      return element[0].outerHTML; 
    }
    else
      return defaultHtml;
  }


  $("#AllDatabasesList").bind('cellclick', function (event) {
    var column = event.args.column;
    var rowindex = event.args.rowindex;
    //alert ("row "+rowindex+" clicked");

    rowdata = $('#AllDatabasesList').jqxGrid('getrowdatabyid', rowindex);
    if (typeof rowdata == 'undefined') return 0;

    ARContext.ServerName = rowdata.srvname;
    
    openWindowFromGrid ("#SpaceUsed_statistics", "detail_page.php", {ARContextJSON: ARContext, 'displaylevel' : 1, 'detail_type': 'SPACEDETAIL', 'dbid': rowdata.dbid, 'dbname': rowdata.dbname, 'isMixedLog': rowdata.isMixedLog});

    ARContext.ServerName = "";
  });



  function refresh_AllDatabasesList (grid) {
    var asemondata = jQuery.data(grid, 'asemondata');
    var cols = [];
    var fields = [];
    var queryfile = '../ASE/sql/sql_alldatabases.php';

    fields = [
           { name: 'srvname',      type: 'string'},
           { name: 'dbid',         type: 'number'},
           { name: 'dbname',       type: 'string'},
           { name: 'TotalSize_Mb', type: 'number'},
           { name: 'DataSize_Mb',  type: 'number'},
           { name: 'LogSize_Mb',   type: 'number'},
           { name: 'DataFree_Mb',  type: 'number'},
           { name: 'PctDatUsed',   type: 'number'},
           { name: 'isMixedLog',   type: 'number'},
           { name: 'LogFree_Mb',   type: 'number'},
           { name: 'PctLogUsed',   type: 'number'},
           { name: 'PageSize',     type: 'number'},
           { name: 'BckET',               type: 'string'},
           { name: 'Bck_s',               type: 'number'},
           { name: 'BtranET',             type: 'string'},
           { name: 'Btran_s',             type: 'number'},
           { name: 'LastChkpt',           type: 'string'}
   ];

    cols= [
           { text: 'srvname',      datafield: 'srvname',       width: 150, filterable: true},
           { text: 'dbname',       datafield: 'dbname',        width: 150, filterable: true},
           { text: 'TotalSize_Mb', datafield: 'TotalSize_Mb',  width: 100, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']},
           { text: 'DataSize_Mb',  datafield: 'DataSize_Mb',   width: 100, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']},
           { text: 'LogSize_Mb',   datafield: 'LogSize_Mb',    width: 100, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']},
           { text: 'DataFree_Mb',  datafield: 'DataFree_Mb',   width: 100, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']},
           { text: 'PctDataUsed',  datafield: 'PctDatUsed',    width: 90,  filterable: false, cellsformat: 'd2',cellsalign: 'right', cellsrenderer: calcColor_pctUsed},
           { text: 'LogFree_Mb',   datafield: 'LogFree_Mb',    width: 100, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']},
           { text: 'PctLogUsed',   datafield: 'PctLogUsed',    width: 90,  filterable: false, cellsformat: 'd2',cellsalign: 'right', cellsrenderer: calcColor_pctUsed},
           { text: 'PageSize',     datafield: 'PageSize',      width: 90,  filterable: false, cellsformat: 'd2',cellsalign: 'right'},
           { text: 'BackupEndTime',           datafield: 'BckET',      width: 140},
           { text: 'dumpdb_duration_s',       datafield: 'Bck_s',      width: 100,  cellsalign: 'right'},
           { text: 'LastTranLogEndDumpTime',  datafield: 'BtranET',    width: 140},
           { text: 'dumptran_duration_s',     datafield: 'Btran_s',    width: 100,  cellsalign: 'right'},
           { text: 'LastCheckpointTime',      datafield: 'LastChkpt',  width: 140},
           { text: '', width: 25,  filterable: false},
    ];

    $(grid).asemonGrid({
      'querydata' : {
                     'queryfile' : queryfile
                    },
      'datafields': fields,
      'columns': cols ,
      'default_order_by': 'srvname,dbname'
    });
  }

  onArchCnxOpened = function(){
    $('.AllDBs').removeClass('nondisplay');
    $('#AllDatabasesList').asemonGrid('refresh');
  }

</script>
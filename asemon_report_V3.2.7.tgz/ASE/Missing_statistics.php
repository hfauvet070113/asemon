<div class="ASE-MissStats nondisplay">
  <center>
  <div class="maingrid">
    <div ID="MissStats_statistics" class="asemongrid singlegrid" ></div>
    <div ID="MissStats_statistics_mess" class="nodisplay" >  </div>
  </div>
  </center>
</div>

<script type="text/javascript">
  var height =    $('#page-content').innerHeight() - 55;

  if (typeof detail_type != 'undefined')
    $('.ASE-MissStats').removeClass('nondisplay');

  $('#MissStats_statistics').asemonGrid({
    'title' : 'Missing statistics',
    'width' : '100%',
    'height' : height,
//    'rowsheight': 80,
    'rowcount': 200,
    'filterable': true,
    'showaggregates': false,
    'querydata': {'queryfile' : '', 'default_order_by' : 'tabname'},
    'beforeRefresh': function() {refresh_MissStats_statistics (this[0]);},
    'datafieldsMapping': {},
    'datafields': [
           { name: 'dbname',  type: 'string'},
           { name: 'owner',   type: 'string'},
           { name: 'tabname', type: 'string'},
           { name: 'Counter', type: 'number'},
           { name: 'c1',      type: 'string'},
           { name: 'c2',      type: 'string'},
           { name: 'c3',      type: 'string'},
           { name: 'c4',      type: 'string'},
           { name: 'c5',      type: 'string'},
           { name: 'c6',      type: 'string'},
           { name: 'c7',      type: 'string'},
           { name: 'c8',      type: 'string'},
           { name: 'c9',      type: 'string'},
           { name: 'c10',     type: 'string'},
           { name: 'c11',     type: 'string'},
           { name: 'c12',     type: 'string'},
           { name: 'c13',     type: 'string'},
           { name: 'c14',     type: 'string'},
           { name: 'c15',     type: 'string'},
           { name: 'c16',     type: 'string'},
           { name: 'c17',     type: 'string'},
           { name: 'c18',     type: 'string'},
           { name: 'c19',     type: 'string'},
           { name: 'c20',     type: 'string'},
           { name: 'c21',     type: 'string'},
           { name: 'c22',     type: 'string'},
           { name: 'c23',     type: 'string'},
           { name: 'c24',     type: 'string'},
           { name: 'c25',     type: 'string'},
           { name: 'c26',     type: 'string'},
           { name: 'c27',     type: 'string'},
           { name: 'c28',     type: 'string'},
           { name: 'c29',     type: 'string'},
           { name: 'c30',     type: 'string'},
           { name: 'c31',     type: 'string'}
    ],
    'columns': [
           { text: 'dbname ', datafield: 'dbname',  width: 70,  filterable: true},
           { text: 'owner  ', datafield: 'owner',   width: 50,  filterable: true},
           { text: 'tabname', datafield: 'tabname', width: 90,  filterable: true},
           { text: 'counter', datafield: 'Counter', width: 100, filterable: false, cellsformat: 'd',  cellsalign: 'right'},
           { text: 'c1     ', datafield: 'c1',      width: 90,  filterable: false},
           { text: 'c2     ', datafield: 'c2',      width: 90,  filterable: false},
           { text: 'c3     ', datafield: 'c3',      width: 90,  filterable: false},
           { text: 'c4     ', datafield: 'c4',      width: 90,  filterable: false},
           { text: 'c5     ', datafield: 'c5',      width: 90,  filterable: false},
           { text: 'c6     ', datafield: 'c6',      width: 90,  filterable: false},
           { text: 'c7     ', datafield: 'c7',      width: 90,  filterable: false},
           { text: 'c8     ', datafield: 'c8',      width: 90,  filterable: false},
           { text: 'c9     ', datafield: 'c9',      width: 90,  filterable: false},
           { text: 'c10    ', datafield: 'c10',     width: 90,  filterable: false},
           { text: 'c11    ', datafield: 'c11',     width: 90,  filterable: false},
           { text: 'c12    ', datafield: 'c12',     width: 90,  filterable: false},
           { text: 'c13    ', datafield: 'c13',     width: 90,  filterable: false},
           { text: 'c14    ', datafield: 'c14',     width: 90,  filterable: false},
           { text: 'c15    ', datafield: 'c15',     width: 90,  filterable: false},
           { text: 'c16    ', datafield: 'c16',     width: 90,  filterable: false},
           { text: 'c17    ', datafield: 'c17',     width: 90,  filterable: false},
           { text: 'c18    ', datafield: 'c18',     width: 90,  filterable: false},
           { text: 'c19    ', datafield: 'c19',     width: 90,  filterable: false},
           { text: 'c20    ', datafield: 'c20',     width: 90,  filterable: false},
           { text: 'c21    ', datafield: 'c21',     width: 90,  filterable: false},
           { text: 'c22    ', datafield: 'c22',     width: 90,  filterable: false},
           { text: 'c23    ', datafield: 'c23',     width: 90,  filterable: false},
           { text: 'c24    ', datafield: 'c24',     width: 90,  filterable: false},
           { text: 'c25    ', datafield: 'c25',     width: 90,  filterable: false},
           { text: 'c26    ', datafield: 'c26',     width: 90,  filterable: false},
           { text: 'c27    ', datafield: 'c27',     width: 90,  filterable: false},
           { text: 'c28    ', datafield: 'c28',     width: 90,  filterable: false},
           { text: 'c29    ', datafield: 'c29',     width: 90,  filterable: false},
           { text: 'c30    ', datafield: 'c30',     width: 90,  filterable: false},
           { text: 'c31    ', datafield: 'c31',     width: 90,  filterable: false}
    ]
  });

  function refresh_MissStats_statistics (grid) {
    var asemondata = jQuery.data(grid, 'asemondata');
    var MissStats = 0;


    if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_MissStats') )  )
      MissStats = 1;
    
    if ( MissStats == 0) {
      $('#MissStats_statistics').hide();
      $('#MissStats_statistics_mess').show();
      $('#MissStats_statistics_mess').html('<p>Missing statistics data is not available. This collector works with ASE 15.0.3ESD#1 and upper. Missing stats capture  has not been activated for server '+ARContext.ServerName+'.<P> (Add  MissStats.xml in the asemon_logger config file, and configure "capture missing statistics" to 1 on the monitored server)</p>');
      $.extend(asemondata, {'querydata' : {'queryfile' : '', 'query': ''}});
      return;
    }
    else {
      $('#MissStats_statistics').show();
      $('#MissStats_statistics_mess').hide();
    }


    $(grid).asemonGrid({'querydata': {'queryfile' : '../ASE/sql/sql_missing_statistics.php'}});
   
  }

  onArchCnxOpened = function(){
    $('.ASE-MissStats').removeClass('nondisplay');
    $('#MissStats_statistics').asemonGrid('refresh');
  }

</script>
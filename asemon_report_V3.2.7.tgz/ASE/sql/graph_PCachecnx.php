<?php
if ($colV16SP04Exists==1)
   $selcolV16SP04=",prepared_stmt_memusage";
else
   $selcolV16SP04="";

$query = "
select Ts=convert(varchar,ListTimestamp.Timestamp,109), 
  memusage".$selcolV16SP04."
from (select distinct Timestamp from ".$ServerName."_CnxActiv 
      where Timestamp >='".$StartTimestamp."'
      and Timestamp <='".$EndTimestamp."'
      ) ListTimestamp  
      left outer join ".$ServerName."_CnxActiv B on ListTimestamp.Timestamp = B.Timestamp and Loggedindatetime between dateadd(ss,-1,'".$Loggedindatetime."') and dateadd(ss,+1,'".$Loggedindatetime."') and B.Spid=".$Spid."
order by ListTimestamp.Timestamp";
?>
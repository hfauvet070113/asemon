<?php
$query = "
select Ts=convert(varchar,Timestamp,109), 
  DataPageCR=F.dpageCR,
  IndexPageCR=F.ipageCR,
  DataRowCR=F.drowCR  
  
  from ".$ServerName."_Fragment F
  where F.dbname='".$dbname."'
  and F.owner='".$owner."'
  and F.tabname='".$tabname."'
  and F.indid=convert(int,'".$indid."')
  order by Timestamp";
?>
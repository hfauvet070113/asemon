<?php
  // retreive all posted params and affect them to variables
  foreach ($_POST as $key => $value)
    @$$key=$value;

  include ("../../COMMON/connectArchiveServer.php");


  $TotalRows = 0;
  $restrictPlan="";
  if ($CompileDate != "")
      $restrictPlan = "and CompileDate = '".$CompileDate."'";
  if ($PlanID != "")
      $restrictPlan = "and PlanID = ".$PlanID;
  $query = "
  select
  OwnerUID   ,
  DBID       ,
  ObjectName ,
  ObjectType ,
  OwnerName  ,
  DBName,
  MaxMemUsageKB = max(MemUsageKB),
  sumExecutionCount=sum(ExecutionCount),
  avgCPUTime       = case when sum(RequestCnt) = 0 then 0 else sum(1.*CPUTime)/sum(RequestCnt)        end,
  avgExecutionTime = case when sum(RequestCnt) = 0 then 0 else sum(1.*ExecutionTime)/sum(RequestCnt)  end,
  avgPhysicalReads = case when sum(RequestCnt) = 0 then 0 else sum(1.*PhysicalReads)/sum(RequestCnt)  end,
  avgLogicalReads  = case when sum(RequestCnt) = 0 then 0 else sum(1.*LogicalReads)/sum(RequestCnt)   end,
  avgPhysicalWrites= case when sum(RequestCnt) = 0 then 0 else sum(1.*PhysicalWrites)/sum(RequestCnt) end,
  avgPagesWritten  = case when sum(RequestCnt) = 0 then 0 else sum(1.*PagesWritten)/sum(RequestCnt)   end,
  sumTempdbRemapCnt=sum(TempdbRemapCnt),
  avgTempdbRemapTime=avg(AvgTempdbRemapTime),
  sumRequestCnt=sum(RequestCnt) 
  
  from ".$ServerName."_CachedPrc (index idx)
  where Timestamp >='".$StartTimestamp."'        
  and Timestamp <'".$EndTimestamp."' 
  and ObjectID = ".$SSQLID."
  ".$restrictPlan."
  group by OwnerUID, DBID,ObjectName, ObjectType, OwnerName , DBName
  ";
  $result = asemon_query($query,$pid);
  if ($result != false){ 
    $row = asemon_fetch_assoc($result); 
    if ($row!=null) 
      $TotalRows = 1;
  }

  if ($error == "")
    $data = array(
      'status' => 'success',
      'TotalRows' => $TotalRows,
      'row' => $row,
      'query' => $query 
      );

  else
    $data = array(
      'status' => 'error',
      'message' => $error,
      'query' => $query
      );

  echo json_encode($data);


?>
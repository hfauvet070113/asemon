<?php

  if (!isset($filter_clause) ) $filter_clause = "";
  if (!isset($sort_clause) )   $sort_clause = "";

  // Check if SQL Text is stored compressed in IQ
  // If yes, will be decompressed in "getgriddata.php"
  $SQLTextIsCompressed = false;
  if ($ArchSrvType=="Sybase IQ") {
    $result = asemon_query("select domain_name from syscolumn C, systable T, sysdomain D where C.table_id=T.table_id and C.domain_id=D.domain_id and T.table_name = '".$ServerName."_CachedSQL' and column_name='SQLText'",$pid);
    $row = asemon_fetch_assoc($result);
    if (strcasecmp(rtrim($row["domain_name"]) , "varbinary") == 0) {
      $SQLTextIsCompressed = true;
    }
  }

if ($SQLtableExists==1) { 
  $query = "set rowcount ".$rowcount."
  select 
    bootcnt=STMStats.bootcount,
    sqlid=STMStats.ssqlid1,
    hashk=STMStats.Hashkey,
    UserID,
    DBID,
    UseCount,
    StatementSize,
    MaxPlanSizeKB,
    MaxCurrentUsageCount,
    MaxUsageCount,
    NumRecompilesSchemaChanges,
    NumRecompilesPlanFlushes,
    MetricsCount,
    MaxPIO,
    AvgPIO,
    TotPIO = 1.*AvgPIO*UseCount,
    MaxLIO,
    AvgLIO,
    TotLIO = 1.*AvgLIO*UseCount,
    MaxCpuTime,
    AvgCpuTime,
    TotCpuTime = 1.*AvgCpuTime*UseCount,
    MaxElapsedTime,
    AvgElapsedTime,
    TotElapsedTime = 1.*AvgElapsedTime*UseCount, 
    DBName,
    CachedDT=convert (varchar, CachedDate, 111)+' '+convert (varchar, CachedDate, 108)+'.'+convert(varchar, datepart(ms,CachedDate)),
    LastUsedDT=convert (varchar, LastUsedDate, 111)+' '+convert (varchar, LastUsedDate, 108)+'.'+convert(varchar, datepart(ms,LastUsedDate)),
    planOK,
    SQLText
from (
  select 
    STM.bootcount,
    STM.SSQLID as ssqlid1,
    STM.Hashkey,
    UserID,
    DBID,
    UseCount=sum(UseCount_smp),
    StatementSize=max(StatementSize),
    MaxPlanSizeKB=max(MaxPlanSizeKB),
    MaxCurrentUsageCount=max(CurrentUsageCount),
    MaxUsageCount=max(MaxUsageCount),
    NumRecompilesSchemaChanges=sum(NumRecompilesSchemaChanges_smp),
    NumRecompilesPlanFlushes=sum(NumRecompilesPlanFlushes_smp),
    MetricsCount=sum(MetricsCount_smp),
    MaxPIO=max(1.*MaxPIO),
    AvgPIO=sum(1.*TotalPIO_smp)/sum(UseCount_smp),
    MaxLIO=max(1.*MaxLIO),
    AvgLIO=sum(1.*TotalLIO_smp)/sum(UseCount_smp),
    MaxCpuTime=max(1.*MaxCpuTime),
    AvgCpuTime=sum(1.*TotalCpuTime_smp)/sum(UseCount_smp),
    MaxElapsedTime=max(1.*MaxElapsedTime),
    AvgElapsedTime=sum(1.*TotalElapsedTime_smp)/sum(UseCount_smp),
    DBName,
    CachedDate,
    LastUsedDate=max(LastUsedDate),
    planOK=''
  from (".$ServerName."_CachedSTM STM  
                                       left outer join ".$ServerName."_CachedSQL SQL on STM.bootcount=SQL.bootcount and STM.SSQLID=SQL.SSQLID and STM.Hashkey=SQL.Hashkey)
  where STM.Timestamp >='".$StartTimestamp."'        
  and STM.Timestamp <'".$EndTimestamp."' 
  ".$filter_clause."

  group by STM.bootcount,STM.SSQLID,STM.Hashkey,UserID,SUserID,DBID,DBName,CachedDate
  having sum(UseCount_smp) >0
  ) STMStats left outer join  ".$ServerName."_CachedSQL CSQL
         on  STMStats.bootcount=CSQL.bootcount and STMStats.ssqlid1=CSQL.SSQLID and STMStats.Hashkey=CSQL.Hashkey ";
}
else
{
  $query = "set rowcount ".$rowcount."
  select 
    bootcnt=STMStats.bootcount,
    sqlid=STMStats.ssqlid1,
    hashk=STMStats.Hashkey,
    UserID,
    DBID,
    UseCount,
    StatementSize,
    MaxPlanSizeKB,
    MaxCurrentUsageCount,
    MaxUsageCount,
    NumRecompilesSchemaChanges,
    NumRecompilesPlanFlushes,
    MetricsCount,
    MaxPIO,
    AvgPIO,
    TotPIO = 1.*AvgPIO*UseCount,
    MaxLIO,
    AvgLIO,
    TotLIO = 1.*AvgLIO*UseCount,
    MaxCpuTime,
    AvgCpuTime,
    TotCpuTime = 1.*AvgCpuTime*UseCount,
    MaxElapsedTime,
    AvgElapsedTime,
    TotElapsedTime = 1.*AvgElapsedTime*UseCount, 
    DBName,
    CachedDT=convert (varchar, CachedDate, 111)+' '+convert (varchar, CachedDate, 108)+'.'+convert(varchar, datepart(ms,CachedDate)),
    LastUsedDT=convert (varchar, LastUsedDate, 111)+' '+convert (varchar, LastUsedDate, 108)+'.'+convert(varchar, datepart(ms,LastUsedDate)),
    planOK='',
    SQLText=''
from (
  select 
    STM.bootcount,
    STM.SSQLID as ssqlid1,
    STM.Hashkey,
    UserID,
    DBID,
    UseCount=sum(UseCount_smp),
    StatementSize=max(StatementSize),
    MaxPlanSizeKB=max(MaxPlanSizeKB),
    MaxCurrentUsageCount=max(CurrentUsageCount),
    MaxUsageCount=max(MaxUsageCount),
    NumRecompilesSchemaChanges=sum(NumRecompilesSchemaChanges_smp),
    NumRecompilesPlanFlushes=sum(NumRecompilesPlanFlushes_smp),
    MetricsCount=sum(MetricsCount_smp),
    MaxPIO=max(1.*MaxPIO),
    AvgPIO=sum(1.*TotalPIO_smp)/sum(UseCount_smp),
    MaxLIO=max(1.*MaxLIO),
    AvgLIO=sum(1.*TotalLIO_smp)/sum(UseCount_smp),
    MaxCpuTime=max(1.*MaxCpuTime),
    AvgCpuTime=sum(1.*TotalCpuTime_smp)/sum(UseCount_smp),
    MaxElapsedTime=max(1.*MaxElapsedTime),
    AvgElapsedTime=sum(1.*TotalElapsedTime_smp)/sum(UseCount_smp),
    DBName,
    CachedDate,
    LastUsedDate=max(LastUsedDate)
  from ".$ServerName."_CachedSTM STM
  where STM.Timestamp >='".$StartTimestamp."'        
  and STM.Timestamp <'".$EndTimestamp."' 
  ".$filter_clause."
  group by STM.bootcount,STM.SSQLID,STM.Hashkey,UserID,SUserID,DBID,DBName,CachedDate
  having sum(UseCount_smp) >0
  ) STMStats";
}

  $query = $query.$sort_clause." 
  set rowcount 0";
?>

<?php
    if (!isset($filter_clause) ) $filter_clause = "";
    if (!isset($sort_clause) )   $sort_clause = "";

if ($ArchSrvType=="Adaptive Server Enterprise"){
$query = "set rowcount ".$rowcount."
  select starttm=convert (varchar, starttime, 111)+' '+convert (varchar, starttime, 108)+'.'+convert(varchar, datepart(ms,starttime)),
    elapsed=datediff(ss, starttime, max(Timestamp)),dbname,dbid,spid,page=1.*page,name,xloid, 
    endtime=convert (varchar, max(Timestamp), 111)+' '+convert (varchar, max(Timestamp), 108)+'.'+convert(varchar, datepart(ms,max(Timestamp))), 
    Loggedindatetime=(select convert (varchar, max (Loggedindatetime), 111)+' '+convert (varchar, max (Loggedindatetime), 108)+'.'+convert(varchar, datepart(ms,max (Loggedindatetime))) from ".$ServerName."_Cnx where Spid=L.spid and Loggedindatetime <= L.starttime)
  from ".$ServerName."_LogsHold L
  where Timestamp >='".$StartTimestamp."'
  and Timestamp <'".$EndTimestamp."'
  ".$filter_clause."
  and starttime != ''
  group by dbname,dbid,spid,page,starttime,name,xloid
  ".$sort_clause."
  set rowcount 0";
}
else {
$query = "set rowcount ".$rowcount."
  select starttm=convert (varchar, starttime, 111)+' '+convert (varchar, starttime, 108)+'.'+convert(varchar, datepart(ms,starttime)),
    elapsed=datediff(ss, starttime, max(Timestamp)),dbname,dbid,spid,page,name,xloid, 
    endtime=convert (varchar, max(Timestamp), 111)+' '+convert (varchar, max(Timestamp), 108)+'.'+convert(varchar, datepart(ms,max(Timestamp))), 
    Loggedindatetime=(select convert (varchar, max (Loggedindatetime), 111)+' '+convert (varchar, max (Loggedindatetime), 108)+'.'+convert(varchar, datepart(ms,max (Loggedindatetime))) from ".$ServerName."_Cnx where Spid=L.spid and Loggedindatetime <= L.starttime)
  from ".$ServerName."_LogsHold L
  where Timestamp >='".$StartTimestamp."'
  and Timestamp <'".$EndTimestamp."'
  ".$filter_clause."
  group by dbname,dbid,spid,page,starttime,name,xloid
  ".$sort_clause."
  set rowcount 0";
}
?>


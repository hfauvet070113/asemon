<?php
    if (!isset($filter_clause) ) $filter_clause = "";
    if (!isset($sort_clause) )   $sort_clause = "";

$query = "set rowcount ".$rowcount."
select DbName, TabName, LockScheme, Pagetype, StatName,
WaitTime_ms=sum(1.*WaitTime),
sumWaits=sum(Waits),
AvgWaitTime_ms = sum(1.*WaitTime)/sum(Waits)
from ".$ServerName."_LockWaits
where Timestamp >='".$StartTimestamp."'        
and Timestamp <'".$EndTimestamp."'        
    ".$filter_clause."
group by DbName, TabName, LockScheme, Pagetype, StatName
    ".$sort_clause."
set rowcount 0";
?>

<?php
  $result = asemon_query("if object_id('#result') is not null drop table #result",$pid);
  $query = "
     select top 10 ID=identity(4),
        SumCpuTime         ,
        AvgCpuTime         ,
        SumWaitTime        ,
        MaxMemUsageKB      ,
        SumPhysicalReads   ,
        SumLogicalReads    ,
        AvgLogicalReads    ,
        SumPagesModified   ,
        SumPacketsSent     ,
        SumPacketsReceived 
  into #result
  from #stmtHashKey
  ".$sort_clause;
  $result = asemon_query($query, $pid);
  if ($result==false){
    $error = "Error select into #stmtHashKey. ".$error;
    return;
  }


?>
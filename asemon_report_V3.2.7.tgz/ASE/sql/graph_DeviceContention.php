<?php
$query = "
select Ts=convert(varchar,Timestamp,109), 
DevSemaphoreContentionPCT   =  avg(case when DevSemaphoreRequests <= 0 then 0 else DevSemaphoreWaits*100. /DevSemaphoreRequests end)
from ".$ServerName."_DevIO
where LogicalName like '".$Device."'
and Timestamp >= '".$StartTimestamp."' and Timestamp <= '".$EndTimestamp."'
group by Timestamp
order by Timestamp";
?>
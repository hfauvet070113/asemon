<?php
/* 
** sometimes Execution count is less than Request count
** TrendProc contains averages computed relative to Executions
** This request re-compute avg relative to RequestCnt
*/
$query = "
select Ts=convert(varchar,day,109),
Value=case when (Executions != RequestCnt) then (1.*".$indic."*Executions)/RequestCnt else ".$indic." end
from ".$ServerName."_TrendProc
where DBID=".$DBID."
and ProcName='".$ProcName."'
and day between '".$StartTimestamp."' and '".$EndTimestamp."'
order by day
";
?>
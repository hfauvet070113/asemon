<?php
if (!isset($filter_clause) ) $filter_clause = "";
if (!isset($sort_clause) )   $sort_clause = "";

  if ($ArchSrvType=="Adaptive Server Enterprise") {  
    $result = asemon_query("if object_id('#dbinfos') is not null drop table #dbinfos",$pid);

  }
  else {
  	// On IQ
  	$result = asemon_query("drop table if exists #dbinfos",$pid);
  }
  
  if ($ArchSrvType=="Adaptive Server Enterprise") {  
    $result = asemon_query("declare c1 cursor for select name from sysobjects where name like '%AseDbSpce'", $pid);
    $result = asemon_query("declare c2 cursor for select name from sysobjects where name like '%MonState'", $pid);
    $declare_cursor = "";
  }
  else {
  	// On IQ
  	$declare_cursor = " 
  	declare c1 cursor for select name from sysobjects where name like '%AseDbSpce' 
  	declare c2 cursor for select name from sysobjects where name like '%MonState'
  	";
  }
  

$query = "set nocount on
declare @tname varchar(255), @srvname varchar(255), @msg varchar(255)
create table #dbinfos (
     srvname           varchar(255) not null,
     dbid              smallint not null,
     dbname            sysname  not null,
     Total_pgs         bigint      not null,
     dbFree_pgs        bigint          null,
     isMixedLog        tinyint     not null,
     logTotal_pgs      bigint      not null,
     logUsed_pgs       bigint          null,
     logFree_pgs       bigint          null,
     logClr_pgs        bigint          null,
     logsegFree_pgs    bigint          null,
     PageSize          int             null,
     BckET             varchar(32)     null,  -- Backup start time
     Bck_s             int             null,  -- Backup elapsed time
     BtranET           varchar(32)     null,  -- Dump tran start time
     Btran_s           int             null,  -- Dump tran elapsed time
     LastChkpt         varchar(32)     null   -- Last checkpoint time
)

".
$declare_cursor
."
-- get all databases infos
open c1
fetch c1 into @tname 
while @@sqlstatus = 0
begin
	select @srvname=substring(@tname,1,datalength(@tname)-10)
	execute ('insert into #dbinfos (srvname,dbid,dbname,Total_pgs,dbFree_pgs,isMixedLog,logTotal_pgs,logUsed_pgs,logFree_pgs,logClr_pgs,logsegFree_pgs,PageSize) 
	          select '''+@srvname+''',dbid,dbname,Total_pgs,dbFree_pgs,isMixedLog,logTotal_pgs,logUsed_pgs,logFree_pgs,logClr_pgs,logsegFree_pgs, null  
	          from '+@tname+' 
	          where Timestamp=(select max(Timestamp) from '+@tname+')
	         ')
	fetch c1 into @tname
end
close c1

-- get all server's pagesize
open c2
fetch c2 into @tname 
while @@sqlstatus = 0
begin
	select @srvname=substring(@tname,1,datalength(@tname)-9)
	execute ('update #dbinfos set PageSize =  A.PageSize   from  '+@tname+' A where A.Timestamp=(select max(Timestamp) from '+@tname+') and #dbinfos.srvname='''+@srvname+'''')
--select @msg= 'update #dbinfos set PageSize =  A.PageSize   from  '+@tname+' A where A.Timestamp=(select max(Timestamp) from '+@tname+') and #dbinfos.srvname='''+@srvname+''''
--print @msg

  -- check if OpenDbs tab is at V16SP04 level
  if exists (select * from syscolumns where name='LastTranLogEndDumpTime' and id=object_id(+@srvname+'_OpenDbs'))
  begin
    execute ('update #dbinfos
              set
                BckET     = (select case when max(BackupEndTime) is null then null else convert (varchar, max(BackupEndTime), 111)+'' ''+convert (varchar, max(BackupEndTime), 108)+''.''+convert(varchar, datepart(ms,max(BackupEndTime))) end from '+@srvname+'_OpenDbs where DBID=I.dbid and LastBackupFailed=0),
                Bck_s     = (select datediff(ss,max(BackupStartTime),max(BackupEndTime)) from '+@srvname+'_OpenDbs where DBID=I.dbid and LastBackupFailed=0), 
                BtranET   = (select case when max(LastTranLogEndDumpTime) is null then null else convert (varchar, max(LastTranLogEndDumpTime), 111)+'' ''+convert (varchar, max(LastTranLogEndDumpTime), 108)+''.''+convert(varchar, datepart(ms,max(LastTranLogEndDumpTime))) end from '+@srvname+'_OpenDbs where DBID=I.dbid and LastBackupFailed=0),
                Btran_s   = (select datediff(ss,max(LastTranLogDumpTime),max(LastTranLogEndDumpTime)) from '+@srvname+'_OpenDbs where DBID=I.dbid and LastBackupFailed=0),
                LastChkpt = (select case when max(LastCheckpointTime) is null then null else convert (varchar, max(LastCheckpointTime), 111)+'' ''+convert (varchar, max(LastCheckpointTime), 108)+''.''+convert(varchar, datepart(ms,max(LastCheckpointTime))) end from '+@srvname+'_OpenDbs where DBID=I.dbid)
              from #dbinfos I
              where I.srvname='''+@srvname+'''
             ')
  end
	fetch c2 into @tname
end
close c2

set rowcount ".$rowcount."
select srvname,dbid,dbname,
  TotalSize_Mb=(Total_pgs*PageSize)/(1024*1024),
  DataSize_Mb=(case when isMixedLog=0 then Total_pgs-logTotal_pgs else Total_pgs end)*PageSize/(1024*1024),
  DataFree_Mb=(dbFree_pgs*PageSize)/(1024*1024),
  isMixedLog,
  LogSize_Mb=case when isMixedLog=0 then (logTotal_pgs*PageSize)/(1024*1024) else 0 end,
  logUsed_pgs,
  LogFree_Mb=(case when isMixedLog=0 then logFree_pgs else dbFree_pgs end)*PageSize/(1024*1024) ,
  logClr_pgs,
  logsegFree_pgs,
  PctDatUsed=str(100. - 100.*dbFree_pgs / case when isMixedLog=0 then  Total_pgs-logTotal_pgs else  Total_pgs end ,6,2),
  PctLogUsed= str(100.*(logUsed_pgs+logClr_pgs)/(case when isMixedLog=0 then logTotal_pgs else Total_pgs  end)  ,6,2),
  PageSize,
  BckET   , 
  Bck_s    ,
  BtranET  ,
  Btran_s  ,
  LastChkpt

from #dbinfos
where 1=1
and PageSize is not null
  ".$filter_clause."
  ".$sort_clause."

drop table  #dbinfos
deallocate cursor c1
deallocate cursor c2
set rowcount 0
";


?>
<?php

  if (!isset($filter_clause) ) $filter_clause = "";
  if (!isset($sort_clause) )   $sort_clause = "";
  if (!isset($DatabaseName) )   $DatabaseName = "";
  if (!isset($support16SP04PL01) )   $support16SP04PL01 = 0;

  if ($support16SP04PL01 == 0) {
    $query = "declare @pgsz int
    select @pgsz=PageSize from ".$ServerName."_MonState where Timestamp=(select max(Timestamp) from ".$ServerName."_MonState where Timestamp <='".$EndTimestamp."')
    select dbid,dbname,
    DataSize_Mb=str(1.*(case when isMixedLog=0 then  Total_pgs-logTotal_pgs else  Total_pgs end) * @pgsz/(1024*1024),12,0),
    DataFree_Mb=str(1.*dbFree_pgs*@pgsz/(1024*1024),12,0), 
    PctDatUsed=str(100. - 100.*dbFree_pgs / case when isMixedLog=0 then  Total_pgs-logTotal_pgs else  Total_pgs end ,6,2),  
    isMixedLog=isMixedLog,  
    LogSize_Mb=  str(1.* (case when isMixedLog=0 then logTotal_pgs else null end) * @pgsz/(1024*1024), 12,0),
    LogUsed_Mb=str(1.*logUsed_pgs*@pgsz/(1024*1024),12,0), 
    LogClr_Mb= str(1.*logClr_pgs*@pgsz/(1024*1024),12,0), 
    PctLogUsed= str(100.*(logUsed_pgs+logClr_pgs)/(case when isMixedLog=0 then logTotal_pgs else Total_pgs  end)  ,6,2),
    LogFree_Mb=str(1.*logFree_pgs*@pgsz/(1024*1024),12,0), 
    logsegFree_Mb=str(1.*logsegFree_pgs*@pgsz/(1024*1024),12,0)
    from ".$ServerName."_AseDbSpce
    where Timestamp=(select max(Timestamp) from ".$ServerName."_AseDbSpce where Timestamp>='".$StartTimestamp."'
      and Timestamp <='".$EndTimestamp."')
    and lower(dbname) like case when '".$DatabaseName."'='TempDBs' then 'tempdb%' else '%' end  
    ".$filter_clause."
    ".$sort_clause;
  }
  else {
    $query = "declare @pgsz int
    select @pgsz=PageSize from ".$ServerName."_MonState where Timestamp=(select max(Timestamp) from ".$ServerName."_MonState where Timestamp <='".$EndTimestamp."')
    select S.dbid,dbname,
    DataSize_Mb=str(1.*(case when isMixedLog=0 then  Total_pgs-logTotal_pgs else  Total_pgs end) * @pgsz/(1024*1024),12,0),
    DataFree_Mb=str(1.*dbFree_pgs*@pgsz/(1024*1024),12,0), 
    PctDatUsed=str(100. - 100.*dbFree_pgs / case when isMixedLog=0 then  Total_pgs-logTotal_pgs else  Total_pgs end ,6,2),  
    isMixedLog=isMixedLog,  
    LogSize_Mb=  str(1.* (case when isMixedLog=0 then logTotal_pgs else null end) * @pgsz/(1024*1024), 12,0),
    LogUsed_Mb=str(1.*logUsed_pgs*@pgsz/(1024*1024),12,0), 
    LogClr_Mb= str(1.*logClr_pgs*@pgsz/(1024*1024),12,0), 
    PctLogUsed= str(100.*(logUsed_pgs+logClr_pgs)/(case when isMixedLog=0 then logTotal_pgs else Total_pgs  end)  ,6,2),
    LogFree_Mb=str(1.*logFree_pgs*@pgsz/(1024*1024),12,0), 
    logsegFree_Mb=str(1.*logsegFree_pgs*@pgsz/(1024*1024),12,0),
    BckET, Bck_s , BtranET, Btran_s, LastChkpt
    from 
        ".$ServerName."_AseDbSpce S, 
        (select DBID, 
                BckET     = case when max(BackupEndTime) is null then null else convert (varchar, max(BackupEndTime), 111)+' '+convert (varchar, max(BackupEndTime), 108)+'.'+convert(varchar, datepart(ms,max(BackupEndTime))) end,
                Bck_s     = datediff(ss,max(BackupStartTime),max(BackupEndTime)), 
                BtranET   = case when max(LastTranLogEndDumpTime) is null then null else convert (varchar, max(LastTranLogEndDumpTime), 111)+' '+convert (varchar, max(LastTranLogEndDumpTime), 108)+'.'+convert(varchar, datepart(ms,max(LastTranLogEndDumpTime))) end,
                Btran_s   = datediff(ss,max(LastTranLogDumpTime),max(LastTranLogEndDumpTime)),
                LastChkpt = case when max(LastCheckpointTime) is null then null else convert (varchar, max(LastCheckpointTime), 111)+' '+convert (varchar, max(LastCheckpointTime), 108)+'.'+convert(varchar, datepart(ms,max(LastCheckpointTime))) end
         from ".$ServerName."_OpenDbs
         where LastBackupFailed=0
         and Timestamp <='".$EndTimestamp."'
         group by DBID
        ) D
    where S.Timestamp=(select max(Timestamp) from ".$ServerName."_AseDbSpce where Timestamp>='".$StartTimestamp."'
      and Timestamp <='".$EndTimestamp."')
    and lower(dbname) like case when '".$DatabaseName."'='TempDBs' then 'tempdb%' else '%' end 
    and S.dbid*=D.DBID
    ".$filter_clause."
    ".$sort_clause;
  }
?>

<?php
  // output variables
  $formattedXML = "";
  $rawXML = "";

//  $debugfile = fopen('/tmp/formattedXML_'.$PlanID.'.txt', 'a+');

  // Check if xmlinfo is stored compressed in IQ
  $xmlinfotIsCompressed = false;
  if ($ArchSrvType=="Sybase IQ") {
    $result = asemon_query("select domain_name from syscolumn C, systable T, sysdomain D where C.table_id=T.table_id and C.domain_id=D.domain_id and T.table_name = '".$ServerName."_CachedXML' and column_name='xmlinfo'",$pid);
    $rowcat = asemon_fetch_assoc($result);
    if (strcasecmp(rtrim($rowcat["domain_name"]) , "varbinary") == 0) {
      $xmlinfotIsCompressed = true;
//      fputs( $debugfile, "  xml is compressed.\n");
    }
  }

  libxml_use_internal_errors(true);
  if ($xmlinfotIsCompressed == true) {
//      fputs( $debugfile, "  before uncompress :\n\n".bin2hex($row['xmlinfo'])."\n\n");
      $xmlinfo = gzuncompress(pack("H*",$row["xmlinfo"]));
//      fputs( $debugfile, "  after uncompress :\n\n".$xmlinfo."\n");
  }
  else
      $xmlinfo = $row["xmlinfo"];
  $rawxml = $xmlinfo;
  $length = strlen($xmlinfo);
  $sxe = simplexml_load_string($xmlinfo);




  if (!$sxe) {
      $formattedXML = $formattedXML. "<div class='Info'>";
      $formattedXML = $formattedXML. "<pre>";
      $formattedXML = $formattedXML. "XML errors. (xmlinfo=".bin2hex($row["xmlinfo"]).")\n";
      foreach(libxml_get_errors() as $error) {
          $formattedXML = $formattedXML. "\t". $error->message;
      }
      $formattedXML = $formattedXML. "</pre>";
      $formattedXML = $formattedXML. "</div>";
  }
  else {
      // Display SQL Text
      $formattedXML = $formattedXML. "<div class='Info'><div class='StatParamPlan'>";
      $xmlinfo = new SimpleXMLElement($xmlinfo);
      $formattedXML = $formattedXML. $xmlinfo->text."<BR>";
      $formattedXML = $formattedXML. "</div></div>";

      $planStatus = trim($xmlinfo->plan->planStatus);
      $processId = $xmlinfo->plan->processId;
      if ( ($planStatus != "available") && ($processId != null) ) {
          $formattedXML = $formattedXML. "<div class='Info'>";
          $formattedXML = $formattedXML. "PLAN not available, was in use during capture (SPID : ".$processId.")";
          $formattedXML = $formattedXML. "</div>";
      }
      
      if ($planStatus == "available") {
          // Display Parameters
          $formattedXML = $formattedXML. "<div class='Info'>";
          $compileParameters=$xmlinfo->plan->compileParameters;
          $execParameters=$xmlinfo->plan->execParameters;
          $formattedXML = $formattedXML. '<table class="StatParamPlan" >';
          $formattedXML = $formattedXML. '<tr><td colspan="3">Parameter</td> <td>compileParameters</td> <td>execParameters</td></tr>';
          $formattedXML = $formattedXML. '<tr><td>number</td><td>name</td><td>type</td><td>value</td><td>value</td></tr>';

              foreach($compileParameters->children() as $child) {
                  $name = $child->name;
                  $number = $child->number;
                  $type = $child->type;
                  $compvalue = $child->value;
                  $execvalue = $execParameters->parameter[$number-1]->value;
                  
                  $formattedXML = $formattedXML. "<tr><td>".$number."</td><td>".$name."</td><td>".$type."</td><td>".$compvalue."</td><td>".$execvalue."</td></tr>";
              }
          $formattedXML = $formattedXML. '</table></div>';

          
          // Display statistics
          $formattedXML = $formattedXML. "<div class='Info'>";
          $formattedXML = $formattedXML. "<pre>";
          $formattedXML = $formattedXML. "Execution stats :\n";
          $formattedXML = $formattedXML. "\texecCount = ". $xmlinfo->plan->execCount ."\n";
          if ($xmlinfo->plan->planSharing != "")
              $formattedXML = $formattedXML. "\tplanSharing = ".$xmlinfo->plan->planSharing."\n";
          $formattedXML = $formattedXML. "\tmaxTime (ms) = ". number_format((float)($xmlinfo->plan->maxTime)/1000,0) ."\n";
          $formattedXML = $formattedXML. "\tavgTime (ms) = ". number_format((float)($xmlinfo->plan->avgTime)/1000,0) ."\n";
          if ($xmlinfo->plan->maxPreQueryTime != null)
            $formattedXML = $formattedXML. "\tmaxPreQueryTime (ms) = ". number_format((float)($xmlinfo->plan->maxPreQueryTime)/1000,0) ."\n";
          if ($xmlinfo->plan->avgPreQueryTime != null)
            $formattedXML = $formattedXML. "\tavgPreQueryTime (ms) = ". number_format((float)($xmlinfo->plan->avgPreQueryTime)/1000,0) ."\n";
          if ($xmlinfo->plan->maxExecTime != null)
            $formattedXML = $formattedXML. "\tmaxExecTime (ms) = ". number_format((float)($xmlinfo->plan->maxExecTime)/1000,0) ."\n";
          if ($xmlinfo->plan->avgExecTime != null)
            $formattedXML = $formattedXML. "\tavgExecTime (ms) = ". number_format((float)($xmlinfo->plan->avgExecTime)/1000,0) ."\n";
          $formattedXML = $formattedXML. "</pre>";
          $formattedXML = $formattedXML. "</div>";
  
          
          
          // Display plan
          $formattedXML = $formattedXML. "<div class='Info'>";
          $formattedXML = $formattedXML. "PLAN :";
          $formattedXML = $formattedXML. "<pre>";
          // Parse plan
          $xmlOpTree = $xmlinfo->plan->opTree->Emit;
          if ($xmlOpTree != null) 
             $formattedXML = $formattedXML. parseNode($xmlOpTree, 1);
          else
             $formattedXML = $formattedXML. " Not available, was in use during capture";
          
          $formattedXML = $formattedXML. "</pre>";
          
          $xmlPlanIos = $xmlinfo->plan->opTree->est;
          if ($xmlPlanIos->totalLio != null) {
              $formattedXML = $formattedXML. "<div class='Info'><table class='StatParamPlan' >";
              $formattedXML = $formattedXML. "<tr><td>               </td><td>totalLio                   </td> <td> totalPio                  </td></tr>";
              $formattedXML = $formattedXML. "<tr><td>Estimated </td><td align='right'>". number_format((float)$xmlPlanIos->totalLio/1) ."</td> <td align='right'>". number_format((float)$xmlPlanIos->totalPio/1) ."</td></tr>";
              $xmlPlanIos = $xmlinfo->plan->opTree->act;
              if ($xmlPlanIos != null)
                $formattedXML = $formattedXML. "<tr><td>Actual </td><td align='right'>". number_format((float)$xmlPlanIos->totalLio/1) ."</td> <td align='right'>". number_format((float)$xmlPlanIos->totalPio/1) ."</td></tr>";
              $formattedXML = $formattedXML. "</table></div>";
          }
          
          $formattedXML = $formattedXML. "</div>";
      }
  }

  // prepare Raw XML Display
  //$rawXML = $rawXML. "<div class='Info'>";
  $rawXML = $rawXML. "<div>";
  $rawXML = $rawXML. '<pre class="brush: sql">';
  $rawXML = $rawXML. str_replace("/", "&#47;", str_replace(">", "&gt;", str_replace("<","&lt;", str_replace(" ","&nbsp;",$rawxml))))   ."<BR>";
  $rawXML = $rawXML. '</pre>';
  $rawXML = $rawXML. "</div>";

//  fputs( $debugfile, "formattedXML : \n".$formattedXML."\n");
//  fclose($debugfile);
?>

<?php
$query = "select 
  Ts=convert(varchar,Timestamp,109),
  Num_Active,
  Max_used ,
  ConfigLocks=Num_Free+Num_Active
from ".$ServerName."_MonConf
where Timestamp >='".$StartTimestamp."'
and Timestamp <='".$EndTimestamp."'
and Name='number of locks'
order by Timestamp";
?>
<?php
$query = "
select 
   Ts=convert(varchar,Timestamp,109)
   , [Current] = Num_Active
   , Max_used 
from ".$ServerName."_MonConf
where Timestamp >='".$StartTimestamp."'
and Timestamp <='".$EndTimestamp."'
and Name like 'number of user connection%'";
?>
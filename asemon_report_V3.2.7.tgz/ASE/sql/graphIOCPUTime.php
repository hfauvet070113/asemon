<?php
$query = "
select 
   Ts=convert(varchar,Timestamp,109)
  ,[IOCPUTime %]=avg(convert(float,IOCPUTime*1000)/Interval*100)
from ".$ServerName."_Engines
where Timestamp >='".$StartTimestamp."'
and Timestamp <='".$EndTimestamp."'
and ContextSwitches>0
group by Timestamp
order by Timestamp";
?>
<?php

  if (!isset($filter_clause) ) $filter_clause = "";
  if (!isset($sort_clause) )   $sort_clause = "";

  $query = "set rowcount ".$rowcount."
  select ts=convert (varchar, Timestamp, 111)+' '+convert (varchar, Timestamp, 108)+'.'+convert(varchar, datepart(ms,Timestamp)),
    proc_name, linenum, tran_name, LocksHeld, memusageKB=memusage*2
    from ".$ServerName."_CnxActiv
    where Spid=".$Spid."
    and Kpid=".$Kpid."
    and Loggedindatetime='".$Loggedindatetime."'
    and Timestamp >='".$StartTimestamp."'
    and Timestamp <'".$EndTimestamp."'
    and proc_name is not null
  ".$filter_clause;


  $query = $query.$sort_clause." 
  set rowcount 0";
?>

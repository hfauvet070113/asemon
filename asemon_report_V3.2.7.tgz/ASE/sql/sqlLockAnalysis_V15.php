<?php
  // retreive all posted params and affect them to variables
  foreach ($_POST as $key => $value)
    @$$key=$value;

  include ("../../COMMON/connectArchiveServer.php");	

  if ($ArchSrvType=="Adaptive Server Enterprise") {  
    // It is on ASE, isolate declare cursor step
    $result=asemon_query(
      "declare c cursor for 
       select BlockedBy,Timestamp,WT=max(WaitTime)
       from ".$ServerName."_BlockedP 
       where Timestamp >='".$StartTimestamp."'
       and   Timestamp <='".$EndTimestamp."'
       and BlockedBy   is not null
       group by BlockedBy,Timestamp
       order by BlockedBy,Timestamp",
       $pid);
    
    if ($result==false){ 
      $error =  "Error Open Cursor : ".$error;
      return;
    }
    else {
      $result = asemon_query("if object_id('#blk_max') is not null drop table #blk_max",$pid);
      $result=asemon_query(
        "declare @savts datetime, @ts datetime, @savWT int, @WT int, @savBlockedBy int, @BlockedBy int
        create table #blk_max (BlockedBy int, max_TS datetime, max_WaitTime int)
        set nocount on
        open c
        fetch c into @savBlockedBy,@savts,@savWT
        if @@sqlstatus = 0
        begin 
            while @@sqlstatus=0
            begin
               fetch c into @BlockedBy,@ts,@WT
               if @@sqlstatus != 0 break
               if @BlockedBy != @savBlockedBy
               begin
                 /* max block found for a spid */
                 insert into #blk_max values (@savBlockedBy,@savts,@savWT)
               end
               else
                 if @WT < @savWT or @WT < 5
                 begin
                   /* max block found for a spid */
                   insert into #blk_max values (@savBlockedBy,@savts,@savWT)
                 end
               select @savWT=@WT, @savts=@ts, @savBlockedBy=@BlockedBy
            end
            /* sav last row found */
            if (@savBlockedBy is not null)
                insert into #blk_max values (@savBlockedBy,@savts,@savWT)
        end
        close c
        deallocate cursor c",
      $pid);

      if ($result==false){ 
        $error = "Error execute cursor : ".$error;
        return;
      }
    }
  }
  else {
    // It is on IQ, don't isolate declare cursor step
    // object_id d'une table tempo est null. La requ�te ci-dessous est inefficace
    $result = asemon_query("if object_id('#blk_max') is not null drop table #blk_max",$pid);
    
    $query = "create table #blk_max (BlockedBy int, max_TS datetime, max_WaitTime int)";
    $result = asemon_query($query,$pid);
    $query = 
      "declare c cursor for 
      select BlockedBy,Timestamp,WT=max(WaitTime)
      from ".$ServerName."_BlockedP 
      where Timestamp >='".$StartTimestamp."'
      and   Timestamp <='".$EndTimestamp."'
      and BlockedBy   is not null
      group by BlockedBy,Timestamp
      order by BlockedBy,Timestamp
      
      begin transaction
      declare @savts datetime, @ts datetime, @savWT int, @WT int, @savBlockedBy int, @BlockedBy int
      /*create table #blk_max (BlockedBy int, max_TS datetime, max_WaitTime int)*/
      set nocount on
      open c
      fetch c into @savBlockedBy,@savts,@savWT
      if @@sqlstatus = 0
      begin 
          while @@sqlstatus=0
          begin
             fetch c into @BlockedBy,@ts,@WT
             if @@sqlstatus != 0 break
             if @BlockedBy != @savBlockedBy
             begin
               /* max block found for a spid */
               insert into #blk_max values (@savBlockedBy,@savts,@savWT)
             end
             else
               if @WT < @savWT or @WT < 5
               begin
                 /* max block found for a spid */
                 insert into #blk_max values (@savBlockedBy,@savts,@savWT)
               end
             select @savWT=@WT, @savts=@ts, @savBlockedBy=@BlockedBy
          end
          /* sav last row found */
          if (@savBlockedBy is not null)
              insert into #blk_max values (@savBlockedBy,@savts,@savWT)
      end
      close c
      deallocate cursor c
      commit transaction";
    $result=asemon_query($query, $pid);
  }



  //  Get total time blocked
  $result=asemon_query(
    "select total_time_blocked=isnull(sum(1.*max_WaitTime),0)
     from #blk_max",
    $pid);
  
  while (($row=asemon_fetch_assoc($result)))
  {
    $total_time_blocked = $row["total_time_blocked"];
  }
  // Nombre de situations de blocage, nb proc bloques, temps moyen , temps max
  $result=asemon_query(
    "select nb_block=count(*),
            avg_blocked_proc=avg( nbblkprocs), 
            max_blocked_proc=max( nbblkprocs),
            avg_time_blocked_s=avg(1.*max_time_blks),
            max_time_blocked_s=max(1.*max_time_blks)
     from (
       select nbblkprocs=count(*),
            max_time_blks=max(1.*max_WaitTime)
             from #blk_max
             group by max_TS) statBlks",
     $pid);
  while (($row=asemon_fetch_assoc($result)))
  {
    $nb_block= $row["nb_block"];
    $avg_blocked_proc= $row["avg_blocked_proc"];
    $max_blocked_proc= $row["max_blocked_proc"];
    $avg_time_blocked_s= $row["avg_time_blocked_s"];
    $max_time_blocked_s= $row["max_time_blocked_s"];
  }

  // Nombre et temps de blocage par objet et type de lock
  $query="set rowcount 20 
    select lckBase, lckObjet, LockType, nb_block=count(*), tps_block_s=sum(B.max_WaitTime)
    from ".$ServerName."_BlockedP A , #blk_max B
    where A.Timestamp = B.max_TS
    and A.LockID = B.BlockedBy
    group by lckBase,lckObjet,LockType  
    order by tps_block_s desc
    set rowcount 0";
  
  $result = asemon_query($query,$pid) ;
  $lockdetail = [];
  if ($result == FALSE ) {
    $error = "Error retreiving locking per object and lock type : ".$error;
    return;
  }
  else {
    while( $row = asemon_fetch_assoc($result)) {
      $lockdetail[] = [
        "lckBase"     => $row["lckBase"]    ,
        "lckObjet"    => $row["lckObjet"]   ,
        "LockType"    => $row["LockType"]   ,
        "nb_block"    => $row["nb_block"]   ,
        "tps_block_s" => $row["tps_block_s"]
      ];
    }
  }

  // Select top blocking occurences
  $query="set rowcount 20 
    select max_TS, max_WT=max_WaitTime, nb_blocked_proc=count(*)
    from #blk_max, ".$ServerName."_BlockedP A
    where #blk_max.max_TS=A.Timestamp
      and #blk_max.BlockedBy = A.BlockedBy
      and A.BlockedState = 'Blocked'
    group by max_TS, max_WaitTime
    order by  max_WT desc
    set rowcount 0";

  $result = asemon_query($query,$pid) ;
  $toplocks = [];
  if ($result == FALSE ) {
    $error = "Error retreiving top blocking occurences : ".$error;
    return;
  }
  else {
    while( $row = asemon_fetch_assoc($result)) {
      $toplocks[] = [
        "max_TS"          => $row["max_TS"]         ,
        "nb_blocked_proc" => $row["nb_blocked_proc"],
        "max_WT"          => $row["max_WT"]
      ];
    }
  }

  // Drop temporary table
  $query = "drop table #blk_max";
  $result = asemon_query($query,$pid);


  if ($error == "")
    $data = array(
      'status' => 'success',
      'total_time_blocked' => $total_time_blocked,
      'nb_block'           => $nb_block          ,
      'avg_blocked_proc'   => $avg_blocked_proc  ,
      'max_blocked_proc'   => $max_blocked_proc  ,
      'avg_time_blocked_s' => $avg_time_blocked_s,
      'max_time_blocked_s' => $max_time_blocked_s,
      'lockdetail'         => $lockdetail,
      'toplocks'           => $toplocks
      );

  else
    $data = array(
      'status' => 'error',
      'message' => $error
      );

  echo json_encode($data);


?>
<?php
$query = "
select Ts=convert(varchar,day,109),
  Value=".$indic."
from ".$ServerName."_TrendStmt
where SQLHashKey=".$SQLHashKey."
and day between '".$StartTimestamp."' and '".$EndTimestamp."'
order by day
";
?>
<?php
  // retreive all posted params and affect them to variables
  foreach ($_POST as $key => $value)
    @$$key=$value;

  include ("../../COMMON/connectArchiveServer.php");	

  if ( !isset($SysmonType) ) $SysmonType="";
  $msgresult = "";

  function msg_handler2($msgnumber, $severity, $state, $line, $msgtext) {
    global $msgresult;
    if ($msgnumber==3701) return; // ASE - Cannot drop the table 'xxx', because it doesn't exist in the system catalogs. 
    if ($msgnumber==2706) return; // IQ - SQL Anywhere Error -141: Table 'XXXX' not found 
  
    $msgresult = $msgresult.str_replace(" ","&nbsp;",$msgtext)   ."<BR>";
  }

  if ( $PHP_main_version==5 )  {
    sybase_set_message_handler('msg_handler2');
    sybase_min_server_severity ( 0 );
  }


  // Check if data exists for this interval
  $query = "if exists (select 1 from ".$ServerName."_SysMon
                       where Timestamp >='".$StartTimestamp."'
                         and Timestamp <='".$EndTimestamp."'
                         )
            select res=1
            else select res=0";
  $result = asemon_query($query, $pid);
  $row = asemon_fetch_assoc($result);
  if ($row["res"] == 0){
    $error="No data available for this interval";
  }
  else {
    // check if it is the new version (better compression of fldname, Interval col no longer needed, new row with grpname='Z' and field_id=0 contains Interval value)
    $query = "if exists (select 1 from ".$ServerName."_SysMon
                         where Timestamp >='".$StartTimestamp."'
                           and Timestamp <='".$EndTimestamp."'
                           and grpname='Z' and field_id=0)
              select res=1
              else select res=0";
    $result = asemon_query($query, $pid);
    $row = asemon_fetch_assoc($result);
    if ($row["res"] == 1){
      include ("sql_sysmon_newversion.php");
    }
    else { 
      include ("sql_sysmon_oldversion.php");
    }
    
    $result = asemon_query($query,$pid);
    if ( $PHP_main_version>=8 )  {
    	// print statements are returned as rows in #asemon_print
    	// Generates $msgresult with these rows. In case of PHP5, $msgresult is generated in msg_handler2
 	    while (($row=asemon_fetch_assoc($result))) {
 	    	if ( is_null($row["msg"]) ) continue;
 	    	$msgresult = $msgresult.str_replace(" ","&nbsp;",$row["msg"])   ."<BR>";
      }
    }
  }

  if ($error == "")
    $data = array(
      'status' => 'success',
      'msgresult' => $msgresult,
      'query' => $query
      );

  else
    $data = array(
      'status' => 'error',
      'message' => $error,
      'query' => $query
      );

  echo json_encode($data);



?>

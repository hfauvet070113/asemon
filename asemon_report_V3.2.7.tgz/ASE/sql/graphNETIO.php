<?php
$query = "
select Ts=convert(varchar,ni.Timestamp,109),
TotIO_sent_per_s= sum (BytesSent * 1.0)*1000. / (1024.*avg(ni.Interval)),
TotIO_received_per_s= sum (BytesReceived * 1.0)*1000. / (1024.*avg(ni.Interval))
from ".$ServerName."_NetworkIO ni
where ni.Timestamp >='".$StartTimestamp."'
and ni.Timestamp <='".$EndTimestamp."'
group by Timestamp
order by Timestamp
";
?>
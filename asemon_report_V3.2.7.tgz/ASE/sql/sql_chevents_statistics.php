<?php

  if (!isset($filter_clause) ) $filter_clause = "";
  if (!isset($sort_clause) )   $sort_clause = "";

$query = "select 
ts=convert (varchar, Timestamp, 111)+' '+convert (varchar, Timestamp, 108)+'.'+convert(varchar, datepart(ms,Timestamp)),
area      ,
type      ,
target    ,
element   ,
oldvalue  ,
newvalue  ,
mode      ,
username  ,
instanceid

from ".$ServerName."_ChEvents
where Timestamp >='".$StartTimestamp."'        
and Timestamp <'".$EndTimestamp."'        
".$filter_clause."
".$sort_clause;
?>

  <?php
  require_once('../../COMMON/SqlFormatter.php');
  // retreive all posted params and affect them to variables
  foreach ($_POST as $key => $value)
    @$$key=$value;

  include ("../../COMMON/connectArchiveServer.php");


  // Check if SQL Text is stored compressed in IQ
  // If yes, will be decompressed in "getgriddata.php"
  $SQLTextIsCompressed = false;
  if ($ArchSrvType=="Sybase IQ") {
    $result = asemon_query("select domain_name from syscolumn C, systable T, sysdomain D where C.table_id=T.table_id and C.domain_id=D.domain_id and T.table_name = '".$ServerName."_CachedSQL' and column_name='SQLText'",$pid);
    $row = asemon_fetch_assoc($result);
    if (strcasecmp(rtrim($row["domain_name"]) , "varbinary") == 0) {
      $SQLTextIsCompressed = true;
    }
  }

  $TotalRows = 0;
  $SQLText = "";

  $query = "
  select
    SQLText
  from ".$ServerName."_CachedSQL
  where bootcount =".$bootcount."
  and SSQLID =".$SSQLID."
  and Hashkey =".$Hashkey;
  $result = asemon_query($query,$pid);
  if ($result != false){ 
    $row = asemon_fetch_assoc($result); 
    if ($row!=null) {
      $TotalRows = 1;
      $SQLText = $row["SQLText"];
      if ($SQLTextIsCompressed) {
        //echo "SQLText is compressed";
        $SQLText = gzuncompress(pack("H*",$SQLText));
      }
    }
  }

  if ($error == "")
    $data = array(
      'status' => 'success',
      'TotalRows' => $TotalRows,
      'SQLText' => $SQLText,
      'FormattedSQL' => SqlFormatter::format($SQLText, false),
      'query' => $query 
      );

  else
    $data = array(
      'status' => 'error',
      'message' => $error,
      'query' => $query
      );

  echo json_encode($data);


?>
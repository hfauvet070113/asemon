<?php
  require_once('../../COMMON/SqlFormatter.php');
  // retreive all posted params and affect them to variables
  foreach ($_POST as $key => $value)
    @$$key=$value;

  include ("../../COMMON/connectArchiveServer.php");



  if ( ($StmtSQLHKExists == 1) &&  ($SQLHashKey != "") )
    $query = 
     "if exists (select 1
       from ".$ServerName."_StmtSQL
       where BootID = ".$BootID."
       and KPID = ".$KPID."
       and SPID = ".$SPID."
       and BatchID = ".$BatchID."
       and Timestamp >= '".$Strttm."'
       and Timestamp <= (select min(Timestamp) from ".$ServerName."_StmtSQL where Timestamp >= '".$Strttm."' and SQLHashKey = ".$SQLHashKey.")
       and SQLHashKey = ".$SQLHashKey."
       )
         -- get SQL with parameters values
         select
         src='StmtSQL',
         LineNumber,
         SequenceInLine,
         SQLText
         from ".$ServerName."_StmtSQL
         where BootID = ".$BootID."  
         and KPID = ".$KPID."
         and SPID = ".$SPID."
         and BatchID = ".$BatchID."
         and Timestamp >= '".$Strttm."'
         and Timestamp <= (select min(Timestamp) from ".$ServerName."_StmtSQL where Timestamp >= '".$Strttm."' and SQLHashKey = ".$SQLHashKey.") 
         and SQLHashKey = ".$SQLHashKey."
         order by 1,2
       else
         -- get SQL normalized without parameters values
         select
         src='StmtSQLHK',
         LineNumber=1,
         Sequence,
         SQLText
         from ".$ServerName."_StmtSQLHK
         where SQLHashKey = ".$SQLHashKey."
         order by 1,2";
  else
    
    $query = 
     "select  distinct
      src='StmtSQL',
      LineNumber,
      SequenceInLine,
      SQLText
      from ".$ServerName."_StmtSQL
      where BootID = ".$BootID."  
      and KPID = ".$KPID."
      and SPID = ".$SPID."
      and BatchID = ".$BatchID."
      order by 1,2, 3";
/* 13/06/2020 removed the 2 next lines before the order by
   Was necessary because a same statement could be retreieved in monSysSQLText if asemon was restarted. Now asemon skip already seen statements
   The restriction was not very good since Timestamp could be higher than Startm+Elasped_ms
   Now, the distict avoid seeing several lines for same statement
      and Timestamp >= '".$Strttm."'
      and Timestamp < dateadd(ms, ".$Elapsed_ms.", '".$Strttm."')
*/


  $result = asemon_query($query, $pid);
  $flatSQL= "";
  $previousLineNumber=1;
  $currentLineNumber=1;
  if ($error=="") {
    $TotalRows=0;
    $Rows = [];
    while (($row=asemon_fetch_assoc($result))) {
      if ($row != null) {
        $Rows[] = $row;
        $TotalRows++;
        $currentLineNumber=$row["LineNumber"];
        if ($currentLineNumber != $previousLineNumber) {
        	if ($currentLineNumber-$previousLineNumber >= 0)
            $flatSQL = $flatSQL . str_repeat("\n",$currentLineNumber-$previousLineNumber);
          $previousLineNumber = $currentLineNumber;
        }
        $flatSQL=$flatSQL.$row["SQLText"];
      } // End if "row != null"
    }
  }

//$error="hgfh";

  if ($error == "")
    $data = array(
      'status' => 'success',
      'TotalRows' => $TotalRows,
      'Rows' => $Rows,
      'FormattedSQL' => SqlFormatter::format($flatSQL, false),
      'query' => $query 
      );

  else
    $data = array(
      'status' => 'error',
      'message' => $error,
      'query' => $query
      );

  echo json_encode($data);


?>
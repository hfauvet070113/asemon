<?php
$query = "
select Ts=convert(varchar,Timestamp,109), 
[Reads/s]    =  convert(numeric(16,0), sum(Reads* 1000.) / avg(Interval)),
[APFReads/s] =  convert(numeric(16,0), sum(APFReads * 1000.) / avg(Interval)),
[Writes/s]   =  convert(numeric(16,0), sum(Writes* 1000.) / avg(Interval))
from ".$ServerName."_DevIO
where LogicalName like '".$Device."'
and Timestamp >= '".$StartTimestamp."' and Timestamp <= '".$EndTimestamp."'
group by Timestamp
order by Timestamp
";
?>
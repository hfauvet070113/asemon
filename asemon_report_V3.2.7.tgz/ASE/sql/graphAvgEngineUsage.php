<?php
$query = "
select EngineNumber, 100*( convert(float,sum(1000.*UserCPUTime)) / (convert(float,sum(1.*Interval)) ) )
from ".$ServerName."_Engines
where Timestamp >='".$StartTimestamp."'
and Timestamp <='".$EndTimestamp."'
group by EngineNumber
having sum(ContextSwitches)>0 -- for online engines only
order by EngineNumber";
?>
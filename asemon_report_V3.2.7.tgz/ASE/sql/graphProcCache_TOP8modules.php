<?php
  // Find top 8 modules during this interval
  $query="select top 8
          ModuleID, ModuleName
          from ".$ServerName."_PModUse
        where Timestamp >='".$StartTimestamp."'
        and Timestamp <'".$EndTimestamp."'
        group by ModuleID, ModuleName
        order by max(Active) desc";
  
  $result=asemon_query($query, $pid);
  if ($result==false){ 
    $error = "Error retreiving top 8 modules in PModUse";
    return;
  }
  $cnt=0;
  while (($row=asemon_fetch_assoc($result)))
  {
     $ModuleID[]      = $row["ModuleID"];
     $ModuleName[]      = $row["ModuleName"];
     $cnt++;
  }

  $query = "";
  if ($cnt > 0) {
    if ($cnt<8) {
      $ModuleID      [7] = -1;
      $ModuleName    [7] = "mod7";
    }
    if ($cnt<7) {
      $ModuleID      [6] = -1;
      $ModuleName    [7] = "mod6";
    }
    if ($cnt<6) {
      $ModuleID      [5] = -1;
      $ModuleName    [7] = "mod5";
    }
    if ($cnt<5) {
      $ModuleID      [4] = -1;
      $ModuleName    [7] = "mod4";
    }
    if ($cnt<4) {
      $ModuleID      [3] = -1;
      $ModuleName    [7] = "mod3";
    }
    if ($cnt<3) {
      $ModuleID      [2] = -1;
      $ModuleName    [7] = "mod2";
    }
    if ($cnt<2) {
      $ModuleID      [1] = -1;
      $ModuleName    [7] = "mod1";
    }
    if ($cnt<1) {
      $ModuleID      [0] = -1;
      $ModuleName    [7] = "mod0";
    }
    
    // Find Active pages for each of these modules
    $query =
    "select 
      Ts=convert(varchar,ListTimestamp.Timestamp,109),
      SumActiveMB=(select sum(1.*Active)/512 from ".$ServerName."_PModUse where Timestamp =B.Timestamp),
      '".$ModuleName[0]."'=isnull(1.*B.Active/512,0),
      '".$ModuleName[1]."'=isnull(1.*C.Active/512,0),
      '".$ModuleName[2]."'=isnull(1.*D.Active/512,0),
      '".$ModuleName[3]."'=isnull(1.*E.Active/512,0),
      '".$ModuleName[4]."'=isnull(1.*F.Active/512,0),
      '".$ModuleName[5]."'=isnull(1.*G.Active/512,0),
      '".$ModuleName[6]."'=isnull(1.*H.Active/512,0),
      '".$ModuleName[7]."'=isnull(1.*I.Active/512,0)
    from (select distinct Timestamp from ".$ServerName."_PModUse 
          where Timestamp >='".$StartTimestamp."'
          and Timestamp <='".$EndTimestamp."'
          ) ListTimestamp  
          left outer join ".$ServerName."_PModUse B on ListTimestamp.Timestamp = B.Timestamp and B.ModuleID=".$ModuleID[0]." 
          left outer join ".$ServerName."_PModUse C on ListTimestamp.Timestamp = C.Timestamp and C.ModuleID=".$ModuleID[1]." 
          left outer join ".$ServerName."_PModUse D on ListTimestamp.Timestamp = D.Timestamp and D.ModuleID=".$ModuleID[2]." 
          left outer join ".$ServerName."_PModUse E on ListTimestamp.Timestamp = E.Timestamp and E.ModuleID=".$ModuleID[3]." 
          left outer join ".$ServerName."_PModUse F on ListTimestamp.Timestamp = F.Timestamp and F.ModuleID=".$ModuleID[4]." 
          left outer join ".$ServerName."_PModUse G on ListTimestamp.Timestamp = G.Timestamp and F.ModuleID=".$ModuleID[5]." 
          left outer join ".$ServerName."_PModUse H on ListTimestamp.Timestamp = H.Timestamp and F.ModuleID=".$ModuleID[6]." 
          left outer join ".$ServerName."_PModUse I on ListTimestamp.Timestamp = I.Timestamp and F.ModuleID=".$ModuleID[7]." 
    order by ListTimestamp.Timestamp";
  }
?>
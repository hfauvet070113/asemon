<?php

  if (!isset($filter_clause) ) $filter_clause = "";
  if (!isset($sort_clause) )   $sort_clause = "";

  if ( $StmtObjVersion == "old" )
      $query = "set rowcount ".$rowcount."
      select 
       DBName ,
       OwnerUserID ,
       ObjectName ,
       ObjectType ,
       IndexID ,
       L_Reads=1.*LogicalReads ,
       PhysicalReads ,
       PhysicalAPFReads ,
       TableSize 
      from ".$ServerName."_StmtObj   
      where StmtID =".$StmtID."
      order by 1,2,3,5";
  else
      $query = "set rowcount ".$rowcount."
      select 
       DBName ,
       OwnerUserID ,
       ObjectName ,
       ObjectType ,
       IndexID ,
       L_Reads=1.*LogicalReads ,
       PhysicalReads ,
       PhysicalAPFReads ,
       PartitionID, 
       PartitionName, 
       PartitionSize,
       IdxName 
      from ".$ServerName."_StmtObj   
      where StmtID =".$StmtID."
      order by 1,2,3,5";

  $query = $query.$sort_clause." 
  set rowcount 0";
?>

<?php
if ($typeGraph == "DATA") {


  $logdataExists = 0;
  // Check if old collector is still used and collects log usage in db with mixed data and log
  $result = asemon_query("
    if exists (select *
      from ".$ServerName."_AseDbSpce
      where isMixedLog=1
      and logUsed_pgs is not null
      and Timestamp>='".$StartTimestamp."'
      and Timestamp <='".$EndTimestamp."')
        select RES=1
      else
        select RES=0
  ",$pid);
  $row = asemon_fetch_assoc($result);
  if ($row["RES"] == 1) $logdataExists = 1;


  if ($logdataExists == 1)
    $cols = 
    "DataSize_Mb=(1.*(case when isMixedLog=0 then  Total_pgs-logTotal_pgs else  Total_pgs end)) * @pgsz/(1024*1024),
     DataUsed_Mb=(1.*(case when isMixedLog=0 then  Total_pgs-logTotal_pgs else  Total_pgs end) - dbFree_pgs )*@pgsz/(1024*1024), 
     LogSize_Mb=  1.* (case when isMixedLog=0 then logTotal_pgs else 0 end) * @pgsz/(1024*1024),
     LogUsed_Mb=1.*logUsed_pgs*@pgsz/(1024*1024), 
     LogClr_Mb= 1.*logClr_pgs*@pgsz/(1024*1024)";
  else
    $cols = 
    "DataSize_Mb=(1.*(case when isMixedLog=0 then  Total_pgs-logTotal_pgs else  Total_pgs end)) * @pgsz/(1024*1024),
     DataUsed_Mb=(1.*(case when isMixedLog=0 then  Total_pgs-logTotal_pgs else  Total_pgs end) - dbFree_pgs )*@pgsz/(1024*1024)"; 
}
else
  $cols = 
  "LogSize_Mb=  1.* (case when isMixedLog=0 then logTotal_pgs else 0 end) * @pgsz/(1024*1024),
   LogUsed_Mb=1.*logUsed_pgs*@pgsz/(1024*1024), 
   LogClr_Mb= 1.*logClr_pgs*@pgsz/(1024*1024)";

$query = "
declare @pgsz int
select @pgsz=PageSize from ".$ServerName."_MonState where Timestamp=(select max(Timestamp) from ".$ServerName."_MonState where Timestamp>='".$StartTimestamp."' and Timestamp <='".$EndTimestamp."')

select Ts=convert(varchar,Timestamp,109),
".$cols."
from ".$ServerName."_AseDbSpce
where Timestamp>='".$StartTimestamp."'
and Timestamp <='".$EndTimestamp."'
and dbid=".$dbid."
order by Timestamp";
?>
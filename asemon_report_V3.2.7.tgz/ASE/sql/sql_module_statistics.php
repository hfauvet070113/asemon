<?php

$query = "select
A.ModuleID, ModuleName, Avg_Active, Max_used,Last_used=B.Active,Tot_reused
from 
(select ModuleID, ModuleName, Avg_Active=avg(1.*Active),Max_used=max(HWM),Tot_reused=sum(1.*NumPagesReused)
from ".$ServerName."_PModUse
where Timestamp >='".$StartTimestamp."'
and Timestamp <'".$EndTimestamp."'
group by ModuleID, ModuleName) A,
(select ModuleID, Active from ".$ServerName."_PModUse where Timestamp =(
        select max(Timestamp) from ".$ServerName."_PModUse 
        where Timestamp >='".$StartTimestamp."'
        and Timestamp <'".$EndTimestamp."')
) B
where A.ModuleID = B.ModuleID
order by A.ModuleID";

?>

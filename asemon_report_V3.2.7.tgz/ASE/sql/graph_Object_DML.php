<?php
$query = "
select Ts=convert(varchar,ListTimestamp.Timestamp,109), 
  [RowsInserted/s]=isnull(RowsInserted,0)*1000./isnull(Interval,1),
  [RowsDeleted/s]=isnull(RowsDeleted,0)*1000./isnull(Interval,1),
  [RowsUpdated/s]=isnull(RowsUpdated,0)*1000./isnull(Interval,1)
from (select distinct Timestamp from ".$ServerName."_OpObjAct 
      where Timestamp >='".$StartTimestamp."'
      and Timestamp <='".$EndTimestamp."'
      ) ListTimestamp  
      left outer join ".$ServerName."_OpObjAct B on ListTimestamp.Timestamp = B.Timestamp
        and B.dbname='".$ObjectDbName."'
        and B.objname='".$ObjectName."'
        and B.IndID=".$IndexID
        .$ObjectID_clause
." order by ListTimestamp.Timestamp";
?>
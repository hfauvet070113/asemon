<?php
    $create_muxthreadsinfo    = "";
    $create_tempThreadStats   = "";
    $update_tempThreadStats   = "";
    $create_tempIOCStats      = "";
    $create_tempWorkQueue     = "";
    $create_tmpThreadPool     = "";
    $create_tmpLoad           = "";
    $create_tempBucketPool    = "";

   
   function check_asemon_proc ($procname) {
   	  global $pid;
      $result = asemon_query("select id=object_id('".$procname."')",$pid);
      $row = asemon_fetch_assoc($result);
      if ( is_null($row["id"]) ) {
      	global $error;
      	$error = $error."Proc ".$procname." missing in asemon database\n";
        return false;
      }
      return true;
   }

   if ($SysCachesExists ==0 ) {
   	 $error = "XXX_SysCaches doesn't exists";
   	 return;
   }
   if ($SysConfExists ==0 ) {
   	 $error = "XXX_SysConf doesn't exists";
   	 return;
   }
   
   


   $ASE_Version="";
   if ($SysMonFl2_exists==1) {
       // Retreive ASE version
       $result = asemon_query("select top 1 ASE_Version from ".$ServerName."_SysMonFl2 where Timestamp = (select max(Timestamp) from ".$ServerName."_SysMonFl2 where Timestamp < '".$EndTimestamp."')",$pid);
       $row = asemon_fetch_assoc($result);
       $ASE_Version = $row["ASE_Version"];
   }

  if ($PHP_main_version>=8) {
  	  // PDO in PHP8 does not support interception of print messages in Transact-SQL. Need to insert printed data into a temporary table
  	  $result = asemon_query("if object_id('#asemon_print') is not null drop table #asemon_print",$pid);
  	  $result = asemon_query("create table #asemon_print (id int identity, msg varchar(512) null)",$pid);
  	  $result = asemon_query("select ID=object_id('asemon_print')",$pid);
      $row = asemon_fetch_assoc($result);
      if (is_null($row["ID"])) {
  	      $error = "New proc 'asemon_print' does not exist in archive database. You must run asemon_logger V3.2.0 or upper to create this proc (and other sp_xxx_PDO procs)";
  	      return;
  	  }
  	  $print_instruction="exec asemon_print";
  }
  else
  	  $print_instruction="print";
 
  // retrieve kernel mode from SysConf (if parameter exists)
  $kernelmode = "process";
  if ($SysConfExists==1) {
    $result = asemon_query("select val=lower(value2)
                          from ".$ServerName."_SysConf
                          where lower(name) = 'kernel mode'
                            and Timestamp = (select max(Timestamp) from ".$ServerName."_SysConf where Timestamp <='".$EndTimestamp."')",$pid);
    if ($result != null) {
      $row = asemon_fetch_assoc($result);
      if ($row != null)
        if ($row["val"] == 'threaded') $kernelmode = "threaded";
    }
  }


  if ($SysEngThrExists == 0){
      $create_muxthreadsinfo = "";
  }
  else {
      $create_muxthreadsinfo = " select enginename, engineid, ThreadID, tpname
        into #muxthreadsinfo
        from ".$ServerName."_SysEngThr
        where Timestamp = (select max(Timestamp) from ".$ServerName."_SysEngThr where Timestamp <='".$EndTimestamp."')";

      $result = asemon_query("select cnt=count(*) from ".$ServerName."_SysEngThr
        where Timestamp = (select max(Timestamp) from ".$ServerName."_SysEngThr where Timestamp <='".$EndTimestamp."')",$pid);
      $row = asemon_fetch_assoc($result);

      // Check if V15.7 "threaded" mode active
      if ($row["cnt"] > 0) {
         $kernelmode = "threaded";

        if ($SysThreadExists==0) {
             $create_tempThreadStatsTmp = "";
             $create_tempThreadStats = "";
             $update_tempThreadStats = "";
         }
         else {

             $create_tempThreadStatsTmp = " select ThreadID, ThreadPoolID,
                MinorFaults=sum(MinorFaults), MajorFaults=sum(MajorFaults),
                UserTime=sum(UserTime), SystemTime=sum(SystemTime),
                VoluntaryCtxtSwitches=sum(VoluntaryCtxtSwitches),
                NonVoluntaryCtxtSwitches=sum(NonVoluntaryCtxtSwitches),
                TaskNameTmp=convert(varchar(30), case when TaskName in ('Signal Handler','NetController', 'DiskController') then TaskName else NULL end)
                into #tempThreadStatsTmp
                from ".$ServerName."_SysThread
                where Timestamp >='".$StartTimestamp."'
                  and Timestamp <='".$EndTimestamp."'
                group by ThreadID, ThreadPoolID, convert(varchar(30), case when TaskName in ('Signal Handler','NetController', 'DiskController') then TaskName else NULL end)";
             $create_tempThreadStats = " select ThreadID, ThreadPoolID,MinorFaults,MajorFaults,UserTime,SystemTime,VoluntaryCtxtSwitches,NonVoluntaryCtxtSwitches,TaskNameTmp as TaskName into #tempThreadStats from #tempThreadStatsTmp";
             $update_tempThreadStats = " update #tempThreadStats
              set TaskName = 'Engine ' + convert(varchar(4), e.EngineNumber)
              from #tempThreadStats t, ".$ServerName."_Engines e
              where e.ThreadID = t.ThreadID and e.Timestamp=(select max(Timestamp) from ".$ServerName."_Engines where Timestamp <='".$EndTimestamp."')";
            
         }
         
         if ($IOControlExists==0) {
             $create_tempIOCStats = "";
         }
         else {

             $create_tempIOCStats = " select ControllerID, BlockingPolls=sum(delta_BlockingPolls), NonBlockingPolls=sum(delta_NonBlockingPolls),
                EventPolls=sum(delta_EventPolls), NonBlockingEventPolls=sum(delta_NonBlockingEventPolls), FullPolls=sum(delta_FullPolls),
                Events=sum(delta_Events), Type
                into #tempIOCStats
                from ".$ServerName."_IOControl
                where Timestamp >='".$StartTimestamp."'
                  and Timestamp <='".$EndTimestamp."'
                group by ControllerID, Type";
            
         }
         
         
         if ($WorkQueueExists==0) {
             $create_tempWorkQueue = "";
         }
         else {

             $create_tempWorkQueue = " select Name, TotalRequests=sum(delta_TotalRequests), QueuedRequests=sum(delta_QueuedRequests), WaitTime=sum(delta_WaitTime)
                into #tempWorkQueue
                from ".$ServerName."_WorkQueue
                where Timestamp >='".$StartTimestamp."'
                  and Timestamp <='".$EndTimestamp."'
                group by Name";
            
         }
         
         if ($ThreaPoolExists==0) {
             $create_tmpThreadPool = "";
         }
         else {

             $create_tmpThreadPool = " select ThreadPoolID, ThreadPoolName, Size=max(Size), Type
                into #tmpThreadPool
                from ".$ServerName."_ThreaPool
                where Timestamp >='".$StartTimestamp."'
                  and Timestamp <='".$EndTimestamp."'
                group by ThreadPoolID, ThreadPoolName, Type
                order by ThreadPoolName";
         }

         if ($SysLoadExists==0) {
             $create_tmpLoad = "";
         }
         else {

             $create_tmpLoad = " select StatisticID, EngineNumber, Avg_1min, Avg_5min, Avg_15min, ThreadPoolID
                into #tmpLoad
                from ".$ServerName."_SysLoad
                where Timestamp = (select max(Timestamp) from ".$ServerName."_SysLoad 
                                   where Timestamp >='".$StartTimestamp."'
                                   and Timestamp <='".$EndTimestamp."')";
            
         }
         if ($BuckPoolExists==0) {
             $create_tempBucketPool = "";
         }
         else {
           if (strcmp($ASE_Version, "16.0.03.00") < 0) {
             $create_tempBucketPool =" select BucketPoolName, BucketSize, BucketAllocs=sum(delta_BucketAllocs), BucketAllocsMissed=sum(delta_BucketAllocsMissed)
                 into #tempBucketPool
                 from ".$ServerName."_BuckPool
                 where Timestamp >='".$StartTimestamp."'
                   and Timestamp <='".$EndTimestamp."'
                 group by BucketPoolName, BucketSize
                 order by BucketPoolName, BucketSize";
           }
           else {
             $create_tempBucketPool =" select BucketPoolName, BucketSize, BucketAllocs=sum(delta_BucketAllocs), BucketFrees=sum(delta_BucketFrees), BucketEmpty=sum(delta_BucketEmpty)
                 into #tempBucketPool
                 from ".$ServerName."_BuckPool
                 where Timestamp >='".$StartTimestamp."'
                   and Timestamp <='".$EndTimestamp."'
                 group by BucketPoolName, BucketSize
                 order by BucketPoolName, BucketSize";
           }
         }
      }
         
  }

  if ($ArchSrvType=="Adaptive Server Enterprise") {  
    $result = asemon_query("if object_id('#tempmon0') is not null drop table #tempmon0",$pid);
    $result = asemon_query("if object_id('#tempmonitors') is not null drop table #tempmonitors",$pid);
    $result = asemon_query("if object_id('#devicemap') is not null drop table #devicemap",$pid);
    $result = asemon_query("if object_id('#cachemap') is not null drop table #cachemap",$pid);
    $result = asemon_query("if object_id('#nvcachemap') is not null drop table #nvcachemap",$pid);
    $result = asemon_query("if object_id('#pool_detail_per_cache') is not null drop table #pool_detail_per_cache",$pid);
    $result = asemon_query("if object_id('#spinlocknames') is not null drop table #spinlocknames",$pid);
    $result = asemon_query("if object_id('#muxthreadsinfo') is not null drop table #muxthreadsinfo",$pid);
    $result = asemon_query("if object_id('#tempThreadStatsTmp') is not null drop table #tempThreadStatsTmp",$pid);
    $result = asemon_query("if object_id('#tempThreadStats') is not null drop table #tempThreadStats",$pid);
    $result = asemon_query("if object_id('#tempIOCStats') is not null drop table #tempIOCStats",$pid);
    $result = asemon_query("if object_id('#tempWorkQueue') is not null drop table #tempWorkQueue",$pid);
    $result = asemon_query("if object_id('#tmpThreadPool') is not null drop table #tmpThreadPool",$pid);
    $result = asemon_query("if object_id('#tmpLoad') is not null drop table #tmpLoad",$pid);
    $result = asemon_query("if object_id('#tempBucketPool') is not null drop table #tempBucketPool",$pid);
  }
  else {
  	// We are on IQ
    $result = asemon_query("drop table if exists #tempmon0",$pid);
    $result = asemon_query("drop table if exists #tempmonitors",$pid);
    $result = asemon_query("drop table if exists #devicemap",$pid);
    $result = asemon_query("drop table if exists #cachemap",$pid);
    $result = asemon_query("drop table if exists #nvcachemap",$pid);
    $result = asemon_query("drop table if exists #pool_detail_per_cache",$pid);
    $result = asemon_query("drop table if exists #spinlocknames",$pid);
    $result = asemon_query("drop table if exists #muxthreadsinfo",$pid);
    $result = asemon_query("drop table if exists #tempThreadStatsTmp",$pid);
    $result = asemon_query("drop table if exists #tempThreadStats",$pid);
    $result = asemon_query("drop table if exists #tempIOCStats",$pid);
    $result = asemon_query("drop table if exists #tempWorkQueue",$pid);
    $result = asemon_query("drop table if exists #tmpThreadPool",$pid);
    $result = asemon_query("drop table if exists #tmpLoad",$pid);
    $result = asemon_query("drop table if exists #tempBucketPool",$pid);
  }



  // Create the spinlock decode table if not yet existing
  $result = asemon_query("create table #spinlocknames (field_name varchar(79) not null, short_field_name varchar(3) not null)",$pid);
  $result = asemon_query("create unique index iu on #spinlocknames (short_field_name)",$pid);

  $query="
insert into #spinlocknames values ('physlockspins' , 'A'                                          )
insert into #spinlocknames values ('Vdp_spin' , '2'                                               )
insert into #spinlocknames values ('ASTC_SPIN' , '5'                                              )
insert into #spinlocknames values ('fglockspins' , '10'                                           )
insert into #spinlocknames values ('DATACHG_SPIN' , '12'                                          )
insert into #spinlocknames values ('PTNCOND_SPIN' , '13'                                          )
insert into #spinlocknames values ('SITEBUF_SPIN' , '14'                                          )
insert into #spinlocknames values ('tablockspins' , '18'                                          )
insert into #spinlocknames values ('Ides Spinlocks' , '23'                                        )
insert into #spinlocknames values ('Pdes Spinlocks' , '24'                                        )
insert into #spinlocknames values ('addrlockspins' , '25'                                         )
insert into #spinlocknames values ('SSQLCACHE_SPIN' , '33'                                        )
insert into #spinlocknames values ('kdaio_spinlock' , '34'                                        )
insert into #spinlocknames values ('Des Upd Spinlocks' , '39'                                     )
insert into #spinlocknames values ('SMCD_spinlock[i]' , '45'                                      )
insert into #spinlocknames values ('default data cache' , '46'                                    )
insert into #spinlocknames values ('kdalloc_spinlock' , '47'                                      )
insert into #spinlocknames values ('Resource->hk_spin' , '49'                                     )
insert into #spinlocknames values ('Dbt->dbt_repl_spin' , '57'                                    )
insert into #spinlocknames values ('Ides Chain Spinlocks' , '58'                                  )
insert into #spinlocknames values ('Kernel->kaspinlock' , '59'                                    )
insert into #spinlocknames values ('Kernel->kbmempools' , '60'                                    )
insert into #spinlocknames values ('Kernel->kespinlock' , '61'                                    )
insert into #spinlocknames values ('Pdes Chain Spinlocks' , '62'                                  )
insert into #spinlocknames values ('SVRNAP_spinlock[i]' , '63'                                    )
insert into #spinlocknames values ('Networking_spinlock' , '69'                                   )
insert into #spinlocknames values ('Resource->rdbt_spin' , '70'                                   )
insert into #spinlocknames values ('Dbtable->dbt_seqspin' , '74'                                  )
insert into #spinlocknames values ('Resource->rdbts_spin' , '75'                                  )
insert into #spinlocknames values ('Kernel->erunqspinlock' , '81'                                 )
insert into #spinlocknames values ('Kernel->kpprocspin[i]' , '82'                                 )
insert into #spinlocknames values ('Resource->rtmpdb_spin' , '83'                                 )
insert into #spinlocknames values ('User Log Cache Spinlocks' , '84'                              )
insert into #spinlocknames values ('Kernel->kfio->irw_lock' , '86'                                )
insert into #spinlocknames values ('Kernel->kprunqspinlock' , '87'                                )
insert into #spinlocknames values ('Resource->rchatrm_spin' , '88'                                )
insert into #spinlocknames values ('Resource->rdesmgr_spin' , '89'                                )
insert into #spinlocknames values ('Resource->rpssmgr_spin' , '90'                                )
insert into #spinlocknames values ('Resource->rsysgam_spin' , '91'                                )
insert into #spinlocknames values ('Kernel->kalarm_spinlock' , '94'                               )
insert into #spinlocknames values ('Kernel->kslots_spinlock' , '95'                               )
insert into #spinlocknames values ('Resource->raccmeth_spin' , '96'                               )
insert into #spinlocknames values ('Resource->rmda_spinlock' , '97'                               )
insert into #spinlocknames values ('Resource->rpdesmgr_spin' , '98'                               )
insert into #spinlocknames values ('Resource->rprocmgr_spin' , '99'                               )
insert into #spinlocknames values ('Resource->rsqltext_spin' , '100'                              )
insert into #spinlocknames values ('Dbtable->dbt_pipemgrspin' , '103'                             )
insert into #spinlocknames values ('Dbtable->dbt_thresh_spin' , '104'                             )
insert into #spinlocknames values ('Kernel->kcsi_spinlock[i]' , '105'                             )
insert into #spinlocknames values ('Kernel->ksalloc_spinlock' , '106'                             )
insert into #spinlocknames values ('Resource->rcaps_spinlock' , '107'                             )
insert into #spinlocknames values ('Resource->rpdeshash_spin' , '108'                             )
insert into #spinlocknames values ('Resource->rwaittask_spin' , '109'                             )
insert into #spinlocknames values ('Kernel->kprocobj_spinlock' , '111'                            )
insert into #spinlocknames values ('Networkmemorypoolspinlock' , '112'                            )
insert into #spinlocknames values ('Resource->rdbtnextid_spin' , '113'                            )
insert into #spinlocknames values ('Resource->rproccache_spin' , '114'                            )
insert into #spinlocknames values ('Resource->rrdatetime_spin' , '115'                            )
insert into #spinlocknames values ('Resource->rgheapblock_spin' , '116'                           )
insert into #spinlocknames values ('Dbtable->dbt_xdesqueue_spin' , '117'                          )
insert into #spinlocknames values ('Dbtable.pfts_data.pfts_spin' , '118'                          )
insert into #spinlocknames values ('Kernel->kpsleepqspinlock[i]' , '119'                          )
insert into #spinlocknames values ('Kernel->kslistener_spinlock' , '120'                          )
insert into #spinlocknames values ('Resource->rlockobjpool_spin' , '121'                          )
insert into #spinlocknames values ('Resource->rqueryplan_spin[i]' , '122'                         )
insert into #spinlocknames values ('Dbtable->dbt_defpipebufgpspin' , '123'                        )
insert into #spinlocknames values ('Kernel->kssocktab_spinlock[i]' , '124'                        )
insert into #spinlocknames values ('Resource->rlocksemaphore_spin' , '125'                        )
insert into #spinlocknames values ('Resource->rlocksleeptask_spin' , '126'                        )
insert into #spinlocknames values ('Resource->runilibmutex_spin[i]' , '127'                       )
insert into #spinlocknames values ('Dbt->dbt_repl_context.repl_spinlock' , '128'                  )
insert into #spinlocknames values ('Dbtable->dbt_alsinfo.adi_plcflusher_queue_spin' , '129'       )
insert into #spinlocknames values ('Dbtable->dbt_alsinfo.adi_xls_writecomplete_queue_spin' , '130')
insert into #spinlocknames values ('COMP_SPIN' , '133'                                            )
insert into #spinlocknames values ('Dynmp_spin' , '134'                                           )
insert into #spinlocknames values ('ENCR_SPIN' , '135'                                            )
insert into #spinlocknames values ('Kernel Spinlock Spinlock' , '136'                             )
insert into #spinlocknames values ('Kernel->kbmemblocks' , '137'                                  )
insert into #spinlocknames values ('Kernel->kbmemstacks' , '138'                                  )
insert into #spinlocknames values ('Kernel->kbspinlock' , '139'                                   )
insert into #spinlocknames values ('Kernel->kcsi_factory_spinlock' , '140'                        )
insert into #spinlocknames values ('Kernel->kfio->foc_lock' , '141'                               )
insert into #spinlocknames values ('Kernel->kmemobjects' , '142'                                  )
insert into #spinlocknames values ('Kernel->kmspinlock' , '143'                                   )
insert into #spinlocknames values ('Kernel->kpspinlock' , '144'                                   )
insert into #spinlocknames values ('Kernel->kshbc_spinlock' , '145'                               )
insert into #spinlocknames values ('Kernel->kssocktab_spinlock[0]' , '146'                        )
insert into #spinlocknames values ('Kernel->kwt->kwt_memspinlock' , '147'                         )
insert into #spinlocknames values ('Kernel->kwt->kwt_spinlock' , '148'                            )
insert into #spinlocknames values ('Kernel->kxpserver_spinlock' , '149'                           )
insert into #spinlocknames values ('Kernel->rrtms_command_spinlock' , '150'                       )
insert into #spinlocknames values ('Kernel->rrtms_jvm_spinlock' , '151'                           )
insert into #spinlocknames values ('LDAP_SPIN' , '152'                                            )
insert into #spinlocknames values ('LMEMUSG_SPIN' , '153'                                         )
insert into #spinlocknames values ('NEXTAPMONDX_SPIN' , '154'                                     )
insert into #spinlocknames values ('Network memory pool spinlock' , '155'                         )
insert into #spinlocknames values ('RMEMLOG_SPINLOCK' , '156'                                     )
insert into #spinlocknames values ('RTMS_SPIN' , '157'                                            )
insert into #spinlocknames values ('Resource->ha_spin' , '158'                                    )
insert into #spinlocknames values ('Resource->maxscanthread_spin' , '159'                         )
insert into #spinlocknames values ('Resource->maxthread_spin' , '160'                             )
insert into #spinlocknames values ('Resource->qdb_spin' , '161'                                   )
insert into #spinlocknames values ('Resource->rals_info.ai_service_spin' , '162'                  )
insert into #spinlocknames values ('Resource->raudit_spin' , '163'                                )
insert into #spinlocknames values ('Resource->rdbt_ext_spin' , '164'                              )
insert into #spinlocknames values ('Resource->rdbt_xspin' , '165'                                 )
insert into #spinlocknames values ('Resource->rdbtddlcount_spin' , '166'                          )
insert into #spinlocknames values ('Resource->rdes_xspin' , '167'                                 )
insert into #spinlocknames values ('Resource->rdesidt_spin' , '168'                               )
insert into #spinlocknames values ('Resource->rdskbuf_spin' , '169'                               )
insert into #spinlocknames values ('Resource->rdumpdb_spin' , '170'                               )
insert into #spinlocknames values ('Resource->rerrpll_spin' , '171'                               )
insert into #spinlocknames values ('Resource->rexerlog_spin' , '172'                              )
insert into #spinlocknames values ('Resource->rgmemfrag' , '173'                                  )
insert into #spinlocknames values ('Resource->rlang_spin' , '174'                                 )
insert into #spinlocknames values ('Resource->rlmt_spin' , '175'                                  )
insert into #spinlocknames values ('Resource->rlockpromotion_spin' , '176'                        )
insert into #spinlocknames values ('Resource->rltctx_spin' , '177'                                )
insert into #spinlocknames values ('Resource->romnicurs_spin' , '178'                             )
insert into #spinlocknames values ('Resource->romnides_spin' , '179'                              )
insert into #spinlocknames values ('Resource->romnipss_spin' , '180'                              )
insert into #spinlocknames values ('Resource->rpage_xspin' , '181'                                )
insert into #spinlocknames values ('Resource->rprot_spin' , '182'                                 )
insert into #spinlocknames values ('Resource->rrdes_spin' , '183'                                 )
insert into #spinlocknames values ('Resource->rrm_spin' , '184'                                   )
insert into #spinlocknames values ('Resource->rsdesmgr_spin' , '185'                              )
insert into #spinlocknames values ('Resource->rslgroup_spin' , '186'                              )
insert into #spinlocknames values ('Resource->rslmgr_hash_spin' , '187'                           )
insert into #spinlocknames values ('Resource->rslmgr_spin' , '188'                                )
insert into #spinlocknames values ('Resource->rsrvdes_spin' , '189'                               )
insert into #spinlocknames values ('Resource->rsysind_spin' , '190'                               )
insert into #spinlocknames values ('Resource->rsysind_xspin' , '191'                              )
insert into #spinlocknames values ('Resource->rtmrng_spin' , '192'                                )
insert into #spinlocknames values ('Resource->runicache_spin' , '193'                             )
insert into #spinlocknames values ('Resource->rxact_xspin' , '194'                                )
insert into #spinlocknames values ('Resource->rxlsmempool_spin' , '195'                           )
insert into #spinlocknames values ('SQLDEBUG' , '196'                                             )
insert into #spinlocknames values ('Security Buffer Pool' , '197'                                 )
insert into #spinlocknames values ('TMPOBJ_SPIN' , '198'                                          )
insert into #spinlocknames values ('TRIG_SPIN' , '199'                                            )
insert into #spinlocknames values ('TXRCOLDES_SPIN' , '200'                                       )
insert into #spinlocknames values ('XDES_HASH_BUCKET_SPINLOCK' , '201'                            )
insert into #spinlocknames values ('XDES_SPIN' , '202'                                            )
insert into #spinlocknames values ('kdmirror_spinlock' , '203'                                    )
insert into #spinlocknames values ('kdvirtdisk_spinlock' , '204'                                  )
insert into #spinlocknames values ('Slgroup Spinlocks' , '205'                                    )
insert into #spinlocknames values ('QMEMUSG_SPIN' , '206'                                         )
insert into #spinlocknames values ('Kernel->ksmigrate_spinlock' , '207'                           )
insert into #spinlocknames values ('Kernel->kkern_resmem_spin' , '208'                            )
insert into #spinlocknames values ('Kernel->kkrmfrag_spin' , '209'                                )
insert into #spinlocknames values ('Kernel->kkrmtp_spin' , '210'                                  )
insert into #spinlocknames values ('Kernel->kkrmtrd_spin' , '211'                                 )
insert into #spinlocknames values ('Kernel->kkrmtsk_spin' , '212'                                 )
insert into #spinlocknames values ('Kernel->kkrmeng_spin' , '213'                                 )
insert into #spinlocknames values ('Kernel->kkrmdefq_spin' , '214'                                )
insert into #spinlocknames values ('Kernel->kkrmbc_spin' , '215'                                  )
insert into #spinlocknames values ('Kernel->kssocktab_spinlock' , '216'                           )
insert into #spinlocknames values ('Kernel->kcsi_mutex_list_spin' , '217'                         )
insert into #spinlocknames values ('Sybatomic_spinlock' , '218'                                   )
insert into #spinlocknames values ('Resource->dbrecdiag_spinlock' , '219'                         )
insert into #spinlocknames values ('DTUMEM_SPIN' , '220'                                          )
insert into #spinlocknames values ('CDFLTMEM_SPIN' , '221'                                        )
insert into #spinlocknames values ('CPINFOMEM_SPIN' , '222'                                       )
insert into #spinlocknames values ('GLBPWDVLT_SPIN' , '223'                                       )
insert into #spinlocknames values ('RAMEM_SPIN' , '224'                                           )
insert into #spinlocknames values ('RTPM_SPIN' , '225'                                            )
insert into #spinlocknames values ('Disk Controller Manager' , '226'                              )
insert into #spinlocknames values ('Network Controller Manager' , '227'                           )
insert into #spinlocknames values ('Ct-Lib Controller Manager' , '228'                            )
insert into #spinlocknames values ('Monitor spinlock' , '229'                                     )
insert into #spinlocknames values ('Kernel->kdynengspinlock' , '230'                              )
insert into #spinlocknames values ('Hashtable' , '231'                                            )
insert into #spinlocknames values ('Multimap' , '232'                                             )
insert into #spinlocknames values ('threadpool' , '233'                                           )
insert into #spinlocknames values ('syb_system_pool' , '234'                                      )
insert into #spinlocknames values ('Deferred Queue' , '235'                                       )
insert into #spinlocknames values ('syb_default_pool' , '236'                                     )
insert into #spinlocknames values ('global sched' , '237'                                         )
insert into #spinlocknames values ('Sched Q' , '238'                                              )
insert into #spinlocknames values ('syb_blocking_pool' , '239'                                    )
insert into #spinlocknames values ('CtlibController' , '240'                                      )
insert into #spinlocknames values ('NetController' , '241'                                        )
insert into #spinlocknames values ('DiskController' , '242'                                       )
insert into #spinlocknames values ('imdb_cache' , '243'                                           )
insert into #spinlocknames values ('inmemrory_cache' , '244'                                      )
insert into #spinlocknames values ('Socktab Spinlock[i]' , '245'                                  )
insert into #spinlocknames values ('Resource->jst_info.jst_spin' , '246'                          )
insert into #spinlocknames values ('CTINFO SPIN' , '247'                                          )
insert into #spinlocknames values ('Resource->rpmctrl_spin' , '248'                               )
insert into #spinlocknames values ('JAVA_PERVM_SP' , '249'                                        )
insert into #spinlocknames values ('JRESOURCE_SPIN' , '250'                                       )
insert into #spinlocknames values ('JRES_POOLS_SPIN' , '251'                                      )
insert into #spinlocknames values ('JAVA_SUBSYSTEM_SP' , '252'                                    )
insert into #spinlocknames values ('JAVA_PROC_BLOCK_SP' , '253'                                   )
insert into #spinlocknames values ('JAVA_GLOBAL_FIXED_POOL_SP' , '254'                            )
insert into #spinlocknames values ('DUMPHIST_SPIN' , '255'                                        )
insert into #spinlocknames values ('Kernel->kencr_csi_spinlock[i]' , '256'                        )
insert into #spinlocknames values ('Kernel->kencr_mutex_list_spin' , '257'                        )
insert into #spinlocknames values ('Kernel->kbmbktpools' , '258'                                  )
insert into #spinlocknames values ('Resource->maxutilthread_spin' , '259'                         )
insert into #spinlocknames values ('CIPC LMSG                      ' , '260'                      )
insert into #spinlocknames values ('Resource->rlockdir_spin        ' , '261'                      )
insert into #spinlocknames values ('Resource->rsidb_spin           ' , '262'                      )
insert into #spinlocknames values ('Resource->rlockdiag_spin       ' , '263'                      )
insert into #spinlocknames values ('cms_event_spinlock             ' , '264'                      )
insert into #spinlocknames values ('lst_log_cache                  ' , '265'                      )
insert into #spinlocknames values ('Cluster Config Event           ' , '266'                      )
insert into #spinlocknames values ('flush_default_data_cache       ' , '267'                      )
insert into #spinlocknames values ('Resource->rclm.gcspin          ' , '268'                      )
insert into #spinlocknames values ('freemsgq                       ' , '269'                      )
insert into #spinlocknames values ('THMGR EVENT                    ' , '270'                      )
insert into #spinlocknames values ('hb_spinlock                    ' , '271'                      )
insert into #spinlocknames values ('DONEQ                          ' , '272'                      )
insert into #spinlocknames values ('ces_eventtbl_lock              ' , '273'                      )
insert into #spinlocknames values ('Resource->rbcmt_spin           ' , '274'                      )
insert into #spinlocknames values ('CIPCWSPINLOCK                  ' , '275'                      )
insert into #spinlocknames values ('PCM_SPINLOCK                   ' , '276'                      )
insert into #spinlocknames values ('ces_event_spinlock             ' , '277'                      )
insert into #spinlocknames values ('Resource->rwlmgr_spin          ' , '278'                      )
insert into #spinlocknames values ('objlockspins                   ' , '279'                      )
insert into #spinlocknames values ('ne_spinlock                    ' , '280'                      )
insert into #spinlocknames values ('cmsmsgq_spinlock               ' , '281'                      )
insert into #spinlocknames values ('Resource->rdbcc_spin           ' , '282'                      )
insert into #spinlocknames values ('iplm_spinlock                  ' , '283'                      )
insert into #spinlocknames values ('lst_data_cache                 ' , '284'                      )
insert into #spinlocknames values ('CIPCSPINLOCK                   ' , '285'                      )
insert into #spinlocknames values ('CIPC MSG                       ' , '286'                      )
insert into #spinlocknames values ('Resource->rwlmgr_ocb_spin      ' , '287'                      )
insert into #spinlocknames values ('SENTQ                          ' , '288'                      )
insert into #spinlocknames values ('Resource->rclm.localmsgidspin  ' , '289'                      )
insert into #spinlocknames values ('SENDQ                          ' , '290'                      )
insert into #spinlocknames values ('cls_spinlock                   ' , '291'                      )
insert into #spinlocknames values ('CLM spinlock                   ' , '292'                      )
insert into #spinlocknames values ('rmtdlcmsgq                     ' , '293'                      )
insert into #spinlocknames values ('Resource->rclm.localbastseqspin' , '294'                      )
insert into #spinlocknames values ('CLM Service Event              ' , '295'                      )
insert into #spinlocknames values ('Kernel->ktimer_spinlock        ' , '296'                      )
insert into #spinlocknames values ('Resource->rclm.timetablespin   ' , '297'                      )
insert into #spinlocknames values ('log_cache                      ' , '298'                      )
insert into #spinlocknames values ('CLM Global Event               ' , '299'                      )
insert into #spinlocknames values ('tt_spinlock                    ' , '300'                      )
insert into #spinlocknames values ('cesq_spinlock                  ' , '301'                      )
insert into #spinlocknames values ('RECVQ                          ' , '302'                      )
insert into #spinlocknames values ('CMS_spinlock                   ' , '303'                      )

insert into #spinlocknames values ('CUDF_SPIN                                     ' , '304'       )
insert into #spinlocknames values ('CUDF_USER_SPIN                                ' , '305'       )
insert into #spinlocknames values ('DES ID Hash Bucket Spin                       ' , '306'       )
insert into #spinlocknames values ('DES Name Hash Bucket Spin                     ' , '307'       )
insert into #spinlocknames values ('DSAMEM_SPIN                                   ' , '308'       )
insert into #spinlocknames values ('Dbtable->dbt_gammgr_spin                      ' , '309'       )
insert into #spinlocknames values ('Dbtable->dbt_hcb->dhcb_spinlock               ' , '310'       )
insert into #spinlocknames values ('Dbtable->dbt_imrs->dimrs_lobgcq_spin          ' , '311'       )
insert into #spinlocknames values ('Dbtable->dbt_imrs->dimrs_pack_pimrsq_spin     ' , '312'       )
insert into #spinlocknames values ('Dbtable->dbt_imrs->dimrs_pimrs_spin           ' , '313'       )
insert into #spinlocknames values ('Dbtable->dbt_imrs->dimrs_ximrs_list_spin      ' , '314'       )
insert into #spinlocknames values ('Dbtable->dbt_imrs->dimrs_ximrs_xid_orderq_spin' , '315'       )
insert into #spinlocknames values ('Dbtable->dbt_plcblock_queue_spin              ' , '316'       )
insert into #spinlocknames values ('GROWINGCOLSTATS_SPIN                          ' , '317'       )
insert into #spinlocknames values ('Kernel->kra_ci_spinlock                       ' , '318'       )
insert into #spinlocknames values ('LFBMEM_SPIN                                   ' , '319'       )
insert into #spinlocknames values ('OMNIPDSTATS_SPIN                              ' , '320'       )
insert into #spinlocknames values ('RASTART_SPIN                                  ' , '321'       )
insert into #spinlocknames values ('RSNAP_SPIN                                    ' , '322'       )
insert into #spinlocknames values ('Resource->raudit_cache_spin                   ' , '323'       )
insert into #spinlocknames values ('Resource->rimrs_stmtdesq_spin[i]              ' , '324'       )
insert into #spinlocknames values ('Resource->rworcap_spin                        ' , '325'       )
insert into #spinlocknames values ('SEQOBJ_SPIN                                   ' , '326'       )
insert into #spinlocknames values ('eresourcep->erprocelc_spin                    ' , '327'       )
insert into #spinlocknames values ('rulerator                                     ' , '328'       )
insert into #spinlocknames values ('bufspin default data cache                    ' , '329'       )
insert into #spinlocknames values ('DROPI_NOWAIT_SPIN                             ' , '330'       )
insert into #spinlocknames values ('SSQLCACHE_SPIN[i]                             ' , '331'       )
";

  $result = asemon_query($query,$pid);

  // check if SysMon contains V15.7 data
  if ($SysMonFl2_exists==1)
      $result = asemon_query("select cnt=count(*) from ".$ServerName."_SysMonFl2 where group_name like 'engine_0' and field_id=76 and ASE_Version='".$ASE_Version."'", $pid);
  else
      $result = asemon_query("select cnt=count(*) from ".$ServerName."_SysMonFld where group_name like 'engine_0' and field_id=76", $pid);

  $row = asemon_fetch_assoc($result);
  if ($row["cnt"] == 0) {
      $V157 = 0;
      $spinlock_case = "
      when  grpname='P'  then 'spinlock_p_0'    
      when  grpname='S'  then 'spinlock_s_0'    
      when  grpname='W'  then 'spinlock_w_0'    
      ";            
  }
  else {
      $V157 = 1;
      $spinlock_case = "
      when  grpname='P'  then 'spinlock_p'    
      when  grpname='S'  then 'spinlock_s'    
      when  grpname='W'  then 'spinlock_w'    
      ";            
  }



  // Retreive sysmon values for this interval
  if ($ArchSrvType=="Adaptive Server Enterprise") {
    $null_convert = "null";
  }
  else {
    $null_convert = "";
  }

  $query = "
    select 
    fldname=convert(varchar(79) ".$null_convert.",fldname),
    group_name=
          case
            when  grpname='C0' then 'access'            
            when  grpname='C1' then 'alloc'           
            when  grpname='C2' then 'astc'            
            when  grpname='C3' then 'btree'           
            when  grpname='C4' then 'config'          
            when  grpname='C5' then 'control'         
            when  grpname='C6' then 'dbcc'            
            when  grpname='C7' then 'dbtable'         
            when  grpname='C8' then 'descriptor'      
            when  grpname='C9' then 'dfl'             
            when  grpname='F0' then 'dolaccess'       
            when  grpname='F1' then 'dolspace_mgmt'   
            when  grpname='F2' then 'dump'            
            when  grpname='F3' then 'ecache'          
            when  grpname='F4' then 'housekeeper'     
            when  grpname='F5' then 'kernel'          
            when  grpname='F6' then 'latch'           
            when  grpname='F7' then 'lock'            
            when  grpname='F8' then 'mda'             
            when  grpname='F9' then 'memory'          
            when  grpname='G0' then 'monitor_access'  
            when  grpname='G1' then 'multdb'          
            when  grpname='G2' then 'network'         
            when  grpname='G3' then 'parallel'        
            when  grpname='G4' then 'procmgr'         
            when  grpname='G5' then 'remote'          
            when  grpname='G6' then 'resmgr'          
            when  grpname='G7' then 'resource_stats'  
            when  grpname='G8' then 'sdesmgr'         
            ".$spinlock_case."
            when  grpname='G9' then 'sysind'          
            when  grpname='H0' then 'textmgr'         
            when  grpname='H1' then 'utils'           
            when  grpname='H2' then 'xact'            
            when  grpname='H3' then 'xls'             
            when  grpname='H4' then 'sysptn'
            when  grpname='H5' then 'login'
            when  substring(grpname,1,1) ='D'  then 'disk_'      +right(grpname,datalength(grpname)-1)
            when  substring(grpname,1,1) ='A'  then 'repagent_'  +right(grpname,datalength(grpname)-1)
            when  substring(grpname,1,1) ='E'  then 'engine_'    +right(grpname,datalength(grpname)-1)
            when  substring(grpname,1,1) ='R'  then 'eresource_' +right(grpname,datalength(grpname)-1)
            when  substring(grpname,1,1) ='B'  then 'buffer_'    +right(grpname,datalength(grpname)-1)
            else grpname
          end,
    field_id, value=case when max(value) is null then sum(1.*d_value) else max(value) end, description=convert(varchar(255), null)
    into #tempmon0
    from ".$ServerName."_SysMon
    where Timestamp >='".$StartTimestamp."'
      and Timestamp <='".$EndTimestamp."'
    group by fldname, grpname, field_id
    ";


  $result = asemon_query($query,$pid);


  // Retrieve field_name
  if ($SysMonFl2_exists==1)
      $query ="
      select field_name=convert(varchar(79) ".$null_convert.",rtrim(F.field_name)), T.group_name, T.field_id, T.value, T.description
      into #tempmonitors
      from #tempmon0 T left outer join ".$ServerName."_SysMonFl2 F on T.field_id = F.field_id and T.group_name = rtrim(F.group_name)
                                                        and F.ASE_Version = '".$ASE_Version."'
      where T.fldname is null
      union all
      select case when S.field_name is null then T.fldname else S.field_name end, T.group_name, T.field_id, T.value, T.description
      from #tempmon0 T left outer join #spinlocknames S on T.fldname = S.short_field_name
      where T.fldname is not null";
  else
      $query ="
      select field_name=convert(varchar(79) ".$null_convert.",rtrim(F.field_name)), T.group_name, T.field_id, T.value, T.description
      into #tempmonitors
      from #tempmon0 T left outer join ".$ServerName."_SysMonFld F on T.field_id = F.field_id and T.group_name = rtrim(F.group_name)
      where T.fldname is null
      union all
      select case when S.field_name is null then T.fldname else S.field_name end, T.group_name, T.field_id, T.value, T.description
      from #tempmon0 T left outer join #spinlocknames S on T.fldname = S.short_field_name
      where T.fldname is not null";


  
  $result = asemon_query($query,$pid);

  if ( (($SysmonType=='all')||($SysmonType=='kernel')||($SysmonType=='taskmgmt') ) && $kernelmode == 'threaded' ) {
    // Create necessary temporary tables
    if ($create_muxthreadsinfo!= "") asemon_query($create_muxthreadsinfo, $pid);
    if ($create_tempThreadStatsTmp!= "") asemon_query($create_tempThreadStatsTmp, $pid);
    if ($create_tempThreadStats!= "") asemon_query($create_tempThreadStats, $pid);
    if ($update_tempThreadStats!= "") asemon_query($update_tempThreadStats, $pid);
    if ($create_tempIOCStats!= "") asemon_query($create_tempIOCStats, $pid);
    if ($create_tempWorkQueue!= "") asemon_query($create_tempWorkQueue, $pid);
    if ($create_tmpThreadPool!= "") asemon_query($create_tmpThreadPool, $pid);
    if ($create_tmpLoad!= "") asemon_query($create_tmpLoad, $pid);
    if ($BuckPoolExists!=0) {
      if ($create_tempBucketPool!="") asemon_query($create_tempBucketPool, $pid);
    }
  }

  if ( (($SysmonType=='all')||($SysmonType=='taskmgmt') ) && $kernelmode == 'process' ) {
    // Create fake temporary tables to allow execution of sp_sysmon_taskmgmt
    asemon_query("create table #tmpThreadPool (ThreadPoolID int, ThreadPoolName varchar( 30), Size int, Type varchar( 30))", $pid);
    asemon_query("create table #muxthreadsinfo (engineid int, enginename varchar(15), tpname varchar(80))", $pid);
  }

  if ($ASE_Version != "") {
      if (strcmp($ASE_Version, "15") < 0) $procversion = "V125";
      else if (strcmp($ASE_Version, "15.5") < 0) $procversion = "V150";
        else if (strcmp($ASE_Version, "15.7") < 0) $procversion = "V155";
           else if (strcmp($ASE_Version, "16") < 0) $procversion = "V157";
              else if (strcmp($ASE_Version, "16.0.03.00") < 0) $procversion = "V16";
                else if (strcmp($ASE_Version, "16.1.00.00") < 0) $procversion = "V16SP3";
                 else $procversion = "V161";
  }

  $PDO = "";
  if ($PHP_main_version>=8) {
     $PDO = "PDO_";
  }

  $procused = "sp_sysmon_xxx_".$PDO.$procversion;
  $sp_sysmon_appmgmt         = "sp_sysmon_appmgmt_".$PDO.$procversion;    
  $sp_sysmon_dcache_dtl      = "sp_sysmon_dcache_dtl_".$PDO.$procversion; 
  $sp_sysmon_dcache_sum      = "sp_sysmon_dcache_sum_".$PDO.$procversion;
  $sp_sysmon_diskio          = "sp_sysmon_diskio_".$PDO.$procversion;
  $sp_sysmon_hk              = "sp_sysmon_hk_".$PDO.$procversion;
  $sp_sysmon_index           = "sp_sysmon_index_".$PDO.$procversion;
  $sp_sysmon_locks           = "sp_sysmon_locks_".$PDO.$procversion;
  $sp_sysmon_memory          = "sp_sysmon_memory_".$PDO.$procversion;
  $sp_sysmon_netio           = "sp_sysmon_netio_".$PDO.$procversion;
  $sp_sysmon_parallel        = "sp_sysmon_parallel_".$PDO.$procversion;
  $sp_sysmon_pcache          = "sp_sysmon_pcache_".$PDO.$procversion;
  $sp_sysmon_recovery        = "sp_sysmon_recovery_".$PDO.$procversion;
  $sp_sysmon_taskmgmt        = "sp_sysmon_taskmgmt_".$PDO.$procversion;
  $sp_sysmon_xactmgmt        = "sp_sysmon_xactmgmt_".$PDO.$procversion;
  $sp_sysmon_xactsum         = "sp_sysmon_xactsum_".$PDO.$procversion;
  $sp_sysmon_kernel          = "sp_sysmon_kernel_".$PDO.$procversion;
  $sp_sysmon_kernel_threaded = "sp_sysmon_kernel_threaded_".$PDO.$procversion;
  $sp_sysmon_nvcache_sum     = "sp_sysmon_nvcache_sum_".$PDO.$procversion;
  $sp_sysmon_nvcache_dtl     = "sp_sysmon_nvcache_dtl_".$PDO.$procversion;
  
  if ($PDO == "PDO_") {
  	// Check existance of new PDO procs
  	check_asemon_proc($sp_sysmon_appmgmt        );
  	check_asemon_proc($sp_sysmon_dcache_dtl     );
  	check_asemon_proc($sp_sysmon_dcache_sum     );
  	check_asemon_proc($sp_sysmon_diskio         );
  	check_asemon_proc($sp_sysmon_hk             );
  	check_asemon_proc($sp_sysmon_index          );
  	check_asemon_proc($sp_sysmon_locks          );
  	check_asemon_proc($sp_sysmon_memory         );
  	check_asemon_proc($sp_sysmon_netio          );
  	check_asemon_proc($sp_sysmon_parallel       );
  	check_asemon_proc($sp_sysmon_pcache         );
  	check_asemon_proc($sp_sysmon_recovery       );
  	check_asemon_proc($sp_sysmon_taskmgmt       );
  	check_asemon_proc($sp_sysmon_xactmgmt       );
  	check_asemon_proc($sp_sysmon_xactsum        );
  	check_asemon_proc($sp_sysmon_kernel         );
  	if (strcmp($ASE_Version, "15.7") >= 0)
  	  check_asemon_proc($sp_sysmon_kernel_threaded);
  	if (strcmp($ASE_Version, "16") >= 0) {
  	  check_asemon_proc($sp_sysmon_nvcache_sum    );
  	  check_asemon_proc($sp_sysmon_nvcache_dtl    );
    }
  }

  //asemon_query("print 'ArchSrvType:".$ArchSrvType." ASE_Version:".$ASE_Version."'",$pid);

  if ($ArchSrvType=="Adaptive Server Enterprise") {
      // check if sp_sysmon_appmgmt exists in archive db
      $result = asemon_query("select cnt=count(*) from sysobjects where name like 'sp_sysmon_appmgmt_".$procversion."%'",$pid);
      $row = asemon_fetch_assoc($result);
      if ($row["cnt"]==0) {
          // Old asemon_logger is used and stored procedures are not created in archive db. Use default ASE sp_sysmon stored procs + new proc for V15.7
          $procused = "Local sp_sysmon procs";
          $sp_sysmon_appmgmt         = "sp_sysmon_appmgmt";
          $sp_sysmon_dcache_dtl      = "sp_sysmon_dcache_dtl";
          $sp_sysmon_dcache_sum      = "sp_sysmon_dcache_sum";
          $sp_sysmon_diskio          = "sp_sysmon_diskio";
          $sp_sysmon_hk              = "sp_sysmon_hk";
          $sp_sysmon_index           = "sp_sysmon_index";
          $sp_sysmon_locks           = "sp_sysmon_locks";
          $sp_sysmon_memory          = "sp_sysmon_memory";
          $sp_sysmon_netio           = "sp_sysmon_netio";
          $sp_sysmon_parallel        = "sp_sysmon_parallel";
          $sp_sysmon_pcache          = "sp_sysmon_pcache";
          $sp_sysmon_recovery        = "sp_sysmon_recovery";
          $sp_sysmon_taskmgmt        = "sp_sysmon_taskmgmt";
          $sp_sysmon_xactmgmt        = "sp_sysmon_xactmgmt";
          $sp_sysmon_xactsum         = "sp_sysmon_xactsum";
          $sp_sysmon_nvcache_sum     = "sp_sysmon_nvcache_sum";
          $sp_sysmon_nvcache_dtl     = "sp_sysmon_nvcache_dtl";
          if (strcmp($ASE_Version, "15.7") > 0) {
            if ( (($SysmonType=='all')||($SysmonType=='kernel')||($SysmonType=='taskmgmt') ) && $kernelmode == 'threaded' ) {

//asemon_query("print 'Check sysmon_kernel_threaded_V157 existance'",$pid);
              $sp_sysmon_kernel_threaded = "sysmon_kernel_threaded_V157";
              // Check if "sysmon_kernel_threaded_V157" exists in archive db
              $result = asemon_query("select id=object_id('sysmon_kernel_threaded_V157')",$pid);
              $row = asemon_fetch_assoc($result);
              if ($row["id"]==null) {
//asemon_query("print 'sysmon_kernel_threaded_V157 doesnot exists'",$pid);
                  include ("../proc/sysmon_kernel_threaded_V157.php");            
                  asemon_query($query, $pid);
//asemon_query("print 'sysmon_kernel_threaded_V157 created'",$pid);
                  asemon_query("grant execute on sysmon_kernel_threaded_V157 to public", $pid);
//asemon_query("print 'grant ok on sysmon_kernel_threaded_V157'",$pid);
              }
              else {
//asemon_query("print 'sysmon_kernel_threaded_V157  exists'",$pid);
              }
            }
          }
      }  
  }


  if ($SysMonFl2_exists==1)
      $select_tmpmonitor="
      insert into #tempmonitors
      select convert(varchar,F.field_name), convert(varchar,F.group_name), F.field_id, 0, null
      from ".$ServerName."_SysMonFl2 F left outer join #tempmonitors M on F.group_name = M.group_name and F.field_id = M.field_id
      where M.value is null
        and F.ASE_Version = '".$ASE_Version."'";
  else
      $select_tmpmonitor="
      insert into #tempmonitors
      select convert(varchar,F.field_name), convert(varchar,F.group_name), F.field_id, 0, null
      from ".$ServerName."_SysMonFld F left outer join #tempmonitors M on F.group_name = M.group_name and F.field_id = M.field_id
      where M.value is null";

  // Get ASE PageSize
  $result = asemon_query("select MaxPageSize=PageSize from ".$ServerName."_MonState 
                where Timestamp =(select max(Timestamp) from ".$ServerName."_MonState
                                  where Timestamp <='".$EndTimestamp."')" , $pid);
  $row = asemon_fetch_assoc($result);
  $MaxPageSize = $row["MaxPageSize"];
  if ($MaxPageSize == '') $MaxPageSize = 2048;


  // populate #nvcachemap if SysNVCach exists
  if ($SysNVCachExists == 1)
    asemon_query("select   ssid,  name,  group_name
                  into #nvcachemap
                  from ".$ServerName."_SysNVCach
                  where Timestamp = (select max(Timestamp) from ".$ServerName."_SysNVCach where Timestamp <='".$EndTimestamp."')
                 ",$pid);

  // Main query to execute sp_sysmon
  $query = "
  declare
      @NumElapsed int,
      @NumElapsedMs int,
      @NumXacts int,
      @NumEngines smallint,
      @Reco char(1),
      @StartTs datetime,
      @EndTs datetime,
      @StartSampling varchar(30),
      @EndSampling varchar(30),
      @Elapsedfirst int,
      @DaysRunning int,
      @CountersCleared datetime,
      @ecache_size int,
      @asemon_string varchar(512)
  
  select @Reco='Y'

  select @NumXacts = value
  from #tempmonitors
  where group_name = 'access'
  and   field_name = 'xacts'
  if @@rowcount=0
  begin
      ".$print_instruction." 'No data for this interval'
      return
  end

  if @NumXacts = 0
      select @NumXacts = 1
  ".
  $select_tmpmonitor
  ."
  select @StartTs = min(Timestamp), @EndTs = max(Timestamp)
  from ".$ServerName."_SysMon
  where Timestamp >='".$StartTimestamp."'
  and Timestamp <='".$EndTimestamp."'
  
  select @Elapsedfirst=d_value*1000
  from ".$ServerName."_SysMon
  where Timestamp = @StartTs
  and grpname='Z'
  and field_id=0

  select @NumElapsedMs = datediff (ms , @StartTs, @EndTs) + @Elapsedfirst,
         @StartSampling=   convert (varchar, dateadd (ms, - @Elapsedfirst, @StartTs )),
         @EndSampling=     convert (varchar, @EndTs )
  
  select NumEngines=avg(NbEnginesOnline) into #numengines
  from (
        select NbEnginesOnline =count(*)
        from ".$ServerName."_Engines
        where Timestamp >='".$StartTimestamp."'
        and Timestamp <='".$EndTimestamp."'
        and ContextSwitches>0 
        group by Timestamp
   ) engOnline
  select @NumEngines=NumEngines from #numengines
  drop table #numengines
      
  select @NumElapsed = @NumElapsedMs /1000


  select name, phyname, group_name='disk_'+convert(varchar,vdevno)
  into #devicemap
  from ".$ServerName."_SysDev
  where Timestamp = (select max(Timestamp) from ".$ServerName."_SysDev where Timestamp <='".$EndTimestamp."')


  select   cid,  name,  group_name,  cache_status,  cache_type,  cache_config_size,  cache_run_size,  config_replacement,  run_replacement
  into #cachemap
  from ".$ServerName."_SysCaches
  where Timestamp = (select max(Timestamp) from ".$ServerName."_SysCaches where Timestamp <='".$EndTimestamp."')
  
  select name, convert (varchar(8), substring([comment], 1, charindex('K', [comment]) - 1)) as io_size
  into #pool_detail_per_cache
  from ".$ServerName."_SysConf
  where Timestamp = (select max(Timestamp) from ".$ServerName."_SysConf where Timestamp <='".$EndTimestamp."')
    and parent = 19
    and [comment] like '%Buffer Pool%'

  select @ecache_size = value
  from ".$ServerName."_SysConf
  where Timestamp = (select max(Timestamp) from ".$ServerName."_SysConf where Timestamp <='".$EndTimestamp."')
    and [comment] like 'extended cache size%'

  select @CountersCleared = CountersCleared, @DaysRunning = DaysRunning
  from ".$ServerName."_MonState
  where Timestamp = (select max(Timestamp) from ".$ServerName."_MonState where Timestamp <='".$EndTimestamp."')
  
  ".$print_instruction." '==============================================================================='
  ".$print_instruction." 'Sybase Adaptive Server Enterprise System Performance Report'
  ".$print_instruction." '==============================================================================='
  ".$print_instruction." ''
  select @asemon_string = 'Sampling Started at   : ' + convert(varchar,@StartSampling)
  ".$print_instruction." @asemon_string
  select @asemon_string = 'Sampling Ended at     : ' + convert(varchar,@EndSampling)
  ".$print_instruction." @asemon_string
  select @asemon_string = 'Sample Interval       : ' + convert(varchar,@NumElapsed) + ' s'
  ".$print_instruction." @asemon_string
  select @asemon_string = 'Nb transactions       : ' + convert(varchar,@NumXacts)
  ".$print_instruction." @asemon_string
  select @asemon_string = 'Counters Last Cleared : ' + convert(varchar,@CountersCleared)
  ".$print_instruction." @asemon_string
  select @asemon_string = 'ASE days running      : ' + convert(varchar,@DaysRunning)
  ".$print_instruction." @asemon_string
  ".$print_instruction." ''
  select @asemon_string = 'Archive server ASE version : ' + convert(varchar(256),@@version)
  ".$print_instruction." @asemon_string
  ".$print_instruction." 'Procedures used : ".$procused."'
  ".$print_instruction." 'Kernel mode : ".$kernelmode."'
  ".$print_instruction." ''
      
  ";
  
  
  if ( (($SysmonType=='all')||($SysmonType=='kernel') ) && $kernelmode == 'process' )
    $query=$query . "
      ".$print_instruction." 'WARNING :  next info about ''Process Search Count'' and ''I/O Polling Process Count'' '
      ".$print_instruction." '           are from archive server not monitored server'
      exec ".$sp_sysmon_kernel." @NumEngines, @NumElapsedMs, @NumXacts, @Reco
      ";

  if ( (($SysmonType=='all')||($SysmonType=='kernel') ) && $kernelmode == 'threaded' ) {
    $exec_sp_sysmon_kernel_threaded = 1;
    if ($SysEngThrExists==0) {
      $query=$query . " ".$print_instruction." 'WARNING : The sysmon_kernel_threaded section needs the SysEngThr collector'";
      $exec_sp_sysmon_kernel_threaded = 0;
    }
    if ($SysThreadExists==0) {
      $query=$query . " ".$print_instruction." 'WARNING : The sysmon_kernel_threaded section needs the SysThread collector'";
      $exec_sp_sysmon_kernel_threaded = 0;
    }
    if ($IOControlExists==0) {
      $query=$query . " ".$print_instruction." 'WARNING : The sysmon_kernel_threaded section needs the IOControl collector'";
      $exec_sp_sysmon_kernel_threaded = 0;
    }
    if ($WorkQueueExists==0) {
      $query=$query . " ".$print_instruction." 'WARNING : The sysmon_kernel_threaded section needs the WorkQueue collector'";
      $exec_sp_sysmon_kernel_threaded = 0;
    }
    if ($ThreaPoolExists==0) {
      $query=$query . " ".$print_instruction." 'WARNING : The sysmon_kernel_threaded section needs the ThreaPool collector'";
      $exec_sp_sysmon_kernel_threaded = 0;
    }
    if ($SysLoadExists==0) {
      $query=$query . " ".$print_instruction." 'WARNING : The sysmon_kernel_threaded section needs the SysLoad collector'";
      $exec_sp_sysmon_kernel_threaded = 0;
    }
    if ( (strcmp($ASE_Version, "16") >= 0) && ($BuckPoolExists==0) ) {
      $query=$query . " ".$print_instruction." 'WARNING : The sysmon_kernel_threaded section needs the BuckPool collector'";
      $exec_sp_sysmon_kernel_threaded = 0;
    }
    if ($exec_sp_sysmon_kernel_threaded ==1 )
      $query=$query . " exec ".$sp_sysmon_kernel_threaded." @NumEngines, @NumElapsedMs, @NumXacts, @Reco";
  }

  if ( ($SysmonType=='all')||($SysmonType=='parallel') ) 
    $query=$query . " exec ".$sp_sysmon_parallel." @NumElapsedMs, @NumXacts, @Reco";

  if ( ($SysmonType=='all')||($SysmonType=='taskmgmt') ) {
    $exec_sp_sysmon_taskmgmt = 1;
    if ( ($SysEngThrExists==0) && ($kernelmode == 'threaded') ) {
      $query=$query . " ".$print_instruction." 'WARNING : The sysmon_taskmgmt section needs the SysEngThr collector'";
      $exec_sp_sysmon_taskmgmt = 0;
    }
    if ( ($ThreaPoolExists==0) && ($kernelmode == 'threaded') ) {
      $query=$query . " ".$print_instruction." 'WARNING : The sysmon_taskmgmt section needs the ThreaPool collector'";
      $exec_sp_sysmon_taskmgmt = 0;
    }
    if ($exec_sp_sysmon_taskmgmt == 1 )
      $query=$query . " exec ".$sp_sysmon_taskmgmt." @NumEngines, @NumElapsedMs, @NumXacts, @Reco, @kernelmode='".$kernelmode."'";
  }

  if ( ($SysmonType=='all')||($SysmonType=='appmgmt') ) 
    $query=$query . " exec ".$sp_sysmon_appmgmt." @NumEngines, @NumElapsedMs, @NumXacts, ''";

  if ( ($SysmonType=='all')||($SysmonType=='hk') )
    $query=$query . " exec ".$sp_sysmon_hk." @NumElapsedMs, @NumXacts, @Reco, @NumEngines";

  if ( ($SysmonType=='all')||($SysmonType=='xactsum') )
    $query=$query . " exec ".$sp_sysmon_xactsum." @NumElapsedMs, @NumXacts";

  if ( ($SysmonType=='all')||($SysmonType=='xactmgmt') )
    $query=$query . " exec ".$sp_sysmon_xactmgmt." @NumElapsedMs, @NumXacts, @Reco";

  if ( ($SysmonType=='all')||($SysmonType=='index') )
   $query=$query . " exec ".$sp_sysmon_index." @NumElapsedMs, @NumXacts";

  if ( ($SysmonType=='all')||($SysmonType=='locks') )
    $query=$query . " exec ".$sp_sysmon_locks." @NumElapsedMs, @NumXacts, @Reco, @NumEngines";

  if ( ($SysmonType=='all')||($SysmonType=='dcache_sum') )
    $query=$query . " exec ".$sp_sysmon_dcache_sum."  @NumEngines, @NumElapsedMs, @NumXacts, @Reco, @maxpagesize=".$MaxPageSize.", @ecache_size=@ecache_size";

  if ( ($SysmonType=='all')||($SysmonType=='dcache_dtl') )
    $query=$query . " exec ".$sp_sysmon_dcache_dtl."  @NumEngines, @NumElapsedMs, @NumXacts, @Reco, @maxpagesize=".$MaxPageSize." ";

  if ( ($SysmonType=='all')||($SysmonType=='pcache') )
    $query=$query . " exec ".$sp_sysmon_pcache." @NumElapsedMs, @NumXacts, @Reco";

  if ( ($SysmonType=='all')||($SysmonType=='memory') )
    $query=$query . " exec ".$sp_sysmon_memory." @NumElapsedMs, @NumXacts";

  if ( ($SysmonType=='all')||($SysmonType=='recovery') )
    $query=$query . " exec ".$sp_sysmon_recovery." @NumElapsedMs, @NumXacts";

  if ( ($SysmonType=='all')||($SysmonType=='diskio') )
    $query=$query . " exec ".$sp_sysmon_diskio." @NumEngines, @NumElapsedMs, @NumXacts, @Reco, @kernelmode='".$kernelmode."'";

  if ( ($SysmonType=='all')||($SysmonType=='netio') )
    $query=$query . " exec ".$sp_sysmon_netio." @NumEngines, @NumElapsedMs, @NumXacts, @kernelmode='".$kernelmode."'";

  if((strcmp($ASE_Version, "16.0.02.00") >= 0) && ( ($SysmonType=='all')||($SysmonType=='nvcache (V16SP02)') ) ) {
    $exec_sp_sysmon_nvcache = 1;
    if ($SysNVCachExists == 0) {
      $query=$query . " ".$print_instruction." 'WARNING : The sysmon_nvcache section needs the SysNVCach collector'";
      $exec_sp_sysmon_nvcache = 0;
    }
    if ($exec_sp_sysmon_nvcache == 1) 
      $query=$query . "
        exec ".$sp_sysmon_nvcache_sum." @NumEngines, @NumElapsedMs, @NumXacts, @Reco
        exec ".$sp_sysmon_nvcache_dtl." @NumEngines, @NumElapsedMs, @NumXacts, @Reco
      ";
  }

  $query = $query . "
  if object_id('#tempmon0')              is not null drop table #tempmon0
  if object_id('#tempmonitors')          is not null drop table #tempmonitors
  if object_id('#devicemap')             is not null drop table #devicemap
  if object_id('#cachemap')              is not null drop table #cachemap
  if object_id('#nvcachemap')            is not null drop table #nvcachemap
  if object_id('#pool_detail_per_cache') is not null drop table #pool_detail_per_cache
  if object_id('#spinlocknames')         is not null drop table #spinlocknames
  if object_id('#muxthreadsinfo')        is not null drop table #muxthreadsinfo
  if object_id('#tempThreadStatsTmp')    is not null drop table #tempThreadStatsTmp
  if object_id('#tempThreadStats')       is not null drop table #tempThreadStats
  if object_id('#tempIOCStats')          is not null drop table #tempIOCStats
  if object_id('#tempWorkQueue')         is not null drop table #tempWorkQueue
  if object_id('#tmpThreadPool')         is not null drop table #tmpThreadPool
  if object_id('#tmpLoad')               is not null drop table #tmpLoad
  if object_id('#tempBucketPool')        is not null drop table #tempBucketPool
  ";

  if ( $PHP_main_version>=8 )  {
  	$query = $query . "select msg from #asemon_print order by id";
  }

?>

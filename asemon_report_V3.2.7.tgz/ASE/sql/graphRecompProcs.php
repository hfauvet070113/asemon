<?php
$query = "
select 
   Ts=convert(varchar,Timestamp,109)
   ,requests_s=avg(Requests*1000./Interval)
   ,loads_s=avg(Loads*1000./Interval)
   ,writes_s=avg(Writes*1000./Interval)
from ".$ServerName."_ProcCache
where Timestamp >='".$StartTimestamp."'
and Timestamp <='".$EndTimestamp."'
group by Timestamp
order by Timestamp";
?>
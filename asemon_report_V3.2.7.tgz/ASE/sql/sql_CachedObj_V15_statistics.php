<?php
if (!isset($filter_clause) ) $filter_clause = "";
if (!isset($sort_clause) )   $sort_clause = "";
$query = "set rowcount ".$rowcount."
select 
  CacheName, 
  DBName, 
  OwnerN=isnull(OwnerName,'dbo'), 
  ObjectName, 
  IndexID, 
  ObjectType, 
  PartitionName, 
  minCachedKB=min(1.*CachedKB),
  avgCachedKB=avg(1.*CachedKB), 
  maxCachedKB=max(1.*CachedKB),  
  avgProcessesAccessing=avg(1.*ProcessesAccessing), 
  avgTotalSizeKB=avg(1.*TotalSizeKB), 
  CacheID, DBID, ObjectID, OwnerUserID, PartitionID

  from ".$ServerName."_CachedObj
  where Timestamp >='".$StartTimestamp."'        
  and Timestamp <'".$EndTimestamp."'        
  ".$filter_clause."
  group by CacheID, DBID, ObjectID, IndexID, OwnerUserID, PartitionID, CacheName, DBName, OwnerName, ObjectName, ObjectType, PartitionName
  ".$sort_clause."
  set rowcount 0";
?>

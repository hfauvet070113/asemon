<?php
  if ($ArchSrvType=="Adaptive Server Enterprise") {  
    // It is on ASE, isolate declare cursor step
    $result=asemon_query(
    "declare c cursor for 
     select blockedSpid,Timestamp,time_blocked
     from ".$ServerName."_BlockedP 
     where Timestamp >='".$StartTimestamp."'
     and   Timestamp <='".$EndTimestamp."'
    order by blockedSpid,Timestamp",
    $pid);
  
    if ($result==false){
      $error = "Error declare cursor. ".$error;
      return;
    }
    $result = asemon_query("if object_id('#blk_max') is not null drop table #blk_max",$pid);
    $result=asemon_query(
      "declare @savts datetime, @ts datetime, @savtb int, @tb int, @savspid int, @spid int
      create table #blk_max (blockedSpid int, max_TS datetime, max_time_blocked int)
      set nocount on
      open c
      fetch c into @savspid,@savts,@savtb
      while @@sqlstatus=0
      begin
         fetch c into @spid,@ts,@tb
         if @tb <@savtb or @spid != @savspid
         begin
           -- max block found for a spid
           insert into #blk_max values (@savspid,@savts,@savtb)
         end
         select @savtb=@tb, @savts=@ts, @savspid=@spid
      end
      close c
      deallocate cursor c",
    $pid);
    if ($result==false){
      $error = "Error exec cursor. ".$error;
      return;
    }
  }
  else {
    // It is on IQ, don't isolate declare cursor step
    $result = asemon_query("if object_id('#blk_max') is not null drop table #blk_max",$pid);
    $query = "create table #blk_max (blockedSpid int, max_TS datetime)";
    $result = asemon_query($query,$pid);
    $var1 = "set nocount on;
      insert into #blk_max
      select blockedSpid,max(Timestamp)
      from ".$ServerName."_BlockedP
      where Timestamp >='".$StartTimestamp."'
      and   Timestamp <='".$EndTimestamp."'
      group by blockedSpid";
    $result=asemon_query($var1,$pid);
    if ($result==false){
      $error = "Error insert into #blk_max. ".$error;
      return;
    }
  }
  
  $query="set rowcount ".$rowcount. " 
   select A.*
   from ".$ServerName."_BlockedP A , #blk_max B
   where A.Timestamp = B.max_TS
   and A.blockedSpid = B.blockedSpid
   ".$filter_clause."
   order by A.Timestamp, A.time_blocked desc
   set rowcount 0";
?>












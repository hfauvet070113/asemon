<?php
$query = "
select Ts=convert(varchar,Timestamp,109), 
  logcontPCT= convert(float,AppendLogWaits )*100/AppendLogRequests
from ".$ServerName."_OpenDbs
where DBName='".$DBName."'
and Timestamp >= '".$StartTimestamp."' and Timestamp <= '".$EndTimestamp."'
order by Timestamp";
?>
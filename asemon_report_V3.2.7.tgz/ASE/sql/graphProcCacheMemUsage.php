<?php
$query = "select Ts=convert(varchar,Timestamp,109), 
  ProcMemKB=sum(case when ObjectType !='user memory' and Statement!='Y' then MemUsageKB else 0 end),
  StmtMemKB=sum(case when ObjectType !='user memory' and Statement='Y' then MemUsageKB else 0 end),
  UserMemKB=sum(case when ObjectType ='user memory' then MemUsageKB else 0 end)
from ".$ServerName."_ProcMem
where Timestamp >='".$StartTimestamp."'
  and Timestamp <='".$EndTimestamp."'
group by Timestamp
order by Timestamp";
?>
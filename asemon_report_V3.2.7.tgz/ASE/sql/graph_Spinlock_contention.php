<?php
if ($Field_id=='') {
   $field_id_clause='';
   $field_id_join_clause='';
}
else {
  if ($field_id_normalized_Exists ==1) {
    $field_id_clause=" and p.field_id_normalized=".$field_id_normalized;
    $field_id_join_clause="and w.field_id_normalized=p.field_id_normalized";
  }
  else {
    $field_id_clause=" and p.field_id=".$Field_id;
    $field_id_join_clause="and w.field_id=p.field_id";
  }
}
$query = "
select 
 Ts=convert(varchar,Timestamp,109), 
 contention=str(avg(waits*100./grabs ),15,4)
from
  (
    select 
    p.Timestamp, grabs=sum(1.*p.d_value),waits=sum(1.*w.d_value)
    from ".$ServerName."_SysMon w, ".$ServerName."_SysMon p
    where w.Timestamp >='".$StartTimestamp."' and w.Timestamp <'".$EndTimestamp."'
    and p.Timestamp >='".$StartTimestamp."' and p.Timestamp <'".$EndTimestamp."'        
    and w.grpname like 'W'
    and p.grpname like 'P'
    ".$field_id_join_clause."
    and w.Timestamp=p.Timestamp
    and p.fldname like '".$fldname."'
    and w.fldname like '".$fldname."'
    and p.d_value !=0".
    $field_id_clause
    ." group by p.Timestamp
  ) spinact
group by Timestamp
order by Timestamp";
?>
<?php

if ($Field_id=='') 
  $field_id_clause='';
else {
  if ($field_id_normalized_Exists ==1)
    $Field_id_clause=" and field_id_normalized=".$field_id_normalized;
  else
    $field_id_clause=" and field_id=".$Field_id;
}

$query = "
select 
  Ts=convert(varchar,Timestamp,109), 
  waits=str(sum(waits),15,4)
from
(
  select 
  Timestamp, waits=sum(1.*d_value)
  from ".$ServerName."_SysMon
  where Timestamp >='".$StartTimestamp."' and Timestamp <'".$EndTimestamp."'
  and grpname like 'W'
  and fldname like '".$fldname."'".
  $field_id_clause
  ." group by Timestamp
) spinact
group by Timestamp
order by Timestamp";
?>
<?php
$query = "
select 
   Ts=convert(varchar,Timestamp,109)
   , activecnx=count(*) 
from ".$ServerName."_CnxActiv
where Timestamp >='".$StartTimestamp."'
and Timestamp <='".$EndTimestamp."'
group by Timestamp
order by Timestamp";
?>
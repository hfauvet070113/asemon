<?php

if ($group=='program') {
	$group_name="program_name";
}

if ($group=='login') {
	$group_name="UserName";
}

if ($indicator== 'logical') {
 $select_clause=$group_name.",value=isnull(sum(1.*B.LogicalReads),0)";
 $title = "Logical_reads by '".$group_name."'";
}
if ($indicator== 'physreads') {
 $select_clause=$group_name.",value=isnull(sum(1.*B.PhysicalReads),0)";
 $title = "Physical_reads by '".$group_name."'";
}
if ($indicator== 'physical') {
 $select_clause=$group_name.",value=isnull(sum(1.*B.PhysicalReads)+sum(1.*PhysicalWrites),0)";
 $title = "Physical_IO by '".$group_name."'";
}
if ($indicator== 'cpu') {
 $select_clause=$group_name.",value=isnull(sum(1.* case when B.CPUTime <1500000000  then B.CPUTime else 0 end),0)";
 $title = "CPU by '".$group_name."'";
}

if (!isset($filter_clause)) $filter_clause = '';

    $result = asemon_query("if object_id('#allgroups') is not null drop table #allgroups",$pid);
    $result = asemon_query("if object_id('#top10groups') is not null drop table #top10groups",$pid);
    $query = "select " .$select_clause." into #allgroups
                    from ".$ServerName."_CnxActiv B, ".$ServerName."_Cnx A
                    where B.Timestamp between '".$StartTimestamp."' and '".$EndTimestamp."'
                      and B.Loggedindatetime = A.Loggedindatetime 
                      and B.Kpid = A.Kpid
                      and B.Spid = A.Spid
                      ".$filter_clause."
                    group by ".$group_name."
              select top 10 ".$group_name.",value
              into #top10groups
              from #allgroups
              order by 2 desc
              select ".$group_name.", value
              from #top10groups
              union all
              /* special construct for IQ. Seems IQ cannot have sum in HAVING */
              select ALLOTHERS,value
              from (
                  select ALLOTHERS='all_others',value=isnull(sum(value),0)
                  from #allgroups
                  where ".$group_name." not in (select ".$group_name." from #top10groups)   
                  ) ALLOTHERS_tab
              where value >0
              ";


?>
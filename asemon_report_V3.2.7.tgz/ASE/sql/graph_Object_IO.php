<?php
$query = "
select Ts=convert(varchar,ListTimestamp.Timestamp,109), 
  [PhysicalReads/s]=isnull(PhysicalReads,0)*1000./isnull(Interval,1),
  [APFReads/s]=isnull(APFReads,0)*1000./isnull(Interval,1),
  [PhysicalWrites/s]=isnull(PhysicalWrites,0)*1000./isnull(Interval,1)
from (select distinct Timestamp from ".$ServerName."_OpObjAct 
      where Timestamp >='".$StartTimestamp."'
      and Timestamp <='".$EndTimestamp."'
      ) ListTimestamp  
      left outer join ".$ServerName."_OpObjAct B on ListTimestamp.Timestamp = B.Timestamp
        and B.dbname='".$ObjectDbName."'
        and B.objname='".$ObjectName."'
        and B.IndID=".$IndexID
        .$ObjectID_clause
." order by ListTimestamp.Timestamp";
?>
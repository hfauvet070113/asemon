<?php
$LSTClause = "";
if ( isset($InstanceIDexists) && ($InstanceIDexists == 1)) {
  // Check if ASE is a node of  a Cluster Edition
  $query = "select top 1 InstanceID
    from ".$ServerName."_Engines
    where Timestamp >='".$StartTimestamp."'
      and Timestamp <='".$EndTimestamp."'";
  $result=asemon_query($query, $pid);
  $row=asemon_fetch_assoc($result);
  if ($row["InstanceID"] > 0)
    $LSTClause = ", TotIO_LST_per_s= sum (convert(numeric(16,0),case when lower(di.LogicalName) like 'lst[_]%' then di.Reads+di.APFReads+di.Writes else 0 end))* 1000 / avg(di.Interval)";
}

$query = "
select Ts=convert(varchar,di.Timestamp,109),
TotIO_data_per_s= sum (convert(numeric(16,0),case when upper(di.LogicalName) not like '%LOG%' and upper(di.LogicalName) not like '%[_]L[0-9][0-9]' and upper(di.LogicalName) not like '%RAMFS%' and upper(di.LogicalName) not like '%TEMPDB%' and lower(di.LogicalName) not like 'vdisk%' then 1.*(di.Reads+di.APFReads+di.Writes) else 0 end))* 1000 / avg(1.*di.Interval),
TotIO_log_per_s= sum (convert(numeric(16,0),case when (lower(di.LogicalName) like '%log%' or upper(di.LogicalName) like '%[_]L[0-9][0-9]')and lower(di.LogicalName) not like '%tempdb%' and lower(di.LogicalName) not like '%ramfs%' and lower(di.LogicalName) not like 'vdisk%' then 1.*(di.Reads+di.APFReads+di.Writes) else 0 end))* 1000 / avg(1.*di.Interval),
TotIO_tempdb_per_s= sum (convert(numeric(16,0),case when upper(di.LogicalName) like '%RAMFS%' or upper(di.LogicalName) like '%TEMPDB%' or lower(di.LogicalName) like 'vdisk%' then 1.*(di.Reads+di.APFReads+di.Writes) else 0 end))* 1000 / avg(1.*di.Interval)
".$LSTClause."
from ".$ServerName."_DevIO di
where di.Timestamp >='".$StartTimestamp."'
and di.Timestamp <='".$EndTimestamp."'
and di.LogicalName not like 'SYSDEV$[_][_]%' /* ignore crazy values for devices of archive db's */
group by Timestamp
order by Timestamp
";
?>
<?php
if (!isset($filter_clause) ) $filter_clause = "";

$query = "set rowcount ".$rowcount."
  select ResolveTime_str=convert (varchar, ResolveTime, 111)+' '+convert (varchar,ResolveTime, 108)+'.'+convert(varchar, datepart(ms,ResolveTime))
  ,*
  from ".$ServerName."_DeadLock
  where ResolveTime >='".$StartTimestamp."'
  and ResolveTime <'".$EndTimestamp."'
  ".$filter_clause."
  order by DeadlockID
  set rowcount 0";
?>

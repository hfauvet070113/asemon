<?php

  if (!isset($filter_clause) ) $filter_clause = "";
  if (!isset($sort_clause) )   $sort_clause = "";

$query = "set rowcount ".$rowcount."
select
  DBID,
  ObjectID,
  PartitionID,
  CompRowInserted=sum(delta_CompRowInserted),
  CompRowUpdated=sum(delta_CompRowUpdated),
  CompRowForward=sum(delta_CompRowForward),
  CompRowScan=sum(delta_CompRowScan),
  RowDecompressed=sum(delta_RowDecompressed),
  RowPageDecompressed=sum(delta_RowPageDecompressed),
  ColDecompressed=sum(delta_ColDecompressed),
  RowCompNoneed=sum(delta_RowCompNoneed),
  PageCompNoneed=sum(delta_PageCompNoneed),
  PagesCompressed=sum(delta_PagesCompressed),
  AvgBytesSavedPageLevel=avg(AvgBytesSavedPageLevel),
  TableName
from ".$ServerName."_Compress
where Timestamp >='".$StartTimestamp."'
and Timestamp <'".$EndTimestamp."'
".$filter_clause."
group by DBID, ObjectID, PartitionID, TableName
".$sort_clause."
set rowcount 0";
?>

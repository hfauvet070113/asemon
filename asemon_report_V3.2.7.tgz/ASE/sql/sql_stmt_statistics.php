<?php

  if (!isset($filter_clause) ) $filter_clause = "";
  if (!isset($sort_clause) )   $sort_clause = "";

  if (isset($ObjectName) && $ObjectName <> '' ) {
    $fromStmtObjClause = " left outer join ".$ServerName."_StmtObj obj on stat.StmtID=obj.StmtID";
    $whereStmtObjClause = " and ObjectName like '".$ObjectName."'";
    if (isset($IndexID) && $IndexID<>"")  $whereStmtObjClause = $whereStmtObjClause." and IndexID=".$IndexID;
    if (isset($ObjectDbName) && $ObjectDbName<>"")  $whereStmtObjClause = $whereStmtObjClause." and DBName='".$ObjectDbName."'";
    if (isset($OwnerUserID) && $OwnerUserID <> 0)  $whereStmtObjClause = $whereStmtObjClause." and OwnerUserID=".$OwnerUserID;
  }
  else {
    $fromStmtObjClause="";
    $whereStmtObjClause="";
  }
  
  if ($support157 ==1) {
    $selClientInfo = ", ClientName, ClientHostName, ClientApplName";
  }
  else {
    $selClientInfo = "";
  }

  if (!isset($SQLHashKeyExists) ) $SQLHashKeyExists = 0;
  if ($SQLHashKeyExists == 1) {
    $selClientInfo = $selClientInfo. ", SQLHashKey";
  }

  if (isset($SQLHashKey) ) 
    $whereSQLHashKeyClause = " and SQLHashKey=".$SQLHashKey;
  else
    $whereSQLHashKeyClause = "";

  $selPlanFromPLANHashKeyStart = "";
  $selPlanFromPLANHashKeyEnd   = "";
  if ($StmtPlnHKExists == 1) {
    $selPlanFromPLANHashKeyStart = "case when PLANHashKey is not null then 'OK' else ";
    $selPlanFromPLANHashKeyEnd = " end";
  }

  if ($colV16SP03Exists == 1)
    $colV16SP03_clause = "
    , SnapCodegenTime         = stat.SnapCodegenTime      
    , SnapJITTime             = stat.SnapJITTime          
    , SnapExecutionTime       = stat.SnapExecutionTime    
    , SnapExecutionCount      = stat.SnapExecutionCount   
    , QueryOptimizationTime   = stat.QueryOptimizationTime
    ";
  else
    $colV16SP03_clause = "";


  if ($supportFieldsAnja == 1)
    $colAnja_clause = "
    , StatementNumber         = stat.StatementNumber
    , ProcNestLevel           = stat.ProcNestLevel
    ";
  else
    $colAnja_clause = "";

  $query = "set rowcount ".$rowcount."
  select distinct
        stat_StmtID=stat.StmtID,
        Debut=convert (varchar, StartTime, 111)+' '+convert (varchar, StartTime, 108)+'.'+convert(varchar, datepart(ms,StartTime)),
        Elapsed_s=datediff(ss,StartTime,EndTime),
        stat.SPID,
        stat.DBID,
        stat.Application,
        stat.ClientHost,
        stat.ProcName,
        stat.LineNumber,
        stat.CpuTime,
        stat.WaitTime,
        stat.MemUsageKB,
        PhysicalReads=1.*stat.PhysicalReads,
        LogicalReads=1.*stat.LogicalReads,
        PagesModified=1.*stat.PagesModified,
        stat.PacketsSent,
        stat.PacketsReceived,
        stat.BatchID,
        stat.ContextID,
        stat.PlanID,
        planOK=".$selPlanFromPLANHashKeyStart." case when pln.StmtID is not null then 'OK' else '' end ".$selPlanFromPLANHashKeyEnd."
        ".$selClientInfo."  
        ".$colV16SP03_clause."
        ".$colAnja_clause."
  from (".$ServerName."_StmtStat stat  left outer join ".$ServerName."_StmtPlan pln on stat.StmtID=pln.StmtID and Sequence=1)
  ".$fromStmtObjClause."
  where StartTime >='".$StartTimestamp."'
  and StartTime <'".$EndTimestamp."' 
  ".$whereStmtObjClause."
  ".$whereSQLHashKeyClause."
  ".$filter_clause."
  ";
  
  
  
  if (isset($ExclApp) && $ExclApp <> '')
  {
    $query = $query . " and Application not like '".$ExclApp."' "; 
  }
  if (isset($StmtID) && $StmtID<> '')
  {
    $query = $query . " and stat.StmtID = ".$StmtID; 
  }
  if (isset($Spid) && $Spid<> '')
  {
    $query = $query . " and stat.SPID = ".$Spid; 
  }
  if (isset($Kpid) && $Kpid<> '')
  {
    $query = $query . " and stat.KPID = ".$Kpid; 
  }
  if (isset($LineNumber) && $LineNumber<> '')
  {
    $query = $query . " and LineNumber = ".$LineNumber; 
  }
  if (isset($ProcName) && $ProcName<> '')
  {
    $query = $query . " and ProcName = '".$ProcName."'"; 
  }
  if (isset($DBID) && $DBID<> '')
  {
    $query = $query . " and DBID = ".$DBID; 
  }
  if (isset($ClientHost) && $ClientHost<> '')
  {
    $query = $query . " and ClientHost like '".$ClientHost."' "; 
  }
  if (isset($ExclHost) && $ExclHost<> '')
  {
    $query = $query . " and ClientHost not like '".$ExclHost."' "; 
  }

  $query = $query.$sort_clause." 
  set rowcount 0";
?>

<?php
$query = "
select Ts=convert(varchar,ListTimestamp.Timestamp,109), 
  [DATA_LReads/s]  = isnull(sum(case when IndID <=1 then LogicalReads else 0 end),0)*1000./isnull(avg(Interval),1),
  [INDEX_LReads/s] = isnull(sum(case when IndID>1 then LogicalReads else 0 end),0)*1000./isnull(avg(Interval),1)
from (select distinct Timestamp from ".$ServerName."_OpObjAct 
      where Timestamp >='".$StartTimestamp."'
      and Timestamp <='".$EndTimestamp."'
      ) ListTimestamp  
      left outer join ".$ServerName."_OpObjAct B on ListTimestamp.Timestamp = B.Timestamp
        and B.dbname='".$ObjectDbName."'
        and B.objname='".$ObjectName."'"
        .$ObjectID_clause
." group by ListTimestamp.Timestamp
order by ListTimestamp.Timestamp";
?>
<?php

    if (!isset($filter_clause) ) $filter_clause = "";
    if (!isset($sort_clause) )   $sort_clause = "";
    
    $query="";
    if ($ArchSrvType=="Adaptive Server Enterprise") {
        $query = "set forceplan on ";
    }
    
    if ($dbid_tmp_pages_exists == 1 ) {
        $dbid_tmp_pages_clause=", Tempdb_id=max(tempdbid), Maxtmp_pages=max(A.tmp_pages)";
    }
    else {
        $dbid_tmp_pages_clause="";
    }
    
    
    if ($colV157SP130Exists == 1)
      $colV157SP130_clause = ",
        SumHeapMemoryAllocs        = sum(1.*HeapMemoryAllocs    ),
        MaxHeapMemoryInUseKB       = max(HeapMemoryInUseKB      ),
        MaxHeapMemoryReservedKB    = max(HeapMemoryReservedKB   ),
        MaxHeapMemoryUsedHWM_KB    = max(HeapMemoryUsedHWM_KB   ),
        SumIOSize1Page             = sum(1.*IOSize1Page         ),
        SumIOSize2Pages            = sum(1.*IOSize2Pages        ),
        SumIOSize4Pages            = sum(1.*IOSize4Pages        ),
        SumIOSize8Pages            = sum(1.*IOSize8Pages        ),
        MaxULCMaxUsage             = max(ULCMaxUsage            ),
        SumWorkTables              = sum(1.*WorkTables          )";
    else
      $colV157SP130_clause = "";

    if ($colV16SP03Exists == 1)
      $colV16SP03_clause = ", QueryOptimizationTm        = sum(1.*QueryOptimizationTime    )";
    else
      $colV16SP03_clause = "";

    if ($colV16SP04Exists == 1)
      $colV16SP04_clause = "
      , prepared_stmt_count        = sum(1.*prepared_stmt_count    )
      , MaxPrepared_stmt_memusageKb     = max(prepared_stmt_memusage)*2
      ";
    else
      $colV16SP04_clause = "";

    $query = $query . "
    set rowcount ".$rowcount."
    select 
      Loggedindt=convert (varchar, A.Loggedindatetime, 111)+' '+convert (varchar, A.Loggedindatetime, 108)+'.'+convert(varchar, datepart(ms,A.Loggedindatetime)),
      A_Spid=A.Spid,
      UserName,
      program_name, 
      CPUTm=sum(convert(numeric(16,0),case when CPUTime <0 then 0 when CPUTime > 1500000000  then 0 else CPUTime end)),  -- filter abnormal values, avoid overflow
      LReads=sum(convert(numeric(16,0),case when LogicalReads <0 then 0 when LogicalReads > 200000000000 then 0 else LogicalReads end)), -- filter abnormal values, avoid overflow
      PReads=sum(convert(numeric(16,0),case when PhysicalReads <0 then 0 when PhysicalReads > 2000000000 then 0 else PhysicalReads end)),  -- filter abnormal values, avoid overflow
      PgRead=sum(convert(numeric(16,0),case when PagesRead<0 then 0 when PagesRead > 2000000000 then 0 else PagesRead end)), -- filter abnormal values, avoid overflow 
      PWrites=sum(convert(numeric(16,0),PhysicalWrites)), 
      PgWritten=sum(convert(numeric(16,0),PagesWritten)), 
      ScPgs=sum(convert(numeric(16,0),ScanPgs)), 
      IPgs=sum(convert(numeric(16,0),IdxPgs)), 
      TTbl=sum(convert(numeric(16,0),TmpTbl)),
      UBytWrite=sum(convert(numeric(20,0),UlcBytWrite)), 
      UFlush=sum(convert(numeric(16,0),UlcFlush)), 
      UFlushFull=sum(convert(numeric(16,0),ULCFlushFull)),
      avgUlcSize= case when sum(convert(numeric(16,0),UlcFlush))=0 then 0 else convert(float,sum(convert(numeric(30,0),UlcBytWrite))) / sum(convert(numeric(16,0),UlcFlush)) end,
      Trans=sum(Transactions),
      Cmits=sum(Commits),
      Rlbacks=sum(Rollbacks), 
      PktReceived=sum(PacketsReceived),
      PktSent=sum(PacketsSent),
      BReceived=sum(convert(numeric(16,0),BytesReceived)),
      BSent=sum(convert(numeric(16,0),BytesSent)),
      avgPktRcv=case when sum(PacketsReceived)=0 then 0 else convert(float,sum(convert(numeric(16,0),BytesReceived)))/sum(PacketsReceived) end,
      avgPktSent=case when sum(PacketsSent)=0 then 0 else convert(float,sum(convert(numeric(16,0),BytesSent)))/sum(PacketsSent) end,
      MaxMemusageKB=max(memusage)*2,
      MaxLocksHeld=max(LocksHeld),
      ipaddr,
      hostname,
      hostprocess,
      execlass,
      clientname,
      clienthostname,
      clientapplname".
      $dbid_tmp_pages_clause.
      $colV157SP130_clause.
      $colV16SP03_clause.
      $colV16SP04_clause."
    from ".$ServerName."_CnxActiv A, ".$ServerName."_Cnx C
    where A.Timestamp >='".$StartTimestamp."'        
    and A.Timestamp <'".$EndTimestamp."'        
    and A.Loggedindatetime = C.Loggedindatetime
    and A.Spid=C.Spid
    and A.Kpid=C.Kpid
    ".$filter_clause."
    group by A.Loggedindatetime, A.Spid, UserName, program_name, ipaddr, hostname, hostprocess, clientname, clienthostname, clientapplname, execlass
    ".$sort_clause."
    set rowcount 0";
    
    if ($ArchSrvType=="Adaptive Server Enterprise") {
        $query = $query . "
        set forceplan off ";
    }
?>

<?php
  // Find top 5 objects during this interval
  $query="select top 5
          DBID,ObjectID,DBName, OwnerN=isnull(OwnerName,'dbo'), ObjectN=case when ObjectID=99 then 'ALLOCPAGE' else ObjectName end, IndexID,maxCachedKB=max(CachedKB)
          from ".$ServerName."_CachedObj
          where Timestamp >='".$StartTimestamp."'
          and Timestamp <'".$EndTimestamp."'
          and CacheName         = '".$CacheName."'
          group by DBID,ObjectID,DBName, isnull(OwnerName,'dbo'), ObjectName, IndexID
          order by max(CachedKB) desc";
  
  $result=asemon_query($query, $pid);
  while (($row=asemon_fetch_assoc($result)))
  {
       $DBID[]      = $row["DBID"];
       $ObjectID[]  = $row["ObjectID"];
       $DBName[]    = $row["DBName"];
       $OwnerName[] = $row["OwnerN"];
       $ObjectName[]= $row["ObjectN"];
       $IndexID[]   = $row["IndexID"];
  }
  $cnt = count($DBID);
  //if ($cnt==1) exit("cnt=2");

  if ($cnt<1) {
    $sel_clause = "
        ";
    $join_clause = "
      ";
  }
  else
  if ($cnt<2) {
    $sel_clause = "
      [".$DBName[0].".".$OwnerName[0].".".$ObjectName[0]."(".$IndexID[0].")]=isnull(B.CachedKB/1024,0)
        ";
    $join_clause = "
        left outer join ".$ServerName."_CachedObj B on ListTimestamp.Timestamp = B.Timestamp and B.DBID=".$DBID[0]." and B.ObjectID=".$ObjectID[0]." and B.IndexID=".$IndexID[0]."
        ";
  }
  else
  if ($cnt<3) {
    $sel_clause = "
      [".$DBName[0].".".$OwnerName[0].".".$ObjectName[0]."(".$IndexID[0].")]=isnull(B.CachedKB/1024,0),
      [".$DBName[1].".".$OwnerName[1].".".$ObjectName[1]."(".$IndexID[1].")]=isnull(C.CachedKB/1024,0)
        ";
    $join_clause = "
        left outer join ".$ServerName."_CachedObj B on ListTimestamp.Timestamp = B.Timestamp and B.DBID=".$DBID[0]." and B.ObjectID=".$ObjectID[0]." and B.IndexID=".$IndexID[0]."
        left outer join ".$ServerName."_CachedObj C on ListTimestamp.Timestamp = C.Timestamp and C.DBID=".$DBID[1]." and C.ObjectID=".$ObjectID[1]." and C.IndexID=".$IndexID[1]."
        ";
  }
  else
  if ($cnt<4) {
    $sel_clause = "
      [".$DBName[0].".".$OwnerName[0].".".$ObjectName[0]."(".$IndexID[0].")]=isnull(B.CachedKB/1024,0),
      [".$DBName[1].".".$OwnerName[1].".".$ObjectName[1]."(".$IndexID[1].")]=isnull(C.CachedKB/1024,0),
      [".$DBName[2].".".$OwnerName[2].".".$ObjectName[2]."(".$IndexID[2].")]=isnull(D.CachedKB/1024,0)
        ";
    $join_clause = "
        left outer join ".$ServerName."_CachedObj B on ListTimestamp.Timestamp = B.Timestamp and B.DBID=".$DBID[0]." and B.ObjectID=".$ObjectID[0]." and B.IndexID=".$IndexID[0]."
        left outer join ".$ServerName."_CachedObj C on ListTimestamp.Timestamp = C.Timestamp and C.DBID=".$DBID[1]." and C.ObjectID=".$ObjectID[1]." and C.IndexID=".$IndexID[1]."
        left outer join ".$ServerName."_CachedObj D on ListTimestamp.Timestamp = D.Timestamp and D.DBID=".$DBID[2]." and D.ObjectID=".$ObjectID[2]." and D.IndexID=".$IndexID[2]."
        ";
  }
  else
  if ($cnt<5) {
    $sel_clause = "
      [".$DBName[0].".".$OwnerName[0].".".$ObjectName[0]."(".$IndexID[0].")]=isnull(B.CachedKB/1024,0),
      [".$DBName[1].".".$OwnerName[1].".".$ObjectName[1]."(".$IndexID[1].")]=isnull(C.CachedKB/1024,0),
      [".$DBName[2].".".$OwnerName[2].".".$ObjectName[2]."(".$IndexID[2].")]=isnull(D.CachedKB/1024,0),
      [".$DBName[3].".".$OwnerName[3].".".$ObjectName[3]."(".$IndexID[3].")]=isnull(E.CachedKB/1024,0)
        ";
    $join_clause = "
        left outer join ".$ServerName."_CachedObj B on ListTimestamp.Timestamp = B.Timestamp and B.DBID=".$DBID[0]." and B.ObjectID=".$ObjectID[0]." and B.IndexID=".$IndexID[0]."
        left outer join ".$ServerName."_CachedObj C on ListTimestamp.Timestamp = C.Timestamp and C.DBID=".$DBID[1]." and C.ObjectID=".$ObjectID[1]." and C.IndexID=".$IndexID[1]."
        left outer join ".$ServerName."_CachedObj D on ListTimestamp.Timestamp = D.Timestamp and D.DBID=".$DBID[2]." and D.ObjectID=".$ObjectID[2]." and D.IndexID=".$IndexID[2]."
        left outer join ".$ServerName."_CachedObj E on ListTimestamp.Timestamp = E.Timestamp and E.DBID=".$DBID[3]." and E.ObjectID=".$ObjectID[3]." and E.IndexID=".$IndexID[3]."
        ";
  }
  else {
  $sel_clause = "
      [".$DBName[0].".".$OwnerName[0].".".$ObjectName[0]."(".$IndexID[0].")]=isnull(B.CachedKB/1024,0),
      [".$DBName[1].".".$OwnerName[1].".".$ObjectName[1]."(".$IndexID[1].")]=isnull(C.CachedKB/1024,0),
      [".$DBName[2].".".$OwnerName[2].".".$ObjectName[2]."(".$IndexID[2].")]=isnull(D.CachedKB/1024,0),
      [".$DBName[3].".".$OwnerName[3].".".$ObjectName[3]."(".$IndexID[3].")]=isnull(E.CachedKB/1024,0),
      [".$DBName[4].".".$OwnerName[4].".".$ObjectName[4]."(".$IndexID[4].")]=isnull(F.CachedKB/1024,0)
      ";
  $join_clause = "
      left outer join ".$ServerName."_CachedObj B on ListTimestamp.Timestamp = B.Timestamp and B.DBID=".$DBID[0]." and B.ObjectID=".$ObjectID[0]." and B.IndexID=".$IndexID[0]."
      left outer join ".$ServerName."_CachedObj C on ListTimestamp.Timestamp = C.Timestamp and C.DBID=".$DBID[1]." and C.ObjectID=".$ObjectID[1]." and C.IndexID=".$IndexID[1]."
      left outer join ".$ServerName."_CachedObj D on ListTimestamp.Timestamp = D.Timestamp and D.DBID=".$DBID[2]." and D.ObjectID=".$ObjectID[2]." and D.IndexID=".$IndexID[2]."
      left outer join ".$ServerName."_CachedObj E on ListTimestamp.Timestamp = E.Timestamp and E.DBID=".$DBID[3]." and E.ObjectID=".$ObjectID[3]." and E.IndexID=".$IndexID[3]."
      left outer join ".$ServerName."_CachedObj F on ListTimestamp.Timestamp = F.Timestamp and F.DBID=".$DBID[4]." and F.ObjectID=".$ObjectID[4]." and F.IndexID=".$IndexID[4]."
      ";
  }

  // Find CachedMB for each object
  $query =
      "select Ts=convert(varchar,ListTimestamp.Timestamp,109), 
      ".$sel_clause."
      from (select distinct Timestamp from ".$ServerName."_CachedObj 
            where Timestamp >='".$StartTimestamp."'
            and Timestamp <='".$EndTimestamp."'
            ) ListTimestamp
            ".$join_clause."
      order by ListTimestamp.Timestamp";


?>
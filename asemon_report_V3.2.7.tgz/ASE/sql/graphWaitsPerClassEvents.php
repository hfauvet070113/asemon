<?php
if ( $ArchSrvType != "Sybase IQ")
  $query = "
  select ClassName='CPU', [Time]=".$CPUTime."
  UNION ALL
  select top 9 ClassName=C.Description, [Time]=sum(1.*WaitTime)
  from ".$ServerName."_CnxWaits W,".$ServerName."_WEvInf E, ".$ServerName."_WClassInf C
  where W.WaitEventID = E.WaitEventID
    and E.WaitClassID = C.WaitClassID
    and Kpid=".$Kpid."
    and W.Timestamp >= '".$Loggedindatetime."'
    and W.Timestamp < (select isnull(min(Loggedindatetime), '1/1/3000')
                       from ".$ServerName."_Cnx cnx
                       where cnx.Kpid = W.Kpid
                         and cnx.Spid = W.Spid
                         and cnx.Loggedindatetime > '".$Loggedindatetime."'
                       )
    and W.Timestamp >='".$StartTimestamp."'
    and W.Timestamp <'".$EndTimestamp."' 
  group by C.Description
  order by 2 desc";
else
  $query = "
  select top 10 *
  from (
    select ClassName='CPU', [Time]=".$CPUTime."
    UNION ALL
    select ClassName=C.Description, [Time]=sum(1.*WaitTime)
    from ".$ServerName."_CnxWaits W,".$ServerName."_WEvInf E, ".$ServerName."_WClassInf C
    where W.WaitEventID = E.WaitEventID
      and E.WaitClassID = C.WaitClassID
      and Kpid=".$Kpid."
      and W.Timestamp >= '".$Loggedindatetime."'
      and W.Timestamp < (select isnull(min(Loggedindatetime), '1/1/3000')
                         from ".$ServerName."_Cnx cnx
                         where cnx.Kpid = W.Kpid
                           and cnx.Spid = W.Spid
                           and cnx.Loggedindatetime > '".$Loggedindatetime."'
                         )
      and W.Timestamp >='".$StartTimestamp."'
      and W.Timestamp <'".$EndTimestamp."' 
    group by C.Description
  ) A
  order by 2 desc";
?>
<?php
if (!isset($filter_clause) ) $filter_clause = "";
if (!isset($sort_clause) )   $sort_clause = "";
if (!isset($show_index_not_used)) $show_index_not_used = 0;
if (!isset($sc_show_table_scans)) $sc_show_table_scans = "";

if ($hasObjectID == 1)
  $ObjectID_clause = ",ObjectID,ownerid";
else
  $ObjectID_clause = "";

if ($hasindname == 1) {
  $indname_clause = ",indname";
}
else {
  $indname_clause = "";
}

if ($support150 == 1)
  $sel150 = ", sumHkgcRequests=sum(1.*HkgcRequests), maxHkgcPending=max(1.*HkgcPending), sumHkgcOverflows=sum(1.*HkgcOverflows)";
else
  $sel150 = "";

if ($support157 == 1)
  $sel157 = ", sumSharedLockWaitTime=sum(1.*SharedLockWaitTime), sumExclusiveLockWaitTime=sum(1.*ExclusiveLockWaitTime), sumUpdateLockWaitTime=sum(1.*UpdateLockWaitTime), maxObjectCacheDate=max(ObjectCacheDate), sumLockWaitTime=sum(1.*SharedLockWaitTime)+sum(1.*ExclusiveLockWaitTime)+sum(1.*UpdateLockWaitTime)";
else
  $sel157 = "";

if ($supportOptSelectCount == 1) 
  $selOptSelectCount = ", OptSelCnt=sum(1.*OptSelectCount)";
else
  $selOptSelectCount = "";
  

if ($show_index_not_used==0)
  $query = "set rowcount ".$rowcount."
  select dbname, objname, IndID".$ObjectID_clause.$indname_clause.", 
  LReads=sum(convert(numeric(20,0),LogicalReads)), 
  PReads=sum(convert(numeric(20,0),PhysicalReads)), 
  AReads=sum(convert(numeric(20,0),APFReads)), 
  PgReads=sum(convert(numeric(20,0),PagesRead)), 
  CacheHitPct= 100 * (sum(1.*LogicalReads)-(sum(1.*PagesRead) )) / sum(1.*LogicalReads) ,
  PWrites=sum(convert(numeric(20,0),PhysicalWrites)), 
  PgWrites=sum(convert(numeric(20,0),PagesWritten)), 
  RowIns=sum(convert(numeric(20,0),RowsInserted)), 
  RowDel=sum(convert(numeric(20,0),RowsDeleted)), 
  RowUpd=sum(convert(numeric(20,0),RowsUpdated)),
  Opers=sum(convert(numeric(20,0),Operations)), 
  LockR=sum(convert(numeric(20,0),LockRequests)), 
  LockW=sum(convert(numeric(20,0),LockWaits)),
  UsedCnt= sum(convert(numeric(20,0),UsedCount)),
  LReads_per_UsedCnt= case when sum(1.*UsedCount)>0 then sum(1.*LogicalReads)/sum(1.*UsedCount) else 0 end
  ".$sel150."
  ".$sel157."
  ".$selOptSelectCount."
  from ".$ServerName."_OpObjAct   
  where Timestamp >='".$StartTimestamp."'
  and Timestamp <'".$EndTimestamp."'
  ".$filter_clause."
  ".$sc_show_table_scans."
  group by dbname, objname, IndID".$ObjectID_clause.$indname_clause."
  ".$sort_clause."
  set rowcount 0";
else
  $query = "set rowcount ".$rowcount."
  select dbname, objname, IndID".$ObjectID_clause.$indname_clause.", 
  LReads=sum(convert(numeric(20,0),LogicalReads)), 
  PReads=sum(convert(numeric(20,0),PhysicalReads)), 
  AReads=sum(convert(numeric(20,0),APFReads)), 
  PgReads=sum(convert(numeric(20,0),PagesRead)), 
  CacheHitPct= 100 * (sum(1.*LogicalReads)-(sum(1.*PhysicalReads))) / sum(1.*LogicalReads) ,
  PWrites=sum(convert(numeric(20,0),PhysicalWrites)), 
  PgWrites=sum(convert(numeric(20,0),PagesWritten)), 
  RowIns=sum(convert(numeric(20,0),RowsInserted)), 
  RowDel=sum(convert(numeric(20,0),RowsDeleted)), 
  RowUpd=sum(convert(numeric(20,0),RowsUpdated)),
  Opers=sum(convert(numeric(20,0),Operations)), 
  LockR=sum(convert(numeric(20,0),LockRequests)), 
  LockW=sum(convert(numeric(20,0),LockWaits)),
  UsedCnt= sum(convert(numeric(20,0),UsedCount)),
  LReads_per_UsedCnt= case when sum(1.*UsedCount)>0 then sum(1.*LogicalReads)/sum(1.*UsedCount) else 0 end
  ".$sel150."
  ".$sel157."
  ".$selOptSelectCount."
  from ".$ServerName."_OpObjAct,
      (select dbn=dbname, objn=objname, iid=IndID, ucount=sum(UsedCount)
       from ".$ServerName."_OpObjAct
       where Timestamp >='".$StartTimestamp."'        
         and Timestamp <'".$EndTimestamp."'
         and IndID between 1 and 254
         ".$filter_clause."
       group by dbname, objname, IndID
       ) B
  where Timestamp >='".$StartTimestamp."'        
  and Timestamp <'".$EndTimestamp."'        
  and IndID between 1 and 254
  and dbname=B.dbn
  and objname=B.objn
  and IndID=B.iid
  and B.ucount = 0
  ".$filter_clause."
  group by dbname, objname, IndID".$ObjectID_clause.$indname_clause."
  ".$sort_clause."
  set rowcount 0";

?>

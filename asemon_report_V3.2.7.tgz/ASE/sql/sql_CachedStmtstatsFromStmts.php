<?php
  // retreive all posted params and affect them to variables
  foreach ($_POST as $key => $value)
    @$$key=$value;

  include ("../../COMMON/connectArchiveServer.php");

  // List of fields of type timestamp which must be converted when returned
  $datafieldsTS = [];
  if (isset($datafieldsTSJSON))
    $datafieldsTS = json_decode($datafieldsTSJSON, true);


  if ($bootcount == "") {
      // Try to find corresponding bootcount according to EndTimestamp
      $result = asemon_query("select bc=max(bootcount) from ".$ServerName."_CachedSTM where CachedDate <= '".$EndTimestamp."'",$pid);
      $row = asemon_fetch_assoc($result);
      if ($row) $bootcount = $row["bc"];
  }

  // Check if bootcount defined; then get info from CachedSTM for this STM and this interval

  $TotalRows = 0;
  if ($bootcount != "") {

      // get statement statistics 
      $query = "
      select bootcount,
      Hashkey,UserID,SUserID,DBID,DBName,CachedDt=convert(varchar,CachedDate,109),
      HasAutoParams,ParallelDegree,QuotedIdentifier,TransactionIsolationLevel,TransactionMode,SAAuthorization,SystemCatalogUpdate,
      UseCount=sum(UseCount_smp),
      StatementSize=max(StatementSize),
      MinPlanSizeKB=min(MinPlanSizeKB),
      MaxPlanSizeKB=max(MaxPlanSizeKB),
      MaxCurrentUsageCount=max(CurrentUsageCount),
      MaxUsageCount=max(MaxUsageCount),
      NumRecompilesSchemaChanges=sum(NumRecompilesSchemaChanges_smp),
      NumRecompilesPlanFlushes=sum(NumRecompilesPlanFlushes_smp),
      MetricsCount=sum(MetricsCount_smp),
      MinPIO=min(1.*MinPIO),
      MaxPIO=max(1.*MaxPIO)
      ".$avgPIO.",
      MinLIO=min(1.*MinLIO),
      MaxLIO=max(1.*MaxLIO)
      ".$avgLIO.",
      MinCpuTime=min(1.*MinCpuTime),
      MaxCpuTime=max(1.*MaxCpuTime)
      ".$avgCpuTime.",
      MinElapsedTime=min(1.*MinElapsedTime),
      MaxElapsedTime=max(1.*MaxElapsedTime)
      ".$avgElapsedTime.",
      LastUsedDt=convert(varchar,max(LastUsedDate),109),
      LastRecompiledDt=convert(varchar,max(LastRecompiledDate),109)
      ".$sel_157_cols."
      from ".$ServerName."_CachedSTM
      where SSQLID=".$SSQLID."
        and bootcount = ".$bootcount."
        and Timestamp >= '".$StartTimestamp."'
        and Timestamp < '".$EndTimestamp."'
      group by bootcount,Hashkey,UserID,SUserID,DBID, DBName,convert(varchar,CachedDate,109),HasAutoParams,ParallelDegree,QuotedIdentifier,TransactionIsolationLevel,TransactionMode,SAAuthorization,SystemCatalogUpdate".$grp_157_cols	;
      
      $result = asemon_query($query,$pid);
      $row = asemon_fetch_assoc($result);
      $myrow = array();
      if ($row!=null) {
        $TotalRows = 1;
        foreach ($row as $key => $value) {
          if (( in_array($key, $datafieldsTS) ) && ( $value != null)) {
            $myrow[$key] = date_format(date_create($value),'Y/m/d H:i:s.u');
          }
          else
            $myrow[$key] = $value;
        }
      }
  }

  if ($error == "")
    $data = array(
      'status' => 'success',
      'TotalRows' => $TotalRows,
      'row' => $myrow,
      'query' => $query 
      );

  else
    $data = array(
      'status' => 'error',
      'message' => $error,
      'query' => $query
      );

  echo json_encode($data);


?>
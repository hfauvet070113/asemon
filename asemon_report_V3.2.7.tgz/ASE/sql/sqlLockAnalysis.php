<?php
  // retreive all posted params and affect them to variables
  foreach ($_POST as $key => $value)
    @$$key=$value;

  include ("../../COMMON/connectArchiveServer.php");	

  if ($ArchSrvType=="Adaptive Server Enterprise") {  
    // It is on ASE, isolate declare cursor step
    $result=asemon_query(
      "declare c cursor for 
         select blockedSpid,Timestamp,time_blocked
         from ".$ServerName."_BlockedP 
         where Timestamp >='".$StartTimestamp."'
         and   Timestamp <='".$EndTimestamp."'
        order by blockedSpid,Timestamp",
       $pid);
    
    if ($result==false){ 
      $error =  "Error Open Cursor : ".$error;
      return;
    }
    else {
      $result = asemon_query("if object_id('#blk_max') is not null drop table #blk_max",$pid);
      $result=asemon_query(
        "declare @savts datetime, @ts datetime, @savtb int, @tb int, @savspid int, @spid int
                        create table #blk_max (blockedSpid int, max_TS datetime, max_time_blocked int)
                        set nocount on
                        open c
                        fetch c into @savspid,@savts,@savtb
                        while @@sqlstatus=0
                        begin
                           fetch c into @spid,@ts,@tb
                           if @tb <@savtb or @spid != @savspid
                           begin
                             -- max block found for a spid
                             insert into #blk_max values (@savspid,@savts,@savtb)
                           end
                           select @savtb=@tb, @savts=@ts, @savspid=@spid
                        end
                        close c
                        deallocate cursor c",
      $pid);

      if ($result==false){ 
        $error = "Error execute cursor : ".$error;
        return;
      }
    }
  }
  else {
    // It is on IQ, don't isolate declare cursor step
    // object_id d'une table tempo est null. La requ�te ci-dessous est inefficace
    $result = asemon_query("if object_id('#blk_max') is not null drop table #blk_max",$pid);
    
    $result = asemon_query($query,$pid);
    $query = 
      "select t1.blockedSpid,t1.Timestamp as max_TS, t1.time_blocked as max_time_blocked
                 into #blk_max
                 from ".$ServerName."_BlockedP t1
                   inner join (select t2.blockedSpid, max(t2.time_blocked) as max_time_blocked
                               from ".$ServerName."_BlockedP t2
                               where t2.Timestamp >='".$StartTimestamp."'
                                 and t2.Timestamp <='".$EndTimestamp."'
                              group by t2.blockedSpid) max_tab
                          on (t1.blockedSpid = max_tab.blockedSpid and t1.time_blocked=max_tab.max_time_blocked)
                   where t1.Timestamp >='".$StartTimestamp."'
                   and   t1.Timestamp <='".$EndTimestamp."'
                 order by t1.blockedSpid, t1.Timestamp";
    $result=asemon_query($query, $pid);
  }



  //  Get total time blocked
  $result=asemon_query(
    "select total_time_blocked=isnull(sum(max_time_blocked),0)
     from #blk_max",
    $pid);
  
  while (($row=asemon_fetch_assoc($result)))
  {
    $total_time_blocked = $row["total_time_blocked"];
  }
  // Nombre de situations de blocage, nb proc bloques, temps moyen , temps max
  $result=asemon_query(
    "select nb_block=count(*),
      avg_blocked_proc=convert(integer,avg( nbblkprocs)), 
      max_blocked_proc=max( nbblkprocs),
      avg_time_blocked_s=convert(integer,avg(max_time_blks)),
      max_time_blocked_s=max(max_time_blks)
     from (
       select nbblkprocs=count(*),
            max_time_blks=max(max_time_blocked)
              from #blk_max
              group by max_TS) statBlks",
     $pid);
  while (($row=asemon_fetch_assoc($result)))
  {
    $nb_block= $row["nb_block"];
    $avg_blocked_proc= $row["avg_blocked_proc"];
    $max_blocked_proc= $row["max_blocked_proc"];
    $avg_time_blocked_s= $row["avg_time_blocked_s"];
    $max_time_blocked_s= $row["max_time_blocked_s"];
  }

  // Nombre et temps de blocage par objet et type de lock
  $query="set rowcount 20 
    select lckBase,lckObjet,lckName, nb_block=count(*), tps_block_s=sum(time_blocked)
    from ".$ServerName."_BlockedP A , #blk_max B
    where A.Timestamp = B.max_TS
    and A.blockedSpid = B.blockedSpid
    group by lckBase,lckObjet,lckName  
    order by tps_block_s desc     
    set rowcount 0";
  
  $result = asemon_query($query,$pid) ;
  $lockdetail = [];
  if ($result == FALSE ){
    $error = "Error retreiving locking per object and lock type : ".$error;
    return;
  }
  else {
    while( $row = asemon_fetch_assoc($result)) {
      $lockdetail[] = [
        "lckBase"     => $row["lckBase"]    ,
        "lckObjet"    => $row["lckObjet"]   ,
        "LockType"    => $row["LockType"]   ,
        "nb_block"    => $row["nb_block"]   ,
        "tps_block_s" => $row["tps_block_s"]
      ];
    }
  }

  // Select top blocking occurences
  $query="set rowcount 20 
    select max_TS, nb_blocked_proc=count(*), max_time_blocked=max(max_time_blocked)
    from #blk_max
    group by max_TS
    order by  max_time_blocked desc
    set rowcount 0";

  $result = asemon_query($query,$pid) ;
  $toplocks = [];
  if ($result == FALSE ){
    $error = "Error retreiving top blocking occurences : ".$error;
    return;
  }
  else {
    while( $row = asemon_fetch_assoc($result)) {
      $toplocks[] = [
        "max_TS"           => $row["max_TS"]         ,
        "nb_blocked_proc"  => $row["nb_blocked_proc"],
        "max_WT"           => $row["max_time_blocked"]
      ];
    }
  }

  // Drop temporary table
  $query = "drop table #blk_max";
  $result = asemon_query($query,$pid);


  if ($error == "")
    $data = array(
      'status' => 'success',
      'total_time_blocked' => $total_time_blocked,
      'nb_block'           => $nb_block          ,
      'avg_blocked_proc'   => $avg_blocked_proc  ,
      'max_blocked_proc'   => $max_blocked_proc  ,
      'avg_time_blocked_s' => $avg_time_blocked_s,
      'max_time_blocked_s' => $max_time_blocked_s,
      'lockdetail'         => $lockdetail,
      'toplocks'           => $toplocks
      );

  else
    $data = array(
      'status' => 'error',
      'message' => $error
      );

  echo json_encode($data);


?>
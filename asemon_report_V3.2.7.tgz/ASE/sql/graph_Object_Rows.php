<?php
$query = "
select Ts=convert(varchar,Timestamp,109), 
  [rowcount]=convert(varchar,F.Rowcnt), 
  [forwarded]=convert(varchar,F.Forwardrowcnt),
  [deleted]=convert(varchar,F.Delrowcnt)
  from ".$ServerName."_Fragment F
  where F.dbname='".$dbname."'
  and F.owner='".$owner."'
  and F.tabname='".$tabname."'
  and F.indid=convert(int,'".$indid."')
  order by Timestamp";
?>
<?php
if ($indid==0)
  $indics = "pagegcnt=convert(varchar,F.pagecnt), 
  leafcnt=convert(varchar,F.leafcnt),
  emptypages=convert(varchar,F.emptypgcnt)";
if ($indid==1)
  $indics = "pagegcnt=convert(varchar,F.pagecnt)";
if ($indid>1)
  $indics = "leafcnt=convert(varchar,F.leafcnt),
  emptypages=convert(varchar,F.emptypgcnt)";
$query = "
select Ts=convert(varchar,Timestamp,109), 
  ".$indics."
  from ".$ServerName."_Fragment F
  where F.dbname='".$dbname."'
  and F.owner='".$owner."'
  and F.tabname='".$tabname."'
  and F.indid=convert(int,'".$indid."')
  order by Timestamp";
?>
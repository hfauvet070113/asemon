<?php
$query = "
select Ts=convert(varchar,ListTimestamp.Timestamp,109), 
  [BytesSent/s]=isnull(convert(float,B.BytesSent)*1000/Interval,0),
  [BytesReceived/s] =isnull(convert(float,B.BytesReceived) *1000/Interval,0)
from (select distinct Timestamp from ".$ServerName."_CnxActiv 
      where Timestamp >='".$StartTimestamp."'
      and Timestamp <='".$EndTimestamp."'
      ) ListTimestamp  
      left outer join ".$ServerName."_CnxActiv B on ListTimestamp.Timestamp = B.Timestamp and Loggedindatetime between dateadd(ss,-1,'".$Loggedindatetime."') and dateadd(ss,+1,'".$Loggedindatetime."') and B.Spid=".$Spid."
order by ListTimestamp.Timestamp
";
?>
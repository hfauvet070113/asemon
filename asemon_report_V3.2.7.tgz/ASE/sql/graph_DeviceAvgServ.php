<?php
$query = "
select Ts=convert(varchar,Timestamp,109), 
 ".$indic."
from ".$ServerName."_DevIO
where LogicalName like '".$Device."'
and Timestamp >= '".$StartTimestamp."' and Timestamp <= '".$EndTimestamp."'
group by Timestamp 
order by Timestamp";
?>
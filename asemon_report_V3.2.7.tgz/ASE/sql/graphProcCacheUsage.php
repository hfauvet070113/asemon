<?php
$query = "
select 
   Ts=convert(varchar,Timestamp,109)
   , Num_Active, Max_configured=Num_Active+Num_Free, Max_used 
from ".$ServerName."_MonConf
where Timestamp >='".$StartTimestamp."'
and Timestamp <='".$EndTimestamp."'
and Name='procedure cache size'
order by Timestamp";
?>
<?php
$indic_calc = $indic;
$indic_name = $indic;
if (isset($rate) && $rate==1) {
  $indic_calc = "1000.*".$indic ."/Interval";
  $indic_name = "[".$indic." /s]";
}
$query = "
select Ts=convert(varchar,ListTimestamp.Timestamp,109), 
  ".$indic_name." = ".$indic_calc."
from (select distinct Timestamp from ".$ServerName."_CnxActiv 
      where Timestamp >='".$StartTimestamp."'
      and Timestamp <='".$EndTimestamp."'
      ) ListTimestamp  
      left outer join ".$ServerName."_CnxActiv B on ListTimestamp.Timestamp = B.Timestamp and Loggedindatetime between dateadd(ss,-1,'".$Loggedindatetime."') and dateadd(ss,+1,'".$Loggedindatetime."') and B.Spid=".$Spid."
order by ListTimestamp.Timestamp";
?>
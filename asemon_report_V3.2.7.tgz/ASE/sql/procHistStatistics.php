<?php
if (!isset($sort_clause) )   $sort_clause = "";
$query = "set rowcount 20
  select 
           DB=ProcedureDatabaseName_ValSmp,
           ProcName=ProcedureName_ValSmp,
           NbExec=sum(convert(numeric(10,0),ProcedureExecutionCount_ValSmp)),
           ElapsedAvg_s=str(avg(ProcedureElapsedTime_AvgSmp),12,2),
           CpuAvg=convert(numeric(6,2),avg(ProcedureCPUTime_AvgSmp)),
           PageIORte=convert(numeric(20,2),avg(PageIO_RteSmp)),
           PageHitPct=convert(numeric(6,2),avg(PageHitPercent_ValSmp)),
           LReads=sum(1.*LogicalPageReads_ValSmp),
           PReads=sum(1.*PhysicalPageReads_ValSmp),
           PWrites=sum(1.*PageWrites_ValSmp),
           ILReads=sum(1.*IndexLogicalReads_ValSmp),
           IPReads=sum(1.*IndexPhysicalReads_ValSmp)
    from ".$ServerName."_procs   
    where Timestamp >='".$StartTimestamp."'        
    and Timestamp <'".$EndTimestamp."'        
    group by ProcedureDatabaseName_ValSmp,ProcedureName_ValSmp
    ".$sort_clause."
    set rowcount 0";
?>

<?php
    if (!isset($filter_clause) ) $filter_clause = "";
    if (!isset($sort_clause) )   $sort_clause = "";


$result = asemon_query("if object_id('#sumplanperproc') is not null drop table #sumplanperproc",$pid);

$query = 
"select DBID, ProcName,Application, nbplans=count(distinct PlanID)
into #sumplanperproc
from ".$ServerName."_StmtStat S
where (S.StartTime >= '".$StartTimestamp."'        
  and S.StartTime <= '".$EndTimestamp."')
  and ProcName is not null
  ".$filter_clause."
group by DBID, ProcName, Application

create index i on #sumplanperproc ( DBID, ProcName)

set rowcount ".$rowcount."

select DBID, Application,ProcName,
    Executions=count(*),
    SumCpuTime=sum(CpuTime),
    AvgCpuTime=sum(CpuTime)/count(*),
    SumWaitTime=sum(WaitTime),
    AvgWaitTime=sum(WaitTime)/count(*),
    MaxMemUsageKB=max(MemUsageKB),
    SumPhysicalReads=sum(PhysicalReads),
    AvgPhysicalReads=sum(PhysicalReads)/count(*),
    SumLogicalReads=sum(LogicalReads),
    AvgLogicalReads=sum(LogicalReads)/count(*),
    SumPagesModified=sum(PagesModified),
    AvgPagesModified=sum(PagesModified)/count(*),
    SumPacketsSent=sum(PacketsSent),
    AvgPacketsSent=sum(PacketsSent)/count(*),
    SumPacketsReceived=sum(PacketsReceived),
    AvgPacketsReceived=sum(PacketsReceived)/count(*),
    SumPlans=(select sum(nbplans) from #sumplanperproc S
              where ProcExec.DBID=S.DBID              
                and isnull(ProcExec.Application,'')=isnull(S.Application,'')
                and ProcExec.ProcName=S.ProcName
             )
from (
    select Application,ProcName, DBID, SPID, KPID, BatchID, ContextID , 
           CpuTime=sum(1.*CpuTime),
           WaitTime=sum(1.*WaitTime), 
           MemUsageKB=max(MemUsageKB), 
           PhysicalReads=sum(1.*PhysicalReads),
           LogicalReads=sum(1.*LogicalReads), 
           PagesModified=sum(1.*PagesModified),
           PacketsSent=sum(1.*PacketsSent), 
           PacketsReceived=sum(1.*PacketsReceived)
    from ".$ServerName."_StmtStat
    where (StartTime >= '".$StartTimestamp."'        
      and StartTime <= '".$EndTimestamp."')
      and ProcName is not null
      ".$filter_clause."
    group by Application,ProcName, DBID, SPID, KPID,BatchID, ContextID 
    ) ProcExec
group by DBID, Application,ProcName
".$sort_clause."
set rowcount 0";
?>

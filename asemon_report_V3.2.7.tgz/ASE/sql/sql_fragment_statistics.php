<?php
if (!isset($filter_clause) ) $filter_clause = "";
if (!isset($sort_clause) )   $sort_clause = "";
if (!isset($filterIndid) )   $filterIndid = "";
if (!isset($selectedTimestamp) )   $selectedTimestamp = "";

if ( ($filterIndid != "") && ($filterIndid[0]=='>'))
  $filterIndid_clause = " and (F.indid".$filterIndid.")";
else
  $filterIndid_clause = " and (F.indid=convert(int,'".$filterIndid."') or '".$filterIndid."'='')";



if ($has_Dpage_utilization == 1)
  $Dpage_utilization_selclause = ", avg_Dpage_utilization = avg(Dpage_utilization)";
else
  $Dpage_utilization_selclause = ", avg_Dpage_utilization = null";

if ($has_oam_cols == 1)
  $oam_cols_selclause = ", avg_oamapgcnt = convert(numeric(16,0),avg(oamapgcnt)), avg_oampagecnt = convert(numeric(16,0),avg(oampagecnt))";
else
  $oam_cols_selclause = "";

// Get ASE PageSize
$result = asemon_query("select MaxPageSize=PageSize from ".$ServerName."_MonState 
              where Timestamp =(select max(Timestamp) from ".$ServerName."_MonState
                                where Timestamp <='".$EndTimestamp."')" , $pid);
$row = asemon_fetch_assoc($result);
$MaxPageSize = $row["MaxPageSize"];
if ($MaxPageSize == '') $MaxPageSize = 2048;


$query = "set rowcount ".$rowcount."
select
    F_Timestamp=F.Timestamp        ,
    F_dbname=F.dbname           ,
    F_owner=F.owner            ,
    F_tabname=F.tabname          ,
    F_indname=F.indname          ,
    F_indid=F.indid            ,
    F_lockmode=F.lockmode         ,
    F_clu=F.clu              ,
    avg_Rowcnt            = avg(1.*Rowcnt           ),
    avg_pagecnt           = convert(numeric(16,0),avg(1.*pagecnt   )),
    avg_leafcnt           = convert(numeric(16,0),avg(1.*leafcnt   )),
    avg_emptypgcnt        = convert(numeric(16,0),avg(1.*emptypgcnt)),
    avg_Forwardrowcnt     = avg(1.*Forwardrowcnt    ),
    avg_Delrowcnt         = avg(1.*Delrowcnt        ),
    avg_dpageCR           = avg(dpageCR          ),
    avg_ipageCR           = avg(ipageCR          ),
    avg_drowCR            = avg(drowCR           ),
    avg_space_utilization = avg(space_utilization),
    avg_largeIO_eff       = avg(largeIO_eff      )
    ".$Dpage_utilization_selclause."
    , object_Mb  = (".$MaxPageSize."/1024)*convert(numeric(12,2),avg(1.*pagecnt+1.*leafcnt)/1024 )
    , delta_Mb   = convert(numeric(12,2),avg(data_delta_Mb+leaf_delta_Mb))
    ".$oam_cols_selclause."
from ".$ServerName."_Fragment F,
(
    select
        dbname,
        owner ,
        tabname,
        indid  ,
        data_delta_Mb=(".$MaxPageSize."/1024)*(max(1.*pagecnt) - min(1.*pagecnt))/1024,
        leaf_delta_Mb=(".$MaxPageSize."/1024)*(max(1.*leafcnt) - min(1.*leafcnt))/1024
    from ".$ServerName."_Fragment
    where /*Timestamp >='".$StartTimestamp."' and */ Timestamp <= '".$EndTimestamp."'
    group by dbname, owner,tabname,indid
) delta_size


/* modif Damien pour IQ ????
Marche pas sur ASE
where Timestamp between '".$selectedTimestamp."' and dateformat('".$selectedTimestamp."','YYYY MM DD HH:NN:SS.999999')
*/
where Timestamp = (select max(Timestamp) from ".$ServerName."_Fragment where Timestamp <= '".$EndTimestamp."')
and delta_size.dbname=F.dbname
and delta_size.owner=F.owner
and delta_size.tabname=F.tabname
and delta_size.indid=F.indid
  ".$filter_clause."
  
group by F.Timestamp, F.dbname, F.owner, F.tabname, F.indname, F.indid, F.lockmode, F.clu
having (   avg(1.*pagecnt          ) >= ".$pagenum."
        or avg(1.*leafcnt          ) >= ".$pagenum.")
 ".$sort_clause."
 set rowcount 0";
?>








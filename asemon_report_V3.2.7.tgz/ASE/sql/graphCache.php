<?php
$query = "
select 
      Ts=convert(varchar,Timestamp,109)
      ,DefCacheSearches_s = sum( convert(float,case when CacheName='default data cache' then CacheSearches else 0 end) / Interval) * 1000
      ,OtherCacheSearches_s = sum( convert(float,case when CacheName!='default data cache' then CacheSearches else 0 end) / Interval) * 1000
from ".$ServerName."_DataCache          
where Timestamp >='".$StartTimestamp."'        
and Timestamp <'".$EndTimestamp."'        
group by Timestamp
order by Timestamp
";
?>
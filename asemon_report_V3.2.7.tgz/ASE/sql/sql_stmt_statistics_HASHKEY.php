<?php

  if (!isset($filter_clause) ) $filter_clause = "";
  if (!isset($sort_clause) )   $sort_clause = "";

  if ($ArchSrvType=="Adaptive Server Enterprise") {  
    $result = asemon_query("if object_id('#stmtHashKey') is not null drop table #stmtHashKey",$pid);
    $result = asemon_query("if object_id('#stmtHashKey02') is not null drop table #stmtHashKey02",$pid);
    $result = asemon_query("if object_id('#stmtHashKey2') is not null drop table #stmtHashKey2",$pid);
    $result = asemon_query("if object_id('#stmtSQL') is not null drop table #stmtSQL",$pid);
  }
  else {
    $result = asemon_query("drop table #stmtHashKey",$pid);
    $result = asemon_query("drop table #stmtHashKey02",$pid);
    $result = asemon_query("drop table #stmtHashKey2",$pid);
    $result = asemon_query("drop table #stmtSQL",$pid);
  }


  if ($colV16SP03Exists == 1) {
    $colV16SP03_clause = "
    , sumSnapCodegenTime         = sum(1.*SnapCodegenTime      )
    , sumSnapJITTime             = sum(1.*SnapJITTime          )
    , sumSnapExecutionTime       = sum(1.*SnapExecutionTime    )
    , sumSnapExecutionCount      = sum(1.*SnapExecutionCount   )
    , sumQueryOptimizationTime   = sum(1.*QueryOptimizationTime)
    ";
    $colV16SP03_clausefinale = "
    , sumSnapCodegenTime      
    , sumSnapJITTime          
    , sumSnapExecutionTime    
    , sumSnapExecutionCount   
    , sumQueryOptimizationTime
    ";
  }
  else {
    $colV16SP03_clause = "";
    $colV16SP03_clausefinale = "";
  }


  $result = asemon_query("
    select SQLHashKey,
          cnt = count(*),
          SumCpuTime           = sum(1.*CpuTime       ),
          AvgCpuTime           = avg(1.*CpuTime       ),
          SumWaitTime          = sum(1.*WaitTime      ),
          MaxMemUsageKB        = max(   MemUsageKB    ),
          SumPhysicalReads     = sum(1.*PhysicalReads ),
          AvgPhysicalReads     = avg(1.*PhysicalReads ),
          SumLogicalReads      = sum(1.*LogicalReads  ),
          AvgLogicalReads      = avg(1.*LogicalReads  ),
          SumPagesModified     = sum(1.*PagesModified ),
          SumPacketsSent       = sum(1.*PacketsSent   ),
          SumPacketsReceived   = sum(1.*PacketsReceived)
          ".$colV16SP03_clause."
    into #stmtHashKey
    from ".$ServerName."_StmtStat
    where StartTime >='".$StartTimestamp."'
    and StartTime < '".$EndTimestamp."' 
    and SQLHashKey is not null
    group by SQLHashKey", $pid);

  if ($result==false){
    $error = "Error select into #stmtHashKey. ".$error;
    return;
  }
  $result = asemon_query("select cnt=count(*) from #stmtHashKey", $pid);
  if ($result!=false){
    $row = asemon_fetch_assoc($result);
    if ($row['cnt'] == 0) return;
  }

  if ($StmtSQLHKExists == 1) {
    // Check if StmtSQLHK contains data (if yes, means the ArchiveSQLHK switch is set in asemon_logger for this server)
    $StmtSQLHK_containsrows = false;
    $result = asemon_query("select 1 where exists (select * from ".$ServerName."_StmtSQLHK where Timestamp between '".$StartTimestamp."' and '".$EndTimestamp."')", $pid);
    if ($result!=false){
      $row = asemon_fetch_assoc($result);
      if ($row != false) $StmtSQLHK_containsrows = true;
    }
  }

  if ($StmtSQLHK_containsrows == true) {
    if ($ArchSrvType=="Adaptive Server Enterprise") {  
      // It is on ASE, isolate declare cursor step
      $result = asemon_query("
        declare c2 cursor for
        select S.SQLHashKey, Sequence, SQLText
        from ".$ServerName."_StmtSQLHK S , #stmtHashKey T
        where S.SQLHashKey = T.SQLHashKey
        order by S.SQLHashKey, Sequence", $pid);
    
      if ($result==false){
        $error = "Error declare cursor c2. ".$error;
        return;
      }
  
      $result = asemon_query("
        set nocount on
        declare @SQLHashKey numeric(20,0), @Sequence int, @SQLText varchar(255), @newSQLText varchar(16384), @prevSQLHashKey numeric(20,0)
        select SQLHashKey,convert(text,'') as SQLText into #stmtSQL from #stmtHashKey where 1=2
        open c2
        fetch c2 into  @SQLHashKey , @Sequence ,@SQLText
        while @@sqlstatus =0
        begin
          if @SQLHashKey != @prevSQLHashKey  and @prevSQLHashKey is not null
          begin
            -- save previous SQL
            insert into #stmtSQL values (@prevSQLHashKey, @newSQLText)
            select @newSQLText = ''
          end
          select @prevSQLHashKey = @SQLHashKey
          select @newSQLText=@newSQLText+@SQLText
          fetch c2 into  @SQLHashKey ,@Sequence, @SQLText
        end 
        -- save last SQL
        if @prevSQLHashKey is not null
          insert into #stmtSQL values (@prevSQLHashKey, @newSQLText)
        close c2
        deallocate cursor c2
        create unique index iu on #stmtSQL(SQLHashKey)", $pid);
  
      if ($result==false){
        $error = "Error generating #stmtSQL. ".$error;
        return;
      }
    }
    else {
      // It is on IQ, don't isolate declare cursor step
      asemon_query("create table #stmtSQL (SQLHashKey numeric(20,0), SQLText varchar(32000))", $pid);
      $result = asemon_query("
        declare c2 cursor for
        select S.SQLHashKey, Sequence, SQLText
        from ".$ServerName."_StmtSQLHK S , #stmtHashKey T
        where S.SQLHashKey = T.SQLHashKey
        order by S.SQLHashKey, Sequence
        set nocount on
        declare @SQLHashKey numeric(20,0), @Sequence int, @SQLText varchar(255), @newSQLText varchar(16384), @prevSQLHashKey numeric(20,0)
        begin transaction
        open c2
        fetch c2 into  @SQLHashKey , @Sequence ,@SQLText
        while @@sqlstatus =0
        begin
          if @SQLHashKey != @prevSQLHashKey  and @prevSQLHashKey is not null
          begin
            -- save previous SQL
            insert into #stmtSQL values (@prevSQLHashKey, @newSQLText)
            select @newSQLText = ''
          end
          select @prevSQLHashKey = @SQLHashKey
          select @newSQLText=@newSQLText+@SQLText
          fetch c2 into  @SQLHashKey ,@Sequence, @SQLText
        end 
        -- save last SQL
        if @prevSQLHashKey is not null
          insert into #stmtSQL values (@prevSQLHashKey, @newSQLText)
        close c2
        deallocate cursor c2
        commit transaction", $pid);

      if ($result==false){
        $error = "Error generating #stmtSQL. ".$error;
        return;
      }
    }

  }
  else {
    // Get SQL from StmtSQL, but need to select only first statement matching same SQLHashKey, since StmtSQL may contains several statements with different parameters

    // Need this temporary table to avoid a bad plan of the next cursor if this SELECT is included in the cursor
    // Need to split the query into two queries because index "idx2" on SQLHashKey, Timestamp is not used in some cases, why ???
    $result = asemon_query("
      select T.SQLHashKey,Timestamp=min(S.Timestamp)
      into #stmtHashKey02
      from ".$ServerName."_StmtSQL S, #stmtHashKey T
      where S.SQLHashKey = T.SQLHashKey
      group by T.SQLHashKey", $pid);
    
    if ($result==false){
      $error = "Error select into #stmtHashKey02. ".$error;
      return;
    }
    // Old query before split :
    //$result = asemon_query("
    //  select distinct S.SQLHashKey,LineNumber, SequenceInLine, SQLText
    //  into #stmtHashKey2
    //  from ".$ServerName."_StmtSQL S, #stmtHashKey T
    //  where S.SQLHashKey = T.SQLHashKey
    //  and S.Timestamp = (select min(Timestamp) from ".$ServerName."_StmtSQL where SQLHashKey =  T.SQLHashKey)", $pid);
    $result = asemon_query("
      select S.SQLHashKey,LineNumber, SequenceInLine, SQLText
      into #stmtHashKey2
      from ".$ServerName."_StmtSQL S, #stmtHashKey02 T
      where S.SQLHashKey = T.SQLHashKey
      and S.Timestamp = T.Timestamp", $pid);
    
    if ($result==false){
      $error = "Error select into #stmtHashKey2. ".$error;
      return;
    }
    
    $result = asemon_query("select cnt=count(*) from #stmtHashKey2", $pid);
    $row = asemon_fetch_assoc($result);
    if ($row["cnt"] > 0) {
    
      // Loop on StmtSQL to find SQLText of first each matching SQLHashKey
      // and for each SQLHashkey concatenate all lines of SQLText into one field
    
      if ($ArchSrvType=="Adaptive Server Enterprise") {  
        // It is on ASE, isolate declare cursor step
    
        $result = asemon_query("
          declare c1 cursor for
          select SQLHashKey,LineNumber, SequenceInLine, SQLText
          from #stmtHashKey2
          order by SQLHashKey,LineNumber, SequenceInLine", $pid);
      
        if ($result==false){
          $error = "Error declare cursor c1. ".$error;
          return;
        }
      
        $result = asemon_query("
          set nocount on
          declare @SQLHashKey numeric(20,0), @LineNumber int, @SequenceInLine int, @SQLText varchar(255), @newSQLText varchar(16384), @prevSQLHashKey numeric(20,0), @prevLineNumber int
          select SQLHashKey,convert(text,'') as SQLText into #stmtSQL from #stmtHashKey where 1=2
          select @prevLineNumber=1
          begin transaction
          open c1
          fetch c1 into  @SQLHashKey , @LineNumber , @SequenceInLine ,@SQLText
          while @@sqlstatus =0
          begin
            if @SQLHashKey != @prevSQLHashKey  and @prevSQLHashKey is not null
            begin
              -- save previous SQL
              insert into #stmtSQL values (@prevSQLHashKey, @newSQLText)
              select @newSQLText = '',@prevLineNumber=1
            end
            select @prevSQLHashKey = @SQLHashKey
            if @LineNumber is not null and @prevLineNumber != @LineNumber
                select @newSQLText=@newSQLText+CHAR(10), @prevLineNumber = @LineNumber
            select @newSQLText=@newSQLText+@SQLText
            fetch c1 into  @SQLHashKey , @LineNumber , @SequenceInLine ,@SQLText
          end 
          -- save last SQL
          if @prevSQLHashKey is not null
            insert into #stmtSQL values (@prevSQLHashKey, @newSQLText)
          close c1
          deallocate cursor c1
          commit transaction
          create unique index iu on #stmtSQL(SQLHashKey)", $pid);
      
        if ($result==false){
          $error = "Error generating #stmtSQL. ".$error;
          return;
        }
      }
      else {
        // It is on IQ, don't isolate declare cursor step
        asemon_query("create table #stmtSQL (SQLHashKey numeric(20,0), SQLText varchar(32000))", $pid);
        $result = asemon_query("
          declare c1 cursor for
          select SQLHashKey,LineNumber, SequenceInLine, SQLText
          from #stmtHashKey2
          order by SQLHashKey,LineNumber, SequenceInLine      
    
          set nocount on
          declare @SQLHashKey numeric(20,0), @LineNumber int, @SequenceInLine int, @SQLText varchar(255), @newSQLText varchar(16384), @prevSQLHashKey numeric(20,0), @prevLineNumber int
          select @prevLineNumber=1
          begin transaction
          open c1
          fetch c1 into  @SQLHashKey , @LineNumber , @SequenceInLine ,@SQLText
          while @@sqlstatus =0
          begin
            if @SQLHashKey != @prevSQLHashKey  and @prevSQLHashKey is not null
            begin
              -- save previous SQL
              insert into #stmtSQL values (@prevSQLHashKey, @newSQLText)
              select @newSQLText = '',@prevLineNumber=1
            end
            select @prevSQLHashKey = @SQLHashKey
            if @LineNumber is not null and @prevLineNumber != @LineNumber
                select @newSQLText=@newSQLText+CHAR(10), @prevLineNumber = @LineNumber
            select @newSQLText=@newSQLText+@SQLText
            fetch c1 into  @SQLHashKey , @LineNumber , @SequenceInLine ,@SQLText
          end 
          -- save last SQL
          if @prevSQLHashKey is not null
            insert into #stmtSQL values (@prevSQLHashKey, @newSQLText)
          close c1
          deallocate cursor c1
          commit transaction", $pid);
    
        if ($result==false){
          $error = "Error generating #stmtSQL. ".$error;
          return;
        }
      }
    
    }
  
  }




  $query = "set rowcount ".$rowcount."
  select stat.SQLHashKey,
        cnt,
        SumCpuTime         ,
        AvgCpuTime         ,
        SumWaitTime        ,
        MaxMemUsageKB      ,
        SumPhysicalReads   ,
        AvgPhysicalReads   ,
        SumLogicalReads    ,
        AvgLogicalReads    ,
        SumPagesModified   ,
        SumPacketsSent     ,
        SumPacketsReceived ,
        SQLText
        ".$colV16SP03_clausefinale."
  from #stmtHashKey stat, #stmtSQL Q
  where stat.SQLHashKey = Q.SQLHashKey
  ".$filter_clause."
  ".$sort_clause."
  set rowcount 0";
    
?>




<?php

  if (!isset($filter_clause) ) $filter_clause = "";
  if (!isset($sort_clause) )   $sort_clause = "";

$query = "select I.WaitEventID,ClassDesc=C.Description,EventDesc=I.Description, SumWaitTime=sum(1.*WaitTime), Sumwaits = sum(1.*Waits),
AvgWaitTime_ms=sum(1000.*WaitTime) / sum(1.*Waits)
from ".$ServerName."_SysWaits W, ".$ServerName."_WEvInf I, ".$ServerName."_WClassInf C
where W.Timestamp >='".$StartTimestamp."'
and W.Timestamp <'".$EndTimestamp."'
and convert(smallint,W.WaitEventID) = I.WaitEventID
and I.WaitClassID=C.WaitClassID
--and lower(C.Description) != 'waiting for internal system event'
".$filter_clause."
group by I.WaitEventID,C.Description,I.Description
".$sort_clause
?>

<?php
if (!isset($CacheName)) $CacheName="";

$sel157cols="";
$add157APF="";
if ($support157==1) {
 $sel157cols = ",sumLogicalReads=sum(1.*LogicalReads), sumPhysicalWrites=sum(1.*PhysicalWrites), sumAPFReads=sum(1.*APFReads), avgAPFPercentage=avg(1.*APFPercentage), avgWashSize=avg(1.*WashSize)";
 $add157APF="+sum(convert(numeric(15,0),APFReads))";
}

// get page size
$pagesizeKb = 2;
$result = asemon_query("select pagesizeKb=min(IOBufferSize)/1024 from ".$ServerName."_CachePool
                        where Timestamp >='".$StartTimestamp."'
                          and Timestamp <'".$EndTimestamp."'"
                      ,$pid);
$row = asemon_fetch_assoc($result);
if ($row["pagesizeKb"] != null) {
  $pagesizeKb = $row["pagesizeKb"];
}

$query = "select
CacheName,
IOBufferSize ,
AllocatedKB ,
sumPagesReads=sum(convert(numeric(15,0),PagesRead)),
sumPhysicalReads=sum(convert(numeric(15,0),PhysicalReads)),
sumStalls=sum(convert(numeric(15,0),Stalls)),
--         sumPagesTouched=sum(PagesTouched),
sumBuffersToMRU=sum(convert(numeric(15,0),BuffersToMRU)),
sumBuffersToLRU=sum(convert(numeric(15,0),BuffersToLRU)),
PhysReads_s=case when datediff(ss,min(Timestamp), max(Timestamp))=0 then 0 else
   (sum(convert(numeric(15,0),PhysicalReads))".$add157APF.") /datediff(ss,min(Timestamp), max(Timestamp))
  end,
Turnover_s=case when sum(convert(numeric(15,0),BuffersToMRU)) = 0 then 'infinite' 
                when datediff(ss,min(Timestamp), max(Timestamp))=0 then '' 
                else
                         str((AllocatedKB/".$pagesizeKb.") /(sum(convert(numeric(15,0),BuffersToMRU))/datediff(ss,min(Timestamp), max(Timestamp)) ), 20,0)
              end,
inter=datediff(ss,min(Timestamp), max(Timestamp))
".$sel157cols."
from ".$ServerName."_CachePool
where Timestamp >='".$StartTimestamp."'
and Timestamp <'".$EndTimestamp."'
and (CacheName='".$CacheName."' or ''='".$CacheName."')
group by CacheName, IOBufferSize, AllocatedKB
order by CacheName, IOBufferSize";



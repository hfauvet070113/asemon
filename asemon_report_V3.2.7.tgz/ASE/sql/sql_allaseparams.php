<?php
if (!isset($filter_clause) ) $filter_clause = "";
if (!isset($sort_clause) )   $sort_clause = "";

  if ($ArchSrvType=="Adaptive Server Enterprise") {  
    $result = asemon_query("if object_id('#aseparamsinfos') is not null drop table #aseparamsinfos", $pid);
    $result = asemon_query("declare c cursor for select name from sysobjects where name like '%AseParams'", $pid);
    $declare_cursor = "";
  }
  else {
  	// On IQ
  	$result = asemon_query("drop table if exists #aseparamsinfos", $pid);
  	$declare_cursor = " declare c cursor for select name from sysobjects where name like '%AseParams' ";
  }


$query="set nocount on
declare @tname varchar(255), @srvname varchar(255)
create table #aseparamsinfos (
     srvname   varchar(255) not null,
     ParamName varchar(255) not null,
     CfgValue  varchar(32) not null,
     RunValue  varchar(32) not null
)
".
$declare_cursor
."
open c
fetch c into @tname 
while @@sqlstatus = 0
begin
	select @srvname=substring(@tname,1,datalength(@tname)-10)
	execute ('insert into #aseparamsinfos select '''+@srvname+''',ParamName,CfgValue,RunValue  from '+@tname+' where Timestamp=(select max(Timestamp) from '+@tname+')')
	fetch c into @tname
end
close c


if ('".$selparams."' = 'All')
begin
  set rowcount ".$rowcount."
  select srvname,ParamName,CfgValue,RunValue
  from #aseparamsinfos
  where 1=1
  ".$filter_clause."
  ".$sort_clause."
end
else
begin  
  set rowcount ".$rowcount."
  select srvname, ParamName=PNAME, CfgValue, RunValue
  from (
    select distinct PNAME=ParamName from #aseparamsinfos A group by ParamName, CfgValue, RunValue  having count(*) < (select count(*) from #aseparamsinfos B where B.ParamName=A.ParamName)   
    ) distinctparam, #aseparamsinfos
  where distinctparam.PNAME=#aseparamsinfos.ParamName
  ".$filter_clause."
  ".$sort_clause."
end
drop table  #aseparamsinfos
deallocate cursor c
set rowcount 0
";


?>
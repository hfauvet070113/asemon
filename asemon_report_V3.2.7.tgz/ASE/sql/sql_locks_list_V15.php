<?php
  if (!isset($filter_clause) ) $filter_clause = "";

  if (!isset($sort_clause) )   $sort_clause = "";
//Contient par ex. : 'order by WaitTime asc'

$computed_sort_clause = "order by 1, 3, 11 desc, 5";

if (strcmp(trim($sort_clause), "order by TS desc")==0)
  $computed_sort_clause = "order by 1 desc, 3, 11 desc, 5";
if (strcmp(trim($sort_clause), "order by WaitTime asc")==0)
  $computed_sort_clause = "order by 26, 3, 11 desc, 5";
if (strcmp(trim($sort_clause), "order by WaitTime desc")==0)
  $computed_sort_clause = "order by 26 desc, 3, 11 desc, 5";

  if ($ArchSrvType=="Adaptive Server Enterprise") {  
    // It is on ASE, isolate declare cursor step
    $result=asemon_query(
    "declare c cursor for 
       select BlockedBy,Timestamp,WT=max(WaitTime)
       from ".$ServerName."_BlockedP 
       where Timestamp >='".$StartTimestamp."'
       and   Timestamp <='".$EndTimestamp."'
       and BlockedBy   is not null
       group by BlockedBy,Timestamp
       order by BlockedBy,Timestamp",
      $pid);

    if ($result==false){
      $error = "Error declare cursor. ".$error;
      return;
    }
    $result = asemon_query("if object_id('#blk_max') is not null drop table #blk_max",$pid);
    $result = asemon_query("if object_id('#blk_max2') is not null drop table #blk_max2",$pid);
    $result=asemon_query(
    "declare @savts datetime, @ts datetime, @savWT int, @WT int, @savBlockedBy int, @BlockedBy int
     create table #blk_max (BlockedBy int, max_TS datetime, max_WaitTime int)
     set nocount on
     open c
     fetch c into @savBlockedBy,@savts,@savWT
     if @@sqlstatus = 0
     begin 
         fetch c into @BlockedBy,@ts,@WT
         while @@sqlstatus=0
         begin
            if @BlockedBy != @savBlockedBy
            begin
              -- max block found for a spid
              insert into #blk_max values (@savBlockedBy,@savts,@savWT)
            end
            else
              if @WT < @savWT or @WT < 5
              begin
                -- max block found for a spid
                insert into #blk_max values (@savBlockedBy,@savts,@savWT)
              end
            select @savWT=@WT, @savts=@ts, @savBlockedBy=@BlockedBy
            fetch c into @BlockedBy,@ts,@WT
         end
         -- sav last row found
         insert into #blk_max values (@savBlockedBy,@savts,@savWT)
     end
     close c
     deallocate cursor c",
    $pid);
    if ($result==false){
      $error = "Error exec cursor. ".$error;
      return;
    }
  }
  else {
    // It is on IQ, don't isolate declare cursor step
    $result = asemon_query("drop table if exists #blk_max",$pid);
    $result = asemon_query("drop table if exists #blk_max2",$pid);
    $query = "create table #blk_max (BlockedBy int, max_TS datetime, max_WaitTime int)";
    $result = asemon_query($query,$pid);
    $result=asemon_query(
    "declare c cursor for 
       select BlockedBy,Timestamp,WT=max(WaitTime)
       from ".$ServerName."_BlockedP 
       where Timestamp >='".$StartTimestamp."'
       and   Timestamp <='".$EndTimestamp."'
       and BlockedBy   is not null
       group by BlockedBy,Timestamp
       order by BlockedBy,Timestamp
       
       begin transaction
       declare @savts datetime, @ts datetime, @savWT int, @WT int, @savBlockedBy int, @BlockedBy int
       set nocount on
       open c
       fetch c into @savBlockedBy,@savts,@savWT
       if @@sqlstatus = 0
       begin 
           fetch c into @BlockedBy,@ts,@WT
           while @@sqlstatus=0
           begin
              if @@sqlstatus != 0 break
              if @BlockedBy != @savBlockedBy
              begin
                -- max block found for a spid
                insert into #blk_max values (@savBlockedBy,@savts,@savWT)
              end
              else
                if @WT < @savWT or @WT < 5
                begin
                  -- max block found for a spid
                  insert into #blk_max values (@savBlockedBy,@savts,@savWT)
                end
              select @savWT=@WT, @savts=@ts, @savBlockedBy=@BlockedBy
              fetch c into @BlockedBy,@ts,@WT
           end
           -- sav last row found
           insert into #blk_max values (@savBlockedBy,@savts,@savWT)
       end
       close c
       deallocate cursor c
       commit transaction",
    $pid);
    if ($result==false){
      $error = "Error exec cursor. ".$error;
      return;
    }
  }


  // Filter blocking occurences if necessary
  $query = "select B.* into #blk_max2 
   from ".$ServerName."_BlockedP A , #blk_max B
   where A.Timestamp = B.max_TS
     and A.BlockedBy = B.BlockedBy
   UNION
   select B.*
   from ".$ServerName."_BlockedP A , #blk_max B
   where A.Timestamp = B.max_TS
     and A.LockID = B.BlockedBy";

  asemon_query($query,$pid) ;

  $query="set rowcount ".$rowcount. " 
  select
       Tmst=A.Timestamp,
       TS=convert (varchar, A.Timestamp, 111)+' '+convert (varchar, A.Timestamp, 108)+'.'+convert(varchar, datepart(ms,A.Timestamp)),
       maxBB=B.BlockedBy ,
       WaitTime    ,
       SPID        ,
       KPID        ,
       DBID        ,
       ParentSPID  ,
       LockID      ,
       A.BlockedBy   ,
       BlockedState,
       Context     ,
       ObjectID    ,
       lckBase     ,
       lckObjet    ,
       lckPage     ,
       lckRow      ,
       LockState   ,
       LockType    ,
       LockLevel   ,
       Usr         ,
       Trn         ,
       Prg         ,
       Prc         ,
       Line        ,
       max_WaitTime
  from ".$ServerName."_BlockedP A, #blk_max2 B
  where A.Timestamp = B.max_TS
  and A.BlockedBy = B.BlockedBy
   ".$filter_clause."
  union all
  select
       Tmst=A.Timestamp,
       TS=convert (varchar, A.Timestamp, 111)+' '+convert (varchar, A.Timestamp, 108)+'.'+convert(varchar, datepart(ms,A.Timestamp)),
       maxBB=B.BlockedBy ,
       WaitTime    ,
       SPID        ,
       KPID        ,
       DBID        ,
       ParentSPID  ,
       LockID      ,
       A.BlockedBy   ,
       BlockedState,
       Context     ,
       ObjectID    ,
       lckBase     ,
       lckObjet    ,
       lckPage     ,
       lckRow      ,
       LockState   ,
       LockType    ,
       LockLevel   ,
       Usr         ,
       Trn         ,
       Prg         ,
       Prc         ,
       Line        ,
       max_WaitTime
  from ".$ServerName."_BlockedP A , #blk_max2 B
  where A.Timestamp = B.max_TS
  and A.LockID = B.BlockedBy
   ".$filter_clause."

  -- pour trace debug :
  --union all select Timestamp='1/1/2000',TS='".$sort_clause."', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, max_WaitTime=null from sysobjects where id=1
  --union all select Timestamp='1/1/2000',TS='".$computed_sort_clause."', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, max_WaitTime=null from sysobjects where id=1

  --order by 1, 3, 11 desc, 5
  ".$computed_sort_clause."
  set rowcount 0";


?>
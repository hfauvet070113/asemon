<?php
$query = "
select Ts=convert(varchar,ListTimestamp.Timestamp,109), 
  CachedKB
from (select distinct Timestamp from ".$ServerName."_CachedObj 
      where Timestamp >='".$StartTimestamp."'
      and Timestamp <='".$EndTimestamp."'
      ) ListTimestamp  
      left outer join ".$ServerName."_CachedObj B on ListTimestamp.Timestamp = B.Timestamp 
        and B.DBName='".$ObjectDbName."' 
        and B.ObjectName='".$ObjectName."' 
        and B.ObjectID=case when ".$ObjectID." =0 then B.ObjectID else ".$ObjectID." end
        and B.IndexID=".$IndexID."
order by ListTimestamp.Timestamp";
?>
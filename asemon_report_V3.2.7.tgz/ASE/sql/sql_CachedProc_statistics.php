<?php

    if (!isset($filter_clause) ) $filter_clause = "";
    if (!isset($sort_clause) )   $sort_clause = "";

if ($support157==1) {
  $sel157cols     = ",ExecutionCount,
  RequestCnt ,
  avgCPUTime       =     case when RequestCnt = 0 then 0 else 1.*CPUTime/RequestCnt end,
  sumCPUTime       =     CPUTime,
  avgExecutionTime =     case when RequestCnt = 0 then 0 else 1.*ExecutionTime/RequestCnt end, 
  sumExecutionTime =     ExecutionTime, 
  avgPhysicalReads =     case when RequestCnt = 0 then 0 else 1.*PhysicalReads/RequestCnt end,
  sumPhysicalReads =     PhysicalReads, 
  avgLogicalReads  =     case when RequestCnt = 0 then 0 else 1.*LogicalReads/RequestCnt end,  
  sumLogicalReads  =     LogicalReads,  
  avgPhysicalWrites=     case when RequestCnt = 0 then 0 else 1.*PhysicalWrites/RequestCnt end,
  sumPhysicalWrites=     PhysicalWrites,
  avgPagesWritten  =     case when RequestCnt = 0 then 0 else 1.*PagesWritten/RequestCnt end,  
  sumPagesWritten  =     PagesWritten,  
  TempdbRemapCnt,
  AvgTempdbRemapTime";
  $sel157cols_agg = ",sumExecutionCount=sum(ExecutionCount),
  sumRequestCnt=sum(RequestCnt),
  avgCPUTime       = case when sum(RequestCnt) = 0 then 0 else sum(1.*CPUTime)/sum(RequestCnt)        end,
  sumCPUTime       = sum(1.*CPUTime),
  avgLogicalReads  = case when sum(RequestCnt) = 0 then 0 else sum(1.*LogicalReads)/sum(RequestCnt)   end,
  sumLogicalReads  = sum(1.*LogicalReads),
  avgExecutionTime = case when sum(RequestCnt) = 0 then 0 else sum(1.*ExecutionTime)/sum(RequestCnt)  end,
  sumExecutionTime = sum(1.*ExecutionTime),
  avgPhysicalReads = case when sum(RequestCnt) = 0 then 0 else sum(1.*PhysicalReads)/sum(RequestCnt)  end,
  sumPhysicalReads = sum(1.*PhysicalReads),
  avgPhysicalWrites= case when sum(RequestCnt) = 0 then 0 else sum(1.*PhysicalWrites)/sum(RequestCnt) end,
  sumPhysicalWrites= sum(1.*PhysicalWrites),
  avgPagesWritten  = case when sum(RequestCnt) = 0 then 0 else sum(1.*PagesWritten)/sum(RequestCnt)   end,
  sumPagesWritten  = sum(1.*PagesWritten),
  sumTempdbRemapCnt=sum(TempdbRemapCnt),
  avgTempdbRemapTime=avg(AvgTempdbRemapTime) ";
}
else {
  $sel157cols     = " ";
  $sel157cols_agg = " ";
}

if ($supportSQLHashKey==1) {
  $selSQLHashKey     = ", SQLHashKey=(select max(SQLHashKey) from ".$ServerName."_StmtStat (index idx2) where ProcName=".$ServerName."_CachedPrc.ObjectName and ".$ServerName."_CachedPrc.ObjectName like '*s%' and SQLHashKey is not null)";
}
else $selSQLHashKey="";


if ($group=='N') {

  $query = "set rowcount ".$rowcount." select
    Timestamp,
    ObjectID   ,
    OwnerUID   ,
    DBID       ,
    PlanID     ,
    MemUsageKB ,
    CDate=convert (varchar, CompileDate, 111)+' '+convert (varchar, CompileDate, 108)+'.'+convert(varchar, datepart(ms,CompileDate)),
    ObjectName ,
    ObjectType ,
    OwnerName  ,
    DBName     
  ".$sel157cols."
  ".$selSQLHashKey."
  from ".$ServerName."_CachedPrc (index idx)
  where Timestamp >='".$StartTimestamp."'
  and Timestamp <'".$EndTimestamp."'
  ".$filter_clause."
  ".$sort_clause."
   set rowcount 0";
}
else {

  $query = "set rowcount ".$rowcount." select
    1, /* fake column to have same column numbers as with th non group by select */
    ObjectID   ,
    OwnerUID   ,
    DBID       ,
    NumPlans     =count(distinct PlanID),
    MaxMemUsageKB = max(MemUsageKB),
    LastCompileDate = convert (varchar, max(CompileDate), 111)+' '+convert (varchar, max(CompileDate), 108)+'.'+convert(varchar, datepart(ms,max(CompileDate))),
    ObjectName ,
    ObjectType ,
    OwnerName  ,
    DBName     
  ".$sel157cols_agg."
  ".$selSQLHashKey."
  from ".$ServerName."_CachedPrc (index idx)
  where Timestamp >='".$StartTimestamp."'        
  and Timestamp <'".$EndTimestamp."'        
  ".$filter_clause."
  group by ObjectID   ,
    OwnerUID   ,
    DBID       ,
    ObjectName ,
    ObjectType ,
    OwnerName  ,
    DBName     
  
  ".$sort_clause."
  set rowcount 0";
}

?>

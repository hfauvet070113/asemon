<?php

  if (!isset($filter_clause) ) $filter_clause = "";
  if (!isset($sort_clause) )   $sort_clause = "";

  $query = "set rowcount ".$rowcount."
  select Class=C.Description, W.WaitEventID, Waits=sum(1.*W.Waits), WaitTime_ms=sum(1.*WaitTime)    , E.Description, avgwaittime=sum(1.*WaitTime)/sum(1.*W.Waits)
  from ".$ServerName."_CnxWaits W,".$ServerName."_WEvInf E, ".$ServerName."_WClassInf C
  where W.WaitEventID = E.WaitEventID
    and E.WaitClassID = C.WaitClassID
    and Spid=".$Spid."
    and Kpid=".$Kpid."
    and W.Timestamp >= '".$Loggedindatetime."'
    and W.Timestamp < (
      select isnull(min(Loggedindatetime), '1/1/3000')
      from ".$ServerName."_Cnx cnx
      where cnx.Kpid = W.Kpid
        and cnx.Spid = W.Spid
        and cnx.Loggedindatetime > '".$Loggedindatetime."'
      )
    and W.Timestamp >='".$StartTimestamp."'
    and W.Timestamp <'".$EndTimestamp."'" 
  .$filter_clause
  ." group by C.Description, W.WaitEventID  , E.Description having sum(1.*W.Waits) > 0"
  .$sort_clause
  ." set rowcount 0";
?>

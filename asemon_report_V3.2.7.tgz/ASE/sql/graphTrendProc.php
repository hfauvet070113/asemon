<?php
$query = "
select Ts=convert(varchar,day,109),
Value=".$indic."
from ".$ServerName."_TrendProc
where DBID=".$DBID."
and ProcName='".$ProcName."'
and day between '".$StartTimestamp."' and '".$EndTimestamp."'
order by day
";
?>
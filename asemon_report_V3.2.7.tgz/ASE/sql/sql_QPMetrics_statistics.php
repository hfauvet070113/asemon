<?php

  if (!isset($filter_clause) ) $filter_clause = "";
  if (!isset($sort_clause) )   $sort_clause = "";
 
  $query = "set rowcount ".$rowcount."
  select 
    Q_dbname=Q.dbname     ,
    Q_owneruid=Q.uid    ,
    Q_id=Q.id    ,
    Q_hashkey=Q.hashkey    ,
    usecount=sum(Q.cnt) ,
    lio_avg = sum(1.*Q.cnt*Q.lio_avg )/sum(Q.cnt)   ,
    totlio = sum(1.*Q.cnt*Q.lio_avg )   ,
    pio_avg = sum(1.*Q.cnt*Q.pio_avg )/sum(Q.cnt)   ,
    totpio = sum(1.*Q.cnt*Q.pio_avg )   ,
    exec_avg=sum(1.*Q.cnt*Q.exec_avg)/sum(Q.cnt)   ,
    elap_avg=sum(1.*Q.cnt*Q.elap_avg)/sum(Q.cnt)   ,
    qtext
  from ".$ServerName."_QPMetrics Q, ".$ServerName."_QPMSQL S
  where Q.Timestamp >='".$StartTimestamp."'        
  and   Q.Timestamp <'".$EndTimestamp."' 
  and Q.dbname=S.dbname
  and Q.uid=S.uid
  and Q.id=S.id
  and Q.hashkey=S.hashkey
  and S.sequence=0
  ".$filter_clause;
  

  $query = $query ." group by Q.dbname,Q.uid,Q.id,Q.hashkey,qtext";
/*
  $query = $query ." order by ".$orderQPMetrics." 
  set rowcount 0";
*/
  $query = $query ."
  ".$sort_clause."
  set rowcount 0";
?>

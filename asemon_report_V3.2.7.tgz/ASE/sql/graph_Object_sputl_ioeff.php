<?php
$query = "
select Ts=convert(varchar,Timestamp,109), 
  space_utilization=F.space_utilization,
  largeIO_efficiency=F.largeIO_eff

  
  from ".$ServerName."_Fragment F
  where F.dbname='".$dbname."'
  and F.owner='".$owner."'
  and F.tabname='".$tabname."'
  and F.indid=convert(int,'".$indid."')
  order by Timestamp";
?>
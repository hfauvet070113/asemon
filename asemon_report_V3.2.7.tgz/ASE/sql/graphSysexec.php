<?php
$query = "
select 
   Ts=convert(varchar,Timestamp,109)
   ,etime_pct = (abs(ExecutionTime)/10.) /Interval
   ,execnt_rate=abs(1000.*ExecutionCnt)/Interval
from ".$ServerName."_SysExec
where OperationName='".$name."'
and Timestamp >= '".$StartTimestamp."' and Timestamp <= '".$EndTimestamp."'
order by Timestamp";
?>
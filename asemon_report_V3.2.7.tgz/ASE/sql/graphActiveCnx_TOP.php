<?php
if (!isset($filter_clause) ) $filter_clause = "";
if (!isset($metric_minimum) ) $metric_minimum = 5;
$query = "
select Ts=convert(varchar,listts.Timestamp,109),
       [Key]=isnull(".$metric_name.", 'NULL'),
       Value=ActiveCnx
from
  (
    select distinct Timestamp from ".$ServerName."_CnxActiv 
    where Timestamp >='".$StartTimestamp."' and Timestamp <'".$EndTimestamp."'        
  ) listts, 
  (
    select A.Timestamp
      , c.$metric_name 
      , ActiveCnx=count(1)
    from ".$ServerName."_CnxActiv A, ".$ServerName."_Cnx c 
    where
      c.Loggedindatetime = A.Loggedindatetime
      and c.Kpid = A.Kpid
      and c.Spid = A.Spid
      and A.Timestamp >='".$StartTimestamp."' and A.Timestamp <'".$EndTimestamp."'
      ".$filter_clause."
    group by A.Timestamp, c.$metric_name
    having count(1) > ".$metric_minimum."
    ) ua
where
    listts.Timestamp *= ua.Timestamp
order by listts.Timestamp";
?>

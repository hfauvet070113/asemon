<?php
  if (!isset($filter_clause) ) $filter_clause = "";
  if (!isset($sort_clause) )   $sort_clause = "";

if ($ArchSrvType=="Adaptive Server Enterprise") {
$query = "set rowcount ".$rowcount."
select
    dbname           ,
    owner            ,
    tabname          ,
    Counter=sum(counter)          ,
    c1               ,
    c2               ,
    c3               ,
    c4               ,
    c5               ,
    c6               ,
    c7               ,
    c8               ,
    c9               ,
    c10              ,
    c11              ,
    c12              ,
    c13              ,
    c14              ,
    c15              ,
    c16              ,
    c17              ,
    c18              ,
    c19              ,
    c20              ,
    c21              ,
    c22              ,
    c23              ,
    c24              ,
    c25              ,
    c26              ,
    c27              ,
    c28              ,
    c29              ,
    c30              ,
    c31              
from ".$ServerName."_MissStats
where Timestamp >='".$StartTimestamp."'        
  and Timestamp <'".$EndTimestamp."'        
  ".$filter_clause."
group by
    dbname           ,
    owner            ,
    tabname          ,
    c1               ,
    c2               ,
    c3               ,
    c4               ,
    c5               ,
    c6               ,
    c7               ,
    c8               ,
    c9               ,
    c10              ,
    c11              ,
    c12              ,
    c13              ,
    c14              ,
    c15              ,
    c16              ,
    c17              ,
    c18              ,
    c19              ,
    c20              ,
    c21              ,
    c22              ,
    c23              ,
    c24              ,
    c25              ,
    c26              ,
    c27              ,
    c28              ,
    c29              ,
    c30              ,
    c31              
  ".$sort_clause."
  set rowcount 0"; }
else {
$query = "set rowcount ".$rowcount."
select
    ms1.dbname           ,
    ms1.owner            ,
    ms1.tabname          ,
    ms2.CNT          ,
    c1               ,
    c2               ,
    c3               ,
    c4               ,
    c5               ,
    c6               ,
    c7               ,
    c8               ,
    c9               ,
    c10              ,
    c11              ,
    c12              ,
    c13              ,
    c14              ,
    c15              ,
    c16              ,
    c17              ,
    c18              ,
    c19              ,
    c20              ,
    c21              ,
    c22              ,
    c23              ,
    c24              ,
    c25              ,
    c26              ,
    c27              ,
    c28              ,
    c29              ,
    c30              ,
    c31
from ".$ServerName."_MissStats ms1,(select sum(counter) as CNT from ".$ServerName."_MissStats group by dbname,owner,tabname) ms2
where Timestamp >='".$StartTimestamp."'
  and Timestamp <'".$EndTimestamp."'
  ".$filter_clause."
  ".$sort_clause."
  set rowcount 0";
}

?>








<?php
$query = "
select Ts=convert(varchar,Timestamp,109), 
  TotWaitTime_s= WaitTime,
  AvgWaitTime_ms=(1000.*WaitTime) / (1.*Waits)
from ".$ServerName."_SysWaits
where WaitEventID=".$WaitEventID."
and Timestamp >= '".$StartTimestamp."' and Timestamp <= '".$EndTimestamp."'
order by Timestamp";
?>
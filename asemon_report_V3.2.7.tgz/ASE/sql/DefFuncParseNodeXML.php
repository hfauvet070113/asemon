<?php

  // Function for parsing XML Plan
  function parseNode($xmlNode, $level) {
    $name = "";
    $formattedXML = "";
    if ($level == 1) $name = "ROOT: ";
    $name = $name.$xmlNode->getName();
    //$formattedXML = $formattedXML. $indent.$name."\n";

    $indent = "";
    for ($i=0; $i < $level-1 ; $i++) $indent = $indent."&nbsp;&nbsp;&nbsp;&nbsp;|";

    if ( $name=="WorkTable" ) {
        $formattedXML = $formattedXML. $indent."  Using ".$xmlNode->wtObjName." for internal storage.\n";
        return $formattedXML;
    }

    $formattedXML = $formattedXML. $indent."\n";
    $indent = $indent."&nbsp;&nbsp;&nbsp;&nbsp;|";
    //$formattedXML = $formattedXML. $indent."level=".$level."\n";


    $formattedXML = $formattedXML. $indent.$name. " Operator (VA = ".$xmlNode->VA.")\n";
    $est = $xmlNode->est;
    $formattedXML = $formattedXML. $indent."&nbsp;&nbsp;(est: "." rowCnt=".$est->rowCnt.", lio=".$est->lio.", pio=".$est->pio.", rowSz=".$est->rowSz.")\n";
    $act = $xmlNode->act;
    if ($act != null)
      if ($act->rowCnt != "") {
        $formattedXML = $formattedXML. $indent."&nbsp;&nbsp;(act: "." rowCnt=".$act->rowCnt;
        if ($act->lio != "")
          $formattedXML = $formattedXML.", lio=".$act->lio;
        if ($act->pio != "")
          $formattedXML = $formattedXML.", pio=".$act->pio;
        if ($act->rowSz != "")
          $formattedXML = $formattedXML.", rowSz=".$act->rowSz;
        $formattedXML = $formattedXML.")\n";
      }
    
    if ( ($name=="Update")||($name=="Delete") ) {
        $formattedXML = $formattedXML. $indent."  The update mode is ".$xmlNode->updateMode."\n";
    }


    if ($xmlNode->arity != "") {
      $arity = $xmlNode->arity;
      $level++;
      foreach ($xmlNode->children() as $child) {
        switch ($child->getName()) {
          case "VA" : break;
          case "est" : break;
          case "act" : break;
          case "arity" : break;
          case "objName" : break;
          case "dataIOSizeInKB" : break;
          case "updateMode" : break;
          default : $formattedXML = $formattedXML.parseNode ($child, $level);
        
        }
      }
    }
    switch ($name) {
      case "Update" :
      case "Delete" :
        $formattedXML = $formattedXML. $indent."\n";
        $formattedXML = $formattedXML. $indent."  TO TABLE\n";
        $formattedXML = $formattedXML. $indent."  ".$xmlNode->objName."\n";
        $formattedXML = $formattedXML. $indent."  Using I/O Size ".$xmlNode->dataIOSizeInKB." Kbytes for data pages.\n";
        break;
        
      case "TableScan" :
      case "IndexScan" :
        // Display final node
        foreach ($xmlNode->children() as $child) {
          switch ($child->getName()) {
            case "VA" : break;
            case "est" : break;
            case "act" : break;
            case "perKey" :
              $formattedXML = $formattedXML. $indent."&nbsp;&nbsp;&nbsp;&nbsp;Key : ".$child->keyCol." (".$child->keyOrder.")\n";
              break;
            case "partitionInfo" :
              $formattedXML = $formattedXML. $indent."&nbsp;&nbsp;&nbsp;&nbsp;partitionCount : ".$child->partitionCount."\n";
              $formattedXML = $formattedXML. $indent."&nbsp;&nbsp;&nbsp;&nbsp;dynamicPartitionElimination : ".$child->dynamicPartitionElimination."\n";
              break;
            default :
              $formattedXML = $formattedXML. $indent."&nbsp;&nbsp;".$child->getName()." : ".$child."\n";
          
          }
        }
    }
    
    return $formattedXML;

  }

?>
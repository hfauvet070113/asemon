<?php
if (!isset($filter_clause) ) $filter_clause = "";
if (!isset($sort_clause) )   $sort_clause = "";


$query = "
select Timestamp,ParamName,CfgValue,RunValue
from ".$srvname."_AseParams
where ParamName='".$ParamName."'
  ".$sort_clause."
";


?>
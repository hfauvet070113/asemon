<?php        
    if (!isset($filter_clause) ) $filter_clause = "";
    if (!isset($sort_clause) )   $sort_clause = "";

$query = 
"set rowcount ".$rowcount."
select A.bootcount, A.spid, A.class, 
       minTsCurs=convert (varchar, A.minTs, 111)+' '+convert (varchar, A.minTs, 108)+'.'+convert(varchar, datepart(ms,A.minTs)), 
       maxTsCurs=convert (varchar, A.maxTs, 111)+' '+convert (varchar, A.maxTs, 108)+'.'+convert(varchar, datepart(ms,A.maxTs)),
       maxOpen=datediff(ss, A.minTs, A.maxTs), 
       A.locktype,A.dbname,A.name,A.context,A.fid,A.loid,A.partitionid,A.page,A.row
from 
  (select distinct bootcount, spid,class, 
     minTs=(select min(Timestamp) from ".$ServerName."_CursLocks where class=C.class and spid=C.spid and bootcount=C.bootcount),
     maxTs=(select max(Timestamp) from ".$ServerName."_CursLocks where class=C.class and spid=C.spid and bootcount=C.bootcount),
     locktype,dbname,name,context,fid,loid,partitionid,page,row
   from ".$ServerName."_CursLocks C        
   where Timestamp >='".$StartTimestamp."'        
   and Timestamp <'".$EndTimestamp."'
   ".$filter_clause."
   ) A
".$sort_clause."
set rowcount 0";
?>

<?php
  if (!isset($hourfrom)) $hourfrom="0";
  if (!isset($hourto)) $hourto="23";

  // Set Monday as first day of week and Retrieve Trend conf
  //$result=asemon_query("set datefirst 1", $pid);


  // Translate the days clause
  if (!isset($days)) $days='';
  if (($days=='' )||($days=='All days'))  $days_clause='';
  if ($days=='no_weekend')     $days_clause=' and datepart(weekday,dt) in (1,2,3,4,5)'; 
  if ($days=='Monday')         $days_clause=' and datepart(weekday,dt)=1';
  if ($days=='Tuesday')        $days_clause=' and datepart(weekday,dt)=2';
  if ($days=='Wednesday')      $days_clause=' and datepart(weekday,dt)=3';
  if ($days=='Thursday')       $days_clause=' and datepart(weekday,dt)=4';
  if ($days=='Friday')         $days_clause=' and datepart(weekday,dt)=5';
  if ($days=='Saturday')       $days_clause=' and datepart(weekday,dt)=6';
  if ($days=='Sunday')         $days_clause=' and datepart(weekday,dt)=7';

  // Translate the hour clause
  $hour_clause = " and datepart(hour, dt) between ".$hourfrom." and ".$hourto;
  

  $query="set datefirst 1
      select Ts=convert(varchar, convert(datetime,convert(varchar,dt,3),3), 109),
      Value=".$aggfunction."(case when Value <0 then 0 else Value end)  /* Ignore negatives values */
      from ".$ServerName."_Trends
      where TrendID=".$TrendID."
      ".$days_clause."
      ".$hour_clause."
      and dt between '".$StartTimestamp."' and '".$EndTimestamp."'
      group by  convert(datetime,convert(varchar,dt,3),3)
      order by convert(datetime,convert(varchar,dt,3),3)"

?>
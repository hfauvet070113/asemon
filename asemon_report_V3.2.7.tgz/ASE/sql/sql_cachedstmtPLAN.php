<?php
  // retreive all posted params and affect them to variables
  foreach ($_POST as $key => $value)
    @$$key=$value;

  include ("../../COMMON/connectArchiveServer.php");

  $TotalRows = 0;
  $Rows = [];

  $query = "
  select
    Sequence,
    SQLPlan
  from ".$ServerName."_CachedPLN
  where bootcount =".$bootcount."
  and SSQLID =".$SSQLID."
  and Hashkey =".$Hashkey."
  order by 1";

  $result = asemon_query($query,$pid);
  if ($result != false){
    while($row = asemon_fetch_assoc($result)) { 
      $Rows[] = $row; 
      $TotalRows++;
    }
  }

  if ($error == "")
    $data = array(
      'status' => 'success',
      'TotalRows' => $TotalRows,
      'Rows' => $Rows,
      'query' => $query 
      );

  else
    $data = array(
      'status' => 'error',
      'message' => $error,
      'query' => $query
      );

  echo json_encode($data);


?>
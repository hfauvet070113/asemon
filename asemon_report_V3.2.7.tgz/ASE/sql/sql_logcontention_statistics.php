<?php        
$query = "select DBName, sumAppendLog=sum(AppendLogRequests) , sumLogWaits=sum(AppendLogWaits ), 
waitPct= convert(float,sum(AppendLogWaits) )*100/sum(AppendLogRequests)
from ".$ServerName."_OpenDbs          
where Timestamp >='".$StartTimestamp."'        
and Timestamp <'".$EndTimestamp."'
group by DBName order by waitPct desc";
?>

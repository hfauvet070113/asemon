<?php

    if (!isset($filter_clause) ) $filter_clause = "";

if ($support157==1) {
  $sel157cols_agg = ",sumExecutionCount=sum(ExecutionCount),
  sumRequestCnt=sum(RequestCnt),
  avgCPUTime       = case when sum(RequestCnt) = 0 then 0 else sum(1.*CPUTime)/sum(RequestCnt)        end,
  sumCPUTime       = sum(1.*CPUTime),
  avgLogicalReads  = case when sum(RequestCnt) = 0 then 0 else sum(1.*LogicalReads)/sum(RequestCnt)   end,
  sumLogicalReads  = sum(1.*LogicalReads),
  avgExecutionTime = case when sum(RequestCnt) = 0 then 0 else sum(1.*ExecutionTime)/sum(RequestCnt)  end,
  sumExecutionTime = sum(1.*ExecutionTime),
  avgPhysicalReads = case when sum(RequestCnt) = 0 then 0 else sum(1.*PhysicalReads)/sum(RequestCnt)  end,
  sumPhysicalReads = sum(1.*PhysicalReads),
  avgPhysicalWrites= case when sum(RequestCnt) = 0 then 0 else sum(1.*PhysicalWrites)/sum(RequestCnt) end,
  sumPhysicalWrites= sum(1.*PhysicalWrites),
  avgPagesWritten  = case when sum(RequestCnt) = 0 then 0 else sum(1.*PagesWritten)/sum(RequestCnt)   end,
  sumPagesWritten  = sum(1.*PagesWritten),
  sumTempdbRemapCnt=sum(TempdbRemapCnt),
  avgTempdbRemapTime=avg(AvgTempdbRemapTime) ";
}
else {
  $sel157cols_agg = " ";
}



  asemon_query("if object_id('#result') is not null drop table #result",$pid);



  $query = "select
    top 10 ID=identity(4),
    ObjectID   ,
    OwnerUID   ,
    DBID       ,
    NumPlans     =count(distinct PlanID),
    MaxMemUsageKB = max(MemUsageKB),
    LastCompileDate = convert (varchar, max(CompileDate), 111)+' '+convert (varchar, max(CompileDate), 108)+'.'+convert(varchar, datepart(ms,max(CompileDate))),
    ObjectName ,
    ObjectType ,
    OwnerName  ,
    DBName     
  ".$sel157cols_agg."
  into #result
  from ".$ServerName."_CachedPrc (index idx)
  where Timestamp >='".$StartTimestamp."'        
  and Timestamp <'".$EndTimestamp."'        
  ".$filter_clause."
  group by ObjectID   ,
    OwnerUID   ,
    DBID       ,
    ObjectName ,
    ObjectType ,
    OwnerName  ,
    DBName     
  order by avgCPUTime desc";

  asemon_query($query, $pid);

?>

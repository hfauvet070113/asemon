<?php
$selrwtime = "";
//$error="rwtime_exists : ".$rwtime_exists." selrwtime avant : ".$selrwtime;
if ($rwtime_exists == 1) {
  $selrwtime = ",
    avgReads_ms=case when sum(1.*Reads)=0 then 0 else sum(ReadTime*1.) / sum(1.*Reads) end ,
    avgWrites_ms=case when sum(1.*Writes)=0 then 0 else sum(WriteTime*1.) / sum(1.*Writes) end
    ";
}
//$error=$error." selrwtime apres : ".$selrwtime;

if (!isset($filter_clause) ) $filter_clause = "";
if (!isset($sort_clause) )   $sort_clause = "";

$query = "
  set rowcount ".$rowcount."
  select 
  Device=substring(LogicalName,1,30),
  PReads= sum (convert(numeric(20,0),Reads)), 
  AReads = sum (convert(numeric(20,0),APFReads )), 
  PWrites= sum (convert(numeric(20,0),Writes)), 
  avgserv_ms=sum(IOTime*1.) / sum(1.*Reads+Writes),
  DevSemaphoreContentionPCT=case when sum(1.*DevSemaphoreRequests)<=0. then -1. else sum(DevSemaphoreWaits*100.)/sum(DevSemaphoreRequests*1.) end
  ".$selrwtime."
  from ".$ServerName."_DevIO
  where Timestamp >='".$StartTimestamp."'        
  and Timestamp <'".$EndTimestamp."' 
  ".$filter_clause."
  and LogicalName not like 'SYSDEV$[_][_]%' /* ignore crazy values for devices of archive db's */
  group by LogicalName
  having sum(convert(numeric(20,0),1.*Reads+Writes)) >0
".$sort_clause."
  set rowcount 0";
?>

<?php
  if ( !isset($groupByName) ) $groupByName="";

  // check if it is the new version (better compression of fldname, Interval col no longer needed, new row with grpname='Z' and field_id=0 contains Interval value)
  $query = "if exists (select 1 from ".$ServerName."_SysMon
                       where Timestamp >='".$StartTimestamp."'
                         and Timestamp <='".$EndTimestamp."'
                         and grpname='Z' and field_id=0)
            select res=1
            else select res=0";
  $result = asemon_query($query, $pid);
  $row = asemon_fetch_assoc($result);
  if ($row["res"] == 1)
      include ("sql_spinlocks_statistics_newversion.php");
  else 
      include ("sql_spinlocks_statistics_oldversion.php");

?>

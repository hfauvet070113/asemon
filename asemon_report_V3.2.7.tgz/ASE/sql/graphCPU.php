<?php
  if (!isset($cpu_offset) ) $cpu_offset = "";

if ($cpu_offset == "") 
  $query = "
  select 
     Ts=convert(varchar,Timestamp,109)
    ,avgCpu=avg(convert(float,UserCPUTime*1000)/Interval*100)
    ,avgCpuSystem=avg(convert(float,SystemCPUTime*1000)/Interval*100)
  from ".$ServerName."_Engines
  where Timestamp >='".$StartTimestamp."'
  and Timestamp <='".$EndTimestamp."'
  and ContextSwitches>0
  group by Timestamp
  order by Timestamp";
else
  $query = "
  select 
     Ts=convert(varchar,t1.Timestamp,109)
    ,avgCpu=avg(convert(float,t1.UserCPUTime*1000)/t1.Interval*100)
    ,avgCpuSystem=avg(convert(float,t1.SystemCPUTime*1000)/t1.Interval*100)
    ,preavgCpu=(select avg(convert(float,t3.UserCPUTime*1000)/t3.Interval*100) from ".$ServerName."_Engines t3
          where t3.Timestamp =
          (select max(t2.Timestamp) from ".$ServerName."_Engines t2 where t2.Timestamp < dateadd(wk, -1, t1.Timestamp)
          )
    )
  from ".$ServerName."_Engines t1
  where t1.Timestamp >='".$StartTimestamp."'
  and t1.Timestamp <='".$EndTimestamp."'
  and t1.ContextSwitches>0
  group by t1.Timestamp
  order by t1.Timestamp";
?>
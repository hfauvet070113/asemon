<?php

  if (!isset($filter_clause) ) $filter_clause = "";
  if (!isset($sort_clause) )   $sort_clause = "";

$query = "select
Flags                   = Flags              ,
ConfigNum               = ConfigNum          ,
MemoryPoolName          = MemoryPoolName          ,
PoolType                = PoolType                ,
PoolOwnerKPID           = PoolOwnerKPID           ,
ConfigOption            = B.name                  ,
TotalSize               = MAX(TotalSize)          ,
MAX_UsedSize            = MAX(UsedSize )          ,
MAX_FreeSize            = MAX(FreeSize )          ,
SUM_NumAllocs           = SUM(delta_NumAllocs)    ,
SUM_NumFrees            = SUM(delta_NumFrees )    ,
SUM_NumSleeps           = SUM(delta_NumSleeps)    ,
SUM_NumSearches         = SUM(delta_NumSearches)  ,
SUM_NumRetries          = SUM(delta_NumRetries )  ,
AVG_ItemSize            = AVG(ItemSize)           ,
MinNumItems             = MIN(MinNumItems)        ,
MaxNumItems             = MAX(MaxNumItems)        ,
MAX_NumUsedItems        = MAX(NumUsedItems)       ,
NumItemsUsedHWM         = MAX(NumItemsUsedHWM)    ,
MinUsedItemSize         = MIN(MinUsedItemSize)    ,
AvgUsedItemSize         = AVG(AvgUsedItemSize)    ,
MaxUsedItemSize         = MAX(MaxUsedItemSize)    ,
MAX_NumUsedItemsMinSize = MAX(NumUsedItemsMinSize),
MAX_NumUsedItemsMaxSize = MAX(NumUsedItemsMaxSize),
MAX_NumFreeItems        = MAX(NumFreeItems)       ,
MinFreeItemSize         = MIN(MinFreeItemSize)    ,
AvgFreeItemSize         = AVG(AvgFreeItemSize)    ,
MaxFreeItemSize         = MAX(MaxFreeItemSize)    ,
MAX_NumFreeItemsMinSize = MAX(NumFreeItemsMinSize),
MAX_NumFreeItemsMaxSize = MAX(NumFreeItemsMaxSize),
MAX_NumBlocks           = MAX(NumBlocks)          ,
MAX_MemSize1            = MAX(MemSize1         )  ,
MAX_NumUsedItemsSize1   = MAX(NumUsedItemsSize1)  ,
MAX_NumFreeItemsSize1   = MAX(NumFreeItemsSize1)  ,
MAX_MemSize2            = MAX(MemSize2         )  ,
MAX_NumUsedItemsSize2   = MAX(NumUsedItemsSize2)  ,
MAX_NumFreeItemsSize2   = MAX(NumFreeItemsSize2)  
from ".$ServerName."_MemUsage A left outer join 
    (select config,name from ".$ServerName."_SysConf where Timestamp =(select max(Timestamp) from ".$ServerName."_SysConf where Timestamp <'".$EndTimestamp."')) B 
     on A.ConfigNum=B.config
where Timestamp >='".$StartTimestamp."'
and Timestamp <'".$EndTimestamp."'
".$filter_clause."
group by Flags, ConfigNum, MemoryPoolName, PoolType,PoolOwnerKPID,B.name
".$sort_clause;
?>

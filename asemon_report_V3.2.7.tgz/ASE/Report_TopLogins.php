<div class="ASE-Statements">
  <center>
  <div class="maingrid_dashboard">
    <H2>Top logins order by CPU time descending</H2>
    <div id="graphTopLogins_CPU" class="chart_nots" style="width:998px;height:300px;margin-bottom: 20px;" > </div>

    <H2>Top logins order by IO descending</H2>
    <div id="graphTopLogins_IO" class="chart_nots" style="width:998px;height:300px;margin-bottom: 20px;" > </div>

  </div>
  </center>


<?php
  // This php section is in this DIV to allow display of "echo" messages (for debug)
  // echo "pid=".$pid."<br>";

  $InReport=true;  // Used in getgraphdata_xxxx


  // Check some table/col existance
  $support157=0;
  if (in_array("ClientName",$SRVcatalog[$ServerName."_StmtStat"])) $support157 = 1;
  //echo "support157=".$support157."<br>";
  




  
  $rowcount = 10;
  
  
  $group = 'login';
  $indicator = 'cpu';
  include ('ASE/sql/graphPieProcess.php');
  $query_sql_top_logins_CPU = $query;
  //echo "query=".$query."<br>";
  $result = asemon_query($query_sql_top_logins_CPU, $pid);
  include ("COMMON/getgraphdata_nots.php");
  $graphLoginsCPUdataJSON = addslashes(json_encode($data));


  $group = 'login';
  $indicator = 'physreads';
  include ('ASE/sql/graphPieProcess.php');
  $query_sql_top_logins_IO = $query;
  //echo "query=".$query."<br>";
  $result = asemon_query($query_sql_top_logins_IO, $pid);
  include ("COMMON/getgraphdata_nots.php");
  $graphLoginsIOdataJSON = addslashes(json_encode($data));



  
?>







</div>

<script type="text/javascript">

  var SRVcatalog = JSON.parse('<?php echo $SRVcatalogJSON     ?>');


  var height =    $('#page-content').innerHeight() - 55;
 // var colors = ['#2f7ed8', '#8bbc21', '#0d233a', '#910000', '#1aadce', 
 //  '#492970', '#f28f43', '#77a1e5', '#c42525', '#a6c96a'];
  var colors = [
      'rgb(135,206,235)',
      'rgb(50,205,50)',
      'rgb(186,85,211)',
      'rgb(240,128,128)',
      'rgb(70,130,180)',
      'rgb(154,205,50)',
      'rgb(64,224,208)',
      'rgb(255,105,180)',
      'rgb(240,230,140)',
      'rgb(210,180,140)',
               ];


  var graphLoginsCPUdata = JSON.parse('<?php echo $graphLoginsCPUdataJSON     ?>');
  var graphLoginsIOdata = JSON.parse('<?php echo $graphLoginsIOdataJSON     ?>');

  for (var i=0; i<graphLoginsCPUdata.series[0].length; i++) {
    if (graphLoginsCPUdata.series[0][i]==null) 
      graphLoginsCPUdata.series[0][i]='UNKNOWN';
  }
  for (var i=0; i<graphLoginsIOdata.series[0].length; i++) {
    if (graphLoginsIOdata.series[0][i]==null) 
      graphLoginsIOdata.series[0][i]='UNKNOWN';
  }


  Highcharts.chart('graphTopLogins_CPU', {

    title: {
      text: 'Top logins per total CPU'
    },
    colors: colors,
    tableName : 'CnxActiv',
    chart: {
        type: 'column',
        spacingLeft: 50,
    },
    legend: {
      enabled: false
    },
    xAxis: {
      title: {
            enabled: true,
            text: 'UserName',
            style: {
                fontWeight: 'normal'
            }
        },
       categories: graphLoginsCPUdata.series[0]
    },
    yAxis: {
      min: 0,
      title: {
            enabled: true,
            text: 'CpuTime (ms)',
            style: {
                fontWeight: 'normal'
            }
      }/*,
      labels: {
            format: '{value} ms'
      }*/
    },
    plotOptions: {
        series: {
            animation: false
        }
    },
    series: [
      {
        name: 'cpu',
        colorByPoint: true,
        pointPadding: 0,
        groupPadding: 0,
        borderWidth: 0,
        shadow: false,
        data: graphLoginsCPUdata.series[1]
      }
    ],
    credits: {
        enabled: false
    }
  
  });

  Highcharts.chart('graphTopLogins_IO', {

    title: {
      text: 'Top IO per logins'
    },
    colors: colors,
    tableName : 'CnxActiv',
    chart: {
        type: 'column',
        spacingLeft: 50,
    },
    legend: {
      enabled: false
    },
    xAxis: {
      title: {
            enabled: true,
            text: 'UserName',
            style: {
                fontWeight: 'normal'
            }
        },
       categories: graphLoginsIOdata.series[0]
    },
    yAxis: {
      min: 0,
      title: {
            enabled: true,
            text: 'PhysicalReads',
            style: {
                fontWeight: 'normal'
            }
      }/*,
      labels: {
            format: '{value}'
      }*/
    },
    plotOptions: {
        series: {
            animation: false
        }
    },
    series: [
      {
        name: 'physreads',
        colorByPoint: true,
        pointPadding: 0,
        groupPadding: 0,
        borderWidth: 0,
        shadow: false,
        data: graphLoginsIOdata.series[1]
      }
    ],
    credits: {
        enabled: false
    }
  
  });





</script>
<div class="ASE-SysWaits nondisplay">
  <center>
  <div class="maingrid">
    <div ID="SysWaits_statistics" class="asemongrid singlegrid" ></div>
    <div ID="SysWaits_statistics_mess" class="nodisplay" ></div>
  </div>
  </center>
</div>

<script type="text/javascript">
  var height =    $('#page-content').innerHeight() - 55;

  if (typeof detail_type != 'undefined')
    $('.ASE-SysWaits').removeClass('nondisplay');

  $('#SysWaits_statistics').asemonGrid({
    'title' : 'Syswaits statistics',
    'width' : '100%',
    'height' : height,
//    'rowsheight': 80,
    'rowcount': 200,
    'filterable': true,
    'showaggregates': true,
    'buttons' : [
       {
        'id': 'GraphBTN',
        'text': 'Graphs',
        'onclick' : function ( ) {
          openWindow ("detail_page.php", {ARContextJSON: ARContext, 'displaylevel' : 1, 'detail_type': 'SYSWAITSGRAPHS'});
        }
       }
     ],
    'querydata': {'queryfile' : '', 'default_order_by' : 'SumWaitTime desc'},
    'beforeRefresh': function() {refresh_SysWaits_statistics (this[0]);},
    'datafieldsMapping': {'ClassDesc': 'C.Description', 'EventDesc': 'I.Description', 'WaitEventID': 'I.WaitEventID'},
    'datafields': [
           { name: 'WaitEventID',    type: 'number'},
           { name: 'ClassDesc',      type: 'string'},
           { name: 'EventDesc',      type: 'string'},
           { name: 'SumWaitTime',    type: 'number'},
           { name: 'Sumwaits',       type: 'number'},
           { name: 'AvgWaitTime_ms', type: 'number'}
    ],
    'columns': [
           { text: 'WaitEventID',     datafield: 'WaitEventID',    width: 90,  filterable: true, cellsformat: 'd0',  cellsalign: 'right'},
           { text: 'ClassDesc',       datafield: 'ClassDesc',      width: 250,  filterable: true},
           { text: 'EventDesc',       datafield: 'EventDesc',      width: 350,  filterable: true},
           { text: 'WaitTime(s)',     datafield: 'SumWaitTime',    width: 90,   filterable: false, cellsformat: 'd',  cellsalign: 'right', aggregates: ['sum']},
           { text: 'Waits',           datafield: 'Sumwaits',       width: 90,   filterable: false, cellsformat: 'd',  cellsalign: 'right', aggregates: ['sum']},
           { text: 'AvgWaitTime(ms)', datafield: 'AvgWaitTime_ms', width: 150,   filterable: false, cellsformat: 'd2',  cellsalign: 'right'},
           { text: '', width: 25,  filterable: false}
    ]
  });

  function refresh_SysWaits_statistics (grid) {
    var asemondata = jQuery.data(grid, 'asemondata');
    var SysWaitsExists = 0;
    var WEvInfExists = 0;
    var WClassInfExists = 0;


    if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_SysWaits') )  )
      SysWaitsExists = 1;
    if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_WEvInf') )  )
      WEvInfExists = 1;
    if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_WClassInf') )  )
      WClassInfExists = 1;
    
    if ( ( SysWaitsExists == 0) || ( WEvInfExists == 0) || ( WClassInfExists == 0) ) {
      $('#SysWaits_statistics').hide();
      $('#SysWaits_statistics_mess').show();
      $('#SysWaits_statistics_mess').html('<p>Some collectors are not activated for server '+ARContext.ServerName+'.<P> Add  SysWaits.xml, WEvInf.xml nad WClassInf.xml in the asemon_logger config file</p>');
      $.extend(asemondata, {'querydata' : {'queryfile' : '', 'query': ''}});
      return;
    }
    else {
      $('#SysWaits_statistics').show();
      $('#SysWaits_statistics_mess').hide();
    }


    $(grid).asemonGrid({'querydata': {'queryfile' : '../ASE/sql/sql_SysWaits_statistics.php'}});
   
  }

  onArchCnxOpened = function(){
    $('.ASE-SysWaits').removeClass('nondisplay');
    $('#SysWaits_statistics').asemonGrid('refresh');
  }

</script>
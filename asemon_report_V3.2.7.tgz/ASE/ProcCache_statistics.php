<div class="ASE-ProcCache nondisplay">
  <center>
  <div class="maingrid">
    <div ID="procCache_statistics" class="asemongrid singlegrid" ></div>
    <div ID="procCache_statistics_mess" class="nodisplay" >  </div>
  </div>
  </center>
</div>


<script type="text/javascript">

  var height =    $('#page-content').innerHeight() - 55;

  if (typeof detail_type != 'undefined')
    $('.ASE-ProcCache').removeClass('nondisplay');

  $('#procCache_statistics').asemonGrid({
    'title' : 'Objects in Procedures Cache',
    'width' : '100%',
    'height' : height,
    'rowcount': '200',
    'editable': false,
    'filterable': true,
    'sortable': true,
    'altrows': true,
    'showaggregates': false,
    'cursor' : 'pointer',
    'beforeRefresh': function() {refresh_procCache_statistics (this[0]);},
    //'afterRefresh': function() {restore_filters (this);},
    'datafields': [
     { name: 'Timestamp', type: 'string'}
     ],
    'columns': [
     { text: 'Timestamp',         datafield: 'Timestamp',         width: 150, filterable: true}
     ],
    'datafieldsMapping' : { },
    'datafieldsTS' : ['Timestamp'],
    'querydata' : {
                     'queryfile' : '',
                     'group' : 'Y',
                     'default_order_by': 'ObjectName'
                  },
    'buttons' : [
       {
        'id': 'groupBTN',
        'text': 'Show all captures',
        'onclick' : function ( ) {
          var deforderby;
          if (this.value == 'Group by ObjectName') {
            this.value = 'Show all captures';
            group = 'Y';
            deforderby = 'ObjectName';
          }
          else {
            this.value = 'Group by ObjectName';
            group = 'N';
            deforderby = 'Timestamp';
          }
          var selector = $('#procCache_statistics')[0];
          var asemondata = jQuery.data( selector , 'asemondata');
          $(selector).jqxGrid('removesort');
          $(selector).jqxGrid('sortby', '', '');
          $.extend(asemondata.querydata, {'group' : group, 'default_order_by': deforderby});
          asemondata.sort_clause = "";

          // Preserve filters
          //var filtersinfo = $(selector).jqxGrid('getfilterinformation');

          $(selector).asemonGrid('refresh');
        }
       }
     ]
  });


  $("#procCache_statistics").bind('cellclick', function (event) {
    var column = event.args.column;
    var rowindex = event.args.rowindex;
    //alert ("row "+rowindex+" selected");
    
    var rowdata = $('#procCache_statistics').jqxGrid('getrowdatabyid', rowindex);
    if (typeof rowdata == 'undefined') return 0;

    var SQLHashKeyExists=false;
    if (typeof rowdata.SQLHashKey != 'undefined') {
      if (rowdata.SQLHashKey != "") SQLHashKeyExists=true;
    }

    var asemondata = jQuery.data(this, 'asemondata');

    if (column.datafield == 'image') {
      if (SQLHashKeyExists)
        openWindowFromGrid ("#procCache_statistics", "detail_page.php", {ARContextJSON: ARContext, 'displaylevel' : 1, 'detail_type': 'TRENDSTMT', 'SQLHashKey': rowdata.SQLHashKey});
      else
        openWindowFromGrid ("#procCache_statistics", "detail_page.php", {ARContextJSON: ARContext, 'displaylevel' : 1, 'detail_type': 'TRENDPROC', 'ProcName': rowdata.ObjectName, 'DBID': rowdata.DBID});
    }
    else {
//      if ( (asemondata.currentRowSelected == -1) || (asemondata.currentRowSelected != rowindex)) {
        if (rowdata.ObjectName[0] == "*") {
          if (asemondata.querydata.group == 'N')
            openWindowFromGrid ("#procCache_statistics", "detail_page.php", {ARContextJSON: ARContext, 'displaylevel' : 2, 'detail_type': 'CACHEDSTMT', 'ProcName': rowdata.ObjectName, 'SSQLID': rowdata.ObjectID, 'CompileDate': rowdata.CDate, 'PlanID': rowdata.PlanID});
          else
            openWindowFromGrid ("#procCache_statistics", "detail_page.php", {ARContextJSON: ARContext, 'displaylevel' : 1, 'detail_type': 'CACHEDSTMT', 'ProcName': rowdata.ObjectName, 'SSQLID': rowdata.ObjectID});
        }
        else
          openWindowFromGrid ("#procCache_statistics", "detail_page.php", {ARContextJSON: ARContext, 'displaylevel' : 1, 'detail_type': 'PROCDETAIL', 'ProcName': rowdata.ObjectName, 'DBID': rowdata.DBID});
//        asemondata.currentRowSelected = rowindex;
//      }
    }

  });

  function restore_filters (grid) {
    var asemondata = jQuery.data(grid, 'asemondata');
    if ((typeof asemondata.filters != 'undefined') && (asemondata.filters.length > 0) ) {
      //restore filters
      var aSavedFilter;
      var aFilterGroup;
      var aFilter;
      for (var i = 0 ; i < asemondata.filters.length; i++) {
        aSavedFilter = asemondata.filters[i];
        aFilterGroup = new $.jqx.filter();
        aFilter = aFilterGroup.createfilter(aSavedFilter.filters[0].type, aSavedFilter.filters[0].value, aSavedFilter.filters[0].condition);
        aFilterGroup.addfilter(0, aFilter);
        $(grid).jqxGrid('addfilter', aSavedFilter.datafield, aFilterGroup);
      }
    }
    $(grid).jqxGrid('applyfilters');
  }

  function refresh_procCache_statistics (grid) {
    var asemondata = jQuery.data(grid, 'asemondata');
    var CachedPrcExists = false;
    var support157 = 0;
    var cols = [];
    var fields = [];
    var supportSQLHashKey = 0;
    
//    asemondata.currentRowSelected = -1;

    if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_CachedPrc') )  )
      CachedPrcExists = true;
    if ( (ARContext.ServerName!="") && ( existColumn(ARContext.ServerName+'_CachedPrc', 'ExecutionTime') )  ) {
      support157 = 1;
    }
    if ( (ARContext.ServerName!="") && ( existColumn(ARContext.ServerName+'_StmtStat', 'SQLHashKey') )  ) {
      supportSQLHashKey = 1;
    }

    if ( !CachedPrcExists) {
      $('#procCache_statistics').hide();
      $('#procCache_statistics_mess').show();
      $('#procCache_statistics_mess').html('<p>Table '+ARContext.ServerName+'_CachedPrc does not exists</p><p>Activate Asemon_logger\'s collector : "CachedPrc.xml"</p>');
      $.extend(asemondata, {'querydata' : {'queryfile' : '', 'query': ''}});
      return;
    }
    else {
      $('#procCache_statistics').show();
      $('#procCache_statistics_mess').hide();
    }



    var cellsrenderer = function (row, column, value, defaultHtml) {
      var rowdata = {};
      if (column == 'image') {
        var element = $(defaultHtml);
        var displayIcon=false;
        
        rowdata = $('#procCache_statistics').jqxGrid('getrowdatabyid', row);

        if (typeof rowdata.ObjectName != 'undefined') {
          if (rowdata.ObjectName[0] != '*') displayIcon=true;
        }
          
        if (typeof rowdata.SQLHashKey != 'undefined') {
          if (rowdata.SQLHashKey != "") displayIcon=true;
        }
        if (typeof rowdata.ObjectName != 'undefined') {
          if (displayIcon)
            return '<i class="fa fa-area-chart" style="padding: 5px; color: green" TITLE="Display procedure\'s trends"></i>';
          else {
            //element.css({ 'background-color': '#e0e9f5', 'width': '100%', 'height': '100%', 'margin': '0px', 'padding' : '4px' });
            //return element[0].outerHTML; 
            return defaultHtml; 
          }
        }
      }
      else
        return defaultHtml;
    }

    fields_ungrouped = [
           { name: 'Timestamp',  type: 'string'},
           { name: 'ObjectID',   type: 'number'},
           { name: 'OwnerUID',   type: 'number'},
           { name: 'DBID',       type: 'number'},
           { name: 'PlanID',     type: 'number'},
           { name: 'MemUsageKB', type: 'number'},
           { name: 'CDate',      type: 'string'},
           { name: 'ObjectName', type: 'string'},
           { name: 'ObjectType', type: 'string'},
           { name: 'OwnerName',  type: 'string'},
           { name: 'DBName',     type: 'string'}
    ];
    cols_ungrouped= [
           { text: '',            datafield: 'image',      width: 25, filterable: false, cellsrenderer: cellsrenderer, editable: false},
           { text: 'Timestamp',   datafield: 'Timestamp',  width: 130, filterable: true},
           { text: 'ObjectID',    datafield: 'ObjectID',   width: 90, filterable: true, cellsalign: 'right'},
           { text: 'OwnerUID',    datafield: 'OwnerUID',   width: 70, filterable: true, cellsalign: 'right'},
           { text: 'DBID',        datafield: 'DBID',       width: 50, filterable: true, cellsalign: 'right'},
           { text: 'PlanID',      datafield: 'PlanID',     width: 50, filterable: true, cellsalign: 'right'},
           { text: 'MemUsageKB',  datafield: 'MemUsageKB', width: 90, filterable: false, cellsformat: 'd', cellsalign: 'right'},
           { text: 'CompileDate', datafield: 'CDate',      width: 150, filterable: true},
           { text: 'ObjectName',  datafield: 'ObjectName', width: 150, filterable: true},
           { text: 'ObjectType',  datafield: 'ObjectType', width: 90, filterable: true},
           { text: 'OwnerName',   datafield: 'OwnerName',  width: 90, filterable: true},
           { text: 'DBName',      datafield: 'DBName',     width: 90, filterable: true}
    ];
    fields157_ungrouped = [
           { name: 'ExecutionCount',     type: 'number'},
           { name: 'RequestCnt',         type: 'number'},
           { name: 'avgCPUTime',         type: 'number'},
           { name: 'sumCPUTime',         type: 'number'},
           { name: 'avgLogicalReads',    type: 'number'},
           { name: 'sumLogicalReads',    type: 'number'},
           { name: 'avgExecutionTime',   type: 'number'},
           { name: 'sumExecutionTime',   type: 'number'},
           { name: 'avgPhysicalReads',   type: 'number'},
           { name: 'sumPhysicalReads',   type: 'number'},
           { name: 'avgPhysicalWrites',  type: 'number'},
           { name: 'sumPhysicalWrites',  type: 'number'},
           { name: 'avgPagesWritten',    type: 'number'},
           { name: 'sumPagesWritten',    type: 'number'},
           { name: 'TempdbRemapCnt',     type: 'number'},
           { name: 'AvgTempdbRemapTime', type: 'number'}
    ];
    cols157_ungrouped= [
           { text: 'ExecutionCount',        datafield: 'ExecutionCount',     width: 90, filterable: false, cellsformat: 'd',  cellsalign: 'right'},
           { text: 'RequestCnt',            datafield: 'RequestCnt',         width: 90, filterable: false, cellsformat: 'd',  cellsalign: 'right'},
           { text: 'avgCPUTime_ms',         datafield: 'avgCPUTime',         width: 90, filterable: false, cellsformat: 'd2', cellsalign: 'right'},
           { text: 'sumCPUTime_ms',         datafield: 'sumCPUTime',         width: 90, filterable: false, cellsformat: 'd',  cellsalign: 'right'},
           { text: 'avgLogicalReads',       datafield: 'avgLogicalReads',    width: 90, filterable: false, cellsformat: 'd2', cellsalign: 'right'},
           { text: 'sumLogicalReads',       datafield: 'sumLogicalReads',    width: 90, filterable: false, cellsformat: 'd',  cellsalign: 'right'},
           { text: 'avgExecTime_ms',        datafield: 'avgExecutionTime',   width: 90, filterable: false, cellsformat: 'd2', cellsalign: 'right'},
           { text: 'sumExecTime_ms',        datafield: 'sumExecutionTime',   width: 90, filterable: false, cellsformat: 'd',  cellsalign: 'right'},
           { text: 'avgPhysicalReads',      datafield: 'avgPhysicalReads',   width: 90, filterable: false, cellsformat: 'd2', cellsalign: 'right'},
           { text: 'sumPhysicalReads',      datafield: 'sumPhysicalReads',   width: 90, filterable: false, cellsformat: 'd',  cellsalign: 'right'},
           { text: 'avgPhysicalWrites',     datafield: 'avgPhysicalWrites',  width: 90, filterable: false, cellsformat: 'd2', cellsalign: 'right'},
           { text: 'sumPhysicalWrites',     datafield: 'sumPhysicalWrites',  width: 90, filterable: false, cellsformat: 'd',  cellsalign: 'right'},
           { text: 'avgPagesWritten',       datafield: 'avgPagesWritten',    width: 90, filterable: false, cellsformat: 'd2', cellsalign: 'right'},
           { text: 'sumPagesWritten',       datafield: 'sumPagesWritten',    width: 90, filterable: false, cellsformat: 'd',  cellsalign: 'right'},
           { text: 'TempdbRemapCnt',        datafield: 'TempdbRemapCnt',     width: 90, filterable: false, cellsformat: 'd',  cellsalign: 'right'},
           { text: 'AvgTempdbRemapTime_ms', datafield: 'AvgTempdbRemapTime', width: 90, filterable: false, cellsformat: 'd2', cellsalign: 'right'}
    ];

    fields_grouped = [
           { name: 'ObjectID',        type: 'number'},
           { name: 'OwnerUID',        type: 'number'},
           { name: 'DBID',            type: 'number'},
           { name: 'NumPlans',        type: 'number'},
           { name: 'MaxMemUsageKB',   type: 'number'},
           { name: 'LastCompileDate', type: 'string'},
           { name: 'ObjectName',      type: 'string'},
           { name: 'ObjectType',      type: 'string'},
           { name: 'OwnerName',       type: 'string'},
           { name: 'DBName',          type: 'string'}
    ];
    cols_grouped= [
           { text: '',                datafield: 'image',           width: 25, filterable: false, cellsrenderer: cellsrenderer},
           { text: 'ObjectID',        datafield: 'ObjectID',        width: 90, filterable: true, cellsalign: 'right'},
           { text: 'OwnerUID',        datafield: 'OwnerUID',        width: 70, filterable: true, cellsalign: 'right'},
           { text: 'DBID',            datafield: 'DBID',            width: 50, filterable: true, cellsalign: 'right'},
           { text: 'NumPlans',        datafield: 'NumPlans',        width: 70, filterable: false, cellsformat: 'd', cellsalign: 'right'},
           { text: 'MaxMemUsageKB',   datafield: 'MaxMemUsageKB',   width: 90, filterable: false, cellsformat: 'd', cellsalign: 'right'},
           { text: 'LastCompileDate', datafield: 'LastCompileDate', width: 150, filterable: true},
           { text: 'ObjectName',      datafield: 'ObjectName',      width: 150, filterable: true},
           { text: 'ObjectType',      datafield: 'ObjectType',      width: 90, filterable: true},
           { text: 'OwnerName',       datafield: 'OwnerName',       width: 90, filterable: true},
           { text: 'DBName',          datafield: 'DBName',          width: 90, filterable: true}
    ];
    fields157_grouped = [
           { name: 'sumExecutionCount',     type: 'number'},
           { name: 'sumRequestCnt',         type: 'number'},
           { name: 'avgCPUTime',            type: 'number'},
           { name: 'sumCPUTime',            type: 'number'},
           { name: 'avgLogicalReads',       type: 'number'},
           { name: 'sumLogicalReads',       type: 'number'},
           { name: 'avgExecutionTime',      type: 'number'},
           { name: 'sumExecutionTime',      type: 'number'},
           { name: 'avgPhysicalReads',      type: 'number'},
           { name: 'sumPhysicalReads',      type: 'number'},
           { name: 'avgPhysicalWrites',     type: 'number'},
           { name: 'sumPhysicalWrites',     type: 'number'},
           { name: 'avgPagesWritten',       type: 'number'},
           { name: 'sumPagesWritten',       type: 'number'},
           { name: 'sumTempdbRemapCnt',     type: 'number'},
           { name: 'avgTempdbRemapTime',    type: 'number'}
    ];
    cols157_grouped= [
           { text: 'ExecutionCount',        datafield: 'sumExecutionCount',  width: 90, filterable: false, cellsformat: 'd',  cellsalign: 'right'},
           { text: 'RequestCnt',            datafield: 'sumRequestCnt',      width: 90, filterable: false, cellsformat: 'd',  cellsalign: 'right'},
           { text: 'avgCPUTime_ms',         datafield: 'avgCPUTime',         width: 90, filterable: false, cellsformat: 'd2', cellsalign: 'right'},
           { text: 'sumCPUTime_ms',         datafield: 'sumCPUTime',         width: 90, filterable: false, cellsformat: 'd',  cellsalign: 'right'},
           { text: 'avgLogicalReads',       datafield: 'avgLogicalReads',    width: 90, filterable: false, cellsformat: 'd2', cellsalign: 'right'},
           { text: 'sumLogicalReads',       datafield: 'sumLogicalReads',    width: 90, filterable: false, cellsformat: 'd',  cellsalign: 'right'},
           { text: 'avgExecTime_ms',        datafield: 'avgExecutionTime',   width: 90, filterable: false, cellsformat: 'd2', cellsalign: 'right'},
           { text: 'sumExecTime_ms',        datafield: 'sumExecutionTime',   width: 90, filterable: false, cellsformat: 'd',  cellsalign: 'right'},
           { text: 'avgPhysicalReads',      datafield: 'avgPhysicalReads',   width: 90, filterable: false, cellsformat: 'd2', cellsalign: 'right'},
           { text: 'sumPhysicalReads',      datafield: 'sumPhysicalReads',   width: 90, filterable: false, cellsformat: 'd',  cellsalign: 'right'},
           { text: 'avgPhysicalWrites',     datafield: 'avgPhysicalWrites',  width: 90, filterable: false, cellsformat: 'd2', cellsalign: 'right'},
           { text: 'sumPhysicalWrites',     datafield: 'sumPhysicalWrites',  width: 90, filterable: false, cellsformat: 'd',  cellsalign: 'right'},
           { text: 'avgPagesWritten',       datafield: 'avgPagesWritten',    width: 90, filterable: false, cellsformat: 'd2', cellsalign: 'right'},
           { text: 'sumPagesWritten',       datafield: 'sumPagesWritten',    width: 90, filterable: false, cellsformat: 'd',  cellsalign: 'right'},
           { text: 'TempdbRemapCnt',        datafield: 'sumTempdbRemapCnt',  width: 90, filterable: false, cellsformat: 'd',  cellsalign: 'right'},
           { text: 'AvgTempdbRemapTime_ms', datafield: 'avgTempdbRemapTime', width: 90, filterable: false, cellsformat: 'd2', cellsalign: 'right'}
    ];

    fieldSQLHashKey = [
           { name: 'SQLHashKey',     type: 'string'}
           ];
    colSQLHashKey= [
           { text: 'SQLHashKey', datafield: 'SQLHashKey', width: 90, filterable: false, cellsalign: 'right'}
           ];


    if (asemondata.querydata.group == 'N') {
      fields = fields_ungrouped;
      cols = cols_ungrouped;
      if (support157 == 1) {
        fields = fields.concat(fields157_ungrouped);
        cols = cols.concat(cols157_ungrouped);
      }
    }
    else {
      fields = fields_grouped;
      cols = cols_grouped;
      if (support157 == 1) {
        fields = fields.concat(fields157_grouped);
        cols = cols.concat(cols157_grouped);
      }
    }
    
    if (supportSQLHashKey==1) {
      fields = fields.concat(fieldSQLHashKey);
      cols = cols.concat(colSQLHashKey);
    }
    
    asemondata.inRefresh = true;
    $(grid).asemonGrid({
      'querydata' : {
                     'queryfile' : '../ASE/sql/sql_CachedProc_statistics.php',
                     'support157': support157,
                     'supportSQLHashKey': supportSQLHashKey
                    },
      'datafields': fields,
      'columns': cols 
    });
    asemondata.inRefresh = false;
    restore_filters(grid);
  }

  onArchCnxOpened = function(){
    $('.ASE-ProcCache').removeClass('nondisplay');
    $('#procCache_statistics').asemonGrid('refresh');
  }

</script>
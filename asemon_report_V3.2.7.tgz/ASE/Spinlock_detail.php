
<center>
<div id="allinfo">
  <H1> Detail for spinlock :  <?php echo $name; ?> </H1>
  <H3> FldName = <?php echo $fldname; ?>, ID = <?php echo $fid; ?> </H3>

  <div style="display: flex;flex-direction: row;justify-content: space-around;flex-wrap: wrap;align-items: center;">
    <div id="graph_Spinlock_contention"    class="mainchart" style="min-width:700px;width:1200px" > </div>
    <div id="graph_Spinlock_waits"         class="mainchart" style="min-width:700px;width:1200px" > </div>
    <div id="graph_Spinlock_spins"         class="mainchart" style="min-width:700px;width:1200px" > </div>
  </div>
</div>
</center>


<script type="text/javascript">


var name     = "<?php echo $name   ; ?>";
var fldname  = "<?php echo $fldname    ; ?>";
var fid      = "<?php echo $fid  ; ?>";
var field_id_normalized_Exists = "<?php echo $field_id_normalized_Exists  ; ?>";
var field_id_normalized = "<?php echo $field_id_normalized  ; ?>";




onArchCnxOpened = function(){
  var graph;

  graph = $('#graph_Spinlock_contention').highcharts();
  if (typeof graph == 'undefined')
    $('#graph_Spinlock_contention').asemonChart({
    title: {
      text: "Spinlock Contention (%)"
    },
    queryFile : '../ASE/sql/graph_Spinlock_contention.php',
    tableName : 'SysMon',
    data: {
      Field_id: fid,
      fldname: fldname,
      field_id_normalized_Exists: field_id_normalized_Exists,
      field_id_normalized: field_id_normalized
    },
    chart: {
       type: 'area'
    },
    series: [
      { name: 'res'      }
    ],
    legend: {
       enabled: true
    },
    yAxis: {
      minRange: 0.5,
      min : 0 
      }
  
    });
  $('#graph_Spinlock_contention').asemonChart('refresh', threadDelays);   

  graph = $('#graph_Spinlock_waits').highcharts();
  if (typeof graph == 'undefined')
    $('#graph_Spinlock_waits').asemonChart({
    title: {
      text: "Waits"
    },
    queryFile : '../ASE/sql/graph_Spinlock_waits.php',
    tableName : 'SysMon',
    data: {
      Field_id: fid,
      fldname: fldname,
      field_id_normalized_Exists: field_id_normalized_Exists,
      field_id_normalized: field_id_normalized
    },
    chart: {
       type: 'area'
    },
    series: [
      { name: 'res'      }
    ],
    legend: {
       enabled: true
    },
    yAxis: {
      minRange: 0.5,
      min : 0 
      }
  
    });
  $('#graph_Spinlock_waits').asemonChart('refresh', threadDelays);

  graph = $('#graph_Spinlock_spins').highcharts();
  if (typeof graph == 'undefined')
    $('#graph_Spinlock_spins').asemonChart({
    title: {
      text: "Spins"
    },
    queryFile : '../ASE/sql/graph_Spinlock_spins.php',
    tableName : 'SysMon',
    data: {
      Field_id: fid,
      fldname: fldname,
      field_id_normalized_Exists: field_id_normalized_Exists,
      field_id_normalized: field_id_normalized
    },
    chart: {
       type: 'area'
    },
    series: [
      { name: 'res'      }
    ],
    legend: {
       enabled: true
    },
    yAxis: {
      minRange: 0.5,
      min : 0 
      }
  
    });
  $('#graph_Spinlock_spins').asemonChart('refresh', threadDelays);

}
</script>


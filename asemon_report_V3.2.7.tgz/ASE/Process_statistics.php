<div class="ASE-Process nondisplay">
  <center>
  <div class="maingrid">
    <div ID="process_statistics" class="asemongrid singlegrid" ></div>
  </div>
  </center>
</div>


<script type="text/javascript">

  var height =    $('#page-content').innerHeight() - 55;

  if (typeof detail_type != 'undefined')
    $('.ASE-Process').removeClass('nondisplay');


  $('#process_statistics').asemonGrid({
    'title' : 'Process Statistics',
    'width' : '100%',
    'height' : height,
    'rowcount': '200',
    'editable': false,
    'filterable': true,
    'cursor' : 'pointer',
    'beforeRefresh': function() {refresh_process_statistics (this[0]);},
    'datafields': [
     { name: 'Loggedindt', type: 'string'}
     ],
    'columns': [
     { text: 'Loggedindatetime', datafield: 'Loggedindt',     width: 220, filterable: false}
     ],
    'querydata' : {'queryfile' : ''},
    'datafieldsMapping' : {
      'A_Spid'                  : 'A.Spid',
      'HeapMemoryAllocs'        : 'SumHeapMemoryAllocs',    
      'MaxHeapMemoryInUseKB'    : 'MaxHeapMemoryInUseKB',   
      'MaxHeapMemoryReservedKB' : 'MaxHeapMemoryReservedKB',
      'MaxHeapMemoryUsedHWM_KB' : 'MaxHeapMemoryUsedHWM_KB',
      'IOSize1Page'             : 'SumIOSize1Page',         
      'IOSize2Pages'            : 'SumIOSize2Pages',        
      'IOSize4Pages'            : 'SumIOSize4Pages',        
      'IOSize8Pages'            : 'SumIOSize8Pages',        
      'ULCMaxUsage'             : 'MaxULCMaxUsage',         
      'WorkTables'              : 'SumWorkTables',
      'Tempdb_id'               : 'tempdbid',
      'Maxtmp_pages'            : 'A.tmp_pages'
    },
    'datafieldsTS' : [],
    'buttons' : [
       {
        'id': 'UserProgBTN',
        'text': 'Pie Graphs by Usernames and by Program_names',
        'onclick' : function ( ) {
          var selector = $('#process_statistics')[0];
          var asemondata = jQuery.data(selector, 'asemondata');
          var filter_clause=asemondata.filter_clause;
          openWindow ("detail_page.php", {ARContextJSON: ARContext, 'displaylevel' : 1, 'detail_type': 'PROCREPART', 'filter_clause': filter_clause});
        }
       },
       {
        'id': 'UserProgBTN',
        'text': 'Line Graphs by active connections',
        'onclick' : function ( ) {
          var selector = $('#process_statistics')[0];
          var asemondata = jQuery.data(selector, 'asemondata');
          var filter_clause=asemondata.filter_clause;
          openWindow ("detail_page.php", {ARContextJSON: ARContext, 'displaylevel' : 1, 'detail_type': 'PROCACTIVITY', 'filter_clause': filter_clause});
        }
       }
     ]
  });


  $("#process_statistics").on('rowselect', function (event) {
    var rowindex = event.args.rowindex;
    //alert ("row "+rowindex+" selected");

    rowdata = $('#process_statistics').jqxGrid('getrowdatabyid', rowindex);
    if (typeof rowdata == 'undefined') return 0;

    openWindowFromGrid ("#process_statistics", "detail_page.php", {ARContextJSON: ARContext, 'displaylevel' : 1, 'detail_type': 'PROCESS', 'Loggedindatetime': rowdata.Loggedindt, 'Spid': rowdata.A_Spid});

  });



  function refresh_process_statistics (grid) {
    var asemondata = jQuery.data(grid, 'asemondata');
    var dbid_tmp_pages_exists = 0;
    var tmpcols = [];
    var tmpfields = [];
    var colV157SP130Exists = 0;
    var colV16SP03Exists = 0;
    var colV16SP04Exists = 0;
    var V16SP03cols = [];
    var V16SP03fields = [];
    var V16SP04cols = [];
    var V16SP04fields = [];

    if ( (ARContext.ServerName!="") &&( existColumn(ARContext.ServerName+'_CnxActiv', 'tmp_pages') ) && (  existColumn(ARContext.ServerName+'_Cnx', 'tempdbid') ) ){
      dbid_tmp_pages_exists = 1;
      var tmpcols = [];
      var tmpfields = [];
      if (dbid_tmp_pages_exists == 1) {
          tmpfields = [{ name: 'Tempdb_id', type: 'number' },
                    { name: 'Maxtmp_pages', type: 'number'}];
          tmpcols= [{ text: 'Tempdb_id'       , datafield: 'Tempdb_id',      width: 100, cellsformat: 'd', filtertype: 'number', cellsalign: 'right'},
                    { text: 'Maxtmp_pages'    , datafield: 'Maxtmp_pages',   width: 100, filterable: false, cellsformat: 'd', filtertype: 'number', cellsalign: 'right'}];
      }
    }


    if ( (ARContext.ServerName!="") &&( existColumn(ARContext.ServerName+'_CnxActiv', 'QueryOptimizationTime') )  ){
      colV16SP03Exists = 1;
      if (colV16SP03Exists == 1) {
          V16SP03fields = [{ name: 'QueryOptimizationTm', type: 'number' }];
          V16SP03cols   = [{ text: 'QueryOptimizationTime', datafield: 'QueryOptimizationTm', width: 100, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']}];
      }
    }

    if ( (ARContext.ServerName!="") &&( existColumn(ARContext.ServerName+'_CnxActiv', 'prepared_stmt_count') )  ){
      colV16SP04Exists = 1;
      if (colV16SP04Exists == 1) {
          V16SP04fields = [
                  { name: 'prepared_stmt_count',    type: 'number' },
                  { name: 'MaxPrepared_stmt_memusageKb', type: 'number' }
          ];
          V16SP04cols   = [
                  { text: 'prepared_stmt_count', datafield: 'prepared_stmt_count', width: 150, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']},
                  { text: 'MaxPrepared_stmt_memusageKb', datafield: 'MaxPrepared_stmt_memusageKb', width: 150, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['max']}
          ];
      }
    }

    if ( (ARContext.ServerName!="") &&( existColumn(ARContext.ServerName+'_CnxActiv', 'HeapMemoryAllocs') )){
      colV157SP130Exists = 1;
          tmpfields = tmpfields.concat([
            { name: 'SumHeapMemoryAllocs',        type: 'number' },
            { name: 'MaxHeapMemoryInUseKB',       type: 'number' },
            { name: 'MaxHeapMemoryReservedKB',    type: 'number' },
            { name: 'MaxHeapMemoryUsedHWM_KB',    type: 'number' },
            { name: 'SumIOSize1Page',             type: 'number' },
            { name: 'SumIOSize2Pages',            type: 'number' },
            { name: 'SumIOSize4Pages',            type: 'number' },
            { name: 'SumIOSize8Pages',            type: 'number' },
            { name: 'MaxULCMaxUsage',             type: 'number' },
            { name: 'SumWorkTables',              type: 'number' }
          ]);
          tmpcols = tmpcols.concat([
            { text: 'HeapMemoryAllocs'        , datafield: 'SumHeapMemoryAllocs',     width: 100, cellsformat: 'd', cellsalign: 'right', filterable: false, aggregates: ['sum']},
            { text: 'MaxHeapMemoryInUseKB'    , datafield: 'MaxHeapMemoryInUseKB',    width: 100, cellsformat: 'd', cellsalign: 'right', filterable: false, aggregates: ['max']},
            { text: 'MaxHeapMemoryReservedKB' , datafield: 'MaxHeapMemoryReservedKB', width: 100, cellsformat: 'd', cellsalign: 'right', filterable: false, aggregates: ['max']},
            { text: 'MaxHeapMemoryUsedHWM_KB' , datafield: 'MaxHeapMemoryUsedHWM_KB', width: 100, cellsformat: 'd', cellsalign: 'right', filterable: false, aggregates: ['max']},
            { text: 'IOSize1Page'             , datafield: 'SumIOSize1Page',          width: 100, cellsformat: 'd', cellsalign: 'right', filterable: false, aggregates: ['sum']},
            { text: 'IOSize2Pages'            , datafield: 'SumIOSize2Pages',         width: 100, cellsformat: 'd', cellsalign: 'right', filterable: false, aggregates: ['sum']},
            { text: 'IOSize4Pages'            , datafield: 'SumIOSize4Pages',         width: 100, cellsformat: 'd', cellsalign: 'right', filterable: false, aggregates: ['sum']},
            { text: 'IOSize8Pages'            , datafield: 'SumIOSize8Pages',         width: 100, cellsformat: 'd', cellsalign: 'right', filterable: false, aggregates: ['sum']},
            { text: 'ULCMaxUsage'             , datafield: 'MaxULCMaxUsage',          width: 100, cellsformat: 'd', cellsalign: 'right', filterable: false, aggregates: ['max']},
            { text: 'WorkTables'              , datafield: 'SumWorkTables',           width: 100, cellsformat: 'd', cellsalign: 'right', filterable: false, aggregates: ['sum']}
          ]);
    }



  
    $(grid).asemonGrid({
      'querydata' : {'queryfile' : '../ASE/sql/sql_process_statistics.php',
                     'dbid_tmp_pages_exists' : dbid_tmp_pages_exists,
                     'colV157SP130Exists' : colV157SP130Exists,
                     'colV16SP03Exists' : colV16SP03Exists,
                     'colV16SP04Exists' : colV16SP04Exists,
                     'default_order_by': 'Loggedindt'},
      'datafields': [
         { name: 'Loggedindt', type: 'string'},    
         { name: 'A_Spid', type: 'number'},          
         { name: 'UserName', type: 'string'},      
         { name: 'program_name', type: 'string'},  
         { name: 'CPUTm', type: 'number'},         
         { name: 'LReads', type: 'number'},        
         { name: 'PReads', type: 'number'},        
         { name: 'PgRead', type: 'number'},        
         { name: 'PWrites', type: 'number'},       
         { name: 'PgWritten', type: 'number'},     
         { name: 'ScPgs', type: 'number'},         
         { name: 'IPgs', type: 'number'},          
         { name: 'UBytWrite', type: 'number'},     
         { name: 'UFlush', type: 'number'},        
         { name: 'UFlushFull', type: 'number'},    
         { name: 'avgUlcSize', type: 'number'},    
         { name: 'Trans', type: 'number'},         
         { name: 'Cmits', type: 'number'},         
         { name: 'Rlbacks', type: 'number'},       
         { name: 'PktReceived', type: 'number'},   
         { name: 'PktSent', type: 'number'},       
         { name: 'BReceived', type: 'number'},     
         { name: 'BSent', type: 'number'},         
         { name: 'avgPktRcv', type: 'number'},     
         { name: 'avgPktSent', type: 'number'},    
         { name: 'ipaddr', type: 'string'},        
         { name: 'hostname', type: 'string'},      
         { name: 'hostprocess', type: 'string'},   
         { name: 'execlass', type: 'string'},      
         { name: 'clientname', type: 'string'},    
         { name: 'clienthostname', type: 'string'},
         { name: 'clientapplname', type: 'string'}
        ]
        .concat(tmpfields)
        .concat([
         { name: 'TTbl',          type: 'number'},
         { name: 'MaxMemusageKB', type: 'number'},
         { name: 'MaxLocksHeld',  type: 'number'}])
        .concat(V16SP03fields)
        .concat(V16SP04fields),
      'columns': [
         { text: 'Loggedindatetime', datafield: 'Loggedindt',     width: 170, filterable: false},                                                                                    
         { text: 'Spid'            , datafield: 'A_Spid',         width: 100, cellsformat: 'd', filtertype: 'number', cellsalign: 'right'},
         { text: 'UserName'        , datafield: 'UserName',       width: 100},                                                                                    
         { text: 'program_name'    , datafield: 'program_name',   width: 100},                                                                                    
         { text: 'CPUTime'         , datafield: 'CPUTm',          width: 100, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']}]
         .concat(V16SP03cols)
         .concat ([
         { text: 'LogicalReads'    , datafield: 'LReads',         width: 100, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']},
         { text: 'PhysicalReads'   , datafield: 'PReads',         width: 100, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']},
         { text: 'PagesRead'       , datafield: 'PgRead',         width: 100, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']},
         { text: 'PhysicalWrites'  , datafield: 'PWrites',        width: 100, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']},
         { text: 'PagesWritten'    , datafield: 'PgWritten',      width: 100, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']},
         { text: 'ScanPgs'         , datafield: 'ScPgs',          width: 100, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']},
         { text: 'IdxPgs'          , datafield: 'IPgs',           width: 100, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']},
         { text: 'UlcBytWrite'     , datafield: 'UBytWrite',      width: 100, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']},
         { text: 'UlcFlush'        , datafield: 'UFlush',         width: 100, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']},
         { text: 'ULCFlushFull'    , datafield: 'UFlushFull',     width: 100, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']},
         { text: 'avgUlcSize'      , datafield: 'avgUlcSize',     width: 100, filterable: false, cellsformat: 'd0',cellsalign: 'right',aggregates: ['avg']},
         { text: 'Transactions'    , datafield: 'Trans',          width: 100, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']},
         { text: 'Commits'         , datafield: 'Cmits',          width: 100, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']},
         { text: 'Rollbacks'       , datafield: 'Rlbacks',        width: 100, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']},
         { text: 'PacketsReceived' , datafield: 'PktReceived',    width: 100, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']},
         { text: 'PacketsSent'     , datafield: 'PktSent',        width: 100, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']},
         { text: 'BytesReceived'   , datafield: 'BReceived',      width: 100, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']},
         { text: 'BytesSent'       , datafield: 'BSent',          width: 100, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']},
         { text: 'avgPktRcv'       , datafield: 'avgPktRcv',      width: 100, filterable: false, cellsformat: 'd0',cellsalign: 'right',aggregates: ['avg']},
         { text: 'avgPktSent'      , datafield: 'avgPktSent',     width: 200, filterable: false, cellsformat: 'd0',cellsalign: 'right',aggregates: ['avg']},
         { text: 'ipaddr'          , datafield: 'ipaddr',         width: 100},
         { text: 'hostname'        , datafield: 'hostname',       width: 100},
         { text: 'hostprocess'     , datafield: 'hostprocess',    width: 100},
         { text: 'execlass'        , datafield: 'execlass',       width: 100},
         { text: 'clientname'      , datafield: 'clientname',     width: 100},
         { text: 'clienthostname'  , datafield: 'clienthostname', width: 100},
         { text: 'clientapplname'  , datafield: 'clientapplname', width: 100}
         ])
        .concat(tmpcols)
        .concat([
         { text: 'TmpTblCreated'   , datafield: 'TTbl',           width: 100, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']},
         { text: 'MaxMemusageKB'   , datafield: 'MaxMemusageKB',  width: 100, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['max']},
         { text: 'MaxLocksHeld'    , datafield: 'MaxLocksHeld',   width: 100, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['max']}
        ])
        .concat(V16SP04cols)
    });
   
  }


  onArchCnxOpened = function(){
    $('.ASE-Process').removeClass('nondisplay');
    $('#process_statistics').asemonGrid('refresh');
  }

</script>
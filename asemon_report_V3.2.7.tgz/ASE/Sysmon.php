<div class="ASE-Sysmon nondisplay">
  <div style="display: flex;flex-direction: row;justify-content: space-around;flex-wrap: wrap;align-items: center;">
      <div id="Sysmon_data_box" class="boxinmain detailbox" >
        <div class="statTitle" ><strong>Sysmon Statistics</strong></div>
        <div class="statLowerTitle" >Sysmon section : 

          <select id="sysmonSelector" style="width: 150px" onchange="refresh_Sysmon_data()" > 
             <option> Choose section </option>
             <option> all </option>
             <option> kernel </option>
             <option> parallel </option>
             <option> taskmgmt </option>
             <option> appmgmt </option>
             <option> hk </option>
             <option> xactsum </option>
             <option> xactmgmt </option>
             <option> index </option>
             <option> locks </option>
             <option> dcache_sum </option>
             <option> dcache_dtl </option>
             <option> pcache </option>
             <option> memory </option>
             <option> recovery </option>
             <option> diskio </option>
             <option> netio </option>
             <option> nvcache (V16SP02) </option>
          </select>
        </div>
        <div id="Sysmon_data" class="boxtext boxcontent_nodata">
          <div>No data to display</div>
        </div>
        <div ID="Sysmon_data_mess" class="nondisplay" >  </div>
      </div>
  </div>
</div>


<script type="text/javascript">

  var ASM_XHR_refresh_Sysmon_data;

  function refresh_Sysmon_data() {
      var SysMon_Exists = 0;
      var SysMonFl2_exists = 0;
      var SysEngThrExists = 0;
      var SysThreadExists = 0;
      var IOControlExists = 0;
      var WorkQueueExists = 0;
      var ThreaPoolExists = 0;
      var SysLoadExists = 0;
      var BuckPoolExists = 0;
      var SysNVCachExists = 0;
      var SysConfExists = 0;
      var SysCachesExists = 0;

      if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_SysMon') )  )
        SysMon_Exists = 1;
      if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_SysMonFl2') )  )
        SysMonFl2_exists = 1;
      if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_SysEngThr') )  )
        SysEngThrExists = 1;
      if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_SysThread') )  )
        SysThreadExists = 1;
      if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_IOControl') )  )
        IOControlExists = 1;
      if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_WorkQueue') )  )
        WorkQueueExists = 1;
      if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_ThreaPool') )  )
        ThreaPoolExists = 1;
      if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_SysLoad') )  )
        SysLoadExists = 1;
      if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_BuckPool') )  )
        BuckPoolExists = 1;
      if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_SysNVCach') )  )
        SysNVCachExists = 1;
      if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_SysConf') )  )
        SysConfExists = 1;
      if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_SysCaches') )  )
        SysCachesExists = 1;

      if ( SysMon_Exists == 0) {
        $('#Sysmon_data').hide();
        $('#Sysmon_data_mess').show();
        $('#Sysmon_data_mess').html('<p>Sysmon data is not available. The sysmon collector has not been activated for server '+ARContext.ServerName+'.<P> (Add SysMon.xml, SysMonFld.xml, SysDev.xml, SysCaches.xml and SysConf.xml in the asemon_logger config file)</p>');
        return;
      }
      else {
        $('#Sysmon_data').show();
        $('#Sysmon_data_mess').hide();
      }

    var SysmonType = $('#sysmonSelector').val();

    var data = {ARContextJSON: JSON.stringify(ARContext),
      'SysMonFl2_exists': SysMonFl2_exists,
      'SysEngThrExists': SysEngThrExists,
      'SysThreadExists': SysThreadExists,
      'IOControlExists': IOControlExists,
      'WorkQueueExists': WorkQueueExists,
      'ThreaPoolExists': ThreaPoolExists,
      'SysLoadExists': SysLoadExists,
      'BuckPoolExists': BuckPoolExists,
      'SysNVCachExists': SysNVCachExists,
      'SysmonType': SysmonType,
      'SysConfExists' : SysConfExists,
      'SysCachesExists' : SysCachesExists};

    $('#Sysmon_data').empty();
    $('#Sysmon_data').removeClass('boxcontent_nodata');
    $('#Sysmon_data').addClass('boxcontent_loading');
    $('#Sysmon_data').append('<div>Loading...<div>');


    if (ASM_XHR_refresh_Sysmon_data != null) {
      ASM_XHR_refresh_Sysmon_data.abort();
      ASM_XHR_refresh_Sysmon_data = null;
    }
    incXHRcnt();
    ASM_XHR_refresh_Sysmon_data = $.post( 'ASE/sql/sql_sysmon.php', data ).done(function(res) {
      $('#Sysmon_data').removeClass('boxcontent_loading');
      var result = JSON.parse(res);
      if ( checkSQLError(result, 'refresh_Sysmon_data') ) return;
      render_Sysmon_data(result);
    })
    .fail(function(data) {
    if (data.statusText == 'abort')
      return;
      alert( "error in refresh_Sysmon_data()" );
    })
    .always(function() {
      decXHRcnt();
    });
  }
  
  function render_Sysmon_data (result) {
  
    $('#Sysmon_data').empty();
    $('#Sysmon_data').append(result.msgresult);
  
  }


  onArchCnxOpened = function(){
    $('.ASE-Sysmon').removeClass('nondisplay');
    refresh_Sysmon_data();
  }


</script>
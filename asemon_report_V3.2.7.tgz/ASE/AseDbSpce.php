<div class="ASE-SpaceUsed nondisplay">
  <center>
  <div class="maingrid">
    <div ID="SpaceUsed_statistics" class="asemongrid singlegrid" ></div>
    <div ID="SpaceUsed_statistics_mess" class="nodisplay" >  </div>
  </div>
  </center>
</div>

<script type="text/javascript">
  var height =    $('#page-content').innerHeight() - 55;

  var calcColor_pctUsed = function (row, column, value, defaultHtml) {
    var element = $(defaultHtml);
    var color = "";

    if ( value > 90)
      color = "red";
    else
      if ( value > 70)
        color = "yellow";

    if (color != "") {
      element.css({ 'background-color': color, 'width': '100%', 'height': '100%', 'margin': '0px', 'padding' : '4px' });
      return element[0].outerHTML; 
    }
    else
      return defaultHtml;
  }

  var calcColor_logUsed = function (row, column, value, defaultHtml) {
    var element = $(defaultHtml);
    var color = "";

    if ( value < 0 )
      color = "red";

    if (color != "") {
      element.css({ 'background-color': color, 'width': '100%', 'height': '100%', 'margin': '0px', 'padding' : '4px' });
      return element[0].outerHTML; 
    }
    else
      return defaultHtml;
  }

  var calcColor_logsegFree = function (row, column, value, defaultHtml) {
    var element = $(defaultHtml);
    var color = "";
    var rowdata;

    rowdata = $('#SpaceUsed_statistics').jqxGrid('getrowdatabyid', row);
    if (typeof rowdata == 'undefined') return defaultHtml;

    var LogFree_Mb = rowdata.LogFree_Mb;
    var logsegFree_Mb = rowdata.logsegFree_Mb;
  
    if ( Math.abs(LogFree_Mb-logsegFree_Mb) / LogFree_Mb > 0.02)
       color = "red";

    if (color != "") {
      element.css({ 'background-color': color, 'width': '100%', 'height': '100%', 'margin': '0px', 'padding' : '4px' });
      return element[0].outerHTML; 
    }
    else
      return defaultHtml;
  }


  if (typeof detail_type != 'undefined')
    $('.ASE-SpaceUsed').removeClass('nondisplay');



  $('#SpaceUsed_statistics').asemonGrid({
    'title' : 'Space used in databases',
    'width' : '100%',
    'height' : height,
    'rowcount': 200,
    'editable': false,
    'filterable': true,
    'cursor' : 'pointer',
    'showaggregates': true,
    'querydata': {'queryfile' : '', 'default_order_by' : 'dbid'},
    'beforeRefresh': function() {refresh_SpaceUsed_statistics (this[0]);},
    'datafieldsMapping': {},
     'datafields': [
     { name: 'Timestamp', type: 'string'}
     ],
    'columns': [
     { text: 'Timestamp',         datafield: 'Timestamp',         width: 150, filterable: true}
     ]
  });

  $("#SpaceUsed_statistics").on('rowselect', function (event) {
    var rowindex = event.args.rowindex;
    //alert ("row "+rowindex+" selected");

    rowdata = $('#SpaceUsed_statistics').jqxGrid('getrowdatabyid', rowindex);
    if (typeof rowdata == 'undefined') return 0;

    openWindowFromGrid ("#SpaceUsed_statistics", "detail_page.php", {ARContextJSON: ARContext, 'displaylevel' : 1, 'detail_type': 'SPACEDETAIL', 'dbid': rowdata.dbid, 'dbname': rowdata.dbname, 'isMixedLog': rowdata.isMixedLog});
  });

  function refresh_SpaceUsed_statistics (grid) {
    var asemondata = jQuery.data(grid, 'asemondata');
    var cols = [];
    var fields = [];
    var AseDbSpceExists = 0;
    var support16SP04PL01 = 0;
    
    if ( (ARContext.ServerName!="") && 
          ( existColumn(ARContext.ServerName+'_OpenDbs', 'BackupStartTime') ) &&
          ( existColumn(ARContext.ServerName+'_OpenDbs', 'BackupEndTime') ) &&
          ( existColumn(ARContext.ServerName+'_OpenDbs', 'LastTranLogEndDumpTime') ) &&
          ( existColumn(ARContext.ServerName+'_OpenDbs', 'LastTranLogDumpTime') ) &&
          ( existColumn(ARContext.ServerName+'_OpenDbs', 'LastCheckpointTime') )
       ) {
        support16SP04PL01 = 1;
    }


    if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_AseDbSpce') )  )
      AseDbSpceExists = 1;
    
    if ( AseDbSpceExists == 0) {
      $('#SpaceUsed_statistics').hide();
      $('#SpaceUsed_statistics_mess').show();
      $('#SpaceUsed_statistics_mess').html('<p>Space used info is not available. The AseDbSpce collector has not been activated for server '+ARContext.ServerName+'.</p><p> (Add AseDbSpce.xml in the asemon_logger config file)</p>');
      $.extend(asemondata, {'querydata' : {'queryfile' : '', 'query': ''}});
      return;
    }
    else {
      $('#SpaceUsed_statistics').show();
      $('#SpaceUsed_statistics_mess').hide();
    }

    fields = [
             { name: 'dbid',          type: 'number'},
             { name: 'dbname',        type: 'string'},
             { name: 'DataSize_Mb',   type: 'number'},
             { name: 'DataFree_Mb',   type: 'number'},
             { name: 'PctDatUsed',    type: 'number'},
             { name: 'isMixedLog',    type: 'number'},
             { name: 'LogSize_Mb',    type: 'number'},
             { name: 'LogUsed_Mb',    type: 'number'},
             { name: 'LogClr_Mb',     type: 'number'},
             { name: 'PctLogUsed',    type: 'number'},
             { name: 'LogFree_Mb',    type: 'number'},
             { name: 'logsegFree_Mb', type: 'number'}
      ];
    
    cols = [
             { text: 'dbid         ', datafield: 'dbid',          width: 70,  filterable: true,  cellsformat: 'd',  cellsalign: 'right'},
             { text: 'dbname       ', datafield: 'dbname',        width: 120,  filterable: true},
             { text: 'DataSize_Mb  ', datafield: 'DataSize_Mb',   width: 90,  filterable: false, cellsformat: 'd',  cellsalign: 'right' ,aggregates: ['sum']},
             { text: 'DataFree_Mb  ', datafield: 'DataFree_Mb',   width: 90, filterable: false, cellsformat: 'd',  cellsalign: 'right' ,aggregates: ['sum']},
             { text: 'PctUsed      ', datafield: 'PctDatUsed',    width: 90,  filterable: false, cellsformat: 'd2',  cellsalign: 'right', cellsrenderer: calcColor_pctUsed},
             { text: 'isMixedLog   ', datafield: 'isMixedLog',    width: 50,  filterable: true,  cellsformat: 'd',  cellsalign: 'right'},
             { text: 'LogSize_Mb   ', datafield: 'LogSize_Mb',    width: 90,  filterable: false, cellsformat: 'd',  cellsalign: 'right' ,aggregates: ['sum']},
             { text: 'LogUsed_Mb   ', datafield: 'LogUsed_Mb',    width: 90,  filterable: false, cellsformat: 'd',  cellsalign: 'right' ,aggregates: ['sum'], cellsrenderer: calcColor_logUsed},
             { text: 'LogClr_Mb    ', datafield: 'LogClr_Mb',     width: 90,  filterable: false, cellsformat: 'd',  cellsalign: 'right' ,aggregates: ['sum']},
             { text: 'PctLogUsed   ', datafield: 'PctLogUsed',    width: 90,  filterable: false, cellsformat: 'd2',  cellsalign: 'right', cellsrenderer: calcColor_pctUsed},
             { text: 'LogFree_Mb   ', datafield: 'LogFree_Mb',    width: 90,  filterable: false, cellsformat: 'd',  cellsalign: 'right' ,aggregates: ['sum']},
             { text: 'logsegFree_Mb', datafield: 'logsegFree_Mb', width: 90,  filterable: false, cellsformat: 'd',  cellsalign: 'right' ,aggregates: ['sum'], cellsrenderer: calcColor_logsegFree} //,
//             { text: '', width: 25,  filterable: false}
      ];
      
    fields_16SP04PL01 = [
           { name: 'BckET',               type: 'string'},
           { name: 'Bck_s',               type: 'number'},
           { name: 'BtranET',             type: 'string'},
           { name: 'Btran_s',             type: 'number'},
           { name: 'LastChkpt',           type: 'string'}
    ];
    
    cols_16SP04PL01= [
           { text: 'BackupEndTime',           datafield: 'BckET',      width: 140},
           { text: 'dumpdb_duration_s',       datafield: 'Bck_s',      width: 100,  cellsalign: 'right'},
           { text: 'LastTranLogEndDumpTime',  datafield: 'BtranET',    width: 140},
           { text: 'dumptran_duration_s',     datafield: 'Btran_s',    width: 100,  cellsalign: 'right'},
           { text: 'LastCheckpointTime',      datafield: 'LastChkpt',  width: 140}
    ];
    
    if (support16SP04PL01 == 1) {
          fields = fields.concat(fields_16SP04PL01);
          cols = cols.concat(cols_16SP04PL01);
    }


    $(grid).asemonGrid({
      'querydata': {
        'queryfile' : '../ASE/sql/sql_SpaceUsed_statistics.php', 
        'support16SP04PL01': support16SP04PL01
        },
      'datafields': fields,
      'columns': cols 
    });
   
  }

  onArchCnxOpened = function(){
    $('.ASE-SpaceUsed').removeClass('nondisplay');
    $('#SpaceUsed_statistics').asemonGrid('refresh');
  }

</script>
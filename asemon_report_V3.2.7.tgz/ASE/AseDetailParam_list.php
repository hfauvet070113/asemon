
<center>
<div id="AseParamDetail">
  <H1> Evolution of parameter : "<?php echo $ParamName ?>" for "<?php echo $srvname ?>" </H1>
  <div class="maingrid">
    <div ID="AseDetailParamList" class="asemongrid singlegrid" ></div>
  </div>

</div>
</center>


<script type="text/javascript">


var srvname = "<?php echo $srvname ?>";
var ParamName = "<?php echo $ParamName ?>";


onArchCnxOpened = function(){

  var height =    $('#page-content').innerHeight()-180;
  var queryfile = '../ASE/sql/sql_aseparams.php';
  var fields = [
           { name: 'Timestamp',      type: 'string'},
           { name: 'ParamName',    type: 'string'},
           { name: 'CfgValue',     type: 'string'},
           { name: 'RunValue',     type: 'string'}
  ];

  var cols= [
           { text: 'Timestamp',      datafield: 'Timestamp',       width: 200, filterable: false},
           { text: 'ParamName',    datafield: 'ParamName',     width: 300, filterable: false},
           { text: 'CfgValue' ,     datafield: 'CfgValue',      width: 150, filterable: false},
           { text: 'RunValue' ,     datafield: 'RunValue',      width: 150, filterable: false},
           { text: '', width: 25,  filterable: false}
  ];

  $('#AseDetailParamList').asemonGrid({
    'title' : 'ASE Parameter',
    'width' : '100%',
    'height' : height,
    'rowcount': '0',
    'editable': false,
    'filterable': true,
    'cursor' : 'pointer',
    'querydata' : {
                     'queryfile' : queryfile,
                     'srvname' : srvname,
                     'ParamName' : ParamName, 
                     'default_order_by': 'Timestamp'
                    },
    'datafieldsMapping': {},
    'datafields': fields,
    'columns': cols
  });


}

</script>
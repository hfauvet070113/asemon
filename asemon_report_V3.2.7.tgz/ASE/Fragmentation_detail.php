
<center>
<div id="allinfo">
  <H1> Fragmentation of object : <?php echo $dbname; ?>.<?php echo $owner; ?>.<?php echo $tabname; ?> </H1>
  <H3> Indid = <?php echo $indid; ?>, IndexName = <?php echo $indname; ?> , Clustered : <?php echo $clu; ?> </H3>
  <H3> Lockmode = <?php echo $lockmode; ?> </H3>

  <div style="display: flex;flex-direction: row;justify-content: space-around;flex-wrap: wrap;align-items: center;">
    <div id="graph_Object_Rows"         class="mainchart" style="min-width:700px;width:1200px" > </div>
    <div id="graph_Object_Size"         class="mainchart" style="min-width:700px;width:1200px" > </div>
    <div id="graph_Object_CR"           class="mainchart" style="min-width:700px;width:1200px" > </div>
    <div id="graph_Object_sputl_ioeff"  class="mainchart" style="min-width:700px;width:1200px" > </div>
  </div>
</div>
</center>


<script type="text/javascript">


var dbname   = "<?php echo $dbname   ; ?>";
var owner    = "<?php echo $owner    ; ?>";
var tabname  = "<?php echo $tabname  ; ?>";
var indid    = "<?php echo $indid    ; ?>";
var indname  = "<?php echo $indname  ; ?>";
var lockmode = "<?php echo $lockmode ; ?>";
var clu      = "<?php echo $clu      ; ?>";





onArchCnxOpened = function(){
  var graph;
  var series;

  if (indid < 2 ) {
    if (indid==0) 
      series=[
        { name: 'rowcount'      },
        { name: 'forwarded'      },
        { name: 'deleted'      }
      ];
    else
      series=[
        { name: 'rowcount'      }
      ];
    $('#graph_Object_Rows').show();
    graph = $('#graph_Object_Rows').highcharts();
    if (typeof graph == 'undefined')
      $('#graph_Object_Rows').asemonChart({
      title: {
        text: "Rows"
      },
      queryFile : '../ASE/sql/graph_Object_Rows.php',
      tableName : 'Fragment',
      data: {
        dbname: dbname,
        owner: owner,
        tabname: tabname,
        indid: indid
      },
      chart: {
         type: 'line'
      },
      series: series,
      legend: {
         enabled: true
      },
      yAxis: {
        minRange: 0.5,
        min : 0
      },
      plotOptions: {
            series: {
                marker: {
                  enabled: true,
                  radius: 3
                }
            }
      }
    
      });
    $('#graph_Object_Rows').asemonChart('refresh', 24*threadDelays);   
  }
  else
    $('#graph_Object_Rows').hide();


    if (indid==0) 
      series=[
        { name: 'pagegcnt'      },
        { name: 'leafcnt'      },
        { name: 'emptypages'      }
      ];
    if (indid==1) 
      series=[
        { name: 'pagegcnt'      },
      ];
    if (indid>1) 
      series=[
        { name: 'leafcnt'      },
        { name: 'emptypages'      }
      ];
  graph = $('#graph_Object_Size').highcharts();
  if (typeof graph == 'undefined')
    $('#graph_Object_Size').asemonChart({
    title: {
      text: "Object size"
    },
    queryFile : '../ASE/sql/graph_Object_Size.php',
    tableName : 'Fragment',
    data: {
      dbname: dbname,
      owner: owner,
      tabname: tabname,
      indid: indid
    },
    chart: {
       type: 'line'
    },
    series: series,
    legend: {
       enabled: true
    },
    yAxis: {
      minRange: 0.5,
      min : 0 
      },
    plotOptions: {
          series: {
              marker: {
                  enabled: true,
                  radius: 3 
              }
          }
      }
  
    });
  $('#graph_Object_Size').asemonChart('refresh', 24*threadDelays);

  graph = $('#graph_Object_CR').highcharts();
  if (typeof graph == 'undefined')
    $('#graph_Object_CR').asemonChart({
    title: {
      text: "Cluster Ratios"
    },
    queryFile : '../ASE/sql/graph_Object_CR.php',
    tableName : 'Fragment',
    data: {
      dbname: dbname,
      owner: owner,
      tabname: tabname,
      indid: indid
    },
    chart: {
       type: 'line'
    },
    series: [
      { name: 'DataPageCR'      },
      { name: 'IndexPageCR'      },
      { name: 'DataRowCR'      }
    ],
    legend: {
       enabled: true
    },
    yAxis: {
      max: 1,
      minRange: 0.5,
      min : 0 
      },
    plotOptions: {
          series: {
              marker: {
                  enabled: true,
                  radius: 3
              }
          }
      }
  
    });
  $('#graph_Object_CR').asemonChart('refresh', 24*threadDelays);

  graph = $('#graph_Object_sputl_ioeff').highcharts();
  if (typeof graph == 'undefined')
    $('#graph_Object_sputl_ioeff').asemonChart({
    title: {
      text: "Space and large IO"
    },
    queryFile : '../ASE/sql/graph_Object_sputl_ioeff.php',
    tableName : 'Fragment',
    data: {
      dbname: dbname,
      owner: owner,
      tabname: tabname,
      indid: indid
    },
    chart: {
       type: 'line'
    },
    series: [
      { name: 'space_utilization'      },
      { name: 'largeIO_efficiency'      }
    ],
    legend: {
       enabled: true
    },
    yAxis: {
      max: 1,
      minRange: 0.5,
      min : 0 
      },
    plotOptions: {
          series: {
              marker: {
                  enabled: true,
                  radius: 3
              }
          }
      }
  
    });
  $('#graph_Object_sputl_ioeff').asemonChart('refresh', 24*threadDelays);

}
</script>


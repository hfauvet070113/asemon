<?php

if (!defined("DIRECTORY_SEPARATOR")) {
define("DIRECTORY_SEPARATOR", "_");
}

  function autoloader ($full_class_name) {
    // replace separator 
    $name = str_replace("_", "/", $full_class_name);
    $name = str_replace("\\", "/", $name);

    // build full path
    $relative_path = "COMMON/".$name.'.php';
    $full_path = __DIR__."/COMMON/".$name.'.php';
 
    // check file
    if (is_file($full_path))
        include ($relative_path);
    else 
        return false;
  };
 
  spl_autoload_register("autoloader");
?>

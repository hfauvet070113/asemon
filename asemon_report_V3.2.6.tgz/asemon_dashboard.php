<?php
  // retreive all posted params and affect them to variables
  foreach ($_GET as $key => $value)
    @$$key=$value;

  $version_asemon_report = "V3.2.6 (251114)";
  $displaylevel=2;  // For fields display on header
  $ARContext['version_asemon_report'] = $version_asemon_report;
  $ARContext['rootDir']          =      $rootDir = addslashes(getcwd());

  require_once("config.php");

  // Retrieve default connection parameters if defined in config.php
  $ARContext['ArchiveServer']            = $default_archive_server;
  $ARContext['ArchiveUser']              = $default_archive_user;
  $ARContext['ArchivePassword']          = $default_archive_password; 
  $ARContext['ArchiveDatabase']          = $default_archive_db;
  $ARContext['ArchiveCharset']           = $default_archive_charset;
  $ARContext['DFormat']                  = $default_date_order;
  $ARContext['password_encryption_type'] = 'none';


  // Retrieve connection parameters if defined on command line. Override default param
  if (isset($server))
    $ARContext['ArchiveServer'] = $server;
  if (isset($user))
    $ARContext['ArchiveUser'] = $user;
  if (isset($password))
    $ARContext['ArchivePassword'] = $password;
  if (isset($database))
    $ARContext['ArchiveDatabase'] = $database;
  if (isset($charset))
    $ARContext['ArchiveCharset'] = $charset;
  if (isset($DFormat))
    $ARContext['DFormat'] = $DFormat;

  if (isset($KEY)) {
    $ARContext['ArchiveUser'] = $KEY;
    $ARContext['ArchivePassword'] = "";
    $ARContext['ArchiveServer']   = "";
  }


  $ok=true;
  if (!isset($KEY) && !isset($user) ){
    echo "Please, pass user ou key defined in aseuserstore<br>";
    $ok=false;
  }


  if (!isset($ARContext['ArchiveDatabase']) || $ARContext['ArchiveDatabase']=='') {
    echo "Please, pass database to use in archive_server<br>";
    $ok=false;
  }
  if (!isset($reportname) || $reportname=='') {
    echo "Please, pass reportname<br>";
    $ok=false;
  }

  if (!isset($ServerName) || $ServerName=='') {
    echo "Please, pass ServerName (Monitored server)<br>";
    $ok=false;
  }
  if (!isset($ServerType) || $ServerType=='') {
    echo "Please, pass ServerType (ASE, RS, IQ, RAO)<br>";
    $ok=false;
  }
  if (!isset($StartTimestamp) || $StartTimestamp=='') {
    echo "Please, pass StartTimestamp<br>";
    $ok=false;
  }
  if (!isset($EndTimestamp) || $EndTimestamp=='') {
    echo "Please, pass EndTimestamp<br>";
    $ok=false;
  }

  if ($ok==false) return;

  $ARContext['ServerName']       = $ServerName;     
  $ARContext['ServerType']       = $ServerType;   
  $ARContext['StartTimestamp']   = $StartTimestamp;
  $ARContext['EndTimestamp']     = $EndTimestamp;    

  $ARContextJSON = json_encode ($ARContext);


//echo "user=".$ARContext['ArchiveUser']."  \$user=".$user."  \$password=".$ARContext['ArchivePassword']." \$KEY=".$KEY." database=".$ARContext['ArchiveDatabase']."<br>";

  include ("COMMON/connectArchiveServer.php");
  
  if ($pid=='') {
    echo "Cannot connect to Archive Server<br>";
    return;
  }

  // Check if monitored server exists
  if ($ServerType=="ASE")
    $query = "select name from sysobjects where type='U' and name = '".$ServerName."_DevIO'";
  if ($ServerType=="RS")
    $query = "select name from sysobjects where type='U' and name = '".$ServerName."_RSStats'";
  if ($ServerType=="RAO")
    $query = "select name from sysobjects where type='U' and name = '".$ServerName."_RAOSTATS'";
  if ($ServerType=="IQ")
    $query = "select name from sysobjects where type='U' and name = '".$ServerName."_IQStatus'";

  $result = asemon_query($query, $pid);
  $row=asemon_fetch_assoc($result);
  if (!isset($row["name"])) {
    echo "Monitored server '".$ServerName."' does not exists in Archive Database<br>";
    return;
  }

  $ARContextJSON = json_encode ($ARContext);
  
  // Get catalog (tables and columns of this monitored server)
  if ($ARContext['ArchSrvType'] == 'Adaptive Server Enterprise')
    $query = "select tname=O.name, cname=C.name from sysobjects O, syscolumns C where O.type = 'U' and O.name like '".$ServerName."%' and C.id = O.id order by 1,2";
  else
    $query  = "select tname, cname from sys.syscolumns where creator=user_name() and tname like '".$ServerName."%' order by 1,2";

  $SRVcatalog = array ();
  $prev_tname= "";
  $cur_columns = array ();
  $result=asemon_query($query, $pid);
  if ($result!=false){
      while ($row=asemon_fetch_assoc($result)) {
        $tname = trim($row["tname"]);
        if ($tname != $prev_tname) {
          // New table
          // Sav previous table
          if ($prev_tname  != "") $SRVcatalog[$prev_tname] = $cur_columns;
          $cur_columns = array();
          $prev_tname=$tname;
        }
        $cname = trim($row["cname"]);
        $cur_columns[] = $cname;
      }
      $SRVcatalog[$prev_tname] = $cur_columns;
      $SRVcatalogJSON = json_encode ($SRVcatalog);
  }

  

  //echo "detail_type:".$detail_type;
  switch ($reportname) {
    case "TOPSTMT" : 
      $title = "Top Statements";
      $includefile = "ASE/Report_TopStatements.php";
      break;
    case "TOPCOMPOBJ" : 
      $title = "Top Compiled Objects";
      $includefile = "ASE/Report_TopCompiledObjects.php";
      break;
    case "TOPLOGINS" : 
      $title = "Top logins";
      $includefile = "ASE/Report_TopLogins.php";
      break;
    default :
      echo "Unknown reportname '".$reportname."'<br>";
      return;
      break;
  }


?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?php echo $title ?></title>
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<link rel="icon" href="favicon.ico" type="image/x-icon">
    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">
    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- Custom CSS -->
    <link href="css/asemon_report.css" rel="stylesheet">
    <link href="css/stylecalend.css" rel="stylesheet" >

    <!-- add the jQWidgets base styles and one of the theme stylesheets -->
    <link rel="stylesheet" href="jqwidgets/styles/jqx.base.css" type="text/css" />
<!--    <link rel="stylesheet" href="jqwidgets/styles/jqx.darkblue.css" type="text/css" />-->
    <link rel="stylesheet" href="jqwidgets/styles/jqx.asemon_dashboard.css" type="text/css" />

    <link href="css/shCore.css" rel="stylesheet" type="text/css" />
    <link href="css/shThemeEclipse.css" rel="stylesheet" type="text/css" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>
    <script src="js/jsDate.js"></script>
    <script src="js/parsedate.js"> </script>
    <script src="js/calendrier.js"> </script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/md5.min.js"></script>

    <script src="js/dashboard.js"></script>
    <script src="js/asemon_report_common.js"></script>

    <script type="text/javascript" src="jqwidgets/jqx-all.js"></script>
    <script type="text/javascript" src="jqwidgets/globalization/globalize.js"></script>

    <script language="JavaScript" type="text/javascript" src="js/columnTooltips.js"></script>


    <script type="text/javascript" src="js/asemon.widgets-min.js"></script>
    <script type="text/javascript" src="js/highstock.js"></script>
    <script type="text/javascript" src="js/no-data-to-display.js"></script>

    <script type="text/javascript">
        ARContext = JSON.parse('<?php echo $ARContextJSON     ?>');
        //ARContext.rootDir = ARContext.rootDir.replace(/\\/g, '\\\\');
        ARContext.dontnotifyMissingDelay = true;
        var AR_EditableGrid                        = '<?php echo $editable_grids ?>';
    </script>




</head>

<body>

<div>


  <div class="banner">
    <div class="logo" ></div>
    <div id="divVersion" >Asemon Report <?php echo $version_asemon_report ?></div>
    <div id="copyrighttext"><b>&copy;</b> By : JP Martin - 2004..2025</div>
    <div class="rightbanner"> 
      <div class="topinput_reduced">
        
        <div class="topinput-row1_reduced">
          <div class="form-group form-group-sm" style="margin-bottom: 5px;" title="Choose server type">
                <label for="select">Type : </label>
                <?php if ($displaylevel==0) {?>
                  <select id="selecttype" name="SrvType" class="form-control">
                    <option>ASE</option>
                    <option>RS</option>
                    <option>IQ</option>
                    <option>RAO</option>
                  </select>
                <?php } else { ?>
                  <input name="SrvType" style="width: 50px" class="form-control" DISABLED value="<?php echo $ServerType ?>" />
                <?php } ?>
          </div>
          
          <div class="form-group form-group-sm" style="margin-bottom: 5px;" title="Choose monitored server">
                <label for="select" >Server : </label>
                <?php if ($displaylevel==0) {?>
                  <select id="selectsrv" name="ServerName" class="form-control" style="width: 250px"  >
                  </select>
                <?php } else { ?>
                  <input name="ServerName" class="form-control" DISABLED value="<?php echo $ServerName ?>" />
                <?php } ?>
          </div>
          
          <div class="form-group form-group-sm" style="margin-bottom: 5px;" title="Choose start datetime of analyzed interval">
            <label for="select" >StartTime : </label>
            <div class="input-group" style="width: 160px">
              <input id="StartTimestamp" <?php if ($displaylevel>1) echo 'DISABLED'; ?> class="form-control" type="text" />
            </div>
          </div>

          <!-- <div id="StartTimestampBTN" class="hide" ></div> -->

          <div class="form-group form-group-sm" style="margin-bottom: 5px;" title="Choose end datetime of analyzed interval">
            <label for="select" >EndTime : </label>
            <div class="input-group" style="width: 160px">
              <input id="EndTimestamp" <?php if ($displaylevel>1) echo 'DISABLED'; ?> class="form-control" type="text" />
            </div>
          </div>
          <!-- <div id="EndTimestampBTN" class="hide" ></div> -->

          <?php if ($displaylevel < 2 ) { ?> 
          <div class="form-group form-group-sm" style="margin-bottom: 5px;">
            <label for="select" >&nbsp;</label>
            <button type="button" id="RefreshBtn" class="form-control btn btn-primary" ><i class="fa fa-refresh fa-fw white"></i> REFRESH </button>
          </div>
          <?php } ?>

        </div>


        <div class="topinput-row2">

          <?php if ($displaylevel < 2 ) { ?> 
          <div style="width: 342px; height: 30px; display: flex;  flex-direction: row;   justify-content: left;align-items: center;padding-left: 20px">
             <div class="checkbox">
               <label>
                 <input id="DispRangeSel" type="checkbox" value="DispRangeSel" checked="" "> Display Range Selector
               </label>
             </div>
          </div>
          <?php } ?>


          <?php if ($displaylevel < 2 ) { ?>
          <div class="topinput-row2-datemenu">




                <div>
                  <select ID="DFormat" name="DFormat" class="form-control" style="height: 30px" title="Choose dateformat : mdy='Month Day Year', dmy='Day Month Year'" onchange="javascript:changeDFormat();">
                      <option <?php if (strtolower ($default_date_order) == "mdy") echo " SELECTED";  ?> >mdy</option>
                      <option <?php if (strtolower ($default_date_order) == "dmy") echo " SELECTED";  ?> >dmy</option>
                  </select>
                </div>


                <div class="IncDateInBanner">
                  <div ID="datemenu">
                    <ul>
                      <li style="width:54px" ><a ONCLICK="javascript:setminusoneday()">-1D</a>
                        <ul>
                          <li style="width:54px" ><a ONCLICK="javascript:addXhours(-1)">-1h</a> </li>
                          <li style="width:54px" ><a ONCLICK="javascript:addXhours(-2)">-2h</a> </li>
                        </ul>
                      </li>
                    </ul>
                    </div>
                </div>


                <div class="SelectDateInBanner">
                  <div ID="datemenu">
                    <ul>
                      <li style="width:106px" ><a ONCLICK="javascript:settoday()">Today</a>
                        <ul>
                          <li style="width:106px" ><a ONCLICK="javascript:setlasthour()">LastHour</a> </li>
                          <li style="width:106px" ><a ONCLICK="javascript:setyesterday()">Yesterday</a> </li>
                          <li style="width:106px" ><a ONCLICK="javascript:setlastweek()">LastWeek</a> </li>
                          <li style="width:106px" ><a ONCLICK="javascript:setlastweekworkdays()">LastWeekWorkD</a> </li>
                          <li style="width:106px" ><a ONCLICK="javascript:setlastmonth()">LastMonth</a> </li>
                        </ul>
                      </li>
                    </ul>
                  </div>
                </div>


                <div class="IncDateInBanner">
                  <div ID="datemenu">
                    <ul>
                      <li style="width:54px" ><a ONCLICK="javascript:setplusoneday()">+1D</a>
                        <ul>
                          <li style="width:54px" ><a ONCLICK="javascript:addXhours(1)">+1h</a> </li>
                          <li style="width:54px" ><a ONCLICK="javascript:addXhours(2)">+2h</a> </li>
                        </ul>
                      </li>
                    </ul>
                  </div>
                </div>    






          </div>
          <?php } // end test if $displaylevel < 2 
          ?>

        </div>

      </div>
    </div>
  </div>




  <div id="page-content" style="padding: 0px" >

  
  <?php
    include ($includefile);
  ?>

  </div>



</div>


</body>

</html>

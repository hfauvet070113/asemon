<?php
  // retreive all posted params and affect them to variables
  foreach ($_POST as $key => $value)
    @$$key=$value;

  include ("../../COMMON/connectArchiveServer.php");
  include ("DefFuncParseNodeXML.php");

  if (!isset($ProcName)) $ProcName = "";
  if (!isset($CompileDate)) $CompileDate = "";




  if ((substr($ProcName,0,2) == "*s") && ($PlanID != '') && ($CompileDate == '')) {
    // Find SSQLID
    $SSQLID = substr($ProcName,3,10);
  
    $query = "
    select ts=convert (varchar, Timestamp, 111)+' '+convert (varchar, Timestamp, 108)+'.'+convert(varchar, datepart(ms,Timestamp)),
      PlanID, xmlinfo
    from ".$ServerName."_CachedXML  
    where ObjectID = ".$SSQLID."
      and PlanID = ".$PlanID."
      and CompileDate = 
         (select max(CompileDate) from ".$ServerName."_CachedXML   
          where ObjectID = ".$SSQLID."
            and PlanID = ".$PlanID."
            and CompileDate <= '".$Strttm."')";
  
  }
  else {
    if ($CompileDate!="") {
      // This page is called from procCache_statistics, soo CompileDate is excactly defined
      $query = 
      "set rowcount 1
      select ts=convert (varchar, Timestamp, 111)+' '+convert (varchar, Timestamp, 108)+'.'+convert(varchar, datepart(ms,Timestamp)),
        PlanID, xmlinfo
      from ".$ServerName."_CachedXML  
      where ObjectID = ".$SSQLID."
          and CompileDate = '".$CompileDate."'
          and PlanID = ".$PlanID."
        and Timestamp >= '".$CompileDate."'
        and Timestamp < '".$EndTimestamp."'
      order by Timestamp desc /* this is to get the last captured plan during the analyzed interval */
       set rowcount 0";
    }
    else {
        if (isset($CachedDate))
            $restictStartDate=" and Timestamp >= '".$CachedDate."'";
        else
            $restictStartDate=" and Timestamp >= '01/01/1900'";
  
      $query =
      "select ts=convert (varchar, Timestamp, 111)+' '+convert (varchar, Timestamp, 108)+'.'+convert(varchar, datepart(ms,Timestamp)),
        PlanID, xmlinfo
      from ".$ServerName."_CachedXML  A
      where ObjectID = ".$SSQLID."
        and Timestamp = (select max(Timestamp)
                         from ".$ServerName."_CachedXML  B
                         where A.ObjectID = B.ObjectID
                           and A.PlanID = B.PlanID
                           and A.CompileDate = B.CompileDate
                           ".$restictStartDate."
                             and B.Timestamp < '".$EndTimestamp."'
                           )
      order by Timestamp";
    }
  }

  $result = asemon_query($query, $pid);
  
  if ($error=="") {
    $total_plans=0; 
    $Plans = [];
    while (($row=asemon_fetch_assoc($result))) {
          if ($row != null) {
              include ("formatXMLPlan.php");
              //if (stristr($error, '"level":3,"code":77')) 
              if (($error->level == 3) and ($error->code==77)) 
                $Plans [] = array ('ts' => $row['ts'], 'PlanID' => $row['PlanID'], 'FormattedXML' => 'XML is truncated, cannot format it.', 'RawXML' => $rawXML);
              else
                $Plans [] = array ('ts' => $row['ts'], 'PlanID' => $row['PlanID'], 'FormattedXML' => $formattedXML, 'RawXML' => $rawXML);
              $total_plans ++;
              $error = "";
          } // End if "row != null"
    }
  }

//$error="hgfh";

  if ($error == "")
    $data = array(
      'status' => 'success',
      'TotalPlans' => $total_plans,
      'Plans' => $Plans,
      'query' => $query 
      );

  else
    $data = array(
      'status' => 'error',
      'message' => $error,
      'query' => $query
      );

  echo json_encode($data);


?>
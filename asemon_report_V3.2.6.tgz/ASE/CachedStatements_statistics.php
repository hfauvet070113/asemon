<div class="ASE-StmtCache nondisplay">
  <center>
  <div class="maingrid">
    <div ID="CachedStatements_statistics" class="asemongrid singlegrid" ></div>
    <div ID="CachedStatements_statistics_mess" class="nodisplay" >  </div>
  </div>
  </center>
</div>

<script type="text/javascript">
  var height =    $('#page-content').innerHeight() - 55;

    var dispSQLText = function (row, column, value, defaultHtml) {
      
      var element = $('<textarea style="border:0px; margin: 0px; padding: 5px; width: 100%; height: 100%;overflow-y: auto; resize: none" spellcheck="false" >'+value+'</textarea>');
      return element[0].outerHTML; 
    }

  if (typeof detail_type != 'undefined')
    $('.ASE-StmtCache').removeClass('nondisplay');

  $('#CachedStatements_statistics').asemonGrid({
    'title' : 'Statement Cache statistics',
    'width' : '100%',
    'height' : height,
    'rowsheight': 80,
    'rowcount': 200,
    'editable': false,
    'filterable': true,
    'showaggregates': false,
    'querydata': {'queryfile' : '', 'default_order_by' : 'UseCount desc'},
    'beforeRefresh': function() {refresh_CachedStatements_statistics (this[0]);},
    'datafieldsMapping': {'bootcnt': 'STM.bootcount', 'sqlid':'STM.SSQLID', 'hashk': 'STM.Hashkey'},
    'datafields': [
           { name: 'bootcnt',                    type: 'number'},
           { name: 'sqlid',                      type: 'number'},
           { name: 'UserID',                     type: 'number'},
           { name: 'DBName',                     type: 'string'},
           { name: 'UseCount',                   type: 'number'},
           { name: 'MaxPIO',                     type: 'number'},
           { name: 'AvgPIO',                     type: 'number'},
           { name: 'TotPIO',                     type: 'number'},
           { name: 'MaxLIO',                     type: 'number'},
           { name: 'AvgLIO',                     type: 'number'},
           { name: 'TotLIO',                     type: 'number'},
           { name: 'MaxCpuTime',                 type: 'number'},
           { name: 'AvgCpuTime',                 type: 'number'},
           { name: 'TotCpuTime',                 type: 'number'},
           { name: 'MaxElapsedTime',             type: 'number'},
           { name: 'AvgElapsedTime',             type: 'number'},
           { name: 'TotElapsedTime',             type: 'number'},
           { name: 'CachedDT',                   type: 'string'},
           { name: 'LastUsedDT',                 type: 'string'},
           { name: 'planOK',                     type: 'string'},
           { name: 'StatementSize',              type: 'number'},
           { name: 'MaxPlanSizeKB',              type: 'number'},
           { name: 'MaxUsageCount',              type: 'number'},
           { name: 'NumRecompilesSchemaChanges', type: 'number'},
           { name: 'NumRecompilesPlanFlushes',   type: 'number'},
           { name: 'MetricsCount',               type: 'number'},
           { name: 'hashk',                      type: 'number'},
           { name: 'SQLText',                    type: 'string'}
    ],
    'columns': [
           { text: 'bootcount                 ', datafield: 'bootcnt',                    width: 70,  filterable: true, cellsformat: 'd', cellsalign: 'right', filtertype: 'number'},
           { text: 'SSQLID                    ', datafield: 'sqlid',                      width: 90,  filterable: true},
           { text: 'UserID                    ', datafield: 'UserID',                     width: 70,  filterable: true, cellsalign: 'right', filtertype: 'number'},
           { text: 'DBName                    ', datafield: 'DBName',                     width: 120, filterable: true},
           { text: 'UseCount                  ', datafield: 'UseCount',                   width: 70,  filterable: false, cellsformat: 'd',  cellsalign: 'right'},
           { text: 'MaxPIO                    ', datafield: 'MaxPIO',                     width: 90,  filterable: false, cellsformat: 'd',  cellsalign: 'right'},
           { text: 'AvgPIO                    ', datafield: 'AvgPIO',                     width: 90,  filterable: false, cellsformat: 'd0', cellsalign: 'right'},
           { text: 'TotPIO                    ', datafield: 'TotPIO',                     width: 90,  filterable: false, cellsformat: 'd0', cellsalign: 'right'},
           { text: 'MaxLIO                    ', datafield: 'MaxLIO',                     width: 90,  filterable: false, cellsformat: 'd',  cellsalign: 'right'},
           { text: 'AvgLIO                    ', datafield: 'AvgLIO',                     width: 90,  filterable: false, cellsformat: 'd0', cellsalign: 'right'},
           { text: 'TotLIO                    ', datafield: 'TotLIO',                     width: 90,  filterable: false, cellsformat: 'd0', cellsalign: 'right'},
           { text: 'MaxCpuTime                ', datafield: 'MaxCpuTime',                 width: 90,  filterable: false, cellsformat: 'd',  cellsalign: 'right'},
           { text: 'AvgCpuTime                ', datafield: 'AvgCpuTime',                 width: 90,  filterable: false, cellsformat: 'd0', cellsalign: 'right'},
           { text: 'TotCpuTime                ', datafield: 'TotCpuTime',                 width: 90,  filterable: false, cellsformat: 'd0', cellsalign: 'right'},
           { text: 'MaxElapsedTime            ', datafield: 'MaxElapsedTime',             width: 90,  filterable: false, cellsformat: 'd',  cellsalign: 'right'},
           { text: 'AvgElapsedTime            ', datafield: 'AvgElapsedTime',             width: 90,  filterable: false, cellsformat: 'd0', cellsalign: 'right'},
           { text: 'TotElapsedTime            ', datafield: 'TotElapsedTime',             width: 90,  filterable: false, cellsformat: 'd0', cellsalign: 'right'},
           { text: 'CachedDate                ', datafield: 'CachedDT',                   width: 170, filterable: false},
           { text: 'LastUsedDate              ', datafield: 'LastUsedDT',                 width: 170, filterable: false},
           { text: 'planOK                    ', datafield: 'planOK',                     width: 50,  filterable: true},
           { text: 'StatementSize             ', datafield: 'StatementSize',              width: 90,  filterable: false, cellsformat: 'd', cellsalign: 'right'},
           { text: 'MaxPlanSizeKB             ', datafield: 'MaxPlanSizeKB',              width: 90,  filterable: false, cellsformat: 'd', cellsalign: 'right'},
           { text: 'MaxUsageCount             ', datafield: 'MaxUsageCount',              width: 90,  filterable: false, cellsformat: 'd', cellsalign: 'right'},
           { text: 'NumRecompilesSchemaChanges', datafield: 'NumRecompilesSchemaChanges', width: 90,  filterable: false, cellsformat: 'd', cellsalign: 'right'},
           { text: 'NumRecompilesPlanFlushes  ', datafield: 'NumRecompilesPlanFlushes',   width: 90,  filterable: false, cellsformat: 'd', cellsalign: 'right'},
           { text: 'MetricsCount              ', datafield: 'MetricsCount',               width: 90,  filterable: false, cellsformat: 'd', cellsalign: 'right'},
           { text: 'Hashkey                   ', datafield: 'hashk',                      width: 90,  filterable: true},
           { text: 'SQLText                   ', datafield: 'SQLText',                    width: 700, filterable: true, sortable: false, editable: false, cellsrenderer: dispSQLText }
    ]
  });

  $("#CachedStatements_statistics").on('rowselect', function (event) {
    var rowindex = event.args.rowindex;
    //alert ("row "+rowindex+" selected");
    
    var rowdata = $('#CachedStatements_statistics').jqxGrid('getrowdatabyid', rowindex);
    if (typeof rowdata == 'undefined') return 0;

    openWindowFromGrid ("#CachedStatements_statistics", "detail_page.php", {ARContextJSON: ARContext, 'displaylevel' : 1, 'detail_type': 'CACHEDSTMT', 'SSQLID': rowdata.sqlid, 'bootcount': rowdata.bootcnt});

  });



  function refresh_CachedStatements_statistics (grid) {
    var asemondata = jQuery.data(grid, 'asemondata');
    var CachedSTMExists = 0;
    var PLNtableExists = 0;
    var SQLtableExists = 0;
    var support157SP130 = 0;
    var queryfile = '../ASE/sql/sql_cachedstmt_statistics.php';


    if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_CachedSTM') )  )
      CachedSTMExists = 1;
    if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_CachedPLN') )  )
      PLNtableExists = 1;
    if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_CachedSQL') )  )
      SQLtableExists = 1;

    if ( (ARContext.ServerName!="") && ( existColumn(ARContext.ServerName+'_CachedSTM', 'TotalPIO_smp') )  ) {
      support157SP130 = 1;
      queryfile = '../ASE/sql/sql_cachedstmt_statistics_V157SP130.php';
    }
    
    if ( CachedSTMExists == 0) {
      $('#CachedStatements_statistics').hide();
      $('#CachedStatements_statistics_mess').show();
      $('#CachedStatements_statistics_mess').html('<p>Statement cache data is not available. The CachedSTM and CachedSQL collectors have not been activated for server '+ARContext.ServerName+'.</p><p> (Add  CachedSTM.xml and CachedSQL.xml in the asemon_logger config file)</p>');
      $.extend(asemondata, {'querydata' : {'queryfile' : '', 'query': ''}});
      return;
    }
    else {
      $('#CachedStatements_statistics').show();
      $('#CachedStatements_statistics_mess').hide();
    }


    $(grid).asemonGrid({
      'querydata' : {
        'queryfile' : queryfile,
        'PLNtableExists': PLNtableExists,
        'SQLtableExists': SQLtableExists,
        'support157SP130': support157SP130
      }
    });
   
  }

  onArchCnxOpened = function(){
    $('.ASE-StmtCache').removeClass('nondisplay');
    $('#CachedStatements_statistics').asemonGrid('refresh');
  }

</script>
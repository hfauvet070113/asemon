<div class="ASE-Compression nondisplay">
  <center>
  <div class="maingrid">
    <div ID="Compression_statistics" class="asemongrid singlegrid" ></div>
    <div ID="Compression_statistics_mess" class="nodisplay" >  </div>
  </div>
  </center>
</div>

<script type="text/javascript">
  var height =    $('#page-content').innerHeight() - 55;




  if (typeof detail_type != 'undefined')
    $('.ASE-Compression').removeClass('nondisplay');

  $('#Compression_statistics').asemonGrid({
    'title' : 'Compression statistics',
    'width' : '100%',
    'height' : height,
    'rowcount': 200,
    'filterable': true,
    'showaggregates': true,
    'querydata': {'queryfile' : '', 'default_order_by' : 'TableName'},
    'beforeRefresh': function() {refresh_Compression_statistics (this[0]);},
    'datafieldsMapping': {},
    'datafields': [
           { name: 'DBID',                   type: 'number'},
           { name: 'ObjectID',               type: 'number'},
           { name: 'TableName',              type: 'string'},
           { name: 'PartitionID',            type: 'number'},
           { name: 'CompRowInserted',        type: 'number'},
           { name: 'CompRowUpdated',         type: 'number'},
           { name: 'CompRowForward',         type: 'number'},
           { name: 'CompRowScan',            type: 'number'},
           { name: 'RowDecompressed',        type: 'number'},
           { name: 'RowPageDecompressed',    type: 'number'},
           { name: 'ColDecompressed',        type: 'number'},
           { name: 'RowCompNoneed',          type: 'number'},
           { name: 'PageCompNoneed',         type: 'number'},
           { name: 'PagesCompressed',        type: 'number'},
           { name: 'AvgBytesSavedPageLevel', type: 'number'}
    ],
    'columns': [
           { text: 'DBID                  ', datafield: 'DBID',                   width: 70,  filterable: true},
           { text: 'ObjectID              ', datafield: 'ObjectID',               width: 100,  filterable: true},
           { text: 'TableName             ', datafield: 'TableName',              width: 150,  filterable: true},
           { text: 'PartitionID           ', datafield: 'PartitionID',            width: 100,  filterable: true},
           { text: 'CompRowInserted       ', datafield: 'CompRowInserted',        width: 100,  filterable: false, cellsformat: 'd',  cellsalign: 'right', aggregates: ['sum']},
           { text: 'CompRowUpdated        ', datafield: 'CompRowUpdated',         width: 100,  filterable: false, cellsformat: 'd',  cellsalign: 'right', aggregates: ['sum']},
           { text: 'CompRowForward        ', datafield: 'CompRowForward',         width: 100,  filterable: false, cellsformat: 'd',  cellsalign: 'right', aggregates: ['sum']},
           { text: 'CompRowScan           ', datafield: 'CompRowScan',            width: 100,  filterable: false, cellsformat: 'd',  cellsalign: 'right', aggregates: ['sum']},
           { text: 'RowDecompressed       ', datafield: 'RowDecompressed',        width: 100,  filterable: false, cellsformat: 'd',  cellsalign: 'right', aggregates: ['sum']},
           { text: 'RowPageDecompressed   ', datafield: 'RowPageDecompressed',    width: 100,  filterable: false, cellsformat: 'd',  cellsalign: 'right', aggregates: ['sum']},
           { text: 'ColDecompressed       ', datafield: 'ColDecompressed',        width: 100,  filterable: false, cellsformat: 'd',  cellsalign: 'right', aggregates: ['sum']},
           { text: 'RowCompNoneed         ', datafield: 'RowCompNoneed',          width: 100,  filterable: false, cellsformat: 'd',  cellsalign: 'right', aggregates: ['sum']},
           { text: 'PageCompNoneed        ', datafield: 'PageCompNoneed',         width: 100,  filterable: false, cellsformat: 'd',  cellsalign: 'right', aggregates: ['sum']},
           { text: 'PagesCompressed       ', datafield: 'PagesCompressed',        width: 100,  filterable: false, cellsformat: 'd',  cellsalign: 'right', aggregates: ['sum']},
           { text: 'AvgBytesSavedPageLevel', datafield: 'AvgBytesSavedPageLevel', width: 100,  filterable: false, cellsformat: 'd2', cellsalign: 'right'},
           { text: '', width: 25,  filterable: false}
    ]
  });

  function refresh_Compression_statistics (grid) {
    var asemondata = jQuery.data(grid, 'asemondata');
    var CompressExists = 0;


    if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_Compress') )  )
      CompressExists = 1;
    
    if ( CompressExists == 0) {
      $('#Compression_statistics').hide();
      $('#Compression_statistics_mess').show();
      $('#Compression_statistics_mess').html('<p>Compress data is not available. The Compress collector has not been activated for server '+ARContext.ServerName+', may be for performance reasons. </p>');
      $.extend(asemondata, {'querydata' : {'queryfile' : '', 'query': ''}});
      return;
    }
    else {
      $('#Compression_statistics').show();
      $('#Compression_statistics_mess').hide();
    }


    $(grid).asemonGrid({'querydata': {'queryfile' : '../ASE/sql/sql_compress_statistics.php'}});
   
  }

  onArchCnxOpened = function(){
    $('.ASE-Compression').removeClass('nondisplay');
    $('#Compression_statistics').asemonGrid('refresh');
  }

</script>
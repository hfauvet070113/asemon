<div class="ASE-Objects_Stats nondisplay">
  <center>
  <div class="maingrid">
    <div ID="objects_statistics" class="asemongrid singlegrid" ></div>
  </div>
  </center>
</div>


<script type="text/javascript">

  var height =    $('#page-content').innerHeight() - 55;

  var hasObjectID = 0;
  var hasindname = 0;
  var support150 = 0;
  var support157 = 0;

  if (typeof detail_type != 'undefined')
    $('.ASE-Objects_Stats').removeClass('nondisplay');

  $('#objects_statistics').asemonGrid({
    'title' : 'Objects Statistics',
    'width' : '100%',
    'height' : height,
    'rowcount': '200',
    'editable': false,
    'filterable': true,
    'cursor' : 'pointer',
    'beforeRefresh': function() {refresh_objects_statistics (this[0]);},
    'datafields': [
     { name: 'dbname', type: 'string'}
     ],
    'columns': [
     { text: 'DBName', datafield: 'dbname',     width: 100, filterable: false}
     ],
/*    'querydata' : {'queryfile' : '../ASE/sql/sql_objects_statistics.php'},*/
    'querydata' : {'queryfile' : ''},
    'datafieldsMapping' : { },
    'buttons' : [
       {
        'id': 'ShowIndexNotUsedBTN',
        'text': 'ShowIndexNotUsed',
        'onclick' : function ( ) {
          var show_index_not_used = 0;
          var sc_show_table_scans = '';
          if (this.value == 'ShowIndexNotUsed') {
            this.value = 'RemoveShowIndexNotUsed';
            show_index_not_used = 1;
          }
          else {
            this.value = 'ShowIndexNotUsed';
            show_index_not_used = 0;
          }
          var selector = $('#objects_statistics')[0];
          var asemondata = jQuery.data( selector , 'asemondata');
          $.extend(asemondata.querydata, {'show_index_not_used' : show_index_not_used,
                                          'sc_show_table_scans' : sc_show_table_scans});
          $('#ShowTableScansBTN').val('ShowTableScans');
          $(selector).asemonGrid('refresh');
        }
       },
       {
        'id': 'ShowTableScansBTN',
        'text': 'ShowTableScans',
        'onclick' : function (event) {
          var show_index_not_used = 0;
          var sc_show_table_scans = '';
          if (this.value == 'ShowTableScans') {
            this.value = 'RemoveShowTableScans';
            sc_show_table_scans = ' and IndID = 0 and UsedCount > 0 ';
          }
          else {
            this.value = 'ShowTableScans';
            sc_show_table_scans = '';
          }
          var selector = $('#objects_statistics')[0];
          var asemondata = jQuery.data( selector , 'asemondata');
          $.extend(asemondata.querydata, {'show_index_not_used' : show_index_not_used,
                                          'sc_show_table_scans' : sc_show_table_scans});
          $('#ShowIndexNotUsedBTN').val('ShowIndexNotUsed');
          $(selector).asemonGrid('refresh');
        }
       }
     ]
    //'datafieldsTS' : ['Loggedindt']
  });

  $("#objects_statistics").on('rowselect', function (event) {
    var rowindex = event.args.rowindex;
    var OwnerUserID = 0;
    var ObjectID = 0;
    //alert ("row "+rowindex+" selected");

    rowdata = $('#objects_statistics').jqxGrid('getrowdatabyid', rowindex);
    if (typeof rowdata == 'undefined') return 0;
    var ObjectDbName = rowdata.dbname;
    var ObjectName = rowdata.objname;
    if (hasObjectID == 1) {
      OwnerUserID = rowdata.ownerid;
      ObjectID = rowdata.ObjectID;
    }

    openWindowFromGrid ("#objects_statistics", "detail_page.php", {ARContextJSON: ARContext, 'displaylevel' : 1, 'detail_type': 'OBJDETAIL', 'ObjectDbName': ObjectDbName, 'ObjectName': ObjectName, 'ObjectID': ObjectID, 'OwnerUserID': OwnerUserID, 'OwnerName': ''});
  });



  function refresh_objects_statistics (grid) {
    var asemondata = jQuery.data(grid, 'asemondata');
    var fieldsojectid = [];
    var colsobjectid = [];
    var fieldsindname = [];
    var colsindname = [];
    var cols150 = [];
    var fields150 = [];
    var cols157 = [];
    var fields157 = [];
    var fieldsOptSelectCount = [];
    var colsOptSelectCount = [];

    hasObjectID = 0;
    hasindname = 0;
    support150 = 0;
    support157 = 0;
    supportOptSelectCount = 0;

    if ( (ARContext.ServerName!="") && ( existColumn(ARContext.ServerName+'_OpObjAct', 'ObjectID') )  )
      hasObjectID = 1;
    if ( (ARContext.ServerName!="") && ( existColumn(ARContext.ServerName+'_OpObjAct', 'indname') )  )
      hasindname = 1;
    if ( (ARContext.ServerName!="") && ( existColumn(ARContext.ServerName+'_OpObjAct', 'HkgcRequests') )  )
      support150 = 1;
    if ( (ARContext.ServerName!="") && ( existColumn(ARContext.ServerName+'_OpObjAct', 'SharedLockWaitTime') )  )
      support157 = 1;
    if ( (ARContext.ServerName!="") && ( existColumn(ARContext.ServerName+'_OpObjAct', 'OptSelectCount') )  )
      supportOptSelectCount = 1;
    
    if (hasObjectID == 1)
    {
          fieldsojectid = [
                 { name: 'ObjectID', type: 'number'},
                 { name: 'ownerid', type: 'number'}
          ];
          colsobjectid= [
                 { text: 'OwnerID',   datafield: 'ownerid',  width: 50, filterable: true,  cellsformat: 'd', cellsalign: 'right'},
                 { text: 'ObjectID',  datafield: 'ObjectID', width: 90, filterable: true,  cellsformat: 'd', cellsalign: 'right'}
          ];
    }
    if (hasindname == 1)
    {
          fieldsindname = [
                 { name: 'indname', type: 'string'}
          ];
          colsindname= [
                 { text: 'IndName',  datafield: 'indname', width: 150, filterable: true}
          ];
    }
    if (support150 == 1)
    {
          fields150 = [
                 { name: 'sumHkgcRequests',   type: 'number' },
                 { name: 'maxHkgcPending',    type: 'number'},
                 { name: 'sumHkgcOverflows',  type: 'number'}
          ];
          cols150= [
                 { text: 'HkgcRequests',   datafield: 'sumHkgcRequests',  width: 100, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']},
                 { text: 'maxHkgcPending', datafield: 'maxHkgcPending',   width: 100, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['max']},
                 { text: 'HkgcOverflows',  datafield: 'sumHkgcOverflows', width: 100, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']}
          ];
    }
    if (support157 == 1)
    {
          fields157 = [
                 { name: 'sumLockWaitTime',          type: 'number' },
                 { name: 'sumSharedLockWaitTime',    type: 'number' },
                 { name: 'sumExclusiveLockWaitTime', type: 'number'},
                 { name: 'sumUpdateLockWaitTime',    type: 'number'},
                 { name: 'maxObjectCacheDate',       type: 'number'}
          ];
          cols157= [
                 { text: 'sumLockWaitTime',       datafield: 'sumLockWaitTime',          width: 100, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']},
                 { text: 'SharedLockWaitTime',    datafield: 'sumSharedLockWaitTime',    width: 100, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']},
                 { text: 'ExclusiveLockWaitTime', datafield: 'sumExclusiveLockWaitTime', width: 100, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']},
                 { text: 'UpdateLockWaitTime',    datafield: 'sumUpdateLockWaitTime',    width: 100, filterable: false, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']},
                 { text: 'maxObjectCacheDate',    datafield: 'maxObjectCacheDate',       width: 120, filterable: false}
          ];
    }

    if (supportOptSelectCount == 1)
    {
          fieldsOptSelectCount = [
                 { name: 'OptSelCnt',       type: 'number'}
          ];
          colsOptSelectCount= [
                 { text: 'OptSelectCount',    datafield: 'OptSelCnt',    width: 100, filterable: true, cellsformat: 'd', cellsalign: 'right' ,aggregates: ['sum']}
          ];
    }

  
    $(grid).asemonGrid({
      'querydata' : {'queryfile' : '../ASE/sql/sql_objects_statistics.php',
                     'hasObjectID': hasObjectID,
                     'hasindname': hasindname,
                     'support150' : support150,
                     'support157' : support157,
                     'supportOptSelectCount': supportOptSelectCount,
                     'default_order_by': 'LReads DESC'
                    },
      'datafields': [
         { name: 'dbname',             type: 'string'},
         { name: 'objname',            type: 'string'}
        ]
        .concat(fieldsojectid)
        .concat(fieldsindname).concat(
        [
         { name: 'IndID',              type: 'number'},
         { name: 'LReads',             type: 'number'},
         { name: 'PReads',             type: 'number'},
         { name: 'AReads',             type: 'number'},
         { name: 'PgReads',            type: 'number'},
         { name: 'CacheHitPct',        type: 'number'},
         { name: 'PWrites',            type: 'number'},
         { name: 'PgWrites',           type: 'number'},
         { name: 'RowIns',             type: 'number'},
         { name: 'RowDel',             type: 'number'},
         { name: 'RowUpd',             type: 'number'},
         { name: 'Opers',              type: 'number'},
         { name: 'LockR',              type: 'number'},
         { name: 'LockW',              type: 'number'},
         { name: 'UsedCnt',            type: 'number'}
         ])
        .concat(fieldsOptSelectCount).concat(
        [
         { name: 'LReads_per_UsedCnt', type: 'number'}
        ])
        .concat(fields150)
        .concat(fields157),
      'columns': [
         { text: 'DBName',             datafield: 'dbname',             width: 100, filterable: true},
         { text: 'ObjName',            datafield: 'objname',            width: 150, filterable: true}
        ]
         .concat(colsobjectid)
         .concat(colsindname).concat(
        [
         { text: 'IndID',              datafield: 'IndID',              width: 50, filterable: true,  cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
         { text: 'LReads',             datafield: 'LReads',             width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
         { text: 'PReads',             datafield: 'PReads',             width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
         { text: 'APFReads',           datafield: 'AReads',             width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
         { text: 'PageReads',          datafield: 'PgReads',            width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
         { text: 'CacheHit%',          datafield: 'CacheHitPct',        width: 90, filterable: false, cellsformat: 'd2', cellsalign: 'right'},
         { text: 'PWrites',            datafield: 'PWrites',            width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
         { text: 'PageWrites',         datafield: 'PgWrites',           width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
         { text: 'RowIns',             datafield: 'RowIns',             width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
         { text: 'RowDel',             datafield: 'RowDel',             width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
         { text: 'RowUpd',             datafield: 'RowUpd',             width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
         { text: 'operations',         datafield: 'Opers',              width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
         { text: 'LockRequests',       datafield: 'LockR',              width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
         { text: 'LockWaits',          datafield: 'LockW',              width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']},
         { text: 'UsedCount',          datafield: 'UsedCnt',            width: 90, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right' ,aggregates: ['sum']}
        ])
        .concat(colsOptSelectCount).concat(
        [
         { text: 'LReads_per_UsedCnt', datafield: 'LReads_per_UsedCnt', width: 90, filterable: false, cellsformat: 'd2', filtertype: 'number', cellsalign: 'right'}
        ])
        .concat(cols150)
        .concat(cols157)
    });
   
  }
  
  onArchCnxOpened = function(){
    $('.ASE-Objects_Stats').removeClass('nondisplay');
    $('#objects_statistics').asemonGrid('refresh');
  }

</script>
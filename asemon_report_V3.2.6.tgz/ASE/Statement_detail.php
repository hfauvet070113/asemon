
<script type="text/javascript" src="js/shCore.js"></script>
<script type="text/javascript" src="js/shBrushSql.js"></script>

<center>
<div class="">
  <h1> Detail for Statement ID = <?php echo $StmtID ?> </h1>

  <div class="boxinmain detailbox" style="max-width:1200px";>
    <div class="statTitle" ><strong>Statement Statistics</strong></div>
    <div id="stmtstats" class="boxcontent">
    </div>
  </div>

  <div class="detailbox">
    <div id="objectsStatistics" > </div>
  </div>
  
  <div id="stmtSQLDIV" class="boxinmain detailbox" style="max-width:1200px";>
    <div class="statTitle" ><strong>SQL or Batch SQL</strong></div>
    <div class="statLowerTitle" ><div style="margin-left: 10px;" align="left" ><input id="FormatSQLBTN" value="FormatSQL" type="button" class="btn btn-primary btn-xs" /></div></div>
    <div id="stmtSQL" class="boxcontent">
      <div> Loading...</div>
    </div>
  </div>

  <div id="stmtSQL2DIV" class="boxinmain detailbox" style="max-width:1200px";>
    <div class="statTitle" id="stmtSQL2Title" ><strong>SQL parameterized</strong></div>
    <div class="statLowerTitle" ><div style="margin-left: 10px;" align="left" ><input id="FormatSQL2BTN" value="FormatSQL2" type="button" class="btn btn-primary btn-xs" /></div></div>
    <div id="stmtSQL2" class="boxcontent">
      <div> Loading...</div>
    </div>
  </div>



  <div id="stmtPLANDIV" class="boxinmain detailbox" style="max-width:1200px";>
    <div class="statTitle" id="stmtPLANTitle"><strong>Plan</strong></div>
    <div id="stmtPLAN" class="boxcontent">
      <div> Loading...</div>
    </div>
  </div>

  <div id="XMLPlans" style="max-width:1200px";> 
  </div>

</div>
</center>


<script type="text/javascript">

var StmtID = <?php echo $StmtID ?>; 
var support157 = 0;
var StmtObjExists = 0;
var StmtSQLHKExists = 0;
var StmtPlnHKExists = 0;
var SQLHashKeyExists = 0;
var PLANHashKeyExists = 0;
var StmtObjVersion = 'old';
var CachedXMLExists = 0;
var colV16SP03Exists = 0;
var supportFieldsAnja = 0;
var Strttm, Elapsed_ms, BootID, KPID, SPID, BatchID, ProcName, PlanID , SQLHashKey, PLANHashKey;
SQLHashKey=-1;
PLANHashKey=-1;
var resultXML;
var ASM_result_stmtSQL;
var ASM_result_stmtSQL2;

var ASM_XHR_refresh_stmtstats;
var ASM_XHR_refresh_stmtSQL;
var ASM_XHR_refresh_stmtSQL2;
var ASM_XHR_refresh_stmtPLAN;
var ASM_XHR_refresh_stmtXML;

var col_tran_name_Exists = 0;

function refresh_stmtstats (support157) {

  var selClientInfo = "";
  if ( support157 == 1 ) {
    selClientInfo = ", ClientName, ClientHostName, ClientApplName";
  }
  if ( SQLHashKeyExists == 1 ) {
    selClientInfo = selClientInfo + ", SQLHashKey";
  }
  if ( PLANHashKeyExists == 1 ) {
    selClientInfo = selClientInfo + ", PLANHashKey";
  }

  if ( colV16SP03Exists == 1 ) {
    selClientInfo = selClientInfo + ", SnapCodegenTime, SnapJITTime, SnapExecutionTime, SnapExecutionCount, QueryOptimizationTime";
  }

  if ( supportFieldsAnja == 1 ) {
    selClientInfo = selClientInfo + ", StatementNumber, ProcNestLevel";
  }

  if ( col_tran_name_Exists == 1 ) {
    selClientInfo = selClientInfo + ", tran_name";
  }


  var query = 
     "select StmtID,                                                            "
    +"    BootID,                                                               "
    +"    KPID,                                                                 "
    +"    SPID,                                                                 "
    +"    BatchID,                                                              "
    +"    Strttm=convert (varchar, StartTime, 111)+' '+convert (varchar, StartTime, 108)+'.'+convert(varchar, datepart(ms,StartTime)),"    
    +"    Elapsed_s=str(convert(float,datediff(ms,StartTime,EndTime))/1000,8,3),"
    +"    Elapsed_ms=datediff(ms,StartTime,EndTime),                            "
    +"    ExactStat,                                                            "
    +"    [Login],                                                              "
    +"    Application,                                                          "
    +"    ClientHost,                                                           "
    +"    ClientIP,                                                             "
    +"    ClientOSPID,                                                          "
    +"    DBID,                                                                 "
    +"    ProcName,                                                             "
    +"    LineNumber,                                                           "
    +"    CpuTime,                                                              "
    +"    WaitTime,                                                             "
    +"    MemUsageKB,                                                           "
    +"    PReads=convert(varchar,PhysicalReads),                                "
    +"    LReads=convert(varchar,LogicalReads),                                 "
    +"    PModified=convert(varchar,PagesModified),                             "
    +"    PacketsSent,                                                          "
    +"    PacketsReceived,                                                      "
    +"    NetworkPacketSize,                                                    "
    +"    PlansAltered,                                                         "
    +"    PlanID,                                                               "
    +"    ContextID,                                                            "
    +"    RowsAffected                                                          "
    +"    "+selClientInfo+"                                                     "
    +" from "+ARContext.ServerName+"_StmtStat                                   "
    +" where StmtID="+StmtID;


//  var data = {ARContextJSON: JSON.stringify(ARContext), 'query' : query, 'datafieldsTSJSON' : JSON.stringify(['Strttm'])};
//  Strttm converted to a PHP date with "date_format(date_create($value),'Y/m/d H:i:s.u')" with output like : '2020/06/10 16:30:21.223000' doesn't work for other queries in 12.5

  var data = {ARContextJSON: JSON.stringify(ARContext), 'query' : query};
  $('#stmtstats').html('<div> Loading...</div>');
  $('#stmtstats').addClass('detailboxcontent_loading');

  if (ASM_XHR_refresh_stmtstats != null) {
    ASM_XHR_refresh_stmtstats.abort();
    ASM_XHR_refresh_stmtstats = null;
  }
  incXHRcnt();
  ASM_XHR_refresh_stmtstats = $.post( 'COMMON/simplequery.php', data ).done(function(res) {
    var result = JSON.parse(res);
    if ( checkSQLError(result, 'refresh_stmtstats') ) return;
    $('#stmtstats').removeClass('detailboxcontent_loading');
    Strttm = result.Rows[0].Strttm;
    Elapsed_ms = result.Rows[0].Elapsed_ms;
    BootID = result.Rows[0].BootID;
    KPID = result.Rows[0].KPID; 
    SPID = result.Rows[0].SPID; 
    BatchID = result.Rows[0].BatchID;
    ProcName = result.Rows[0].ProcName;
    PlanID = result.Rows[0].PlanID;
    render_stmtstats(result, support157);
    if ( SQLHashKeyExists == 1 )
      SQLHashKey = result.Rows[0].SQLHashKey;
    if ( PLANHashKeyExists == 1 )
      PLANHashKey = result.Rows[0].PLANHashKey;

    refresh_stmtSQL();
    refresh_stmtPLAN();

    if (ProcName != null) 
      if ( (CachedXMLExists == 1) && (ProcName[0] == "*") )
        refresh_stmtXML();
  })
  .fail(function(data) {
    if (data.statusText == 'abort')
      return;
    alert( "error in refresh_stmtstats()" );
    $('#stmtstats').html('<div> Error when loading data </div>');
  })
  .always(function() {
    decXHRcnt();
  });
}


function render_stmtstats(result, support157) {


  $('#stmtstats').empty();
  if (result.TotalRows == 0) {
    $('#stmtstats').addClass('detailboxcontent_nodata');
    $('#stmtstats').append('<div>No data to display</div>');
  }
  else {
    $('#stmtstats').append('<table id="stmtstatsTable" >');
    $('#stmtstats').append('<tr> <td class="statTableUpperTitle" colspan="2" style="width:600px;"> Statement Info</td> <td class="statTableUpperTitle" colspan="2" style="width:600px"> Statement Statistics</td> </tr>');
    $('#stmtstats').append('<tr> <td class="statTableLabel">StartTime   : </td> <td class="statTable">' + Strttm                                    + ' </td> <td class="statTableLabel"> CpuTime_ms        : </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].CpuTime          )     + ' </td></tr>');
    $('#stmtstats').append('<tr> <td class="statTableLabel">Elapsed_s   : </td> <td class="statTable">' + number_format(result.Rows[0].Elapsed_s )  + ' </td> <td class="statTableLabel"> WaitTime_ms       : </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].WaitTime         )     + ' </td></tr>');
    $('#stmtstats').append('<tr> <td class="statTableLabel">Login       : </td> <td class="statTable">' + result.Rows[0].Login                      + ' </td> <td class="statTableLabel"> MemUsageKB        : </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].MemUsageKB       )     + ' </td></tr>');
    $('#stmtstats').append('<tr> <td class="statTableLabel">Application : </td> <td class="statTable">' + result.Rows[0].Application                + ' </td> <td class="statTableLabel"> PhysicalReads     : </td> <td class="statTable alignRight"> ' + result.Rows[0].PReads                               + ' </td></tr>');
    $('#stmtstats').append('<tr> <td class="statTableLabel">ClientHost  : </td> <td class="statTable">' + result.Rows[0].ClientHost                 + ' </td> <td class="statTableLabel"> LogicalReads      : </td> <td class="statTable alignRight"> ' + result.Rows[0].LReads                               + ' </td></tr>');
    $('#stmtstats').append('<tr> <td class="statTableLabel">ClientIP    : </td> <td class="statTable">' + result.Rows[0].ClientIP                   + ' </td> <td class="statTableLabel"> PagesModified     : </td> <td class="statTable alignRight"> ' + result.Rows[0].PModified                            + ' </td></tr>');
    $('#stmtstats').append('<tr> <td class="statTableLabel">ClientOSPID : </td> <td class="statTable">' + result.Rows[0].ClientOSPID                + ' </td> <td class="statTableLabel"> PacketsSent       : </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].PacketsSent      )     + ' </td></tr>');
    $('#stmtstats').append('<tr> <td class="statTableLabel">DBID        : </td> <td class="statTable">' + result.Rows[0].DBID                       + ' </td> <td class="statTableLabel"> PacketsReceived   : </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].PacketsReceived  )     + ' </td></tr>');
    $('#stmtstats').append('<tr> <td class="statTableLabel">ProcName    : </td> <td class="statTable">' + ProcName                                  + ' </td> <td class="statTableLabel"> NetworkPacketSize : </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].NetworkPacketSize)     + ' </td></tr>');
    $('#stmtstats').append('<tr> <td class="statTableLabel">LineNumber  : </td> <td class="statTable">' + result.Rows[0].LineNumber                 + ' </td> <td class="statTableLabel"> PlansAltered      : </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].PlansAltered     )     + ' </td></tr>');
    $('#stmtstats').append('<tr> <td class="statTableLabel">SPID        : </td> <td class="statTable">' + SPID                                      + ' </td> <td class="statTableLabel"> RowsAffected      : </td> <td class="statTable alignRight"> ' + number_format(result.Rows[0].RowsAffected     )     + ' </td></tr>');
    $('#stmtstats').append('<tr> <td class="statTableLabel">KPID        : </td> <td class="statTable">' + KPID                                      + ' </td> <td class="statTableLabel"> SQLHashKey        : </td> <td class="statTable alignRight"> ' +               result.Rows[0].SQLHashKey             + ' </td></tr>');
    $('#stmtstats').append('<tr> <td class="statTableLabel">PlanID      : </td> <td class="statTable">' + PlanID                                    + ' </td> <td class="statTableLabel"> PLANHashKey       : </td> <td class="statTable alignRight"> ' +               result.Rows[0].PLANHashKey            + ' </td></tr>');
    $('#stmtstats').append('<tr> <td class="statTableLabel">BatchID     : </td> <td class="statTable">' + BatchID                                   + ' </td> <td class="statTableLabel"> ExactStats         : </td> <td class="statTable alignRight"> ' +               result.Rows[0].ExactStat              + ' </td></tr>');
    if ( colV16SP03Exists == 0)
      $('#stmtstats').append('<tr> <td class="statTableLabel">ContextID   : </td> <td class="statTable">' + result.Rows[0].ContextID                  + ' </td> <td class="statTableLabel"> </td> <td class="statTable"> </td></tr>');
    else
      $('#stmtstats').append('<tr> <td class="statTableLabel">ContextID   : </td> <td class="statTable">' + result.Rows[0].ContextID                  + ' </td> <td class="statTableLabel"> QueryOptimizationTime_ms         : </td> <td class="statTable alignRight"> ' +               result.Rows[0].QueryOptimizationTime              + ' </td></tr>');
    
    if (support157 == 1)
      if (colV16SP03Exists == 1) {
      $('#stmtstats').append('<tr> <td class="statTableLabel">ClientName       : </td> <td class="statTable">' + result.Rows[0].ClientName     + ' </td> <td class="statTableLabel"> SnapCodegenTime_us    : </td> <td class="statTable alignRight"> ' + result.Rows[0].SnapCodegenTime    + ' </td></tr>');
      $('#stmtstats').append('<tr> <td class="statTableLabel">ClientHostName   : </td> <td class="statTable">' + result.Rows[0].ClientHostName + ' </td> <td class="statTableLabel"> SnapJITTime_us        : </td> <td class="statTable alignRight"> ' + result.Rows[0].SnapJITTime        + ' </td></tr>');
      $('#stmtstats').append('<tr> <td class="statTableLabel">ClientApplName   : </td> <td class="statTable">' + result.Rows[0].ClientApplName + ' </td> <td class="statTableLabel"> SnapExecutionTime_us  : </td> <td class="statTable alignRight"> ' + result.Rows[0].SnapExecutionTime  + ' </td></tr>');
      $('#stmtstats').append('<tr> <td class="statTableLabel">                   </td> <td class="statTable">                                      </td> <td class="statTableLabel"> SnapExecutionCount : </td> <td class="statTable alignRight"> ' + result.Rows[0].SnapExecutionCount + ' </td></tr>');
      }
      else {
      $('#stmtstats').append('<tr> <td class="statTableLabel">ClientName       : </td> <td class="statTable">' + result.Rows[0].ClientName     + ' </td> <td class="statTableLabel"> </td> <td class="statTable"> </td></tr>');
      $('#stmtstats').append('<tr> <td class="statTableLabel">ClientHostName   : </td> <td class="statTable">' + result.Rows[0].ClientHostName + ' </td> <td class="statTableLabel"> </td> <td class="statTable"> </td></tr>');
      $('#stmtstats').append('<tr> <td class="statTableLabel">ClientApplName   : </td> <td class="statTable">' + result.Rows[0].ClientApplName + ' </td> <td class="statTableLabel"> </td> <td class="statTable"> </td></tr>');
      }

    if ( supportFieldsAnja == 1) {
      $('#stmtstats').append('<tr> <td class="statTableLabel">StatementNumber   : </td> <td class="statTable">' + result.Rows[0].StatementNumber                + ' </td> <td class="statTableLabel"> </td> <td class="statTable"> </td></tr>');
      $('#stmtstats').append('<tr> <td class="statTableLabel">ProcNestLevel     : </td> <td class="statTable">' + result.Rows[0].ProcNestLevel                  + ' </td> <td class="statTableLabel"> </td> <td class="statTable"> </td></tr>');
    }
    
    if ( col_tran_name_Exists == 1 ) {
      $('#stmtstats').append('<tr> <td class="statTableLabel">Transaction Name  : </td> <td class="statTable">' + result.Rows[0].tran_name                + ' </td> <td class="statTableLabel"> </td> <td class="statTable"> </td></tr>');
    }

    $('#stmtstats').append('</table>');

  }
}


function refresh_stmtSQL () {


  var data = {ARContextJSON: JSON.stringify(ARContext),
              'StmtSQLHKExists' : StmtSQLHKExists,
               'SQLHashKey' : SQLHashKey,
               'BootID': BootID,
               'KPID': KPID,
               'SPID': SPID,
               'BatchID': BatchID,
               'Strttm': Strttm,
               'Elapsed_ms': Elapsed_ms};
  $('#stmtSQL').html('<div> Loading...</div>');
  $('#stmtSQL').removeClass('detailboxcontent_nodata');
  $('#stmtSQL').addClass('detailboxcontent_loading');

  if (ASM_XHR_refresh_stmtSQL != null) {
    ASM_XHR_refresh_stmtSQL.abort();
    ASM_XHR_refresh_stmtSQL = null;
  }
  incXHRcnt();
  ASM_XHR_refresh_stmtSQL = $.post( 'ASE/sql/sql_stmt_SQL.php', data ).done(function(res) {
    var result_stmtSQL = JSON.parse(res);
    if ( checkSQLError(result_stmtSQL, 'refresh_stmtSQL') ) return;
    $('#stmtSQL').removeClass('detailboxcontent_loading');
    if (result_stmtSQL.TotalRows == 0) {
      $('#stmtSQL').html('<div> No data to display</div>');
      $('#stmtSQL').addClass('detailboxcontent_nodata');
      $('#stmtSQL2DIV').hide();
    }
    else {
      if (result_stmtSQL.Rows[0].src=="StmtSQL") {
        result_stmtSQL.FormattedSQL = result_stmtSQL.FormattedSQL.replace('<', '&lt;');
        ASM_result_stmtSQL = result_stmtSQL; // Save this result in global var
        render_stmtSQL(); 
        if ( StmtSQLHKExists ==1 )  {
          // Retreive SQL from StmtSQLHK also (SQL Request normalized without param values)
          refresh_stmtSQL2 ();
        }
      }
      else
        refresh_stmtSQL2 ();
    }
  })
  .fail(function(data) {
    if (data.statusText == 'abort')
      return;
    alert( "error in refresh_stmtSQL()" );
    $('#stmtSQL').html('<div> Error when loading data </div>');
  })
  .always(function() {
    decXHRcnt();
  });
}


function render_stmtSQL() {

  var sql = "";
  var sqltext;
  var sep = "\n";
  var previousLineNumber = 1;
  var currentLineNumber;
  for (var i=0; i< ASM_result_stmtSQL.TotalRows; i++) {
    sqltext = ASM_result_stmtSQL.Rows[i].SQLText.replace('<', '&lt;');
    currentLineNumber = ASM_result_stmtSQL.Rows[i].LineNumber
    if (currentLineNumber == null) currentLineNumber = 1;
    if (currentLineNumber != previousLineNumber) {
      sql = sql + sep.repeat(currentLineNumber - previousLineNumber)  + sqltext;
      previousLineNumber = currentLineNumber;
    }
    else
      sql = sql + sqltext;
    
  }
  $('#stmtSQL').html('<pre class="brush: sql">'+sql+'</pre>');
  SyntaxHighlighter.highlight();

}



function refresh_stmtSQL2 () {


  var data = {ARContextJSON: JSON.stringify(ARContext),
              'StmtSQLHKExists' : StmtSQLHKExists,
               'SQLHashKey' : SQLHashKey,
               'BootID': 0,
               'KPID': 0,
               'SPID': 0,
               'BatchID': 0,
               'Strttm': '1/1/1900',
               'Elapsed_ms': 0};
  $('#stmtSQL2').html('<div> Loading...</div>');
  $('#stmtSQL2').removeClass('detailboxcontent_nodata');
  $('#stmtSQL2').addClass('detailboxcontent_loading');

  if (ASM_XHR_refresh_stmtSQL2 != null) {
    ASM_XHR_refresh_stmtSQL2.abort();
    ASM_XHR_refresh_stmtSQL2 = null;
  }
  incXHRcnt();
  ASM_XHR_refresh_stmtSQL2 = $.post( 'ASE/sql/sql_stmt_SQL.php', data ).done(function(res) {
    var result_stmtSQL = JSON.parse(res);
    if ( checkSQLError(result_stmtSQL, 'refresh_stmtSQL2') ) return;
    $('#stmtSQL2').removeClass('detailboxcontent_loading');
    if (result_stmtSQL.TotalRows == 0) {
//      $('#stmtSQL2').html('<div> No data to display</div>');
//      $('#stmtSQL2').addClass('detailboxcontent_nodata');
      $('#stmtSQL2DIV').hide();
    }
    else {
      result_stmtSQL.FormattedSQL = result_stmtSQL.FormattedSQL.replace('<', '&lt;');
      ASM_result_stmtSQL2 = result_stmtSQL; // Save this result in global var
      $('#stmtSQL2Title').html('<strong>SQL parameterized (HashKey='+SQLHashKey+')</strong>');
      render_stmtSQL2(); 
    }
  })
  .fail(function(data) {
    if (data.statusText == 'abort')
      return;
    alert( "error in refresh_stmtSQL()" );
    $('#stmtSQL').html('<div> Error when loading data </div>');
  })
  .always(function() {
    decXHRcnt();
  });
}


function render_stmtSQL2() {

  var sql = "";
  var sqltext;
  var sep = "\n";
  var previousLineNumber = 1;
  var currentLineNumber;
  for (var i=0; i< ASM_result_stmtSQL2.TotalRows; i++) {
    sqltext = ASM_result_stmtSQL2.Rows[i].SQLText.replace('<', '&lt;');
    currentLineNumber = ASM_result_stmtSQL2.Rows[i].LineNumber
    if (currentLineNumber == null) currentLineNumber = 1;
    if (currentLineNumber != previousLineNumber) {
      sql = sql + sep.repeat(currentLineNumber - previousLineNumber)  + sqltext;
      previousLineNumber = currentLineNumber;
    }
    else
      sql = sql + sqltext;
    
  }
  $('#stmtSQL2').html('<pre class="brush: sql">'+sql+'</pre>');
  SyntaxHighlighter.highlight();

}



function render_formattedSQL () {
  $('#stmtSQL').html('<pre class="brush: sql">'+ASM_result_stmtSQL.FormattedSQL+'</pre>');
  SyntaxHighlighter.highlight();
}

function render_formattedSQL2 () {
  $('#stmtSQL2').html('<pre class="brush: sql">'+ASM_result_stmtSQL2.FormattedSQL+'</pre>');
  SyntaxHighlighter.highlight();
}

function refresh_stmtPLAN () {

  var query;
  if ( (typeof PLANHashKey == 'undefined') || (PLANHashKey == "")|| (StmtPlnHKExists==0) ) {
    query = 
     "select       "
    +"    Sequence,"
    +"    SQLPlan  "
    +" from "+ARContext.ServerName+"_StmtPlan"
    +" where StmtID = "+StmtID+"             "
    +" order by 1";
    $('#stmtPLANTitle').html('<strong>Plan</strong>');
  }
  else {
    query = 
     "select       "
    +"    Sequence,"
    +"    SQLPlan  "
    +" from "+ARContext.ServerName+"_StmtPlnHK"
    +" where PLANHashKey = "+PLANHashKey+"    "
    +" order by 1";
    $('#stmtPLANTitle').html('<strong>Plan (HashKey='+PLANHashKey+')</strong>');
  }


  var data = {ARContextJSON: JSON.stringify(ARContext), 'query' : query};
  $('#stmtPLAN').html('<div> Loading...</div>');
  $('#stmtPLAN').addClass('detailboxcontent_loading');

  if (ASM_XHR_refresh_stmtPLAN != null) {
    ASM_XHR_refresh_stmtPLAN.abort();
    ASM_XHR_refresh_stmtPLAN = null;
  }
  incXHRcnt();
  ASM_XHR_refresh_stmtPLAN = $.post( 'COMMON/simplequery.php', data ).done(function(res) {
    var result = JSON.parse(res);
    if ( checkSQLError(result, 'refresh_stmtPLAN') ) return;
    $('#stmtPLAN').removeClass('detailboxcontent_loading');
    if (result.TotalRows == 0) {
      $('#stmtPLAN').html('<div> No data to display</div>');
      $('#stmtPLAN').addClass('detailboxcontent_nodata');
    }
    else
      render_stmtPLAN(result);
  })
  .fail(function(data) {
    if (data.statusText == 'abort')
      return;
    alert( "error in refresh_stmtPLAN()" );
    $('#stmtPLAN').html('<div> Error when loading data </div>');
  })
  .always(function() {
    decXHRcnt();
  });
}

function render_stmtPLAN(result) {

    var plan = "";
    var SQLPlan;
    var sep = "\n";
    for (var i=0; i < result.TotalRows; i++) {
      SQLPlan = result.Rows[i].SQLPlan.replace('<', '&lt;');
      plan = plan  + sep + SQLPlan;
      
    }
    $('#stmtPLAN').html('<pre class="brush: sql">'+plan+'</pre>');
    SyntaxHighlighter.highlight();
}

function refresh_stmtXML () {


  var data = {ARContextJSON: JSON.stringify(ARContext), 'ProcName' : ProcName, 'PlanID' : PlanID, 'Strttm' : Strttm};

  if (ASM_XHR_refresh_stmtXML != null) {
    ASM_XHR_refresh_stmtXML.abort();
    ASM_XHR_refresh_stmtXML = null;
  }
  incXHRcnt();
  ASM_XHR_refresh_stmtXML = $.post( 'ASE/sql/sql_stmt_XML.php', data ).done(function(res) {
    var result = JSON.parse(res);
    if ( checkSQLError(result, 'refresh_stmtXML') ) return;
    render_stmtXML(result);
  })
  .fail(function(data) {
    if (data.statusText == 'abort')
      return;
    alert( "error in refresh_stmtXML()" );
  })
  .always(function() {
    decXHRcnt();
  });
}

function render_stmtXML(result) {

  resultXML = result;

  if (result.TotalPlans > 0) {
    for (var i=0; i < result.TotalPlans; i++) {

      $('#XMLPlans').append('<div class="boxinmain detailbox" >'
                          + '  <div class="statTitle" ><strong>XML Plan ID : '+PlanID+' Captured at : '+result.Plans[i].ts+'</strong></div>'
                          + '  <div class="statLowerTitle" ><div style="margin-left: 10px;" align="left" ><input id="XMLBtn_'+i+'" value="ShowRawXML" type="button" class="btn btn-primary btn-xs" /></div></div>'
                          + '  <div id="XMLText_'+i+'" class="boxcontent" style="width:100%" align="left" >'+result.Plans[i].FormattedXML+'</div>'
                          + '</div>');

      $('#XMLBtn_'+i).click(function() {
        var i = this.id.substring(7);
        if (this.value == 'ShowRawXML') {
          $('#XMLText_'+i).html(resultXML.Plans[i].RawXML);
          this.value = 'ShowFormattedXML';
        }
        else {
          $('#XMLText_'+i).html(resultXML.Plans[i].FormattedXML);
          this.value = 'ShowRawXML';
        }
      });

      //$('#stmtXML').html(resultXML.Plans[i].RawXML);
      
    }
  }
}


onArchCnxOpened = function(){

  if ( existColumn(ARContext.ServerName+'_StmtStat', 'ClientName') ) {
    support157 = 1;
  }

  if ( existTable(ARContext.ServerName+'_StmtObj' ) ) {
    StmtObjExists = 1;
  }
  if ( existColumn(ARContext.ServerName+'_StmtObj', 'PartitionID') ) {
    StmtObjVersion = 'new';
  }

  if ( existTable(ARContext.ServerName+'_CachedXML' ) ) {
    CachedXMLExists = 1;
  }

  if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_StmtSQLHK') )  ) {
    StmtSQLHKExists = 1;
  }

  if ( (ARContext.ServerName!="") && ( existTable(ARContext.ServerName+'_StmtPlnHK') )  ) {
    StmtPlnHKExists = 1;
  }

  if ( (ARContext.ServerName!="") && ( existColumn(ARContext.ServerName+'_StmtStat', 'SQLHashKey') )  ) {
    SQLHashKeyExists = 1;
  }

  if ( (ARContext.ServerName!="") && ( existColumn(ARContext.ServerName+'_StmtStat', 'PLANHashKey') )  ) {
    PLANHashKeyExists = 1;
  }

  if ( (ARContext.ServerName!="") && ( existColumn(ARContext.ServerName+'_StmtStat', 'QueryOptimizationTime') )  ) {
    colV16SP03Exists = 1;
  }

  if ( (ARContext.ServerName!="") && ( existColumn(ARContext.ServerName+'_StmtStat', 'StatementNumber') ) && ( existColumn(ARContext.ServerName+'_StmtStat', 'ProcNestLevel') ) ) {
    supportFieldsAnja = 1;
  }

  if ( (ARContext.ServerName!="") && ( existColumn(ARContext.ServerName+'_StmtStat', 'tran_name') ) ) {
    col_tran_name_Exists = 1;
  }

  refresh_stmtstats(support157);

  if (StmtObjExists == 1) {


    var fields = [];
    var cols = [];
    if (StmtObjVersion == 'old') {
      fields = [
                   { name: 'DBName',           type: 'string'},
                   { name: 'OwnerUserID',      type: 'number'},
                   { name: 'ObjectName',       type: 'string'},
                   { name: 'ObjectType',       type: 'string'},
                   { name: 'IndexID',          type: 'number'},
                   { name: 'L_Reads',     type: 'number'},
                   { name: 'PhysicalReads',    type: 'number'},
                   { name: 'PhysicalAPFReads', type: 'number'},
                   { name: 'TableSize',        type: 'number'}
                   ];
      cols= [
                { text: 'DBName    ',  datafield: 'DBName',           width: 140, filterable: false},
                { text: 'Owner     ',  datafield: 'OwnerUserID',      width: 140, filterable: false},
                { text: 'ObjectName',  datafield: 'ObjectName',       width: 220, filterable: false},
                { text: 'ObjectType',  datafield: 'ObjectType',       width: 180, filterable: false},
                { text: 'IndexID   ',  datafield: 'IndexID',          width: 120, filterable: false},
                { text: 'L_Reads   ',  datafield: 'L_Reads',     width: 100, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
                { text: 'P_Reads   ',  datafield: 'PhysicalReads',    width: 100, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
                { text: 'P_APFReads',  datafield: 'PhysicalAPFReads', width: 100, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
                { text: 'TblSize(Kb)', datafield: 'TableSize',        width: 100, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'}
                ];
    }
    else {
      fields = [
                   { name: 'DBName',           type: 'string'},
                   { name: 'OwnerUserID',      type: 'number'},
                   { name: 'ObjectName',       type: 'string'},
                   { name: 'ObjectType',       type: 'string'},
                   { name: 'IndexID',          type: 'number'},
                   { name: 'L_Reads',     type: 'number'},
                   { name: 'PhysicalReads',    type: 'number'},
                   { name: 'PhysicalAPFReads', type: 'number'},
                   { name: 'PartitionSize',    type: 'number'},
                   { name: 'IdxName',          type: 'string'}
                   ];
      cols= [
                { text: 'DBName    ',  datafield: 'DBName',           width: 120, filterable: false},
                { text: 'Owner     ',  datafield: 'OwnerUserID',      width: 120, filterable: false},
                { text: 'ObjectName',  datafield: 'ObjectName',       width: 160, filterable: false},
                { text: 'ObjectType',  datafield: 'ObjectType',       width: 120, filterable: false},
                { text: 'IndexID   ',  datafield: 'IndexID',          width: 120, filterable: false},
                { text: 'L_Reads   ',  datafield: 'L_Reads',     width: 100, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
                { text: 'P_Reads   ',  datafield: 'PhysicalReads',    width: 100, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
                { text: 'P_APFReads',  datafield: 'PhysicalAPFReads', width: 100, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
                { text: 'PtnSize(Kb)', datafield: 'PartitionSize',    width: 100, filterable: false, cellsformat: 'd',  filtertype: 'number', cellsalign: 'right'},
                { text: 'IdxName',     datafield: 'IdxName',          width: 160, filterable: false}
                ];
    }
    
    
    $('#objectsStatistics').asemonGrid({
    'title' : 'Statement Objects Statistics',
    'width' : '100%',
    'height' : 400,
    'minimizeheight': true,
    'rowcount': 100,
    'filterable': false,
    'sortable': true,
    'toolbar': false,
    'showaggregates': false,
    'querydata' : {'queryfile' : '../ASE/sql/sql_stmt_objects.php',
                   'StmtID' : StmtID,
                   'StmtObjVersion': StmtObjVersion},
    'datafieldsMapping' : { },
    'datafields': fields,
    'columns': cols
    });

  }


  $('#FormatSQLBTN').click(function() {
    if (this.value == 'FormatSQL') {
      render_formattedSQL ();
      this.value = 'OriginalSQL';
    }
    else {
      render_stmtSQL ();
      this.value = 'FormatSQL';
    }
  });

  $('#FormatSQL2BTN').click(function() {
    if (this.value == 'FormatSQL2') {
      render_formattedSQL2 ();
      this.value = 'OriginalSQL2';
    }
    else {
      render_stmtSQL2 ();
      this.value = 'FormatSQL2';
    }
  });


};

  
</script>


/**
* <p>Asemon_logger</p>
* <p>Asemon_logger :  main class</p>
* <p>Copyright: Jean-Paul Martin (jpmartin@sybase.com) Copyright (c) 2004</p>
* @version 3.2.6
*/

package asemon_logger;
import java.util.*;
import gnu.getopt.*;
import java.text.SimpleDateFormat;
import java.lang.management.ManagementFactory;
import java.io.*;
import java.sql.*;

public class Asemon_logger {
   static String Asemon_logger_version = "V3.2.6";
   static String Asemon_logger_sysmonprocs_version = "V3.2.0";  // Change this only if sp_sysmon procs have changed.
                                                                // Avoid recreating procs for each new asemon version
   
   static int asemon_procs_version_V12503    = 27180;
   static int asemon_procs_version_V125      = 27180;
   static int asemon_procs_version_V15       = 27180;
   static int asemon_procs_version_V157      = 31000;
   static int asemon_procs_version_V157SP100 = 31000;
   static int asemon_procs_version_V16       = 31000;
   static int threadNameSizeMax=1;                          // Used to format messages
   static String config_file;                               // Configuration file name (with or without path)
   static Config config;                                    // Used to store all the configuration
   static CnxMgr cnxMgr;                                    // Used to manage all types of connections
   static PassFileMgr pfm=null;                             // Used to manage passwords

   static int admin_port=0;                                 // port this asemon will listen to. If 0, don't listen to any port.
   static String name="";                                   // used to retreive the sa password in the password file of this asemon_logger

   static Archive_interface archive_class;       // Class used to implement archive methods
//   static String archive_DBMS=null;
   static String archive_server=null;
   static String archive_type=null;
   static String archive_user=null;
   static String archive_aseUserStoreKey=null;
   static Boolean archive_useKerberos;
   static Boolean archive_useSSL;
   static Boolean archive_useLongSrvNames; // Yes if tables in archive database can have long names (255 chars)
   static String archive_base=null;
   static String archive_charset=null;
   static String archive_address=null;
   static String archive_granteeList=null;
   static int    archive_poolsize=1;
   static int    archive_packet_size=0;                      // If >0, use this packet size to connect to the servers
   static String archive_sbssav="";
   static boolean archive_use_IQ_RLV = false;
   
   static Vector<Integer> traceflags;
   static boolean skipRetreiveSQLText = false;
   static boolean skipRetreivePlan = false;
   static boolean disableBulkLoad = false;
   static boolean enableJNDI = false;
   static boolean disableENCPASS = false;
   static boolean skipSAProcs = false;
   static boolean skipRetreiveProcessObject = false;
   static boolean traceCounterOverflow = false;
   static boolean forceIQMerge = false;
   static boolean skipArchiveSQL = false;
   static boolean ArchiveSQLHK = true;                      // Since V3.1.5 set default to TRUE
   static boolean skipArchiveSQLHK = false;
   static boolean bypassCheckAlreadyConnected = false;
   static boolean skipReorgUpdstatsArchTables = false;
   static boolean skipCollapseInLists = false;

   static boolean debug=false;                               // if TRUE, then DEBUG mode
   static Vector<Integer> debugSwitchs;

   static int DBG100 = 100;  // Collector CachedSQL
   static int DBG101 = 101;  // Collector CachedXML
   static int DBG102 = 102;  // Gzip
   static int DBG103 = 103;  // Check and load sysmon procs
   static int DBG104 = 104;  // Collector MonSQL
   static int DBG105 = 105;  // Debug MetricDescriptor
   static int DBG106 = 106;  // Print Archive_array's
   static int DBG107 = 107;  // Debug LockWaits
   static int DBG108 = 108;  // Debug Get/free archCnx
   static int DBG109 = 109;  // Print content of archive_array in case of error
   static int DBG110 = 110;  // Debug set/unset BULK COPY on cnx
   static int DBG111 = 111;  // Debug usage of currentRunningStmts
   static int DBG112 = 112;  // Debug archiveIndic
   static int DBG113 = 113;  // Debug purge
   static int DBG114 = 114;  // Debug reorg tables
   static int DBG115 = 115;  // Debug SQL parametrization
   static int DBG116 = 116;  // Debug SQL normalization
   static int DBG117 = 117;  // Debug IQSysmon
   static int DBG118 = 118;  // Print SQL in case of error during remove of comments in normStr
   static int DBG119 = 119;  // Print XML collect in monSQL

   static Long osProcessId;

//   static final Object lock_archive_conn = new Object();          // Used by all threads to synchronize on this

//   static Connection archive_conn=null;


   static String usage_string = "Usage : asemon_logger  -c config_file.xml [-V] \n";

   
   static void getArgs(String args[]) {

        Getopt g = new Getopt("asemon_logger", args, "c:T:V?Dd:");

        int c;
        int traceflag;
        int debugswitch;

        while ((c = g.getopt()) != -1) {
            switch(c) {
            case 'c':
                config_file = g.getOptarg();
                break;
            case 'T':
                traceflag=0;
                try {
                  traceflag = Integer.parseInt(g.getOptarg());
                }
                catch (Exception e) {
                   Asemon_logger.printmess ("Bad trace flag : " + g.getOptarg());
                   System.exit(1);
                }
                traceflags.add( new Integer(traceflag) );
                switch (traceflag) {
                case 1 :
                  skipRetreiveSQLText=true;
//                  Asemon_logger.printmess("Active traceflag : "+traceflag + " = skipRetreiveSQLText");
                  break;
                case 2 :
                  disableBulkLoad=true;
//                  Asemon_logger.printmess("Active traceflag : "+traceflag + " = disableBulkLoad");
                  break;
                case 3 :
                  enableJNDI=true;
//                  Asemon_logger.printmess("Active traceflag : "+traceflag + " = enableJNDI");
                  break;
                case 4 :
                  disableENCPASS=true;
//                  Asemon_logger.printmess("Active traceflag : "+traceflag + " = disable ENCRYPT PASSWORD");
                  break;
                case 5 :
                  skipRetreivePlan=true;
//                  Asemon_logger.printmess("Active traceflag : "+traceflag + " = skipRetreivePlan");
                  break;
                case 6 :
                  skipSAProcs=true;
//                  Asemon_logger.printmess("Active traceflag : "+traceflag + " = skipSAProcs");
                  break;
                case 7 :
                  skipRetreiveProcessObject=true;
//                  Asemon_logger.printmess("Active traceflag : "+traceflag + " = skipRetreiveProcessObject");
                  break;
                case 8 :
                  traceCounterOverflow=true;
//                  Asemon_logger.printmess("Active traceflag : "+traceflag + " = traceCounterOverflow");
                  break;
                case 9 :
                  forceIQMerge=true;
//                  Asemon_logger.printmess("Active traceflag : "+traceflag + " = forceIQMerge");
                  break;
                case 10 :
                  skipArchiveSQL=true;
//                  Asemon_logger.printmess("Active traceflag : "+traceflag + " = skipArchiveSQL");
                  break;
                case 11 :
                  ArchiveSQLHK=true;
//                  Asemon_logger.printmess("Active traceflag : "+traceflag + " = ArchiveSQLHK");
                  break;                  
                case 12 :
                  bypassCheckAlreadyConnected=true;
                  Asemon_logger.printmess("Active traceflag : "+traceflag + " = bypassCheckAlreadyConnected");
                  break;
                case 13 :
                  skipReorgUpdstatsArchTables=true;
                  Asemon_logger.printmess("Active traceflag : "+traceflag + " = skipReorgUpdstatsArchTables");
                  break;
                case 14 :
                  skipArchiveSQLHK=true;
                  ArchiveSQLHK=false;
//                  Asemon_logger.printmess("Active traceflag : "+traceflag + " = skipArchiveSQLHK");
                  break;                  
                case 15 :
                  skipCollapseInLists=true;
                  Asemon_logger.printmess("Active traceflag : "+traceflag + " = skipCollapseInLists");
                  break;                  
                default:
                  Asemon_logger.printmess("Unknown traceflag : "+traceflag);
                }
                break;
            case 'V':
            	System.out.println(Asemon_logger_version);
                System.exit(1);
                break;
            case 'D':
            	Asemon_logger.printmess ("DEBUG mode");
                debug=true;
                break;
            case '?':
            	System.out.println(usage_string);
                break;
            case 'd':
                debugswitch=0;
                try {
                  debugswitch = Integer.parseInt(g.getOptarg());
                }
                catch (Exception e) {
                   Asemon_logger.printmess ("Bad debugswitch : " + g.getOptarg());
                   System.exit(1);
                }
                debugSwitchs.add( new Integer(debugswitch) );
                Asemon_logger.printmess ("DEBUG flag : "+debugswitch);
                break;
            default:
                System.out.println("Invalid switch '" + (char)c + "'");
            	System.out.println(usage_string);
                System.exit(1);
            }
        }
	
      if ( config_file==null ) {
                Asemon_logger.printmess ("ERROR Provide a configuration file");
            	System.out.println(usage_string);
                System.exit(1);
      }
	
   }





  static void printmess(String aMessage)
  {
    java.util.Date curdate= new java.util.Date();
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS" );
    System.out.println(sdf.format(curdate) + " " + String.format("%-"+threadNameSizeMax+"s",Thread.currentThread().getName()) +" - " + aMessage );
  }

  static void ERROR (String aMessage)
  {
          printmess("ERROR  - " + aMessage);
  }


  static void DEBUG (String aMessage)
  {
      if (debug) {
          printmess("DEBUG  - " + aMessage);
      }
  }

  static void DEBUG (int level,String aMessage)
// 100 : debug in CachedSQL
// 101 : debug in CachedXML
  {
      if ( debug || (debugSwitchs.contains(level)) ) {
          printmess("DEBUG  - " + aMessage);
      }
  }
  
  
  static String readfile (String fic) throws Exception {
      BufferedReader reader;
      String         line;
      StringBuilder  stringBuilder;
      String         ls = "\n";

      reader = new BufferedReader( new FileReader (fic));
      line = null;
      stringBuilder = new StringBuilder();

      while( ( line = reader.readLine() ) != null ) {
          stringBuilder.append( line );
          stringBuilder.append( ls );
      }
      return stringBuilder.toString();
  }
  
  static void load_sp_sysmon_procs(CnxMgr.ArchCnx aArchCnx) {
      String fname;
      String procname;
      Statement stmt=null;
      ResultSet rs;
      String SQL;
      
      // check files in directory "proc"
      Properties sysprops = System.getProperties();
      String asemon_home = sysprops.getProperty("ASEMON_LOGGER_HOME");
      if (asemon_home==null) asemon_home=".";
      
      try {
          stmt = aArchCnx.archive_conn.createStatement();
          
          if (archive_type.compareTo("ASE") == 0) {
              rs = stmt.executeQuery(
                        "if not  exists (select spid from master..sysprocesses where program_name = 'asemon_arch' and clientname = 'asemon_procs_in_construction')\n" +
                        " begin\n" +
                        "  set clientname asemon_procs_in_construction\n" +
                        "  select 'OK'\n" +
                        " end\n" +
                        " else\n" +
                        "  select 'BUSY'");
              if (rs.next()) {
                  if (rs.getString(1).compareTo("BUSY")==0) {
                      // Another asemon_logger is creating procs.
                      // Exit this procedure
                      printmess("Another asemon_logger is currently creating sp_sysmon procs in archive database. Skip this step.");
                      stmt.close();
                      return;
                  }
              }
              //stmt.executeUpdate("set clientname asemon_procs_in_construction");
          }






          File folder = new File(asemon_home+"/proc/");
          if (folder == null ) return;
          printmess("Check/create sp_sysmon procs in archive database");
          if (archive_type.compareTo("ASE") == 0) {
              // For ASE, create temporary tables necessary to compile procs
              for (final File fileEntry : folder.listFiles()) {
                  if (fileEntry.isDirectory()) continue; // skip directory if any
                  fname = fileEntry.getName();
                  if ( (fname.startsWith("tmp_")) && (fname.endsWith(".sql")) ) {
                      // create temp table
                      DEBUG ("load_sp_sysmon_procs. Create temp table with file : " + fname);

                      // read file into string
                      try {
                          SQL = readfile (asemon_home+"/proc/"+fname);
                          stmt. executeUpdate(SQL);
                      }
                      catch (Exception e) {
                          DEBUG("load_sp_sysmon_procs. Err in '"+fname+"' : " + e.getMessage());
                      }
                  }
              }
          }
          
          String asemonProcVersion="";     // Asemon version of procedures in database
          String procASEVersion;           // ASE version of proc (V125,V150,V155,V157,V16, V16SP3)
          boolean reload_procs=false;
          
          rs = null;
          try {
              rs=stmt.executeQuery("exec sp_sysmon_asemon_version");
          }
          catch (SQLException e) {
              int err = e.getErrorCode();
              // 504 : proc not found in ASE
              // 2812 : proc not found in IQ
              if (( err==504) || (err==2812)) {
                  asemonProcVersion = "";
              }
          }
          if (rs!=null) {
              rs.next();
              asemonProcVersion=rs.getString(1);
          }
          DEBUG(Asemon_logger.DBG103,"load_sp_sysmon_procs. Procversion = "+asemonProcVersion);
          if (asemonProcVersion.compareTo(Asemon_logger_sysmonprocs_version)<0) {
              reload_procs = true;
              if (asemonProcVersion.length()>0) stmt.executeUpdate("drop proc sp_sysmon_asemon_version");
              stmt.executeUpdate("create proc sp_sysmon_asemon_version as select '"+Asemon_logger_sysmonprocs_version+"'");
          }
          for (final File fileEntry : folder.listFiles()) {
              if (fileEntry.isDirectory()) continue; // skip directory if any
              fname = fileEntry.getName();
              if ( !(fname.startsWith("tmp_")) && (fname.endsWith(".sql")) ) {
                  // extract proc name
                  procname = fname.substring(0, fname.lastIndexOf(".sql"));
                  if (fname.lastIndexOf("_V")==-1) {
                      // no version. Force to 12.5
                      procASEVersion="12.5";
                  }
                  else {
                      procASEVersion = fname.substring(fname.lastIndexOf("_V")+2, fname.lastIndexOf(".sql"));
                      if (procASEVersion.compareTo("125")==0) procASEVersion="12.5";
                      else if (procASEVersion.compareTo("150")==0) procASEVersion="15.0";
                      else if (procASEVersion.compareTo("155")==0) procASEVersion="15.5";
                      else if (procASEVersion.compareTo("157")==0) procASEVersion="15.7";
                      else if (procASEVersion.compareTo("16")==0) procASEVersion="16.0";
                      else if (procASEVersion.compareTo("16SP3")==0) procASEVersion="16.0.03.00";
                      else if (procASEVersion.compareTo("161")==0) procASEVersion="16.1.00.00";
                  }

                  if (Asemon_logger.archive_sbssav.compareTo(procASEVersion) < 0 )
                      // Archive server version is lower than version of procedure, skip it, it may not load into this ASE
                      continue;
                  DEBUG(Asemon_logger.DBG103, "load_sp_sysmon_procs. Check existance of procedure : " + procname);
                  try {
                      if (reload_procs)
                          try {
                          stmt.executeUpdate("drop proc " + procname);
                          }
                          catch (SQLException e) {
                              int err = e.getErrorCode();
                              if ( (err!=3701)&&(err!=504)) {
                                  ERROR ("Cannot drop procedure '"+ procname+"'. Error="+e.getErrorCode()+ " "+ e.getMessage());
                                  throw e;
                              }
                          }
                      rs = stmt.executeQuery("select object_id('" + procname + "')");
                      rs.next();
                      rs.getInt(1);
                      if ( rs.wasNull() ) {
                          // object does not exists
                          printmess ("load_sp_sysmon_procs. Load procedure : " + procname);

                          stmt.executeUpdate("set quoted_identifier off");

                          // read file into string
                          SQL = readfile (asemon_home+"/proc/"+fname);
                          stmt.executeUpdate(SQL);
                          if ((archive_granteeList != null)&&(!archive_granteeList.equals(""))) {
                                 stmt.executeUpdate("grant execute on " + procname + " to "+archive_granteeList);
                          }
                      }
                  }
                  catch (SQLException sqle) {
                      if (sqle.getErrorCode() == 2007) {
                          // Ignore warning 'Cannot add rows to sysdepends for the current stored procedure because it depends on the missing object '%.*s'. The stored procedure will still be created.
                      }
                  }
                  catch (Exception e) {
                      ERROR ("load_sp_sysmon_procs. Err in '"+fname+"' : " + e.getMessage());
                      ERROR ("                      sp_sysmon_xxx procedures will re-created at next restart");
                      try {
                          stmt.executeUpdate("drop proc sp_sysmon_asemon_version");
                      }
                      catch (Exception ex) {}
                  }
                  finally {
                      try {
                          stmt.executeUpdate("set quoted_identifier on");
                      }
                      catch (Exception ex) {}                     
                  }
              }
          }
      }
      catch (Exception e) {
          ERROR ("load_sp_sysmon_procs. " + e.getMessage());
      }
      finally {
          try {
              if (archive_type.compareTo("ASE") == 0) {
                  if (stmt != null) 
                      stmt.executeUpdate("set clientname ''");
              }
          }
          catch (Exception ex) {}                     
      }

      
}
  


  public static void main(String[] args)
  {
    traceflags = new Vector<Integer>();
    debugSwitchs = new Vector();

    getArgs(args);


    // Get host process id of this running asemon_logger
    String pid = ManagementFactory.getRuntimeMXBean().getName();
    String[]Ids = pid.split("@");
    osProcessId = Long.valueOf(Ids[0]);


    printmess ("Java version used =  "+System.getProperty("java.version"));
    printmess ("Start Asemon_logger "+Asemon_logger_version);
    printmess ("Current directory is : "+System.getProperty("user.dir"));
    String jver = System.getProperty("java.version");
    printmess ("Java version : "+jver);
    float jverAsFloat = Float.parseFloat(jver.substring(0,3));
    if (jverAsFloat < 1.6) {
        printmess ("Your Java version should be 1.6 minium");
        System.exit(1);
    }
    printmess ("Classpath is : "+System.getProperty("java.class.path"));
    printmess ("Config file used : "+config_file);
    // initialize the password manager
    pfm = new PassFileMgr("passwords");
    // encrypt clear passwords
    pfm.encryptFile();

    // Force caching of DNS lookup to 0 s
    // So if DNS address is changed, asemon_logger will reconnect to the new address
    java.security.Security.setProperty("networkaddress.cache.ttl" , "0");    
    // tests on Sun show this is not working
    // you must set -Dsun.net.inetaddr.ttl=0 on the start command of the java vm

    // Initialize configuration
    config = new Config();
    if ( !config.loadConfig(config_file) )
        System.exit(1);

    if (skipRetreiveSQLText==true)
                  Asemon_logger.printmess("Active traceflag : 1 = skipRetreiveSQLText");
    if (disableBulkLoad==true)
                  Asemon_logger.printmess("Active traceflag : 2 = disableBulkLoad");
    if (enableJNDI==true)
                  Asemon_logger.printmess("Active traceflag : 3 = enableJNDI");
    if (disableENCPASS==true)
                  Asemon_logger.printmess("Active traceflag : 4 = disable ENCRYPT PASSWORD");
    if (skipRetreivePlan==true)
                  Asemon_logger.printmess("Active traceflag : 5 = skipRetreivePlan");
    if (skipSAProcs==true)
                  Asemon_logger.printmess("Active traceflag : 6 = skipSAProcs");
    if (skipRetreiveProcessObject==true)
                  Asemon_logger.printmess("Active traceflag : 7 = skipRetreiveProcessObject");
    if (traceCounterOverflow==true)
                  Asemon_logger.printmess("Active traceflag : 8 = traceCounterOverflow");
    if (forceIQMerge==true)
                  Asemon_logger.printmess("Active traceflag : 9 = forceIQMerge");
    if (skipArchiveSQL==true)
                  Asemon_logger.printmess("Active traceflag : 10 = skipArchiveSQL");
//    if (ArchiveSQLHK==true)
//                  Asemon_logger.printmess("Active traceflag : 11 = ArchiveSQLHK");
    if (bypassCheckAlreadyConnected==true)
                  Asemon_logger.printmess("Active traceflag : 12 = bypassCheckAlreadyConnected");
    if (skipReorgUpdstatsArchTables==true)
                  Asemon_logger.printmess("Active traceflag : 13 = skipReorgUpdstatsArchTables");
    if (skipArchiveSQLHK==true)
                  Asemon_logger.printmess("Active traceflag : 14 = skipArchiveSQLHK");
    if (skipCollapseInLists==true)
                  Asemon_logger.printmess("Active traceflag : 15 = skipCollapseInLists");
    
    // initialize connections manager
    cnxMgr = new CnxMgr();
         
    // initialize archive class
    switch (Asemon_logger.archive_type) {
        case "ASE" : {
            archive_class = (Archive_interface) new Archive_ASE();
            break;
        }
        case "IQ" : {
            archive_class = (Archive_interface) new Archive_IQ();
            // Force disable BULK LOAD when archiving into IQ
            Asemon_logger.disableBulkLoad = true;
            break;
        }
        default : {
            printmess ("Invalid archive type");            
            System.exit(1);
        }
    }
    
    
    // Check password for the archive server
    String pw = Asemon_logger.pfm.getPassword(archive_server, archive_user);
    // Get an archive connection from the pool
    CnxMgr.ArchCnx aArchCnx=null;
    try {
        aArchCnx = CnxMgr.archCnxPool.getArchCnx(true);
        if ( (pw==null) && (!aArchCnx.isConnected) ) {
            // Password was not defined and connection couldn't open : probably bad password given
            // Remove the given password from the password file and exit
            Asemon_logger.pfm.delPassword(archive_server, archive_user);
            Asemon_logger.printmess ("Password removed from passwords file for '" +archive_server+"."+archive_user+"'");
            System.exit(1);
        }
    }
    catch (Exception e) {
        System.exit(1);
    }

    // load sp_sysmon procedures in archive db
    if ( aArchCnx.isConnected) load_sp_sysmon_procs(aArchCnx);
    
    // Return this connection to the pool
    CnxMgr.archCnxPool.putArchCnx(aArchCnx);
    
    // Start thread for each metric descriptor for the monitored servers in the config file
    MonitoredSRV aMonitoredSRV;
    Config.SrvDescriptor aSrvDescriptor;

    // Loop on all monitored server to establish connection (this is to ask password, if necessary, at the begining of asemon)
    int tmpthreadNameSizeMax=1;
    for (Enumeration eMs = config.monitoredSRVs.elements(); eMs.hasMoreElements();) {
        aMonitoredSRV = (MonitoredSRV) eMs.nextElement();
        aSrvDescriptor = aMonitoredSRV.sd;
        if (aMonitoredSRV.name.length()+10 > tmpthreadNameSizeMax)
            tmpthreadNameSizeMax = aMonitoredSRV.name.length()+10;

        // Check if a password exists in the password file for this server
        // If no, will be asked during connection establishment
        pw = Asemon_logger.pfm.getPassword(aMonitoredSRV.name, aMonitoredSRV.user);

        boolean cOK=false;

        // Open connection. If cannot open connection, don't wait
        cOK = aMonitoredSRV.opencnx(true, true);

        if (!cOK && (pw==null)) {
            // Password was not defined and connection couldn't open : probably bad password given
            // Remove the given password from the password file and exit
            Asemon_logger.pfm.delPassword(aMonitoredSRV.name, aMonitoredSRV.user);
            Asemon_logger.printmess ("Password removed from passwords file for '" +aMonitoredSRV.name+"."+aMonitoredSRV.user+"'");
//            System.exit(1);
            aMonitoredSRV.hasPassword = false;
        }
        else
            aMonitoredSRV.hasPassword = true;
    }
    threadNameSizeMax = tmpthreadNameSizeMax;

    // Loop on all monitored servers to start all collector threads
    for (Enumeration eMs = config.monitoredSRVs.elements(); eMs.hasMoreElements();) {
        aMonitoredSRV = (MonitoredSRV) eMs.nextElement();
        if (!aMonitoredSRV.hasPassword) continue; // don't start threads if server has no password defined
        aSrvDescriptor = aMonitoredSRV.sd;
        aMonitoredSRV.collectors = new Hashtable<String, Collector>();

        // Loop on all metric descriptors attached to this server descriptor
        String metricsDescriptorsFile;
        Properties SDLevelParameters;   
        MetricDescriptor aMetricDescriptor;
        for (int itMd = 0; itMd < aSrvDescriptor.metricsDescriptorsFiles.length ; itMd++) {
            metricsDescriptorsFile = aSrvDescriptor.metricsDescriptorsFiles[itMd];
            SDLevelParameters = aSrvDescriptor.SDLevelParameters[itMd];
            
            try {
            aMetricDescriptor = config.loadMetricdescriptor(metricsDescriptorsFile, SDLevelParameters, aMonitoredSRV);
            }
            catch (Exception e) {
                Asemon_logger.printmess("ERROR Loading descriptor '"+metricsDescriptorsFile+"'. Err="+e.getMessage() );
                continue;
            }
            
            if (aMetricDescriptor == null)
                continue;                 // this collector has no descriptor for this version. Skip it


            Collector aCollector=null;
            if ( (aMetricDescriptor.metricType).equals("GENERIC") ) {
                CollectorGeneric cg = new CollectorGeneric (aMonitoredSRV, aMetricDescriptor);
                aCollector = cg;
            }
            else {
              // This is a hard coded metric
              if ( (aMetricDescriptor.metricName).equals("MonSQL") ) {
                  CollectorMonSQL monSQL = new CollectorMonSQL (aMonitoredSRV, aMetricDescriptor);
                  aCollector = monSQL;
              }

              if ( (aMetricDescriptor.metricName).equals("MonConf") ) {
                  CollectorMonConf monConf = new CollectorMonConf (aMonitoredSRV, aMetricDescriptor);
                  aCollector = monConf;
              }

              if ( (aMetricDescriptor.metricName).equals("Cnx") ) {
                  CollectorCnx asecnx = new CollectorCnx (aMonitoredSRV, aMetricDescriptor);
                  aCollector = asecnx;
              }

              if ( (aMetricDescriptor.metricName).equals("BlockedP") ) {
                  CollectorBlockedP blockedP = new CollectorBlockedP (aMonitoredSRV, aMetricDescriptor);
                  aCollector = blockedP;
              }

              if ( (aMetricDescriptor.metricName).equals("RaActiv") ) {
                  CollectorRaActiv raCounters = new CollectorRaActiv (aMonitoredSRV, aMetricDescriptor);
                  aCollector = raCounters;
              }

              if ( (aMetricDescriptor.metricName).equals("RAOSTATS") ) {
                  CollectorRaoStats raoCounters = new CollectorRaoStats (aMonitoredSRV, aMetricDescriptor);
                  aCollector = raoCounters;
              }

              if ( (aMetricDescriptor.metricName).equals("LockWaits") ) {
                  CollectorLockWaits lockWaits = new CollectorLockWaits (aMonitoredSRV, aMetricDescriptor);
                  aCollector = lockWaits;
              }

              if ( (aMetricDescriptor.metricName).equals("IQStatus") ) {
                  CollectorIQStatus IQStatus = new CollectorIQStatus (aMonitoredSRV, aMetricDescriptor);
                  aCollector = IQStatus;
              }

              if ( (aMetricDescriptor.metricName).equals("IQSysmon") ) {
                  CollectorIQSysmon IQSysmon = new CollectorIQSysmon (aMonitoredSRV, aMetricDescriptor);
                  aCollector = IQSysmon;
              }

              if ( (aMetricDescriptor.metricName).equals("RSStats") ) {
                  CollectorRSStats RSStats = new CollectorRSStats (aMonitoredSRV, aMetricDescriptor);
                  aCollector = RSStats;
              }

              if ( (aMetricDescriptor.metricName).equals("CachedSQL") ) {
                  CollectorCachedSQL CachedSQL = new CollectorCachedSQL (aMonitoredSRV, aMetricDescriptor);
                  aCollector = CachedSQL;
              }

              if ( (aMetricDescriptor.metricName).equals("CachedXML") ) {
                  CollectorCachedXML CachedXML = new CollectorCachedXML (aMonitoredSRV, aMetricDescriptor);
                  aCollector = CachedXML;
              }

              if ( (aMetricDescriptor.metricName).equals("AmStats") ) {
                  CollectorAmStats AmStats = new CollectorAmStats (aMonitoredSRV, aMetricDescriptor);
                  aCollector = AmStats;
              }
              if (aCollector == null) {
                  Asemon_logger.printmess("ERROR : bad metric name : "+aMetricDescriptor.metricName);
                  continue;
              }
            }

            aMonitoredSRV.collectors.put(aMetricDescriptor.metricName, aCollector);      // Add this collector to the list

            // save collector's file name and parameters in collector itself
            aCollector.metricsDescriptorsFile = metricsDescriptorsFile;
            aCollector.SDLevelParameters = SDLevelParameters;
            
            // Start this metric even if mandatory configs are not satisfied (may be satisfied later if dynamically activated)
            aCollector.start();
            
        }  // end loop on all collectors of this monitored server
        // Start purge thread for this monitored server
        new PurgeThread(aMonitoredSRV).start();
    }  // end loop on all monitored servers
    

    if (admin_port > 0)
        // Start listener
        SrvClass.startSrv();

  }

}

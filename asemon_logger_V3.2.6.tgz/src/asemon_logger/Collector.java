/**
* <p>Collector</p>
* <p>Asemon_logger :  parent class for any collector </p>
* <p>Copyright: Jean-Paul Martin (jpmartin@sybase.com) Copyright (c) 2010</p>
* @version 3.1.6b
*/
package asemon_logger;
import java.util.*;
import java.sql.*;

/**
 *
 * @author jpmartin
 */
public class Collector  extends Thread {
    final MonitoredSRV msrv;                  // monitored server this thread is associated with
    String metricsDescriptorsFile;            // XML file containing configuration of this collector
    Properties SDLevelParameters;             // Parameters of a MD defined at the config file level (rather than default params in the MD XML file)
    MetricDescriptor metricDescriptor;

    Connection previousMonSrvConn;            // previous JConnect connection

    int delay;                              // collection interval (delay between two collections)

    Hashtable <String, Hashtable<String, ArchiveColumnDesc>> hashArchTableColList = null; // for each arch table used by this collector, store list of columns of archive table
    boolean SaveIntervalCol = false;       // If true, save the Interval col in CollectorGeneric (implemented to improve SysMon collector)


    // Monitoring variables for this collector
    long startCollectTS;        // asemon_logger collection start time
    long endCollectTS;          // asemon_logger collection end time
    long timeSrv;               // ASE server time of event
    long monCnxWaitTime = 0;
    long monCnxActiveTime = 0;
    long archCnxWaitTime = 0;
    long archCnxActiveTime = 0;
    int archRows;                          // Number of rows archived during one collect. -1 if no collection of data because error or needed ASE config param not set

    int nbCollections = 0;
    long avgMonCnxWaitTime = 0;
    long avgMonCnxActiveTime = 0;
    long avgArchCnxWaitTime = 0;
    long avgArchCnxActiveTime = 0;
    int totArchRows = 0;

    Collector (MonitoredSRV ms, MetricDescriptor aMetricDescriptor) {
        super(ms.name+"_"+aMetricDescriptor.metricName);
        msrv = ms;
        metricDescriptor = aMetricDescriptor;
        // default delay if descriptor is not yet initialized
        delay = 60;
    }

    void computeStatsCollection(){

        endCollectTS = System.currentTimeMillis();
        monCnxActiveTime = endCollectTS - startCollectTS - archCnxWaitTime - archCnxActiveTime;
        Asemon_logger.DEBUG ("End capture. cWait = " + monCnxWaitTime
              + "\tcActive = "  + monCnxActiveTime
              + "\taWait = " + archCnxWaitTime
              + "\taActive = "  + archCnxActiveTime
              );
        timeSrv = endCollectTS + msrv.timeAdjust.value();

        // save statitics in stat's pipe
        msrv.amStats.addStats(endCollectTS,
                      metricDescriptor.metricName,
                      timeSrv ,
                      monCnxWaitTime,
                      monCnxActiveTime,
                      archCnxWaitTime,
                      archCnxActiveTime,
                      archRows,
                      delay);

        nbCollections++;
        avgMonCnxWaitTime = ((avgMonCnxWaitTime*(nbCollections-1))+monCnxWaitTime)/nbCollections;
        avgMonCnxActiveTime = ((avgMonCnxActiveTime*(nbCollections-1))+monCnxActiveTime)/nbCollections;
        avgArchCnxWaitTime = ((avgArchCnxWaitTime*(nbCollections-1))+archCnxWaitTime)/nbCollections;
        avgArchCnxActiveTime = ((avgArchCnxActiveTime*(nbCollections-1))+archCnxActiveTime)/nbCollections;
        totArchRows += archRows;          // Cumulate rows archived since start

    }


    void addPurgeDescriptors () {
        // Add the correponding purge descriptors, if any, to the global list of purge descriptors

        // Initialize list if not yet initialized
        if (msrv.activePurgeDescs==null) msrv.activePurgeDescs = new Hashtable<String, MetricDescriptor.PurgeDescriptor>();

        MetricDescriptor.PurgeDescriptor aPurgeDesc=null;
        MetricDescriptor.PurgeDescriptor aActivePurgeDesc=null;
        if (metricDescriptor.purgeDescriptors != null) {
            for (Iterator itPurgeDesc=metricDescriptor.purgeDescriptors.iterator(); itPurgeDesc.hasNext();) {
                aPurgeDesc=(MetricDescriptor.PurgeDescriptor)itPurgeDesc.next();
                // set tne normalised name of the monitored server in the active desc
                aPurgeDesc.srvNormalized = msrv.srvNormalized;

                // Compute table name
                StringBuffer purgeTableName = new StringBuffer(aPurgeDesc.tableName);
                int start = purgeTableName.indexOf("?SERVERNAME?");
                if (start != -1) 
                      purgeTableName.replace(start,start+"?SERVERNAME?".length(), aPurgeDesc.srvNormalized);
                aPurgeDesc.trueTableName = purgeTableName.toString();


                // Check if this table is already in the list
                if (msrv.activePurgeDescs.get(aPurgeDesc.trueTableName) != null)
                    // yes, skip it
                    continue;

                // clone this purge desc to make it specific to the current monitored server
                try {
                    aActivePurgeDesc = (MetricDescriptor.PurgeDescriptor)aPurgeDesc.clone();
                } catch (Exception e){}
                if (aActivePurgeDesc != null) {

                    // set the number of days to keep during purge for this server
                    // First, check if this metric desc has a specif value defined in the config file
                    String daysToKeepStr=metricDescriptor.parameters.getProperty("daysToKeep");
                    int daysToKeep=-1;
                    if ( daysToKeepStr != null) {
                        try {
                            daysToKeep=Integer.parseInt(daysToKeepStr);
                        }
                        catch (NumberFormatException e) {
                             Asemon_logger.printmess ("ERROR - Parse XML Config file : invalid number for 'daysToKeep' for server '"+
                                     msrv.name+"', Metric : '"+ metricDescriptor.metricName +"'. Default used.");
                        }
                    }
                    if (daysToKeep >-1) 
                        aActivePurgeDesc.daysToKeep=daysToKeep;
                    else
                        aActivePurgeDesc.daysToKeep = msrv.daysToKeep;


                    // set the deletesleep during purge for this server
                    // First, check if this metric desc has a specif value defined in the config file
                    String deleteSleepStr=metricDescriptor.parameters.getProperty("deleteSleep");
                    int deleteSleep=-1;
                    if ( deleteSleepStr != null) {
                        try {
                            deleteSleep=Integer.parseInt(deleteSleepStr);
                        }
                        catch (NumberFormatException e) {
                             Asemon_logger.printmess ("ERROR - Parse XML Config file : invalid number for 'deleteSleep' for server '"+
                                     msrv.name+"', Metric : '"+ metricDescriptor.metricName +"'. Default used.");
                        }
                    }
                    if (deleteSleep >-1) 
                        aActivePurgeDesc.deleteSleep=deleteSleep;
                    else
                        aActivePurgeDesc.deleteSleep = msrv.deleteSleep;

                    // set the batchsize during purge for this server
                    // First, check if this metric desc has a specif value defined in the config file
                    String batchsizeStr=metricDescriptor.parameters.getProperty("batchsize");
                    int batchsize=1000;
                    if ( batchsizeStr != null) {
                        try {
                            batchsize=Integer.parseInt(batchsizeStr);
                        }
                        catch (NumberFormatException e) {
                             Asemon_logger.printmess ("ERROR - Parse XML Config file : invalid number for 'batchsize' for server '"+
                                     msrv.name+"', Metric : '"+ metricDescriptor.metricName +"'. Default used.");
                        }
                    }
                    if (batchsize < 0)
                        // Restore default value
                        aActivePurgeDesc.batchsize = msrv.batchsize;
                    else
                        aActivePurgeDesc.batchsize=batchsize;
                    if (Asemon_logger.archive_type.equalsIgnoreCase("IQ") && (aActivePurgeDesc.batchsize == 1000)) {
                        aActivePurgeDesc.batchsize = 100000000;
                    }
                }

                // add this active purge desc to the list of active puge desc
                msrv.activePurgeDescs.put(aActivePurgeDesc.trueTableName, aActivePurgeDesc);
            } // end loop on purgeDescriptors attached to this collector        
        }
    }

  
  
  void initialize() throws Exception
  {
      
      // Reload the metric descriptor (in case it was not loaded at startup of asemon 
      
      metricDescriptor = Asemon_logger.config.loadMetricdescriptor(metricsDescriptorsFile, SDLevelParameters, msrv);
      if (metricDescriptor ==  null) {
          Exception e = new Exception("Initialize - Metric descriptor file '"+metricsDescriptorsFile+ "' not found");
          throw e;
      }
      
      // Add purge descriptors to the list if not already in
      if (msrv.purgeArchive == true) {
          addPurgeDescriptors();
      }
      
      delay = metricDescriptor.delay;
      // Retrieve option "delay" if it has been specified in the server config file
      String paramValue = metricDescriptor.parameters.getProperty("delay");
      if (paramValue != null) {
          try {
              delay = Integer.parseInt(paramValue);
          }
          catch (Exception e) {
              Asemon_logger.printmess ("ERROR Collector : Bad 'delay'. Will use default");
          }
          if (delay <0) {
              Asemon_logger.printmess ("ERROR Collector : 'delay' cannot be <0. Will use default");
          }
      }

      // Get an archive connection from the pool
      CnxMgr.ArchCnx aArchCnx = CnxMgr.archCnxPool.getArchCnx(false);
      archCnxWaitTime += aArchCnx.waitedFor;
      try {
          // in any case ...
          aArchCnx.archive_conn.setAutoCommit(true);
          Hashtable <String, ArchiveColumnDesc> confTabColList; // Used to retreive col names and col description of a archive table
          // Create tables used by this collector if necessary
          Hashtable<String,MetricDescriptor.Archive_table> artbls = MetricDescriptor.getArchiveTables(metricDescriptor);
          if ( artbls != null) {
              Statement stmt = aArchCnx.archive_conn.createStatement();
              String configTabName;   // Name of table in descriptor file
              String archiveTabName;  // Name of table in archive database (prefixed with server name)
              MetricDescriptor.Archive_table aArchive_table;
              Iterator itArTables = artbls.keySet().iterator();
              while (itArTables.hasNext()) {
                  configTabName = (String)itArTables.next();
                  // Get the Archive_table structure
                  aArchive_table = artbls.get(configTabName);

                  // Compute the create table string
                  StringBuffer ct = new StringBuffer (aArchive_table.createTable);
                  int start = ct.indexOf("?SERVERNAME?");
                  ct.replace(start,start+"?SERVERNAME?".length(),msrv.srvNormalized);
                  // Don't check if the table already exists. If exists, it generates an error and ignore it

                  // Compute full name of archive table
                  archiveTabName = msrv.srvNormalized+"_"+configTabName;
                  // Save this name in Archive_table structure
                  aArchive_table.archiveTabName = archiveTabName;

                  // Create table in archive database (skip error if already exists)
                  Asemon_logger.archive_class.createArchiveTable(ct, stmt);

                  // Check if GranteeList is null
                  if ((Asemon_logger.archive_granteeList != null)&&(!Asemon_logger.archive_granteeList.equals(""))) {                          
                      Asemon_logger.archive_class.grantRightsOnArchiveTable(archiveTabName, Asemon_logger.archive_granteeList, stmt);
                  }

                  confTabColList = Asemon_logger.archive_class.checkAndAlterArchiveTable(aArchive_table.createTable,configTabName,archiveTabName, stmt, this);
                  if ( hashArchTableColList==null) hashArchTableColList = new Hashtable<String, Hashtable<String,ArchiveColumnDesc>> ();
                  // Save list of columns in the collector descriptor (associated with the table name)
                  hashArchTableColList.put(configTabName, confTabColList);
                  // check if there is a "Interval" col in table
                  if (confTabColList.containsKey("Interval"))
                      SaveIntervalCol = true;
              }

              stmt.close();
          }

          // Create indexes used by this collector if necessary
          StringBuffer[] aridx = MetricDescriptor.getCreateIndexes(metricDescriptor);
          if (aridx != null) {
              Statement stmt = aArchCnx.archive_conn.createStatement();
              for (int i=0; i < aridx.length; i++) {
                  // Compute the create index string
                  StringBuffer ci = new StringBuffer(aridx[i]);
                  int start;
                  boolean found_SERVERNAME = false;
                  while (true) {
                      start = ci.indexOf("?SERVERNAME?");
                      if (start==-1) break;
                      ci.replace(start,start+"?SERVERNAME?".length(),msrv.srvNormalized);
                      found_SERVERNAME = true;
                  }
                  if (found_SERVERNAME)
                      Asemon_logger.archive_class.createIndex(ci.toString(), stmt);
                                    
              }
              stmt.close();
          }
      }
      catch (Exception e) {
          throw e;
      }
      finally {
          // Return archive connection to the pool
          archCnxActiveTime +=  CnxMgr.archCnxPool.putArchCnx(aArchCnx);
      }



  }


    public void getMetrics () throws Exception {

    }

  public void run() {
      Boolean initialized = false;         // Flag used to say if collector has been initialized
      Asemon_logger.printmess ("Start thread.");
      boolean skipCnxCheck=false;

      //loop, wait each time on the tempo of this collector
      while (true) {

          // Reset asemon monitor's counters
          monCnxWaitTime =0;
          monCnxActiveTime = 0;
          archCnxWaitTime = 0;
          archCnxActiveTime = 0;
          startCollectTS = System.currentTimeMillis();

//          synchronized(Asemon_logger.lock_archive_conn) {

          if (metricDescriptor.metricName.equalsIgnoreCase("AmStats")) {
              // Special case for AmStats collector (collect asemon statistics for this monitored server. Don't need a connection to the monitored server)
              skipCnxCheck=true;
          }

          // synchronize on monitored server objet, even for AmStats (avoid warning if not enougth archive connections)
          synchronized(msrv) {
              monCnxWaitTime = System.currentTimeMillis() - startCollectTS;
              Asemon_logger.DEBUG ("Start. mWait = " + monCnxWaitTime);
              startCollectTS = System.currentTimeMillis();
              try {

                  if (!skipCnxCheck) {
                      // Check connection to monitored server
                      if ((msrv.monSrvConn==null) || msrv.monSrvConn.isClosed())
                          // Not open try reopen it, and wait until the connection is open
                          if (msrv.opencnx(false, false)) {
                              // now, it's reopen, set flag for reinitialzation
                              initialized = false;
                          }
                          else {
                              msrv.monSrvConn = null;
                              //Asemon_logger.printmess("Stopping this thread");
                              //return;
                          }

                      // Check if connection is the same as before (the connection may have been reopen by another thread)
                      if ( (msrv.monSrvConn!=null) && (msrv.monSrvConn != previousMonSrvConn) ) {
                          // No, set flag for reinitialzation
                          initialized = false;
                      }
                      previousMonSrvConn = msrv.monSrvConn; // Save current connection (for checking during the next loop)
                  }
                  if (! initialized && ((msrv.monSrvConn!=null) || skipCnxCheck)) {
                      // this module is not initialized and the monitored connection is open
                      try {
                              this.initialize();
                              initialized = true;  // Set flag
                      }
                      catch (SQLWarning sqlw) {
                              Asemon_logger.printmess ("initialize : "  + sqlw);
                      }
                      catch (SQLException sqle) {
                              Asemon_logger.printmess ("initialize : "  + sqle);
                      }
                      catch (Exception e) {
                              Asemon_logger.printmess ("initialize : "  + e);
                              e.printStackTrace(System.out);
                              return;
                      }
                  }

                  if( (msrv.monSrvConn!=null) && (initialized) ) {
                      Asemon_logger.DEBUG ("Begin capture.");
                      skipCnxCheck=false; // Reset this flag for next loop
                      this.getMetrics();
                  }

              }


              catch (AsemonSQLException asemonEx) {
                  Asemon_logger.printmess("Error in loop on table '" + asemonEx.getTableName() +"' on connection : '"+asemonEx.getCnxType()+ "'. Error="+asemonEx.getErrorCode()+" state="+asemonEx.getSQLState()+". SQL message=" + asemonEx.getMessage() );
                  if ( ! (  (asemonEx.getSQLState().equals("JZ0C0")) || (asemonEx.getSQLState().equals("JZ006")) )) {
                      asemonEx.printStackTrace(System.out);
                      initialized = false; // This module will be reinitialize in the next loop
                  }
              }
              catch (SQLException sqlEx) {
                  String state1 = sqlEx.getSQLState();
                  String state2 = "";
                  SQLException sqlEx2 = sqlEx.getNextException();
                  if (sqlEx2 != null)
                      state2= sqlEx2.getSQLState();
                  switch (sqlEx.getErrorCode()) {
                      case 12036 :
                          Asemon_logger.printmess("Error in loop. Error="+sqlEx.getErrorCode()+" state="+sqlEx.getSQLState()+" SQL message="+sqlEx.getMessage());
                          Asemon_logger.DEBUG("Missing mandatory config. Don't exit this thread");
                          break;
                      case 936 :
                          //The model database is unavailable. It is being used to create a new database
                          Asemon_logger.printmess("Error in loop. Error="+sqlEx.getErrorCode()+" state="+sqlEx.getSQLState()+" SQL message="+sqlEx.getMessage());
                          break;
                      case 937 :
                          // Database unavailable. It is undergoing a load database.
                          // Ignore this error
                          break;
                      case 968 :
                          // Database is not upgraded and hence is not available for access.
                          break;
                      case 8233 :
                          // An alter table or reorg operation is in progress on the object...
                          // Ignore this error
                          break;
                      default :
                          Asemon_logger.printmess("Error in loop. Error="+sqlEx.getErrorCode()+" state="+sqlEx.getSQLState()+" SQL message="+sqlEx.getMessage());
                  }
                  if (state1 != null) {
                      if (state1.equals("JZ006")) {
                          if (state2.equals("JZ0C1")) {
                              // This is a closed connection error
                              Asemon_logger.printmess("Connection closed");
                              initialized = false;
                          }
                          if (state2.equals("JZ0TO")) {
                              // This is a network timeout error. Don't close or consider the connection is closed
                              Asemon_logger.printmess("Network timed out. Will retry...");
                              skipCnxCheck=true;
                          }
                              
                      }
                      else {
                        if ( ! (  (state1.equals("JZ0C0")) || (state1.equals("JZ006")) || (state1.equals("ZZZZZ")))) {
                          sqlEx.printStackTrace(System.out);
                          initialized = false;
                          skipCnxCheck=false;
                        }
                      }
                  }
              }
              catch (Exception e) {
                Asemon_logger.printmess("Error in loop. "+e);
                e.printStackTrace(System.out);
                initialized = false;
              }
              finally {
              }


              computeStatsCollection();




              
              
              
          } // End synchronized block

          try {
            java.lang.Thread.sleep(delay*1000);
          }
          catch (Exception e) {}

      }  // End loop on tempo

  }
}

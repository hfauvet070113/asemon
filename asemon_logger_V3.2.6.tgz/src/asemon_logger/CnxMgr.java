/*
 * CnxMgr.java
 *
 * Created on 12 septembre 2007, 10:58
 *
 * <p>CnxMgr</p>
 * <p>class managing connections</p>
 * <p>Copyright: Jean-Paul Martin (jpmartin@sybase.com) Copyright (c) 2007</p>
 * @version 3.2.6
 */

package asemon_logger;
import static asemon_logger.Asemon_logger.*;
import java.sql.*;
import java.util.*;
import java.util.concurrent.Semaphore;


public class CnxMgr {

    // Pool of archive connections;
    static ArchCnxPool archCnxPool;

    /** Creates a new instance of CnxMgr */
    public CnxMgr() {
        archCnxPool = new ArchCnxPool();
    }
    



    /*
     * ArchCnx : class usedConnections to manage a connection to the archive server (only ASE supported for archive conn)
     *
     */
    class ArchCnx {
        // Connection handle to the archive server
        Connection archive_conn=null;
//        boolean first_time;  // True if this is the first time the connection is used
        long waitedFor;  // Time in ms spent waiting for a free cnx from the pool
        long startUse;   // System time when this cnx started to be used (include connexion establishment, if not yet connected)
        boolean isConnected; // True if the JDBC connection is open

        ArchCnx() {
            isConnected =false;
        }
        
        boolean setBulkLoad () {
            if (isConnected) {
                if (!Asemon_logger.disableBulkLoad) {
                    DEBUG (DBG110,"setBulkLoad on "+this);
                    try {
                        archive_conn.setClientInfo("ENABLE_BULK_LOAD", "ARRAYINSERT_WITH_MIXED_STATEMENTS");
                    }
                    catch (SQLClientInfoException ex) {
                        DEBUG (DBG110,"setBulkLoad ENABLE_BULK_LOAD : "+ex.getFailedProperties());
                        return false;
                    }
                    try {
                        archive_conn.setClientInfo("RTRIM_FOR_ENABLE_BULK_LOAD", "TRUE"); // Fix introduced in CR744035
                    }
                    catch (SQLClientInfoException ex) {
                        DEBUG (DBG110,"setBulkLoad RTRIM_FOR_ENABLE_BULK_LOAD : "+ex.getFailedProperties());
                        return false;
                    }
                }
            }
            return true;
        }

        boolean unsetBulkLoad () {
            if (isConnected) {
                try {
                    DEBUG (DBG110,"unsetBulkLoad on "+this);
                    archive_conn.setClientInfo("ENABLE_BULK_LOAD", "FALSE");
                }
                catch (SQLClientInfoException ex) {
                    ERROR("unsetBulkLoad : "+ex.getErrorCode()+" "+ex.getMessage());
                    return false;
                }
            }
            return true;
        }

    }

    /*
     * ArchCnxPool : class for managing pool of ArchCnx connections
     *  (size is currently hardcoded to 5)
     */

    class ArchCnxPool {
       private final int MAX_AVAILABLE = Asemon_logger.archive_poolsize;
       private final Semaphore available = new Semaphore(MAX_AVAILABLE, true);
       protected ArchCnx[] archConnections = new ArchCnx[MAX_AVAILABLE];
       protected boolean[] usedConnections = new boolean[MAX_AVAILABLE];

       public ArchCnxPool () {
           // Initialize arch conn descriptors
           for (int i=0; i<MAX_AVAILABLE; i++)
               archConnections[i] = new ArchCnx();
       }

       public ArchCnx getArchCnx(boolean waitFlag) throws Exception {
           ArchCnx aArchCnx;
           long startWait = System.currentTimeMillis();
           // Get a connection from the pool
           available.acquire();
           aArchCnx=getNextAvailableItem();

           aArchCnx.startUse = System.currentTimeMillis();
           long waitedForArchCnx =  aArchCnx.startUse - startWait;
           DEBUG(DBG108, "get archnx : "+aArchCnx+" Time wait :" +waitedForArchCnx+"ms");
           aArchCnx.waitedFor = waitedForArchCnx;
           if (waitedForArchCnx > 10000)
               Asemon_logger.printmess  ("getArchCnx : waited more than 10 s for a free cnx. Increase pool size.");
           // Open this connection if not already open
           if ((aArchCnx.archive_conn == null ) || (aArchCnx.archive_conn.isClosed() ) )
               aArchCnx.isConnected = Asemon_logger.archive_class.connect_archive_SRV(aArchCnx, waitFlag);
           //aArchCnx.first_time = false;
           return aArchCnx;
       }

       public long putArchCnx(ArchCnx aArchCnx) {
           try {
               aArchCnx.archive_conn.commit(); // Force commit before returning the connection
           }
           catch (SQLException sqle) {
               ERROR ("Error on commit before returning connection to pool : "+sqle.getErrorCode()+" "+sqle.getMessage());
               try {
                   aArchCnx.archive_conn.close();
               } catch (Exception e) {}
           }
           long timeUsed = System.currentTimeMillis() - aArchCnx.startUse;
           DEBUG(DBG108, "put archnx : "+aArchCnx+" Time used :" +timeUsed+"ms");
           if (markAsUnused(aArchCnx))
               available.release();

           return timeUsed;
       }


       protected synchronized ArchCnx getNextAvailableItem() {
         for (int i = 0; i < MAX_AVAILABLE; ++i) {
           if (!usedConnections[i]) {
              usedConnections[i] = true;
              DEBUG(DBG108, "Get archive conn "+ i);
              return archConnections[i];
           }
         }
         return null; // not reached
       }

       protected synchronized boolean markAsUnused(ArchCnx item) {
         for (int i = 0; i < MAX_AVAILABLE; ++i) {
           if (item == archConnections[i]) {
              if (usedConnections[i]) {
                usedConnections[i] = false;
                DEBUG(DBG108, "Free archive conn "+i);
                return true;
              } else
                return false;
           }
         }
         return false;
       }

    }

    static String checkPasswd (String servername, String username, String question, boolean verbose)
    {
        String pw;
        // Check if password exists in passwords file
        pw=Asemon_logger.pfm.getPassword(servername, username);
        if (pw==null) {
            // not found in passwords file, ask to user
            System.out.print (question);
            pw=Password.getPassword();
            // save this password in passwords file
            Asemon_logger.pfm.addPassword(servername, username, pw);
            Asemon_logger.printmess ("Password added in passwords file for '" +servername+"."+username+"'");
        }
	else
            if (verbose) Asemon_logger.printmess ("Using password from passwords file for '" +servername+"."+username+"'");
        return pw;

   }

    static Connection connectSRV(String user, String srv, String db, String charset, String question, boolean verbose, String appName, Boolean useKerberos, Boolean displayErrors, int packet_size, Boolean useSSL, String address, String srvType, String aseUserStoreKey) {
        Connection cnx=null;
        String passwd=null;
        String port=null;
        String host=null;

        if (verbose) Asemon_logger.printmess ("Try to connect to srv : "+srv);

        SybSrvAddress sAdd = null;
        
        if (aseUserStoreKey != null) {
            // server (host, port), user and password are retreived from aseUserStore
            
            if (System.getProperty("java.version").compareTo("1.8") < 0) {
                Asemon_logger.printmess  ("aseUserStoreKey cannot be used : Java version should be at leat V1.8.");
                System.exit(1);
            }
                    
            if (user != null)
                if (verbose) Asemon_logger.printmess  ("aseUserStoreKey and user are defined in config file. User will be ignored");
            if (useKerberos)
                if (verbose) Asemon_logger.printmess  ("aseUserStoreKey and useKerberos are defined in config file. useKerberos will be ignored");
            if (address != null)
                if (verbose) Asemon_logger.printmess  ("aseUserStoreKey and address are defined in config file. address will be ignored");
            
            if (verbose) Asemon_logger.printmess ("Using key : "+aseUserStoreKey+" in AseUserStore for connection");
        }
        else {
            if (address!=null && ! address.isEmpty()) {
                String delims = "[:]";
                String[] tokens = address.split(delims);
                if ( tokens.length==2 ) {
                    host=tokens[0];
                    port=tokens[1];
                }
            }
            if ( host == null && port==null ) {
                sAdd = SybDirectory.getServerAddress(srv);
                if (sAdd ==null) {
                    Asemon_logger.printmess  ("connectSRV : ERROR Server "+srv+" does not exists in interfaces or SQL.INI file");
                    return null;
                }
                if (verbose) Asemon_logger.printmess ("Srv found in interfaces or SQL.INI file. Host="+sAdd.host +" Port="+sAdd.port);
            } else {
                sAdd = new SybSrvAddress(srv);
                sAdd.host = host;
                sAdd.port = port;
                if (verbose) Asemon_logger.printmess ("Use address found in config Host="+sAdd.host +" Port="+sAdd.port);
            }

            if (! useKerberos)
                passwd = CnxMgr.checkPasswd (srv, user, question , verbose);
        }
        try {
            Class.forName("com.sybase.jdbc42.jdbc.SybDriver").newInstance();

            Properties props = new Properties();


            if (aseUserStoreKey != null)
                props.put("SECURE_STORE_KEY", aseUserStoreKey);
            else {
                if (! useKerberos) {
                    props.put("user", user);
                    props.put("password", passwd);
                } 
                else {
                    if (verbose) Asemon_logger.printmess ("Kerberos is activated");
                }
            }

            if (appName != null) props.put("APPLICATIONNAME", appName);

    //        props.put("JCONNECT_VERSION","6");
    //        props.put("JCONNECT_VERSION","6.05");
            props.put("JCONNECT_VERSION","7.0");

            props.put("LANGUAGE","english");

            if (packet_size > 0)
                props.put("PACKETSIZE",String.valueOf(packet_size));

            if (useSSL) {
                if (verbose) Asemon_logger.printmess ("SSL is activated");
                props.put("ENABLE_SSL","TRUE");
            }


            props.put("USE_METADATA","FALSE");
            props.put("DYNAMIC_PREPARE","FALSE");

    // Removed the next setting since it WAS incompatible with ENABLE_BULK_LOAD. Bug fixed in jConnect
            props.put("ESCAPE_PROCESSING_DEFAULT","FALSE");

            props.put("IS_CLOSED_TEST","INTERNAL");
    //        props.put("IS_CLOSED_TEST","select 1");

            if ( (!Asemon_logger.disableBulkLoad) && (srvType.equalsIgnoreCase("ASE")) ) {
    //            props.put("ENABLE_BULK_LOAD","TRUE");
                props.put("ENABLE_BULK_LOAD","ARRAYINSERT_WITH_MIXED_STATEMENTS");
    //            props.put("ENABLE_BULK_LOAD","ARRAYINSERT");
                props.put("RTRIM_FOR_ENABLE_BULK_LOAD", "TRUE"); // Fix introduced in CR744035
            }
            else {
                props.put("ENABLE_BULK_LOAD","FALSE");
            }


            props.put("EARLY_BATCH_READ_THRESHOLD", 1000);

            if ((!useKerberos) && (!Asemon_logger.disableENCPASS)) {
                props.put("ENCRYPT_PASSWORD","TRUE");

                // don't need next property if Certicom jars are in same dir as Jconn3.jar
                //props.put("JCE_PROVIDER_CLASS","com.certicom.ecc.jcae.Certicom");
            }

            props.put("CONNECTION_FAILOVER", "TRUE"); // Used by JNDI
                                                      // Note : when TRUE, try the next entry in ini or interfaces file
                                                      //        if any connection error including when login/password is incorrect

            if (charset!=null) props.put("CHARSET", charset);

            if ( (aseUserStoreKey == null) && (useKerberos) ) {
                props.put("REQUEST_KERBEROS_SESSION","TRUE");
                props.put("SERVICE_PRINCIPAL_NAME", srv);
                System.setProperty("javax.security.auth.useSubjectCredsOnly", "false");
                System.setProperty("java.security.auth.login.config","jaas.conf");
            }

            // Set the HOSTPROCESS ID
            props.put("HOSTPROC", Long.toString(Asemon_logger.osProcessId));

            if ( aseUserStoreKey != null)
                    cnx = DriverManager.getConnection
                        ("jdbc:sybase:Tds:",  props);
            else {
                if (Asemon_logger.enableJNDI)
                    cnx = DriverManager.getConnection
                        ("jdbc:sybase:jndi:file:"+sAdd.iFile+"?"+srv,  props);
                else
                    cnx = DriverManager.getConnection
                        ("jdbc:sybase:Tds:"+sAdd.host+":"+sAdd.port,  props);
            }



            if ((db != null) && ( db.trim().length() != 0 )) {
                // Force autocommit
                cnx.setAutoCommit(true);
                Statement stmt = cnx.createStatement();
                stmt.executeUpdate("use " + db);
                // Check if connected to the correct db
                ResultSet rs=stmt.executeQuery("select db_name()" );
                rs.next();
                String curr_db = rs.getString(1);
                stmt.close();
                if (!curr_db.equals(db) ) {
                    // database is not correct, close this connection
                    Asemon_logger.printmess ("ERROR connectSRV. Srv="+srv + " : not connected in '" +db + "'");
                    cnx.close();
                    cnx = null;
                }            
            }
        }

        catch (java.sql.SQLException ex){
            if (ex.getSQLState().equals("JZ00L") && displayErrors) {
                // Login failed
                Asemon_logger.printmess ("ERROR connectSRV (1). Srv="+srv
                        + " State= " +ex.getSQLState()
                        + " Err= " +ex.getErrorCode()
                        + " Msg=" + ex.getMessage());
                ex=ex.getNextException();
                if (ex != null)
                    Asemon_logger.printmess ("ERROR connectSRV (2). Srv="+srv
                        + " State= " +ex.getSQLState()
                        + " Err= " +ex.getErrorCode()
                        + " Msg=" + ex.getMessage());

                return null;
            }

            if (( verbose || (
                           (!ex.getSQLState().equals("JZ006"))
                        && (!ex.getSQLState().equals("JZ0C0"))
                        //&& (!ex.getSQLState().equals("JZ00L"))  // login locked
                        )
                    ) && displayErrors)
                    Asemon_logger.printmess ("ERROR connectSRV (1). Srv="+srv + " : " +ex);
            ex=ex.getNextException();
                while (ex!=null)	{
                    if (displayErrors) Asemon_logger.printmess ("ERROR connectSRV (2). Srv="+srv + " : "+ ex);
                ex=ex.getNextException();
                }
                return null;
        }
        catch (Exception e) {
                Asemon_logger.printmess ("ERROR connectSRV (3). Srv="+srv + " : "+e);
                return null;
        }

        return cnx;
   }

  static int getConfigOption(Connection monSrvConn,String opt) {
    int optValue = -1;
    try {
      Statement stmt = monSrvConn.createStatement();
      ResultSet rs=stmt.executeQuery("select b.value from master..sysconfigures a, master..syscurconfigs b where a.config=b.config and upper(a.name) = upper('" +opt + "')" );
      rs.next();
      optValue = rs.getInt(1);
    }
    catch (Exception e) { 
      	Asemon_logger.printmess("ERROR getConfigOption - error : "+e);
        return -1;
    }
    return optValue;
  }




  static boolean connectMonitoredRS (MonitoredSRV msrv, boolean verbose, boolean nowait) {
      Connection monSrvConn=null;
      Statement stmt = null;
      Connection RSSDConn=null;

      boolean displayErrors=true;
      while (monSrvConn == null)  {
          if (msrv.packet_size==0)
              // Packet size not set in config file, force to 2K
              msrv.packet_size = 2048;
          monSrvConn = connectSRV(msrv.user, msrv.name, null,msrv.charset, "For monitored server '"+msrv.name+"', user '"+msrv.user+"' - ", verbose, null, msrv.useKerberos, displayErrors, msrv.packet_size, msrv.useSSL, msrv.address, msrv.sd.type, msrv.aseUserStoreKey);
          if (monSrvConn==null) {
              if (nowait) return false;
              if (displayErrors)
                  Asemon_logger.printmess("Connection  to " +msrv.name +" is closed. Trying to reconnect every 10 s ...");
              try {
                java.lang.Thread.sleep(10000);  // wait 10 s before retrying
                displayErrors = false;
                verbose=false;
              }
              catch (Exception e) {}
          }
      }

      // Get RS version of monitored server
      try {
          stmt = monSrvConn.createStatement();
          ResultSet rs=stmt.executeQuery(
                "admin version");
          rs.next();
          StringBuffer versionStrB = new StringBuffer(rs.getString(1));
          versionStrB = new StringBuffer(versionStrB.substring(versionStrB.indexOf("/")+1,versionStrB.length()));
          String ver = new String(versionStrB.substring(0,versionStrB.indexOf("/")));
          msrv.sbssav = ver;
          ver = ver.replaceAll("\\.", "");
          if (ver.length()>4)
            ver=ver.substring(0,4);
          if (ver.length()==3)
            ver=ver+"0";
          msrv.version = Integer.parseInt(ver);
      }
      catch (Exception e) { 
          e.printStackTrace();
          Asemon_logger.printmess("ERROR connectMonitoredRS : error getting version. "+e);
          try {
              monSrvConn.close();
          }
          catch (Exception ex) {}
      	  return false;
      }

      Asemon_logger.printmess ("connectMonitoredRS - connected to : " +msrv.name + " Version : "+ msrv.version);
      // save connection in the cnx structure
      msrv.monSrvConn = monSrvConn;
      msrv.needRSSDServer = false;

      if (msrv.version > 1500) {
          // Check statistics configuration
          try {
              String configuration, current;
              ResultSet rs=stmt.executeQuery(
                    "admin statistics, 'status'");
              while (rs.next()) {
                  configuration = rs.getString(1);
                  current = rs.getString(3);
                  if ((configuration.compareToIgnoreCase("stats_sampling")==0) && (current.compareToIgnoreCase("OFF")==0) ) {
                      Asemon_logger.printmess("WARNING connectMonitoredRS : stats_sampling = OFF. Not all statistics will be captured.");
                      Asemon_logger.printmess("You should execute \"configure replication server set stats_sampling to 'ON'\" on RS");
                  }
                  if ((configuration.compareToIgnoreCase("stats_show_zero_counters")==0) && (current.compareToIgnoreCase("ON")==0) ) {
                      Asemon_logger.printmess("WARNING connectMonitoredRS : stats_show_zero_counters = ON.");
                  }
                  if ((configuration.compareToIgnoreCase("stats_engineering_counters")==0) && (current.compareToIgnoreCase("ON")==0) ) {
                      Asemon_logger.printmess("WARNING connectMonitoredRS : stats_engineering_counters = ON.");
                  }
              }
              stmt.close();
              getRSSDtime(msrv);
              Asemon_logger.printmess ("Time difference (ms) between RS and asemon_logger (positive when RS is in advance) : " + msrv.timeAdjust.value() );
          }
          catch (Exception e) {
            Asemon_logger.printmess("ERROR connectMonitoredRS : error getting statistics status. "+e);
            try {
                  monSrvConn.close();
            }
            catch (Exception ex) {}
            return false;
          }
          // Check if RSSD info is required and configured
          if (msrv.version<1550) {
              msrv.needRSSDServer = true;
              if ((msrv.RSSDUser == null) || (msrv.RSSDServer == null)){
                Asemon_logger.printmess("ERROR connectMonitoredRS : for RS15 < 15.5, RSSD info should be defined in config file");
                try {
                  monSrvConn.close();
                }
                catch (Exception ex) {}
                return false;
             }
          }
      }


      if (msrv.needRSSDServer) {
          // Connect to the RSSDServer
          RSSDConn = connectSRV(msrv.RSSDUser, msrv.RSSDServer, msrv.RSSDDatabase,msrv.charset, "For RSSD server, ", verbose, null, msrv.useKerberos, true, msrv.packet_size, msrv.useSSL, msrv.address, msrv.sd.type, msrv.aseUserStoreKey);
          if (RSSDConn==null) {
              // Close connection to RS
              try {
                  monSrvConn.close();
              } catch (Exception e) {}
              monSrvConn=null;
              return false;
          }
          // save connection in the cnx structure
          msrv.RSSDConn = RSSDConn;
      }

      return true;
  }  
  
  static boolean connectMonitoredRAO (MonitoredSRV msrv, boolean verbose, boolean nowait) {
      Connection monSrvConn=null;

      boolean displayErrors = true;
      while (monSrvConn == null)  {
          monSrvConn = connectSRV(msrv.user, msrv.name, null,msrv.charset, "For monitored server '"+msrv.name+"', user '"+msrv.user+"' - ", verbose, null, msrv.useKerberos, displayErrors, msrv.packet_size, msrv.useSSL, msrv.address, msrv.sd.type, msrv.aseUserStoreKey);
          if (monSrvConn==null) {
              if (nowait) return false;
              if (displayErrors)
                  Asemon_logger.printmess("Connection  to " +msrv.name +" is closed. Trying to reconnect every 10 s ...");
              try {
                java.lang.Thread.sleep(10000);  // wait 10 s before retrying
                displayErrors = false;
                verbose=false;
              }
              catch (Exception e) {}
          }
      }

      // Get RS version of monitered server
/*
      try {
          stmt = monSrvConn.createStatement();
          ResultSet rs=stmt.executeQuery(
                "admin version");
          rs.next();
          StringBuffer versionStrB = new StringBuffer(rs.getString(1));
          versionStrB = new StringBuffer(versionStrB.substring(versionStrB.indexOf("/")+1,versionStrB.length()));
          versionStrB = new StringBuffer(versionStrB.substring(0,versionStrB.indexOf("/")));
          versionStrB.deleteCharAt(versionStrB.indexOf("."));
          cnx.version = Integer.parseInt(versionStrB.toString());
      }
      catch (Exception e) { 
      	Asemon_logger.printmess("ERROR connectMonitoredRS : error getting version. "+e);
      	return false;
      }
*/
      Asemon_logger.printmess ("connectMonitoredRAO - connected to : " +msrv.name + " Version : "+ msrv.version);
      // save connection in the cnx structure
      msrv.monSrvConn = monSrvConn;
      return true;
  }  
  
  static boolean connectMonitoredIQ (MonitoredSRV msrv, boolean verbose, boolean nowait) {
      Connection monSrvConn=null;
      Statement stmt = null;
      
      boolean displayErrors = true;
      while (monSrvConn == null)  {
          if (msrv.packet_size==0)
              // Packet size not set in config file, force to 2K
              msrv.packet_size = 2048;
          monSrvConn = connectSRV(msrv.user, msrv.name, null,msrv.charset, "For monitored server '"+msrv.name+"', user '"+msrv.user+"' - ", verbose, null, msrv.useKerberos, displayErrors, msrv.packet_size, msrv.useSSL, msrv.address, msrv.sd.type, msrv.aseUserStoreKey);
          if (monSrvConn==null) {
              if (nowait) return false;
              if (displayErrors)
                  Asemon_logger.printmess("Connection  to " +msrv.name +" is closed. Trying to reconnect every 10 s ...");
              try {
                java.lang.Thread.sleep(10000);  // wait 10 s before retrying
                displayErrors = false;
                verbose=false;
              }
              catch (Exception e) {}
          }
      }

      try {
          // Force autocommit
          monSrvConn.setAutoCommit(true);
          stmt = monSrvConn.createStatement();
          ResultSet rs=stmt.executeQuery(
                "select substring("+
                   "substring(@@version,charindex ('/',@@version)+1, datalength(@@version)),"+
                   "1, "+
                   "charindex ('/',substring(@@version,charindex ('/',@@version)+1, datalength(@@version)))-1"+
                ")"
           );
          rs.next();
          msrv.versionStr = rs.getString(1);
          msrv.sbssav = msrv.versionStr;           // sbssav is used to select version descriptors
      }
      catch (Exception e) { 
          e.printStackTrace();
          Asemon_logger.printmess("ERROR connectMonitoredIQ : error getting version. "+e);
          try {
              monSrvConn.close();
          }
          catch (Exception ex) {}
          return false;
      }

      // Force mode "chained=OFF" to avoid versioning
      try {
          stmt = monSrvConn.createStatement();
          stmt.executeUpdate("set temporary option chained='OFF'");
      }
      catch (Exception e) { 
      	Asemon_logger.printmess("ERROR connectMonitoredIQ : error setting CHAINED=OFF. "+e);
        try {
              monSrvConn.close();
        }
        catch (Exception ex) {}
      	return false;
      }


      Asemon_logger.printmess ("connectMonitoredIQ - connected to : " +msrv.name + " Version : "+ msrv.versionStr);
      // save connection in the cnx structure
      msrv.monSrvConn = monSrvConn;
      try {
          ResultSet rs=stmt.executeQuery("select getdate()");
          while (rs.next()) {
              Timestamp ts = rs.getTimestamp(1);
              msrv.timeAdjust.adjustTime(ts);
          }
          Asemon_logger.printmess ("Time difference (ms) between IQ and asemon_logger (positive when IQ is in advance) : " + msrv.timeAdjust.value() );
      }
      catch (Exception e) { 
      	     Asemon_logger.printmess("ERROR connectMonitoredIQ : error getting IQ time. "+e);
      }
      return true;
  }  
  
  
  static boolean connectMonitoredASE (MonitoredSRV msrv, String checkMonitoringConfig, boolean verbose, boolean nowait) {
      Connection monSrvConn=null;
      Statement stmt = null;
      
      boolean displayErrors = true;
      while (monSrvConn == null)  {
          monSrvConn = connectSRV(msrv.user, msrv.name, "tempdb", msrv.charset, "For monitored server '"+msrv.name+"', user '"+msrv.user+"' - ", verbose, "asemon_logger", msrv.useKerberos, displayErrors, msrv.packet_size, msrv.useSSL, msrv.address, msrv.sd.type, msrv.aseUserStoreKey);
          if (monSrvConn==null) {
              if (nowait) return false;
              if (displayErrors)
                  Asemon_logger.printmess("Connection  to " +msrv.name +" is closed. Trying to reconnect every 10 s ...");
              try {
                java.lang.Thread.sleep(10000);  // wait 10 s before retrying
                displayErrors = false;
                verbose=false;
              }
              catch (Exception e) {}
          }
      }

      // Get ASE version of monitored server, and current time
      try {
          stmt = monSrvConn.createStatement();
          
          ResultSet rs=stmt.executeQuery(                                                                        
                "select ts=getdate()" +
                       ", substring(" +
                       "     substring(@@version,charindex('ise/',@@version)+4,datalength(@@version))," +
                       "     1," +                                                                                    
                       "     charindex('/',substring(@@version,charindex('ise/',@@version)+4,datalength(@@version)))-1" +
                       "    )" +
                       ",@@bootcount");                                                                                         
          rs.next();
          Timestamp ts = rs.getTimestamp(1);
          msrv.timeAdjust.adjustTime(ts);
          String s = rs.getString(2);
          msrv.bootcount = rs.getInt(3);     // Get bootcount

          msrv.sbssav = s;                   // compute a sbssav string which never existed before. This variable is overriden for 15.7 servers
                                             // Contains for example : 12.5.0.3, 12.5.3, 12.5.4, 15.0.3, 15.5
          s=s.replaceAll("\\.", "");
          if (s.length()>4)
              s=s.substring(0,4).trim();
          msrv.version = Integer.parseInt(s);
          if (msrv.version == 155)
              // special case for V15.5
              msrv.version= 1550;
          if (msrv.version == 157)
              // special case for V15.7
              msrv.version= 1570;
          if (msrv.version == 160)
              // special case for V16
              msrv.version= 1600;
          if (msrv.version == 161)
              // special case for V161
              msrv.version= 1610;
          
          if (msrv.version >= 1570) {
              // Get new @@sbssav variable containing exact version
              rs=stmt.executeQuery("select @@sbssav");
              rs.next();
              msrv.sbssav = rs.getString(1);
              
              // In case ASE is a Cluster Edition, force system_view to 'instance'
              stmt.executeUpdate("set system_view instance");
              
              // Get instanceID if ASE is cluster edition
              rs=stmt.executeQuery("select isnull(@@instanceid,0)");
              rs.next();
              msrv.instanceid = rs.getInt(1);

          }
          
                   
          // set clientapplname to srvDescriptor : this is usedConnections to distinguish several connection to same ASE for different purposes
          stmt.executeUpdate("set clientapplname " + msrv.srvDescriptor);
          
          
          if (!bypassCheckAlreadyConnected) {
          // Check if asemon_logger is already connected (avoid automatic reconnection which can saturate connections on the server)
          rs=stmt.executeQuery(
                "select isnull(count(*),0) from master..sysprocesses where program_name='asemon_logger' and clientapplname='" + msrv.srvDescriptor +"'");
          rs.next();
          if (rs.getInt(1) > 1){
              Asemon_logger.printmess("ERROR : asemon_logger is already connected. Closing this connection.");
              monSrvConn.close();
              try {
                  // wait before returning. Avoid too many 'already connected' messages
                java.lang.Thread.sleep(60*1000);
              }
              catch (Exception e) {}
              return false;
          }
          }
          
      }
      catch (Exception e) {
          e.printStackTrace();
      	  Asemon_logger.printmess ("ERROR connectMonitoredASE : error getting version. "+e);
          try {
              monSrvConn.close();
          }
          catch (Exception ex) {}
      	return false;
      }

      Asemon_logger.printmess ("connectMonitoredASE - connected to : " +msrv.name + " Version : "+ msrv.sbssav  + " bootcount : "+ msrv.bootcount);
      Asemon_logger.printmess ("Time difference (ms) between ASE and asemon_logger (positive when ASE is in advance) : " + msrv.timeAdjust.value() );
      
      if ((checkMonitoringConfig!=null) && (checkMonitoringConfig.equals("yes"))) {
          // Check if user has "mon_role"
          try {
              stmt = monSrvConn.createStatement();
              ResultSet rs=stmt.executeQuery(
                    "select proc_role('mon_role')");
              rs.next();
              msrv.mon_role = rs.getInt(1);
          }
          catch (Exception e) { 
              Asemon_logger.printmess("ERROR connectMonitoredASE : error getting mon_role. "+e);
                try {
                      monSrvConn.close();
                }
                catch (Exception ex) {}
              return false;
          }
          if (msrv.mon_role == 0) {
              Asemon_logger.printmess ("connectMonitoredASE : 'mon_role' missing for user '"+msrv.user+"'");
                try {
                      monSrvConn.close();
                }
                catch (Exception ex) {}
              return false;
          }

          try {
              // Check if user has "sa_role"
              stmt = monSrvConn.createStatement();
              ResultSet rs=stmt.executeQuery(
                    "select proc_role('sa_role')");
              rs.next();
              msrv.sa_role = rs.getInt(1);

              msrv.asemon_indirect_sa_role =0;
              if (msrv.sa_role == 0) {
                  // Check if user has "asemon_indirect_sa_role"
                  stmt = monSrvConn.createStatement();
                  rs=stmt.executeQuery("sp_asemon_check_sa_role");
                  rs.next();
                  msrv.asemon_indirect_sa_role = rs.getInt(1);
              }
          }
          catch (Exception e) { 
          }

          msrv.maxcharlen = 1;
          try {
              // get maxcharlength
              ResultSet rs=stmt.executeQuery(
                    "select @@maxcharlen");
              rs.next();
              msrv.maxcharlen = rs.getInt(1);
          }
          catch (Exception e) { 
          }

          if (msrv.textsize != 32768) try {
              stmt = monSrvConn.createStatement();
              stmt.executeUpdate("set textsize "+msrv.textsize);
              Asemon_logger.printmess("Set textsize to "+msrv.textsize);
          }
          catch (Exception e) {
              Asemon_logger.printmess("Erreur in setting textsize. Msg : "+e.getMessage());
          }

          // Special actions when user has no sa_role
          if ( (msrv.sa_role == 0 ) && (msrv.asemon_indirect_sa_role == 0)) {
              Asemon_logger.printmess ("WARNING : Login '"+msrv.user+ "' has no sa_role or asemon_indirect_sa_role");
              msrv.disableRAmonitor=true;
          }

          if ( msrv.sa_role == 0 ) {
              // User has no sa_role
              // check if user is defined in all databases

              // Use a temporary table rather than a cursor to avoid maintaining shared locks on rows of sysdatabases table
              try {
                  String instanceidPredicate = "";
                  stmt = monSrvConn.createStatement();
                  Statement stmt2 = monSrvConn.createStatement();
                  String dbname;

                  if (msrv.instanceid > 0)
                      // don't access local temporary db not owned by this instance
                      instanceidPredicate = " and (instanceid=@@instanceid or instanceid is null)";

                  ResultSet rs = stmt.executeQuery(
                        "select name from master..sysdatabases "
                          + "where name != 'sybsecurity' "
                          + "and status&32!=32 /* db created for load */"
                          + "and status&64!=64 /* recovery started */"
                          + "and status&256!=256 /* db suspect */"
                          + "and status&2048!=2048 /* dbo use only */"
                          + "and status&4096!=4096 /* single user */"
                          + "and status2&16!=16 /* db offline */"
                          + "and status2&32!=32 /* db offline until recovery */"
                          + "and status2&512!=512  /* db upgrading */"
                          + "and status3&8!=8  /* db is being shut down */"
                          + "and status3&4096!=4096  /* db has been shut down  */"
                          + "and status3&9192!=8192  /* a drop database is in progress  */" 
                          + instanceidPredicate);
                  while (rs.next()){
                      dbname = rs.getString(1);
                      try {
                          stmt2.executeQuery("select 1 from "+dbname+"..sysobjects where id=1");
                      }
                      catch (SQLException  sqlex) {
                          int err = sqlex.getErrorCode();
                          switch (err) {
                            case 10351 :
                              Asemon_logger.printmess ("WARNING connectMonitoredASE : user '"+msrv.user+"' is not defined in database '"+dbname+"'");
                              break;
                            case 936 :
                              // The Model database is unavailable. It is being used to create a new database
                              break;
                            case 968 :
                              // Database is not upgraded and hence is not available for access.
                              // Ignore this error
                              break;
                            default :
                              throw sqlex;
                          }
                      }
                  }
                  
              }
              catch (SQLException  sqlex) {
                     Asemon_logger.printmess ("ERROR connectMonitoredASE : " +sqlex.getErrorCode() + " "+ sqlex.getMessage());
                        try {
                              monSrvConn.close();
                        }
                        catch (Exception ex) {}
                     return false;
              }
              catch (Exception e) { 
                     Asemon_logger.printmess ("ERROR connectMonitoredASE : error verifying access to all db's. "+e);
                        try {
                              monSrvConn.close();
                        }
                        catch (Exception ex) {}
                     return false;
              }

              if (!Asemon_logger.skipSAProcs) {
                  // Check version of installed asemon procs
                  int current_procs_version;
                  int needed_procs_version;
                  // Check which script should be executed
                  String needed_scriptVersion;
                  String current_procs_scriptVersion;
                  // 12.5.0.3 -> V12503, 
                  // 12.5.3 , 12.5.4 -> V125, 
                  // 15.0.3 , 15.5 -> V15, 
                  // 15.7.0.61 -> V15.7,
                  // 15.7.0.100 -> V15.7SP100, 
                  // 16.xx ->V16
                  if (msrv.sbssav.compareTo("12.5.0.3") == 0 ) {needed_scriptVersion = "V12503"; needed_procs_version=Asemon_logger.asemon_procs_version_V12503;}
                  else if (msrv.sbssav.compareTo("15") < 0 ) {needed_scriptVersion = "V125"; needed_procs_version=Asemon_logger.asemon_procs_version_V125;}
                  else if (msrv.sbssav.compareTo("15.7") < 0 ) {needed_scriptVersion = "V15"; needed_procs_version=Asemon_logger.asemon_procs_version_V15;}
                  else if (msrv.sbssav.compareTo("15.7.0.100") < 0 ) {needed_scriptVersion = "V15.7"; needed_procs_version=Asemon_logger.asemon_procs_version_V157;}
                  else if (msrv.sbssav.compareTo("16") < 0 ) {needed_scriptVersion = "V15.7SP100"; needed_procs_version=Asemon_logger.asemon_procs_version_V157SP100;}
                  else {needed_scriptVersion = "V16"; needed_procs_version=Asemon_logger.asemon_procs_version_V16;}
                  try {
                      ResultSet rs=stmt.executeQuery("sp_asemon_procs_version");
                      rs.next();
                      current_procs_version = rs.getInt(1);
                      current_procs_scriptVersion = rs.getString(2);
                  }
                  catch (SQLException sqlex) {
                      if (sqlex.getErrorCode()==2812) {
                          Asemon_logger.printmess("ERROR : asemon stored procs not installed or not at correct version. Run script 'install_asemon_procs_non_sa_"+needed_scriptVersion+".sql'");
                      }
                      else if (sqlex.getErrorCode()==10330) {
                          Asemon_logger.printmess("ERROR : no exec rigths on asemon stored procs");
                      }
                      else {
                          Asemon_logger.printmess("ERROR checking asemon stored procs : "+sqlex.getErrorCode()+" "+sqlex.getMessage());
                          Asemon_logger.printmess("ERROR : asemon stored procs not installed or not at correct version. Run script 'install_asemon_procs_non_sa_"+needed_scriptVersion+".sql'");
                      }
                      try {
                          monSrvConn.close();
                      }
                      catch (Exception ex) {}
                      try {
                          java.lang.Thread.sleep (60000); // Wait 1 mn before retry
                      }
                      catch (Exception ex) {}
                      return false;
                  }

                  if ( (current_procs_scriptVersion.compareTo(needed_scriptVersion) != 0) ||
                          (current_procs_version!=needed_procs_version)) {
                      Asemon_logger.printmess("ERROR. Reinstall asemon stored procs! Version installed="+current_procs_version+" scriptVersion="+current_procs_scriptVersion+". Run script 'install_asemon_procs_non_sa_"+needed_scriptVersion+".sql'");

                      try {
                          monSrvConn.close();
                      }
                      catch (Exception ex) {}
                      try {
                          java.lang.Thread.sleep (60000); // Wait 1 mn before retry
                      }
                      catch (Exception ex) {}
                      return false;
                  }
                  Asemon_logger.printmess(msrv.user+" has asemon_indirect_sa_role. Will use asemon procs");
              }
          }



          // Check configured options
        if ( getConfigOption(monSrvConn,"enable monitoring") != 1) {
            Asemon_logger.printmess ("WARNING : Option 'enable monitoring' is set to 0");
            /*
            Asemon_logger.printmess ("ERROR : You should configure server option 'enable monitoring' to 1");
            try {
                  monSrvConn.close();
            }
            catch (Exception ex) {}
            return false;
             */
        }    

        if ( getConfigOption(monSrvConn,"max SQL text monitored") <= 0) {
            Asemon_logger.printmess ("WARNING : You should configure server option 'max SQL text monitored' to a value > 0 (ex. 512)");
            msrv.maxSQLtextMonitored = false;
        }

        msrv.sql_batch_capture=true;
        if ( getConfigOption(monSrvConn,"SQL batch capture") != 1) {
            Asemon_logger.printmess ("WARNING : Server option 'SQL batch capture' is not set, not all statistics will be captured");
            msrv.sql_batch_capture=false;
        }    

        if ( getConfigOption(monSrvConn,"object lockwait timing") != 1) {
            Asemon_logger.printmess ("WARNING : Server option 'Object lockwait timing' is not set, not all statistics will be captured");
            msrv.object_lockwait_timing=false;
        }    

        msrv.per_object_stats = true;
        if ( getConfigOption(monSrvConn,"per object statistics active") != 1) {
            Asemon_logger.printmess ("WARNING : Server option 'per object statistics active' is not set, not all statistics will be captured");
            msrv.per_object_stats = false;
        }    


        msrv.statement_stats = true;
        if ( getConfigOption(monSrvConn,"statement statistics active") != 1) {
            Asemon_logger.printmess ("WARNING : Server option 'statement statistics active' is not set, not all statistics will be captured");
            msrv.statement_stats = false;
        }    

        if ( getConfigOption(monSrvConn,"wait event timing") != 1) {
            Asemon_logger.printmess ("WARNING : Option 'wait event timing' is set to 0");
            /*
            Asemon_logger.printmess ("ERROR : You should configure server option 'wait event timing' to 1");
            try {
                  monSrvConn.close();
            }
            catch (Exception ex) {}
            return false;
             */
        }    

        if ( getConfigOption(monSrvConn,"statement pipe active") == 1) {
            msrv.statementPipeActive = true;
        }

        if ( getConfigOption(monSrvConn,"sql text pipe active") == 1) {
            msrv.sqlTextPipeActive = true;
        }

        if ( getConfigOption(monSrvConn,"deadlock pipe active") == 1) {
            msrv.deadlockPipeActive = true;
        }
    }  // end if checkMonitoredConfig
      
    try {
        if (msrv.sa_role != 0)
            stmt.executeUpdate("if object_id('tempdb..spinlocknames') is not null\n" +
                           " exec ('drop table tempdb..spinlocknames')");
    }
    catch (SQLException e) {
        Asemon_logger.printmess ("WARNING : Cannot drop table tempdb..spinlocknames. Err = "+e.getErrorCode()+ "Msg = "+e.getMessage());
    }
      
    // save connection in the cnx structure
    msrv.monSrvConn = monSrvConn;
    return true;
  }
    
  static void getRSSDtime(MonitoredSRV msrv) {
      // Connect to rssd to retreive RS time
      try {
          Statement stmt = msrv.monSrvConn.createStatement();
          try {
              Asemon_logger.DEBUG("CnxMgr - Line 1010, connect to rssd");
              stmt.executeUpdate("connect to rssd");
          }
          catch (SQLException e) {
              if (e.getErrorCode()!=15539) {
                Asemon_logger.printmess("Error="+e.getErrorCode()+" "+e.getMessage());
                e.printStackTrace(System.out);
              }
          }
          ResultSet rs=stmt.executeQuery("select getdate()");
          while (rs.next()) {
              Timestamp ts = rs.getTimestamp(1);
              msrv.timeAdjust.adjustTime(ts);
          }
          try {
              Asemon_logger.DEBUG("CnxMgr - Line 1025, disconnect");
              stmt.executeUpdate("disconnect");
          }
          catch (SQLException e) {
              if (e.getErrorCode()!=15540) {
                Asemon_logger.printmess("Error="+e.getErrorCode()+" "+e.getMessage());
                e.printStackTrace(System.out);
              }
          }
          stmt.close();
      }
      catch (Exception e){
                    e.printStackTrace(System.out);
      }
  }  
    
}
